"""T96-T118: Self-Evolution 3.0 (GOOD FATHER). Real SQLite, real throwaway repositories, real `patch`/`compileall`/subprocess canaries.
Nothing here touches the production tree: patches are applied to temporary mini-repositories or to isolated copies."""
import hashlib
import json
import os
import shutil
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path

from kora.core import identity, policy
from kora.core.db import get_connection, init_db, record_audit
from kora.core.queue import DurableQueue, P3
from kora.services import emergency, governance, ops, rag
from kora.services import self_evolution as se
from kora.services import self_evolution_3 as se3
from kora.services import trust

PATCH_OK = """--- a/kora/services/calc.py
+++ b/kora/services/calc.py
@@ -1,2 +1,3 @@
 def add(a, b):
+    \"\"\"Add two numbers.\"\"\"
     return a + b
"""
PATCH_BREAKS = """--- a/kora/services/calc.py
+++ b/kora/services/calc.py
@@ -1,2 +1,2 @@
 def add(a, b):
-    return a + b
+    return a - b
"""
PATCH_EVIL = """--- a/kora/services/calc.py
+++ b/kora/services/calc.py
@@ -1,2 +1,3 @@
 def add(a, b):
+    exec("import os")
     return a + b
"""


def _db():
    p = os.path.join(tempfile.mkdtemp(prefix="kora-e3-"), "e.db")
    init_db(p)
    return p


def _mini_repo():
    r = Path(tempfile.mkdtemp(prefix="kora-mini-")) / "repo"
    for d in ("kora/tests", "kora/services", "app"):
        (r / d).mkdir(parents=True)
    (r / "app/__init__.py").write_text("")
    (r / "kora/__init__.py").write_text('VERSION = "0.0.test"\n')
    (r / "kora/tests/__init__.py").write_text("")
    (r / "kora/services/__init__.py").write_text("")
    (r / "kora/services/calc.py").write_text("def add(a, b):\n    return a + b\n")
    (r / "kora/tests/run_all.py").write_text(
        "from kora.services.calc import add\nassert add(1, 2) == 3\nassert add(2, 2) == 4\nassert add(0, 0) == 0\nprint('TEST SUITE COMPLETE: 3/3 PASS')\n")
    return r


def _proposal(db, repo, patch, risk="HIGH"):
    pid = governance.create_proposal("MODIFY_CODE", "test proposal", risk, [], ["suite"], "restore snapshot", db)
    d = repo / "data" / "evolution" / "proposals"
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{pid}.patch").write_text(patch)
    se3.record(pid, "capability_check", {"goal": "t", "existing_matches": {}}, db)
    se3.record(pid, "provenance", {"patch_sha256": hashlib.sha256(patch.encode()).hexdigest(), "sources": ["LOCAL_ONLY"]}, db)
    return pid


@contextmanager
def _calm():
    orig = ops.pressure_level
    ops.pressure_level = lambda *a, **k: {"level": "NORMAL", "reasons": [], "unknown": []}
    # Wall-clock ratios of sub-second, 2-decimal-rounded suite timings are noise (0.01s vs 0.02s = "2.00x"): functional tests must not depend on
    # them. The slowdown gate itself is covered deterministically by T166.
    orig_slow = se3.CANARY_MAX_SLOWDOWN
    se3.CANARY_MAX_SLOWDOWN = float("inf")
    try:
        yield
    finally:
        ops.pressure_level = orig
        se3.CANARY_MAX_SLOWDOWN = orig_slow


def register(run_test):
    # ---- H evolution memory (tamper-evident, no secrets) -----------------------------------------------------------------------
    def t_ledger():
        db = _db()
        se3.record("p1", "proposal", {"goal": "x", "api_key": "sk-ABCDEFGHIJKLMNOPQRSTUV123456", "note": "Bearer abcdefghijklmnop12345"}, db)
        se3.record("p1", "decision", {"decision": "approve", "category": "perf"}, db)
        raw = json.dumps(se3.memory("p1", db_path=db))
        assert "sk-ABCDEF" not in raw and "abcdefghijklmnop12345" not in raw, "secrets must never be stored"
        assert se3.verify_ledger(db) == {"ok": True, "checked": 2}
        conn = get_connection(db)
        conn.execute("UPDATE evo_ledger SET payload='{\"decision\": \"reject\"}' WHERE id=2;")
        conn.close()
        assert se3.verify_ledger(db)["ok"] is False and se3.verify_ledger(db)["broken_at"] == 2
        db2 = _db()
        for i in range(3):
            se3.record("", "x", {"i": i}, db2)
        conn = get_connection(db2)
        conn.execute("DELETE FROM evo_ledger WHERE id=2;")
        conn.close()
        assert se3.verify_ledger(db2)["ok"] is False, "deleting a row breaks the chain"
        assert se3.normalize({"payload": {"decision": "approve"}})["payload"]["category"] == "uncategorized"
        assert se3.migrate_ledger(db)["rewritten"] == 0
    run_test("T96", "Evolution memory: hash-chained ledger, secrets redacted, edit/delete detected, old-schema rows normalized (never rewritten)", t_ledger)

    # ---- hard freeze / safe mode ---------------------------------------------------------------------------------------------------
    def t_freeze():
        db = _db()
        repo = _mini_repo()
        pid = _proposal(db, repo, PATCH_OK)
        se3.freeze("owner", db, "test")
        for fn in (lambda: se3.run_cycle(db, str(repo), {}), lambda: se3.canary(pid, db, str(repo)), lambda: se3.promote(pid, db, str(repo)),
                   lambda: se3.capture_baseline(pid, db, str(repo)), lambda: se3.propose("improve calc", db, str(repo), generate_patch=False)):
            try:
                fn()
                assert False, "must be refused while frozen"
            except se3.EvolutionFrozen:
                pass
        assert se.apply_approved(pid, db, str(repo), _gate_ok=True)["status"] == "FROZEN", "even the legacy engine honours the freeze"
        se3.unfreeze("owner", db)
        assert not se3.frozen(db)
        emergency.set_safe_mode(True, "t", db)
        try:
            se3.run_cycle(db, str(repo), {})
            assert False
        except se3.EvolutionFrozen:
            pass
    run_test("T97", "Owner hard freeze + safe mode stop every evolution entry point (cycle/baseline/canary/promote/propose/apply)", t_freeze)

    # ---- A continuous capability discovery ---------------------------------------------------------------------------------------------
    def t_discover():
        db = _db()
        import kora.services.handlers  # noqa: F401
        a = se3.discover_capabilities(db, {})
        assert a["first_snapshot"] is True and a["auto_install"] is False and a["auto_pay"] is False and a["auto_connect"] is False
        assert a["capabilities"]["provider:local_deterministic_fallback"]["available"] and "skill:noop" in a["capabilities"]
        assert a["capabilities"]["provider:openai"]["available"] is False and a["capabilities"]["provider:openai"]["availability"] == "UNAVAILABLE"
        assert a["hardware"]["gpu"].startswith("UNVERIFIED")
        b = se3.discover_capabilities(db, {"GROQ_API_KEY": "x"})
        assert "provider:groq" in b["new_since_last"] and not b["first_snapshot"]
        c = se3.discover_capabilities(db, {})
        assert "provider:groq" in c["lost_since_last"]
        assert b["provider_preference"][0] != "provider:groq" or b["capabilities"]["provider:groq"]["state"] == "CONFIGURED"
    run_test("T98", "Continuous capability discovery: real tool/lib/skill/provider inventory, NEW/LOST detection, never installs/connects/pays", t_discover)

    # ---- E dependency intelligence -----------------------------------------------------------------------------------------------------
    def t_deps():
        db = _db()
        repo = _mini_repo()
        d = se3.dependency_intel(str(repo), db)
        assert d["python"]["stdlib_only"] is True and d["node"]["status"] == "NOT_PRESENT"
        (repo / "kora/services/uses_ext.py").write_text("import totally_missing_pkg_xyz\nimport json\n")
        (repo / "package.json").write_text(json.dumps({"dependencies": {"react": "^18"}, "devDependencies": {"react": "^19", "vite": "^5"}}))
        d2 = se3.dependency_intel(str(repo), db)
        mod = {x["module"]: x for x in d2["python"]["third_party"]}["totally_missing_pkg_xyz"]
        assert mod["status"] == "MISSING" and mod["importable"] is False and "python:totally_missing_pkg_xyz" in d2["stale_or_conflicting"]
        assert d2["node"]["version_conflicts"] == ["react"] and "node:no_lockfile" in d2["stale_or_conflicting"]
        assert d2["node"]["build_status"].startswith("UNVERIFIED") and d2["freshness"].startswith("UNVERIFIED") and d2["license_status"].startswith("UNVERIFIED")
    run_test("T99", "Dependency intelligence: missing/conflicting deps detected, freshness/license/build honestly UNVERIFIED (never claimed available until validated)", t_deps)

    # ---- B self-benchmark lab ---------------------------------------------------------------------------------------------------------------
    def t_bench():
        db = _db()

        def slow():
            return sum(i * i for i in range(60000))

        def fast():
            return 59999 * 60000 * (2 * 59999 + 1) // 6
        r = se3.benchmark(slow, fast, workload="sum of squares", runs=9, db_path=db, proposal_id="b1")
        assert r["decision"] == "PROMOTE_CANDIDATE" and r["gain"]["time"] > 0.5 and r["confidence"] in ("MEDIUM", "HIGH"), r
        # The decision logic below is checked with a DETERMINISTIC clock (fixed per-function durations) so that scheduler noise cannot make
        # two identical functions look 50% different. Real measurement is still exercised above (slow vs a closed-form fast path).
        def _fixed_timing(costs):
            def fake(fn, seed):
                se3.random.seed(seed)
                try:
                    out, ok = fn(), True
                except Exception:  # noqa: BLE001
                    out, ok = None, False
                c = costs.get(fn, 0.001)
                return {"t": c, "cpu": c, "ok": ok, "out": out}
            return fake
        real_timed = se3._run_timed
        se3._run_timed = _fixed_timing({slow: 0.04, fast: 0.001})
        try:
            wrong = se3.benchmark(slow, lambda: 1, runs=7)
            assert wrong["decision"] == "REJECT" and any("differs" in x for x in wrong["reasons"])
            same = se3.benchmark(slow, slow, runs=9, min_gain=0.5)
            assert same["decision"] == "REJECT" and any("no measurable benefit" in x for x in same["reasons"]), same
            few = se3.benchmark(slow, fast, runs=3)
            assert few["decision"] == "INCONCLUSIVE"

            def flaky():
                raise RuntimeError("x")
            assert se3.benchmark(slow, flaky, runs=7)["decision"] == "REJECT", "a failing candidate is rejected, not crashed on"

            def hungry():
                return (sum(i * i for i in range(60000)), bytearray(8 * 1024 * 1024)[:1])
            damage = se3.benchmark(lambda: (sum(i * i for i in range(60000)), b"\0"), hungry, runs=7, check=lambda a, b: a[0] == b[0])
            assert damage["decision"] == "REJECT" and any("memory regressed" in x for x in damage["reasons"]), damage
        finally:
            se3._run_timed = real_timed
        rec = se3.memory("b1", "benchmark", db)[0]["payload"]
        assert rec["workload"] == "sum of squares" and rec["decision"] == "PROMOTE_CANDIDATE"
    run_test("T100", "Self-benchmark lab: baseline vs candidate on time/CPU/memory/failures/correctness; rejects no-benefit, wrong output, silent damage; logs the record", t_bench)

    # ---- C evolution score + M owner preference ------------------------------------------------------------------------------------------
    def t_score():
        s = se3.score({"benefit": .8, "reliability": .7, "quality": .6, "risk": .2, "complexity": .3}, measurable=True)
        assert s["status"] == "RECOMMEND" and s["verdict"]["decision"] == "PROPOSE" and "performance" in s["unknown"]
        assert se3.score({"benefit": .9}) ["status"] == "INSUFFICIENT_EVIDENCE" and se3.score({"benefit": .9})["net"] is None
        v = se3.score({"benefit": .9, "risk": .1}, damaged=["memory"], preference=.1, measurable=True)
        assert v["veto"] and v["status"] == "VETO_DAMAGE" and v["preference_applied"] == 0 and v["verdict"]["decision"] == "HOLD", "no silent damage to another metric"
        assert se3.score({"benefit": .5, "risk": .5}, preference=5.0)["preference_applied"] == 0.1, "preference is clamped to +-0.10"
        assert se3.score({"benefit": .5, "risk": .5}, duplicate=True)["verdict"]["decision"] == "REFUSE"
        try:
            se3.score({"benefit": 1.5, "risk": .1})
            assert False
        except ValueError:
            pass
        db = _db()
        assert se3.preference_weight("perf", db) == 0.0, "not enough decisions => no preference"
        for d in ("approve", "approve", "approve", "reject"):
            se3.learn_decision("p", d, "perf", db)
        for d in ("reject", "reject", "reject", "postpone"):
            se3.learn_decision("p", d, "ui", db)
        assert 0 < se3.preference_weight("perf", db) <= 0.1 and -0.1 <= se3.preference_weight("ui", db) < 0
        try:
            se3.learn_decision("p", "maybe", "perf", db)
            assert False
        except ValueError:
            pass
    run_test("T101", "Evolution score: multi-factor net from evidence, vetoes silent damage, reuses godfather verdict; owner preference only nudges ranking (+-0.10)", t_score)

    # ---- D regression intelligence --------------------------------------------------------------------------------------------------------
    def t_regress():
        db = _db()
        g = se3.add_guard("return a - b", "subtraction bug once broke add()", ["kora/services/calc.py"], "T-calc", db)
        hits = se3.check_guards(PATCH_BREAKS, ["kora/services/calc.py"], db)
        assert hits and hits[0]["guard_id"] == g["guard_id"] and "subtraction" in hits[0]["reason"]
        assert se3.check_guards(PATCH_OK, ["kora/services/calc.py"], db) == []
        conn = get_connection(db)
        assert conn.execute("SELECT hits FROM evo_guards;").fetchone()[0] == 1
        conn.close()
        for i in range(2):
            se3.record(f"r{i}", "rollback", {"files": ["kora/services/calc.py"]}, db)
        rp = se3.risk_pattern_confidence(["kora/services/calc.py", "kora/services/other.py"], db)
        assert rp["per_file"]["kora/services/calc.py"] == 0.5 and rp["per_file"]["kora/services/other.py"] == 1.0 and rp["repeated_regressions"] == ["kora/services/calc.py"]
    run_test("T102", "Regression intelligence: guards fire on re-introduced defects, repeated rollbacks lower per-file confidence", t_regress)

    # ---- L upgrade dependency graph + levels ----------------------------------------------------------------------------------------------
    def t_graph():
        repo = _mini_repo()
        (repo / "kora/services/net.py").write_text("import urllib.request\n\ndef go():\n    return urllib.request.urlopen('x')\n")
        (repo / "kora/services/user.py").write_text("from kora.services import calc\n")
        g = se3.impact_graph(["kora/services/calc.py", "kora/services/net.py"], str(repo))
        n = {x["file"]: x for x in g["nodes"]}
        assert "kora.services.user" in n["kora/services/calc.py"]["imported_by"] and n["kora/services/calc.py"]["tests_reference_it"] is True
        assert n["kora/services/net.py"]["external_side_effects"] is True and g["reject"] is True and "net.py" in g["unresolved_high_risk"][0]
        assert se3.classify(["kora/tests/x.py"])["risk"] == "LOW" and se3.classify(["kora/services/ops.py"])["level"] == 4
        assert se3.classify(["kora/core/policy.py"])["risk"] == "CRITICAL"
        assert se3.classify(["kora/services/self_evolution_3.py"])["level_name"] == "META_EVOLUTION" and se3.classify(["kora/services/self_evolution_3.py"])["risk"] == "CRITICAL"
        assert se3.classify(["kora/services/social.py"])["risk"] == "HIGH"
    run_test("T103", "Upgrade dependency graph: importers, test coverage, permissions, side effects; unresolved high-risk rejects; META/protected files classified CRITICAL", t_graph)

    # ---- adversarial evolution guard ---------------------------------------------------------------------------------------------------------
    def t_adv():
        assert se3.adversarial_scan(PATCH_OK)["clean"] is True
        assert se3.adversarial_scan(PATCH_EVIL)["findings"][0]["kind"] == "dynamic_code_execution"
        cases = {
            "hardcoded_secret": '+API_KEY = "abcdefghijklmnop123456"',
            "security_disabled": "+HARD_BLOCKS = set()",
            "process_execution": "+    os.system('ls')",
            "path_escape": "+    open('/etc/passwd')",
        }
        for kind, line in cases.items():
            r = se3.adversarial_scan("--- a/x.py\n+++ b/x.py\n@@ -1 +1 @@\n" + line + "\n")
            assert any(f["kind"] == kind for f in r["findings"]) and not r["clean"], (kind, r)
        r = se3.adversarial_scan("--- a/x.py\n+++ b/x.py\n@@ -1 +1 @@\n-    policy.require_enabled('PUBLISH_SOCIAL', db)\n+    pass\n")
        assert r["findings"][0]["kind"] == "safety_check_removed" and not r["clean"]
        r = se3.adversarial_scan("--- a/t.py\n+++ b/t.py\n@@ -1,2 +1 @@\n-    assert a == 1\n-    assert b == 2\n+    assert True\n")
        assert any(f["kind"] == "tests_weakened" for f in r["findings"])
        assert "abcdefghijklmnop123456" not in json.dumps(se3.adversarial_scan("--- a/x.py\n+++ b/x.py\n@@ -1 +1 @@\n" + cases["hardcoded_secret"] + "\n")), "secrets are redacted in reports"
        assert se3.adversarial_scan("+++ b/x\n+url = 'https://example.org/x'\n")["clean"] is True, "a new endpoint is a warning (MEDIUM), not a block"
    run_test("T104", "Adversarial evolution guard: exec/shell/secrets/disabled security/removed checks/weakened tests are blocked, secrets redacted", t_adv)

    # ---- I capability gap radar ----------------------------------------------------------------------------------------------------------------
    def t_gaps():
        db = _db()
        q = DurableQueue(db, retry_base=0)
        for i in range(3):
            j = q.enqueue("flaky_job", {}, max_retries=1)
            c = q.claim_next_job("w")
            q.fail_job(c["id"], "w", "boom")
        for _ in range(3):
            conn = get_connection(db)
            conn.execute("INSERT INTO dna_learn(task,outcome,correction,preference,source,confidence,created_at) VALUES ('t','o','make it shorter','','user',0.9,?);", (time.time(),))
            conn.close()
        for _ in range(3):
            record_audit("brain_command", "owner:owner:text", {"intent": None, "source": "text", "text": "make me a movie"}, db)
        g = se3.detect_gaps(db)
        ids = {x["id"]: x for x in g["gaps"]}
        assert "GAP_FAILING_flaky_job" in ids and ids["GAP_FAILING_flaky_job"]["evidence"]["dead_lettered"] == 3
        kinds = {x["kind"] for x in g["gaps"]}
        assert {"repeated_user_corrections", "missing_tools", "failed_goals"} <= kinds
        assert any(x["id"].startswith("GAP_UNRECOGNIZED_") for x in g["gaps"])
        assert all(x["evidence"] for x in g["gaps"]) and len(g["not_observable"]) >= 2
        assert [x["id"] for x in g["gaps"] if x["severity"] == "HIGH"] == sorted(x["id"] for x in g["gaps"] if x["severity"] == "HIGH")
        assert se3.detect_gaps(_db())["count"] >= 0
    run_test("T105", "Capability gap radar: gaps come only from recorded signals (DLQ, corrections, unrecognised goals, adapters), each with evidence; unobservable signals are listed", t_gaps)

    # ---- F performance evolution --------------------------------------------------------------------------------------------------------------------
    def t_perf():
        db = _db()
        conn = get_connection(db)
        now = time.time()
        for i in range(6):
            conn.execute("INSERT INTO jobs(id,priority,status,handler_name,payload,created_at,updated_at,max_retries) VALUES (?,?,?,?,?,?,?,?);",
                         (f"slow{i}", 0, "COMPLETED", "render", "{}", now - 100, now - 100 + 45, 3))
        for i in range(4):
            conn.execute("INSERT INTO jobs(id,priority,status,handler_name,payload,created_at,updated_at,max_retries) VALUES (?,?,?,?,?,?,?,?);",
                         (f"dl{i}", 0, "DEAD_LETTER", "render", "{}", now - 100, now - 90, 3))
        conn.close()
        p = se3.performance_profile(db, now)
        assert p["handlers"]["render"]["p95_s"] == 45.0 and p["jobs_7d"]["completed"] == 6
        assert any(s["area"] == "latency" for s in p["suggestions"]) and any(s["area"] == "reliability" for s in p["suggestions"])
        assert "network efficiency" in " ".join(p["unavailable"])
        assert se3.performance_profile(_db())["suggestions"] == [], "no data => no invented optimisations"
    run_test("T106", "Performance evolution: suggestions only from measured latency/failure/disk/RAM; efficiency metrics with no telemetry are UNAVAILABLE", t_perf)

    # ---- G failure prediction ------------------------------------------------------------------------------------------------------------------------
    def t_predict():
        db = _db()
        repo = _mini_repo()
        pid = _proposal(db, repo, PATCH_BREAKS)
        se3.add_guard("return a - b", "defect", [], "", db)
        p = se3.predict(pid, db, str(repo), {})
        assert set(p["categories"]) == {"provider_failure", "dependency_failure", "timeout", "resource_exhaustion", "queue_overload", "duplicate_action",
                                        "offline_condition", "quality_regression", "permission_failure"}
        assert p["categories"]["quality_regression"]["risk"] == "HIGH", "guard hit predicts a quality regression"
        assert p["categories"]["timeout"]["risk"] == "UNKNOWN", "no canary timing yet => UNKNOWN, not LOW"
        assert p["categories"]["provider_failure"]["risk"] == "MEDIUM" and p["overall"] == "HIGH"
        emergency.set_safe_mode(True, "t", db)
        assert se3.predict("", db, str(repo), {})["categories"]["permission_failure"]["risk"] == "HIGH"
    run_test("T107", "Failure prediction: 9 failure classes from real pre-checks (providers, deps, timing, pressure, queue, duplicates, offline, guards, permissions)", t_predict)

    # ---- N resource-aware cycle + O offline evolution queue --------------------------------------------------------------------------------------------------
    def t_cycle():
        db = _db()
        repo = _mini_repo()
        with _calm():
            r = se3.run_cycle(db, str(repo), {}, goal="improve calc module")
        assert r["status"] == "COMPLETED" and r["completed_steps"] == list(se3.STEPS) and r["production_mutation"] is False
        assert r["result"]["existing"]["existing_matches"], "FIND existing capability before building"
        assert governance.checkpoint_load(r["run_id"], db)["done"] == list(se3.STEPS)
        # constrained => pause mid-run with checkpoint + durable resume job, spending nothing more
        db2 = _db()
        calls = {"n": 0}
        orig = ops.pressure_level

        def flaky_pressure(*a, **k):
            calls["n"] += 1
            return {"level": "NORMAL" if calls["n"] <= 2 else "CRITICAL", "reasons": [] if calls["n"] <= 2 else ["cpu_load 9/cpu"], "unknown": []}
        ops.pressure_level = flaky_pressure
        try:
            p = se3.run_cycle(db2, str(repo), {}, goal="x")
        finally:
            ops.pressure_level = orig
        assert p["status"] == "PAUSED" and p["completed_steps"] and p["paused_before"] in se3.STEPS and p["resume"].startswith("queued")
        conn = get_connection(db2)
        job = conn.execute("SELECT handler_name,priority,idempotency_key FROM jobs WHERE handler_name='evolution_resume';").fetchone()
        conn.close()
        assert job and job["priority"] == P3, "resume is a normal durable job on the single queue (tier P3)"
        with _calm():
            fin = se3.resume(p["run_id"], db2, str(repo), {})
        assert fin["status"] == "COMPLETED" and fin["completed_steps"] == list(se3.STEPS)
        assert fin["completed_steps"][:len(p["completed_steps"])] == p["completed_steps"], "steps done before the pause are not repeated"
        # daily run limit and recursion guard
        db3 = _db()
        with _calm():
            for _ in range(se3.MAX_RUNS_PER_DAY):
                assert se3.run_cycle(db3, str(repo), {})["status"] == "COMPLETED"
            d = se3.run_cycle(db3, str(repo), {})
        assert d["status"] == "DEFERRED" and "daily_run_limit" in d["reasons"]
        from kora.core.anti_loop import DepthGuard
        with DepthGuard(limit=1):
            with _calm():
                assert se3.run_cycle(_db(), str(repo), {})["status"] == "REFUSED"
    run_test("T108", "Resource-aware evolution: checkpoint every step, PAUSE under pressure with durable resume, no repeated steps, daily cap, no recursive evolution", t_cycle)

    def t_offline_q():
        db = _db()
        repo = _mini_repo()
        orig_net = ops.network_state
        ops.network_state = lambda *a, **k: {"state": "OFFLINE", "via": "test"}
        try:
            with _calm():
                r = se3.run_cycle(db, str(repo), {}, goal="g", urls=["https://example.org/doc"])
            assert r["result"]["research"]["status"] == "QUEUED_OFFLINE", "no fresh data is faked while offline"
            conn = get_connection(db)
            row = conn.execute("SELECT id,payload FROM jobs WHERE handler_name='evolution_net_check';").fetchone()
            conn.close()
            assert row and json.loads(row["payload"])["urls"] == ["https://example.org/doc"]
            from kora.services import handlers
            try:
                handlers.h_evolution_net_check(json.loads(row["payload"]))
                assert False, "still offline => transient failure (retry with backoff)"
            except RuntimeError as exc:
                assert "offline" in str(exc)
        finally:
            ops.network_state = orig_net
        # reconnect: handler fetches (through the guarded fetcher) and records evidence
        from kora.services import research
        orig_fetch = research.fetch_page
        research.fetch_page = lambda url, *a, **k: {"ok": True, "url": url, "title": "Doc", "text": "x" * 50, "bytes": 50, "injection_flagged": False}
        ops.network_state = lambda *a, **k: {"state": "ONLINE", "via": "test"}
        from kora.core import worker
        worker._ctx.db = db  # exactly what the worker sets while dispatching a job
        try:
            out = handlers.h_evolution_net_check({"run_id": "evo-x", "urls": ["https://example.org/doc"]})
        finally:
            research.fetch_page, ops.network_state = orig_fetch, orig_net
            worker._ctx.db = None
        assert out["status"] == "DONE" and out["fetched"] == 1
        ev = se3.memory(stage="research", db_path=db)
        assert any(s["url"] == "https://example.org/doc" for e in ev for s in e["payload"].get("sources", [])), "evidence was recorded in the ledger"
        assert "evolution_net_check" in trust.SKILL_META and "evolution_resume" in trust.SKILL_META
        from kora.bridge.api import ENQUEUE_ALLOWED
        assert "evolution_net_check" not in ENQUEUE_ALLOWED and "evolution_resume" not in ENQUEUE_ALLOWED, "API callers cannot enqueue evolution jobs"
    run_test("T109", "Offline evolution queue: network research is queued on the durable queue, retried while offline, executed after reconnect; nothing faked", t_offline_q)

    # ---- J self-test generator -----------------------------------------------------------------------------------------------------------------------------------
    def t_gen():
        db = _db()
        repo = _mini_repo()
        made = []
        for kind, params in (("unit", {"module": "kora.services.ops", "func": "health"}), ("regression", {"file": "kora/services/ops.py", "pattern": "ZZZ_NOT_PRESENT"}),
                             ("permission", {"skill": "noop"}), ("resource", {"module": "kora.services.ops"}), ("offline", {}), ("security", {}), ("integration", {})):
            g = se3.generate_test(kind, db, str(repo), **params)
            assert g["status"] == "GENERATED_UNREVIEWED" and g["compiles"] and (repo / g["path"]).is_file()
            results = []
            ns = {}
            exec(compile(g["source"], g["name"], "exec"), ns)
            ns["register"](lambda i, n, f: results.append((i, f)))
            assert len(results) == 1
            results[0][1]()  # the generated test really runs (and passes) against the real code base
            made.append(kind)
        assert made == ["unit", "regression", "permission", "resource", "offline", "security", "integration"]
        try:
            se3.generate_test("unit", db, str(repo), module="x; import os")
            assert False
        except ValueError:
            pass
        try:
            se3.generate_test("rce", db, str(repo))
            assert False
        except ValueError:
            pass
    run_test("T110", "Self-test generator: unit/regression/permission/resource/offline/security/integration templates compile AND pass; unsafe parameters refused; output is UNREVIEWED", t_gen)

    # ---- canary (isolated), promotion gate, promotion, rollback ---------------------------------------------------------------------------------------
    def t_canary():
        db = _db()
        repo = _mini_repo()
        before = (repo / "kora/services/calc.py").read_text()
        with _calm():
            ok = _proposal(db, repo, PATCH_OK)
            c = se3.canary(ok, db, str(repo))
            assert c["status"] == "PASSED" and c["passed"] == 3 and c["total"] == 3 and c["duration_s"] >= 0 and "max_rss_mb_children" in c and "cpu_s" in c, c
            assert (repo / "kora/services/calc.py").read_text() == before, "canary never touches production"
            bad = _proposal(db, repo, PATCH_BREAKS)
            cb = se3.canary(bad, db, str(repo))
            assert cb["status"] == "TESTS_FAILED" and cb["passed"] is None, cb
            evil = _proposal(db, repo, PATCH_EVIL)
            ce = se3.canary(evil, db, str(repo))
            assert ce["status"] == "BLOCKED_ADVERSARIAL"
            assert se3.canary("nope", db, str(repo))["status"] == "PATCH_NOT_FOUND"
        assert (repo / "kora/services/calc.py").read_text() == before
        assert se3.memory(ok, "canary", db)[0]["payload"]["status"] == "PASSED"
        left = [p for p in Path(tempfile.gettempdir()).glob("kora-canary-*")]
        assert not left, "temporary canary copies are always removed"
    run_test("T111", "Canary: patch applied to a throwaway copy, compiled, full suite run with measured CPU/RSS/time; production untouched; failing/adversarial patches stopped", t_canary)

    def t_promote():
        db = _db()
        repo = _mini_repo()
        orig = (repo / "kora/services/calc.py").read_text()
        with _calm():
            pid = _proposal(db, repo, PATCH_OK)
            g0 = se3.promotion_gate(pid, db, str(repo))
            assert not g0["can_promote"] and {"baseline_captured", "canary_passed", "owner_approval", "candidate_benchmark"} <= set(g0["blocked_by"])
            assert se.apply_approved(pid, db, str(repo))["status"] == "GATE_REQUIRED", "legacy direct apply cannot bypass the gate"
            r0 = se3.promote(pid, db, str(repo))
            assert r0["status"] == "REFUSED" and (repo / "kora/services/calc.py").read_text() == orig
            assert se3.memory(pid, "refusal", db), "every refusal is remembered (Evolution by Refusal)"
            b = se3.capture_baseline(pid, db, str(repo))
            assert b["status"] == "PASSED" and b["passed"] == 3
            assert se3.canary(pid, db, str(repo))["status"] == "PASSED"
            assert not se3.promotion_gate(pid, db, str(repo))["can_promote"], "still needs owner approval"
            assert se3.promote(pid, db, str(repo))["status"] == "REFUSED"
            assert governance.decide(pid, True, "owner", db)
            gate = se3.promotion_gate(pid, db, str(repo))
            assert gate["can_promote"], gate["blocked_by"]
            st = {i["item"]: i["status"] for i in gate["items"]}
            assert st["owner_approval"] == "PASS" and st["legal_platform_preflight"] == "NOT_APPLICABLE" and st["post_deploy_health"] == "AFTER_APPLY"
            assert gate["level"]["risk"] in ("MEDIUM", "HIGH", "LOW")
            res = se3.promote(pid, db, str(repo))
        assert res["status"] == "PROMOTED_VERIFIED", res
        assert "Add two numbers" in (repo / "kora/services/calc.py").read_text()
        dep = se3.memory(pid, "deployment", db)[0]["payload"]
        assert dep["success"] and dep["before"] != dep["after"] and dep["tests"] == "PASS"
        assert se3.memory(pid, "lesson", db)
        # a proposal cannot be promoted twice (approval was consumed by the engine)
        with _calm():
            assert se3.promote(pid, db, str(repo))["status"] != "PROMOTED_VERIFIED"
    run_test("T112", "Evidence-based promotion: gate lists every item with evidence; apply only after baseline+canary+benchmark+approval; legacy apply cannot bypass; refusals remembered", t_promote)

    def t_rollback():
        db = _db()
        repo = _mini_repo()
        orig = (repo / "kora/services/calc.py").read_text()
        with _calm():
            pid = _proposal(db, repo, PATCH_OK)
            se3.capture_baseline(pid, db, str(repo))
            se3.canary(pid, db, str(repo))
            governance.decide(pid, True, "owner", db)
            assert se3.promote(pid, db, str(repo))["status"] == "PROMOTED_VERIFIED"
        pts = se3.rollback_points(db, str(repo))
        assert pts and pts[0]["proposal_id"] == pid and pts[0]["score"] >= 70 and "deployment succeeded" in pts[0]["reasons"]
        rb = se3.verified_rollback(pid, db, str(repo), actor="owner")
        assert rb["status"] == "ROLLBACK_VERIFIED" and rb["hash_mismatches"] == [] and rb["compiles"] is True, rb
        assert (repo / "kora/services/calc.py").read_text() == orig
        assert (repo / rb["evidence_preserved"] / "kora/services/calc.py").is_file(), "failing state is preserved as evidence"
        assert se3.memory(pid, "rollback", db)[0]["payload"]["verified"] is True
        conn = get_connection(db)
        assert conn.execute("SELECT COUNT(*) FROM evo_guards WHERE pattern=?;", (f"rolled_back:{pid}",)).fetchone()[0] == 1, "rollback adds a regression guard"
        conn.close()
        assert se3.verified_rollback("missing", db, str(repo))["status"] == "NO_RESTORE_POINT"
        # deterministic ordering with several points
        assert [p["proposal_id"] for p in se3.rollback_points(db, str(repo))] == [p["proposal_id"] for p in se3.rollback_points(db, str(repo))]
    run_test("T113", "Rollback intelligence: restore points scored by health/tests/provenance/history, rollback hash-verified + compiled, evidence preserved, guard added", t_rollback)

    def t_post_deploy():
        db = _db()
        repo = _mini_repo()
        orig = (repo / "kora/services/calc.py").read_text()
        with _calm():
            pid = _proposal(db, repo, PATCH_OK)
            se3.capture_baseline(pid, db, str(repo))
            se3.canary(pid, db, str(repo))
            governance.decide(pid, True, "owner", db)
            record_audit("x", "t", {"a": 1}, db)
            conn = get_connection(db)  # tamper AFTER the gate would pass: post-deploy health must catch it
            conn.execute("UPDATE audit_events SET details='{\"a\": 9}' WHERE id=(SELECT MAX(id) FROM audit_events WHERE hash IS NOT NULL);")
            conn.close()
            res = se3.promote(pid, db, str(repo))
        assert res["status"] == "ROLLED_BACK_POST_DEPLOY" and res["rollback"]["status"] == "ROLLBACK_VERIFIED", res
        assert (repo / "kora/services/calc.py").read_text() == orig, "failed verification => trusted state restored"
    run_test("T114", "Post-deploy verification failure (health BLOCKED) triggers STOP -> verified ROLLBACK -> evidence preserved", t_post_deploy)

    def t_slowdown_gate_deterministic():
        db = _db(); repo = _mini_repo()
        with _calm():
            pid = _proposal(db, repo, PATCH_OK)
            se3.capture_baseline(pid, db, str(repo)); se3.canary(pid, db, str(repo))
            governance.decide(pid, True, "owner", db)
            def bench(limit):
                se3.CANARY_MAX_SLOWDOWN = limit
                try: return {i["item"]: i for i in se3.promotion_gate(pid, db, str(repo))["items"]}["candidate_benchmark"]
                finally: se3.CANARY_MAX_SLOWDOWN = float("inf")
            b = bench(-1.0)                                  # any ratio (>= 0) exceeds a negative limit => deterministic FAIL, independent of machine speed
            assert b["status"] == "FAIL" and "slower than baseline" in b["evidence"], b
            assert bench(float("inf"))["status"] == "PASS"   # same measured data, limit lifted => PASS (functional checks unchanged)
    run_test("T166", "Canary slowdown gate is enforced deterministically (limit injected, no wall-clock dependence)", t_slowdown_gate_deterministic)

    # ---- META evolution and platform/legal gate -------------------------------------------------------------------------------------------------------------
    def t_meta():
        db = _db()
        repo = _mini_repo()
        (repo / "kora/services/self_evolution_3.py").write_text("X = 1\n")
        (repo / "kora/services/social.py").write_text("Y = 1\n")
        meta = "--- a/kora/services/self_evolution_3.py\n+++ b/kora/services/self_evolution_3.py\n@@ -1 +1,2 @@\n X = 1\n+Z = 2\n"
        soc = "--- a/kora/services/social.py\n+++ b/kora/services/social.py\n@@ -1 +1,2 @@\n Y = 1\n+W = 2\n"
        with _calm():
            pm = _proposal(db, repo, meta, risk="HIGH")
            se3.capture_baseline(pm, db, str(repo))
            se3.canary(pm, db, str(repo))
            governance.decide(pm, True, "owner", db)
            g = se3.promotion_gate(pm, db, str(repo))
            st = {i["item"]: i for i in g["items"]}
            assert g["level"]["level_name"] == "META_EVOLUTION" and not g["can_promote"]
            assert st["owner_approval"]["status"] == "FAIL" and "CRITICAL" in st["owner_approval"]["evidence"], "META needs a CRITICAL proposal"
            assert st["security_permission_checks"]["status"] == "FAIL" and "TOTP" in st["security_permission_checks"]["evidence"]
            ps = _proposal(db, repo, soc)
            se3.capture_baseline(ps, db, str(repo))
            se3.canary(ps, db, str(repo))
            governance.decide(ps, True, "owner", db)
            g2 = se3.promotion_gate(ps, db, str(repo))
            assert "legal_platform_preflight" in g2["blocked_by"]
            se3.attest_legal_review(ps, "owner", "reviewed platform terms", db)
            assert "legal_platform_preflight" not in se3.promotion_gate(ps, db, str(repo))["blocked_by"]
    run_test("T115", "Level 6 META-evolution needs a CRITICAL proposal + enrolled TOTP; platform/legal files need an attested legal review", t_meta)

    # ---- controlled chaos --------------------------------------------------------------------------------------------------------------------------------------
    def t_chaos():
        r = se3.chaos_check()
        assert r["status"] == "PASS" and set(r["scenarios"]) >= {"worker_crash_recovery", "no_duplicate_completion", "failure_goes_to_dlq", "kill_switch_blocks_claims",
                                                                 "pressure_pauses_low_tier", "paused_work_resumes"}, r
        assert "production untouched" in r["scope"]
    run_test("T116", "Controlled chaos on a throwaway DB: worker crash, duplicate completion, failing handler, kill switch, pressure pause all recover safely", t_chaos)

    # ---- dashboard -------------------------------------------------------------------------------------------------------------------------------------------------
    def t_dash():
        db = _db()
        d0 = se3.dashboard(db)
        assert d0["capabilities_discovered"].startswith("UNAVAILABLE") and d0["trends"]["cost"].startswith("UNAVAILABLE") and d0["trends"]["resource_efficiency"].startswith("UNAVAILABLE")
        assert d0["benchmark_wins"] == d0["benchmark_losses"] == d0["rollbacks"] == 0 and d0["ledger"]["ok"]
        txt = json.dumps(d0).lower()
        for fake in ("infinite", "100% guaranteed", "unlimited"):
            assert fake not in txt
        se3.record("p", "benchmark", {"decision": "PROMOTE_CANDIDATE"}, db)
        se3.record("p", "benchmark", {"decision": "REJECT"}, db)
        se3.record("p", "refusal", {"blocked_by": ["x"]}, db)
        se3.add_guard("pat", "why", [], "", db)
        d1 = se3.dashboard(db)
        assert d1["benchmark_wins"] == 1 and d1["benchmark_losses"] == 1 and d1["regressions_prevented"] == 1 and d1["regression_guards"]["count"] == 1
    run_test("T117", "Growth dashboard: every figure counted from real records, UNAVAILABLE when no data, no fabricated scores", t_dash)

    # ---- API end to end ---------------------------------------------------------------------------------------------------------------------------------------------
    def t_api():
        import io
        from dataclasses import replace
        from kora.bridge.api import KoraApp
        from kora.config.settings import load_settings
        db = _db()
        app = KoraApp(replace(load_settings({}), auth_token="tok-abcdef123456", require_auth_local=True), db_path=db)

        def call(method, path, body=None, tok="tok-abcdef123456", headers=None):
            raw = json.dumps(body).encode() if body is not None else b""
            env = {"REQUEST_METHOD": method, "PATH_INFO": path, "REMOTE_ADDR": "127.0.0.1", "HTTP_HOST": "127.0.0.1:8080", "CONTENT_LENGTH": str(len(raw)),
                   "CONTENT_TYPE": "application/json", "wsgi.input": io.BytesIO(raw)}
            if tok:
                env["HTTP_AUTHORIZATION"] = "Bearer " + tok
            for k, v in (headers or {}).items():
                env["HTTP_" + k.upper().replace("-", "_")] = v
            out = {}
            res = app(env, lambda s, h, e=None: out.update(s=int(s.split()[0])))
            b = b"".join(res)
            return out["s"], (json.loads(b) if b[:1] in (b"{", b"[") else b)
        for path in ("/api/evolution/3/dashboard", "/api/evolution/3/gaps", "/api/evolution/3/capabilities", "/api/evolution/3/dependencies", "/api/evolution/3/performance",
                     "/api/evolution/3/rollback-points"):
            assert call("GET", path, tok=None)[0] in (401, 403), path
            s, b = call("GET", path)
            assert s == 200 and b["ok"] is True, (path, s, b)
        s, b = call("POST", "/api/evolution/3/score", {"factors": {"benefit": .7, "risk": .2}})
        assert s == 200 and b["status"] in ("RECOMMEND", "WEAK_OR_NEGATIVE")
        assert call("POST", "/api/evolution/3/score", {"factors": {"benefit": 7}})[0] == 400
        assert call("POST", "/api/evolution/3/tests", {"kind": "offline"})[0] == 200
        assert call("POST", "/api/evolution/3/tests", {"kind": "rce"})[0] == 400
        s, b = call("POST", "/api/evolution/3/memory", {})
        assert s == 200 and b["chain"]["ok"]
        assert call("POST", "/api/evolution/3/chaos", {})[1]["status"] == "PASS"
        # freeze blocks cycle with 409, unfreeze works
        assert call("POST", "/api/evolution/3/freeze", {"reason": "t"})[0] == 200
        assert call("POST", "/api/evolution/3/cycle", {"goal": "g"})[0] == 409
        assert call("POST", "/api/evolution/3/unfreeze", {})[0] == 200
        # direct apply of an unknown proposal is refused by the gate, never a 500
        s, b = call("POST", "/api/evolution/nope/apply", {})
        assert s == 200 and b["status"] == "REFUSED" and b["ok"] is False
        # postpone keeps a proposal pending and teaches preference only
        pid = governance.create_proposal("MODIFY_CODE", "t", "HIGH", [], [], "", db)
        s, b = call("POST", f"/api/governance/proposals/{pid}/postpone", {"category": "perf"})
        assert s == 200 and b["status"] == "PENDING"
        assert governance.list_proposals(db, "PENDING", 10)[0]["id"] == pid
        # approval of a code proposal WITHOUT evidence applies nothing
        s, b = call("POST", f"/api/governance/proposals/{pid}/approve", {"category": "perf"})
        assert s == 200 and b["evolution"]["status"] == "AWAITING_EVIDENCE" and "canary_passed" in b["evolution"]["blocked_by"]
        # non-owner principals are locked out of everything evolution-related
        p = identity.create_principal("eve", "user", db_path=db)
        for m, path in (("GET", "/api/evolution/3/dashboard"), ("POST", "/api/evolution/3/cycle"), ("POST", "/api/evolution/3/freeze"), ("POST", "/api/evolution/3/canary")):
            assert call(m, path, {} if m == "POST" else None, tok=p["token"])[0] == 403, path
        # step-up: once TOTP is enrolled, unfreeze needs a one-time code
        enrol = identity.totp_enroll(db) if hasattr(identity, "totp_enroll") else None
        if enrol:
            assert call("POST", "/api/evolution/3/unfreeze", {})[0] == 403
    run_test("T118", "Evolution 3.0 API: owner-only + auth on every route, freeze => 409, apply/approve cannot bypass the evidence gate, postpone teaches preference only", t_api)
