#!/usr/bin/env python3
"""KILCRITIC V8 - Main Entry Point"""
import os
import json
import sys
from typing import Dict, Any
from dotenv import load_dotenv
from pipeline.singularity_pipeline import SingularityPipeline
from core.exceptions import KILCRITICException
from core.middleware import ErrorHandler

load_dotenv()

class KILCRITIC:
    """KILCRITIC V8 - Main Application"""

    def __init__(self):
        api_key = os.getenv('ANTHROPIC_API_KEY')
        if not api_key:
            raise KILCRITICException("ANTHROPIC_API_KEY not set")

        self.pipeline = SingularityPipeline(api_key)
        self.version = "8.0.0"

    def process(self, content: Dict[str, Any], options: Dict[str, Any] = None) -> Dict[str, Any]:
        """Process content through KILCRITIC"""
        return self.pipeline.execute(content, options)

    def batch_process(self, contents: list, parallel: bool = False) -> Dict[str, Any]:
        """Process multiple contents"""
        return self.pipeline.batch_execute(contents, parallel)

    def get_stats(self) -> Dict[str, Any]:
        """Get system statistics"""
        return self.pipeline.get_pipeline_stats()

    def clear_memory(self) -> Dict[str, Any]:
        """Clear caches"""
        return self.pipeline.clear_cache()

def main():
    """Main CLI interface"""
    try:
        kc = KILCRITIC()
        print(f"KILCRITIC v{kc.version} - Ready")

        # Example 1: Text analysis
        print("\n=== TEXT ANALYSIS ===")
        text_content = {
            'type': 'text',
            'data': 'This is amazing content about digital marketing strategies that drives real engagement and builds community.'
        }
        result = kc.process(text_content, {'detailed': True})
        print(json.dumps(result, indent=2))

        # Example 2: Video analysis
        print("\n=== VIDEO ANALYSIS ===")
        video_content = {
            'type': 'video',
            'data': {
                'duration': 120,
                'frames': 3600,
                'bitrate': 5000,
                'title': 'Amazing Product Launch'
            }
        }
        result = kc.process(video_content)
        print(json.dumps(result, indent=2))

        # Example 3: Image analysis
        print("\n=== IMAGE ANALYSIS ===")
        image_content = {
            'type': 'image',
            'data': {
                'width': 1920,
                'height': 1080,
                'format': 'jpeg',
                'file_size': 2500000
            }
        }
        result = kc.process(image_content)
        print(json.dumps(result, indent=2))

        # Example 4: Batch processing
        print("\n=== BATCH PROCESSING ===")
        batch = [
            {'type': 'text', 'data': 'Content 1'},
            {'type': 'text', 'data': 'Content 2'},
            {'type': 'text', 'data': 'Content 3'}
        ]
        result = kc.batch_process(batch)
        print(json.dumps({
            'success': result['success'],
            'total': result['total'],
            'successful': result['successful'],
            'failed': result['failed'],
            'duration': result['duration']
        }, indent=2))

        # System stats
        print("\n=== SYSTEM STATS ===")
        stats = kc.get_stats()
        print(json.dumps(stats, indent=2))

    except KILCRITICException as e:
        print(f"ERROR: {str(e)}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"FATAL: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()
