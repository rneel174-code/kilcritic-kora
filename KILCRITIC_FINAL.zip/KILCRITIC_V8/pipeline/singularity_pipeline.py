"""KILCRITIC V8 - Singularity Pipeline"""
import time
from typing import Dict, Any, List, Optional
from ..engine.immortal_engine import ImmortalEngine
from ..core.validators import TokenValidator, ContentValidator
from ..core.exceptions import PipelineError
from ..core.middleware import ErrorHandler, RateLimiter

class SingularityPipeline:
    """Advanced processing pipeline - orchestrates content through engine"""

    STAGES = ['validate', 'process', 'optimize', 'store']

    def __init__(self, api_key: str):
        self.engine = ImmortalEngine(api_key)
        self.rate_limiter = RateLimiter(max_requests=100, window=60)
        self.results = {}
        self.max_results = 100

    def execute(self, content: Dict[str, Any], options: Dict[str, Any] = None) -> Dict[str, Any]:
        """Execute pipeline"""
        start_time = time.time()

        # Rate limit check
        if not self.rate_limiter.check():
            return ErrorHandler.handle('RATE_LIMIT', 'Too many requests', 429)

        # Prepare options
        options = options or {}
        skip_cache = options.get('skip_cache', False)
        detailed = options.get('detailed', False)

        try:
            # Stage 1: Validate
            valid, msg = ContentValidator.validate(content)
            if not valid:
                return self._format_response(False, msg, time.time() - start_time)

            # Stage 2: Process
            result = self.engine.process_content(content)
            if not result.get('success'):
                return self._format_response(False, result.get('message'), time.time() - start_time)

            # Stage 3: Optimize
            optimized = self._optimize_result(result['result'])

            # Stage 4: Store
            self._store_result(content, optimized)

            # Format response
            response = {
                'success': True,
                'data': optimized,
                'duration': time.time() - start_time,
                'cached': result.get('cached', False),
                'remaining_requests': self.rate_limiter.get_remaining()
            }

            if detailed:
                response['stages'] = ['validate', 'process', 'optimize', 'store']
                response['engine_stats'] = self.engine.get_memory_summary()

            return response

        except Exception as e:
            return self._format_response(False, str(e), time.time() - start_time)

    def batch_execute(self, contents: List[Dict[str, Any]], parallel: bool = False) -> Dict[str, Any]:
        """Execute pipeline on multiple contents"""
        start_time = time.time()

        if len(contents) > 50:
            return ErrorHandler.handle('SERVER_ERROR', 'Batch size too large (max 50)', 400)

        results = []
        successful = 0
        failed = 0

        for i, content in enumerate(contents):
            try:
                result = self.execute(content)
                if result.get('success'):
                    successful += 1
                else:
                    failed += 1
                results.append(result)
            except Exception as e:
                failed += 1
                results.append(ErrorHandler.handle('SERVER_ERROR', str(e)))

        return {
            'success': failed == 0,
            'total': len(contents),
            'successful': successful,
            'failed': failed,
            'results': results,
            'duration': time.time() - start_time
        }

    def _optimize_result(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """Optimize result for delivery"""
        optimized = {
            'type': result.get('type'),
            'timestamp': result.get('timestamp'),
            'quality_score': result.get('quality_score', 0)
        }

        # Remove None values
        for key, value in result.items():
            if value is not None and key not in optimized:
                optimized[key] = value

        return optimized

    def _store_result(self, content: Dict[str, Any], result: Dict[str, Any]) -> None:
        """Store result with minimal overhead"""
        if len(self.results) >= self.max_results:
            # Remove oldest 20 results
            sorted_keys = sorted(self.results.keys(), key=lambda k: self.results[k].get('timestamp', 0))
            for key in sorted_keys[:20]:
                del self.results[key]

        content_id = hash(str(content)) % 100000
        self.results[content_id] = {
            'content': content.get('type'),
            'result': result,
            'timestamp': time.time()
        }

    def _format_response(self, success: bool, message: str, duration: float) -> Dict[str, Any]:
        """Format standard response"""
        return {
            'success': success,
            'message': message,
            'duration': duration,
            'remaining_requests': self.rate_limiter.get_remaining()
        }

    def get_pipeline_stats(self) -> Dict[str, Any]:
        """Get pipeline statistics"""
        return {
            'results_stored': len(self.results),
            'rate_limiter_remaining': self.rate_limiter.get_remaining(),
            'engine_memory': self.engine.get_memory_summary(),
            'timestamp': time.time()
        }

    def clear_cache(self) -> Dict[str, Any]:
        """Clear engine cache"""
        cache_size = len(self.engine.cache)
        self.engine.cache.clear()
        self.results.clear()
        return {
            'success': True,
            'cleared_cache_items': cache_size,
            'cleared_results': len(self.results)
        }
