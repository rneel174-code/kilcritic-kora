"""KILCRITIC V8 - Pipeline Module"""
from .singularity_pipeline import SingularityPipeline

__all__ = ['SingularityPipeline']
