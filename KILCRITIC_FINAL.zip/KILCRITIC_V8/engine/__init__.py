"""KILCRITIC V8 - Engine Module"""
from .immortal_engine import ImmortalEngine

__all__ = ['ImmortalEngine']
