"""KILCRITIC V8 - Immortal Engine (Core Processing)"""
import time
import hashlib
from typing import Dict, Any, List, Optional
from anthropic import Anthropic
from ..core.validators import TokenValidator, ContentValidator
from ..core.exceptions import EngineError, TokenValidationError, ContentValidationError
from ..core.middleware import RequestLogger, ErrorHandler

class ImmortalEngine:
    """Core processing engine - handles content analysis and generation"""

    def __init__(self, api_key: str):
        self.logger = RequestLogger()

        # Validate token
        valid, msg = TokenValidator.validate(api_key)
        if not valid:
            raise TokenValidationError(msg)

        self.client = Anthropic(api_key=api_key)
        self.model = "claude-3-5-sonnet-20241022"
        self.max_tokens = 2048
        self.cache = {}
        self.memory = {"interactions": [], "max_history": 50}

    def process_content(self, content: Dict[str, Any]) -> Dict[str, Any]:
        """Process content through engine"""
        start_time = time.time()

        try:
            # Validate
            valid, msg = ContentValidator.validate(content)
            if not valid:
                self.logger.log('process_content', 'FAILED', time.time() - start_time)
                return ErrorHandler.handle('INVALID_CONTENT', msg)

            # Check cache
            content_hash = hashlib.md5(str(content).encode()).hexdigest()
            if content_hash in self.cache:
                self.logger.log('process_content', 'CACHED', time.time() - start_time)
                return {'success': True, 'result': self.cache[content_hash], 'cached': True}

            # Process based on type
            result = self._process_by_type(content)

            # Cache result
            if result.get('success'):
                self.cache[content_hash] = result.get('result')

            duration = time.time() - start_time
            self.logger.log('process_content', 'SUCCESS', duration)

            return {
                'success': True,
                'result': result.get('result'),
                'duration': duration,
                'cached': False
            }

        except Exception as e:
            duration = time.time() - start_time
            self.logger.log('process_content', 'ERROR', duration)
            return ErrorHandler.handle('SERVER_ERROR', str(e), 500)

    def _process_by_type(self, content: Dict[str, Any]) -> Dict[str, Any]:
        """Process content based on type"""
        content_type = content.get('type')
        data = content.get('data')

        if content_type == 'text':
            return self._analyze_text(data)
        elif content_type == 'video':
            return self._analyze_video(data)
        elif content_type == 'image':
            return self._analyze_image(data)
        elif content_type == 'audio':
            return self._analyze_audio(data)
        else:
            return {'success': False, 'error': 'Unknown type'}

    def _analyze_text(self, text: str) -> Dict[str, Any]:
        """Analyze text content"""
        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                messages=[{
                    "role": "user",
                    "content": f"Analyze this content for quality, engagement, and viral potential:\n\n{text[:500]}"
                }]
            )

            analysis = response.content[0].text

            # Store in memory
            self._store_interaction('text_analysis', analysis)

            return {
                'success': True,
                'result': {
                    'type': 'text_analysis',
                    'analysis': analysis,
                    'timestamp': time.time(),
                    'tokens_used': response.usage.input_tokens + response.usage.output_tokens
                }
            }
        except Exception as e:
            raise EngineError(f"Text analysis failed: {str(e)}")

    def _analyze_video(self, video_data: Dict) -> Dict[str, Any]:
        """Analyze video content"""
        try:
            duration = video_data.get('duration', 0)
            frames = video_data.get('frames', 0)

            analysis = {
                'type': 'video_analysis',
                'duration': duration,
                'frames_analyzed': min(frames, 10),  # Sample 10 frames max
                'quality_score': self._calculate_quality(duration, frames),
                'timestamp': time.time(),
                'recommendations': []
            }

            if duration > 60:
                analysis['recommendations'].append('Consider shorter videos for higher engagement')
            if duration < 15:
                analysis['recommendations'].append('Too short for detailed storytelling')

            self._store_interaction('video_analysis', analysis)

            return {'success': True, 'result': analysis}
        except Exception as e:
            raise EngineError(f"Video analysis failed: {str(e)}")

    def _analyze_image(self, image_data: Dict) -> Dict[str, Any]:
        """Analyze image content"""
        try:
            width = image_data.get('width', 0)
            height = image_data.get('height', 0)

            analysis = {
                'type': 'image_analysis',
                'resolution': f"{width}x{height}",
                'aspect_ratio': self._calculate_aspect_ratio(width, height),
                'quality_score': self._calculate_image_quality(width, height),
                'timestamp': time.time(),
                'optimization': []
            }

            if width < 1080:
                analysis['optimization'].append('Increase resolution to at least 1080p')
            if width > 4096:
                analysis['optimization'].append('Reduce resolution to improve load time')

            self._store_interaction('image_analysis', analysis)

            return {'success': True, 'result': analysis}
        except Exception as e:
            raise EngineError(f"Image analysis failed: {str(e)}")

    def _analyze_audio(self, audio_data: Dict) -> Dict[str, Any]:
        """Analyze audio content"""
        try:
            duration = audio_data.get('duration', 0)
            bitrate = audio_data.get('bitrate', 128)

            analysis = {
                'type': 'audio_analysis',
                'duration': duration,
                'bitrate': bitrate,
                'quality_score': self._calculate_audio_quality(bitrate),
                'timestamp': time.time(),
                'notes': []
            }

            if bitrate < 128:
                analysis['notes'].append('Low bitrate: consider 192kbps for better quality')
            if duration < 30:
                analysis['notes'].append('Short audio: ensure clear messaging')

            self._store_interaction('audio_analysis', analysis)

            return {'success': True, 'result': analysis}
        except Exception as e:
            raise EngineError(f"Audio analysis failed: {str(e)}")

    def _calculate_quality(self, duration: int, frames: int) -> float:
        """Calculate video quality score"""
        if duration == 0:
            return 0.0
        fps = frames / duration if duration > 0 else 0
        score = min(100, (fps / 30) * 100)
        return round(score, 2)

    def _calculate_aspect_ratio(self, width: int, height: int) -> str:
        """Calculate aspect ratio"""
        if height == 0:
            return "unknown"
        ratio = width / height
        if abs(ratio - 16/9) < 0.1:
            return "16:9"
        elif abs(ratio - 9/16) < 0.1:
            return "9:16"
        elif abs(ratio - 1) < 0.1:
            return "1:1"
        else:
            return f"{ratio:.2f}:1"

    def _calculate_image_quality(self, width: int, height: int) -> float:
        """Calculate image quality score"""
        pixels = width * height
        if pixels < 1920 * 1080:
            return 60.0
        elif pixels < 3840 * 2160:
            return 85.0
        else:
            return 95.0

    def _calculate_audio_quality(self, bitrate: int) -> float:
        """Calculate audio quality score"""
        if bitrate < 128:
            return 40.0
        elif bitrate < 192:
            return 70.0
        elif bitrate < 320:
            return 85.0
        else:
            return 95.0

    def _store_interaction(self, interaction_type: str, data: Any) -> None:
        """Store interaction in memory"""
        if len(self.memory['interactions']) >= self.memory['max_history']:
            self.memory['interactions'] = self.memory['interactions'][-25:]

        self.memory['interactions'].append({
            'type': interaction_type,
            'data': data,
            'timestamp': time.time()
        })

    def get_memory_summary(self) -> Dict[str, Any]:
        """Get memory summary"""
        return {
            'total_interactions': len(self.memory['interactions']),
            'types': list(set(i['type'] for i in self.memory['interactions'])),
            'logger_stats': self.logger.get_stats(),
            'cache_size': len(self.cache)
        }
