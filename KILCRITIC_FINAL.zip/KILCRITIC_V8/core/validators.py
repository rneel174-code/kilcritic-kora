"""KILCRITIC V8 - Validators"""
import re
from typing import Dict, Any, Tuple
from .exceptions import TokenValidationError, ContentValidationError

class TokenValidator:
    """Real Anthropic token validation"""

    PATTERN = r'^sk-[a-zA-Z0-9]{48}$'
    MIN_LENGTH = 50
    MAX_LENGTH = 60

    @staticmethod
    def validate(token: str) -> Tuple[bool, str]:
        """Validate API token format and structure"""
        if not token or not isinstance(token, str):
            return False, "Token must be a non-empty string"

        token = token.strip()

        if len(token) < TokenValidator.MIN_LENGTH or len(token) > TokenValidator.MAX_LENGTH:
            return False, f"Token length invalid: {len(token)} (expected 50-60)"

        if not re.match(TokenValidator.PATTERN, token):
            return False, "Token format invalid: must start with 'sk-' followed by 48 alphanumeric chars"

        return True, "Token valid"

class ContentValidator:
    """Content validation and sanitization"""

    MAX_CONTENT_LENGTH = 100000
    MIN_CONTENT_LENGTH = 1

    @staticmethod
    def validate(content: Dict[str, Any]) -> Tuple[bool, str]:
        """Validate content structure"""
        if not isinstance(content, dict):
            return False, "Content must be dictionary"

        required_fields = ['type', 'data']
        for field in required_fields:
            if field not in content:
                return False, f"Missing required field: {field}"

        if content['type'] not in ['text', 'video', 'image', 'audio']:
            return False, f"Invalid content type: {content['type']}"

        if not isinstance(content['data'], (str, dict, list)):
            return False, "Data must be string, dict, or list"

        data_str = str(content['data'])
        if len(data_str) < ContentValidator.MIN_CONTENT_LENGTH:
            return False, "Content too short"

        if len(data_str) > ContentValidator.MAX_CONTENT_LENGTH:
            return False, f"Content too long: {len(data_str)} > {ContentValidator.MAX_CONTENT_LENGTH}"

        return True, "Content valid"

    @staticmethod
    def sanitize(text: str) -> str:
        """Remove dangerous characters"""
        dangerous_patterns = [r'<script[^>]*>.*?</script>', r'javascript:', r'on\w+\s*=']
        result = text
        for pattern in dangerous_patterns:
            result = re.sub(pattern, '', result, flags=re.IGNORECASE | re.DOTALL)
        return result.strip()
