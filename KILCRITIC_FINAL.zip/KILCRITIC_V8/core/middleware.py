"""KILCRITIC V8 - Middleware"""
import time
from typing import Any, Callable, Dict
from .exceptions import TokenValidationError, PipelineError

class RequestLogger:
    """Request/response logging middleware"""

    def __init__(self):
        self.requests = []
        self.max_history = 100

    def log(self, method: str, status: str, duration: float, data: Dict = None) -> None:
        """Log request with minimal overhead"""
        if len(self.requests) >= self.max_history:
            self.requests = self.requests[-50:]

        self.requests.append({
            'timestamp': time.time(),
            'method': method,
            'status': status,
            'duration': duration,
            'data_size': len(str(data)) if data else 0
        })

    def get_stats(self) -> Dict[str, Any]:
        """Get request statistics"""
        if not self.requests:
            return {'total': 0, 'avg_duration': 0, 'last_status': 'none'}

        return {
            'total': len(self.requests),
            'avg_duration': sum(r['duration'] for r in self.requests) / len(self.requests),
            'last_status': self.requests[-1]['status'] if self.requests else 'none'
        }

class ErrorHandler:
    """Centralized error handling"""

    ERROR_CODES = {
        'INVALID_TOKEN': 401,
        'INVALID_CONTENT': 400,
        'RATE_LIMIT': 429,
        'SERVER_ERROR': 500,
        'NOT_FOUND': 404,
        'UNAUTHORIZED': 403
    }

    @staticmethod
    def handle(error_type: str, message: str, status_code: int = None) -> Dict[str, Any]:
        """Handle error with proper response"""
        code = status_code or ErrorHandler.ERROR_CODES.get(error_type, 500)
        return {
            'success': False,
            'error': error_type,
            'message': message,
            'code': code,
            'timestamp': time.time()
        }

    @staticmethod
    def safe_execute(func: Callable, *args, **kwargs) -> tuple:
        """Execute function safely, return (result, error)"""
        try:
            result = func(*args, **kwargs)
            return result, None
        except Exception as e:
            return None, str(e)

class RateLimiter:
    """Simple rate limiting"""

    def __init__(self, max_requests: int = 1000, window: int = 3600):
        self.max_requests = max_requests
        self.window = window
        self.requests = []

    def check(self, key: str = 'default') -> bool:
        """Check if request allowed"""
        now = time.time()
        self.requests = [t for t in self.requests if now - t < self.window]

        if len(self.requests) >= self.max_requests:
            return False

        self.requests.append(now)
        return True

    def get_remaining(self) -> int:
        """Get remaining requests in window"""
        now = time.time()
        self.requests = [t for t in self.requests if now - t < self.window]
        return max(0, self.max_requests - len(self.requests))
