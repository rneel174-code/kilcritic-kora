"""KILCRITIC V8 - Exception Handling"""

class KILCRITICException(Exception):
    """Base exception for KILCRITIC system"""
    pass

class TokenValidationError(KILCRITICException):
    """Token validation failed"""
    pass

class ContentValidationError(KILCRITICException):
    """Content validation failed"""
    pass

class PipelineError(KILCRITICException):
    """Pipeline execution error"""
    pass

class EngineError(KILCRITICException):
    """Engine processing error"""
    pass

class ConfigurationError(KILCRITICException):
    """Configuration error"""
    pass
