# KILCRITIC INFINITE — Coding Kit

This is an additive architecture starter kit for the KORA 8.8.5 baseline.
It is intentionally separated from the real production tree until the original
source ZIP is available.

Core flow:
REQUEST -> CONTEXT -> POLICY -> PLAN -> PERMISSION -> EXECUTE -> VERIFY -> LEARN

Hard rule:
Owner preferences can change configurable behavior, but cannot disable hard
security, legal, platform, permission, or resource protections.
