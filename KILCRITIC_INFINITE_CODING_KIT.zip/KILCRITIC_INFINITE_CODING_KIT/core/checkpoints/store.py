import json
from pathlib import Path

class Checkpoints:
    def __init__(self, root: Path):
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)

    def save(self, task_id, state):
        p = self.root / f"{task_id}.json"
        p.write_text(json.dumps(state, indent=2), encoding="utf-8")
        return p

    def load(self, task_id):
        p = self.root / f"{task_id}.json"
        if not p.exists():
            return None
        return json.loads(p.read_text(encoding="utf-8"))
