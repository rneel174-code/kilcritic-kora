from .models import Task, Risk, Verification
from .policy import evaluate

class KilcriticEngine:
    """Small governed execution kernel; production adapters belong around it."""

    def plan(self, task: Task) -> dict:
        return {
            "task_id": task.task_id,
            "goal": task.goal,
            "steps": ["understand", "policy", "permissions", "execute", "verify"],
            "risk": task.risk.value,
        }

    def authorize(self, action: str, task: Task) -> dict:
        return evaluate(action, task.risk)

    def verify(self, result) -> Verification:
        if result is None:
            return Verification("FAIL", notes=["No result"])
        return Verification("PASS", evidence=[{"type": "runtime_result", "present": True}])

    def execute_governed(self, task: Task, action: str, handler):
        decision = self.authorize(action, task)
        if decision["decision"] == "BLOCK":
            return {"status": "BLOCKED", "reason": decision["reason"]}
        if decision["decision"] == "APPROVAL_REQUIRED":
            return {"status": "PENDING_APPROVAL", "reason": decision["reason"]}
        result = handler()
        verification = self.verify(result)
        if verification.status != "PASS":
            return {"status": "FAILED", "verification": verification.__dict__}
        return {"status": "VERIFIED", "result": result, "verification": verification.__dict__}
