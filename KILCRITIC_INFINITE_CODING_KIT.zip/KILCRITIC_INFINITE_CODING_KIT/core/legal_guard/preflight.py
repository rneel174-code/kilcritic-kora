def preflight(asset: dict) -> dict:
    issues = []
    if asset.get("rights") == "UNKNOWN":
        issues.append("Rights are unknown; do not assume permission.")
    if asset.get("source") == "UNAUTHORIZED":
        issues.append("Unauthorized source.")
    if asset.get("duplicate_risk"):
        issues.append("Potential duplicate/reused content.")
    if asset.get("platform_risk"):
        issues.append("Potential platform-policy issue.")
    return {
        "status": "BLOCKED" if issues else "PASS",
        "issues": issues,
        "legal_guarantee": False,
    }
