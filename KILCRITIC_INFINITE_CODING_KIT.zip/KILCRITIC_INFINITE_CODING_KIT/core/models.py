from dataclasses import dataclass, field
from typing import Any, Dict, List
from enum import Enum
import uuid
from datetime import datetime, timezone

class Risk(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

class TruthState(str, Enum):
    VERIFIED = "VERIFIED"
    SOURCE_BASED = "SOURCE_BASED"
    TOOL_GENERATED = "TOOL_GENERATED"
    INFERRED = "INFERRED"
    UNCERTAIN = "UNCERTAIN"
    UNAVAILABLE = "UNAVAILABLE"

@dataclass
class Task:
    goal: str
    risk: Risk = Risk.LOW
    permissions: List[str] = field(default_factory=list)
    budget: Dict[str, Any] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

@dataclass
class Proposal:
    reason: str
    changes: List[Dict[str, Any]]
    risk: Risk
    tests: List[str]
    rollback: str
    proposal_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    approval: str = "PENDING"

@dataclass
class Verification:
    status: str
    evidence: List[Dict[str, Any]] = field(default_factory=list)
    rollback_required: bool = False
    notes: List[str] = field(default_factory=list)
