from .models import TruthState

def classify(value, evidence=None, user_preference=False, inferred=False):
    if user_preference:
        return TruthState.TOOL_GENERATED
    if evidence:
        return TruthState.SOURCE_BASED
    if inferred:
        return TruthState.INFERRED
    if value is None:
        return TruthState.UNAVAILABLE
    return TruthState.UNCERTAIN

def cannot_convert_preference_to_fact():
    return True
