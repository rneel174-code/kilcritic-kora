class CostGovernor:
    def __init__(self, daily_limit=0, monthly_limit=0):
        self.daily_limit = daily_limit
        self.monthly_limit = monthly_limit
        self.spent = 0

    def can_spend(self, estimate: float) -> bool:
        return self.spent + estimate <= self.daily_limit if self.daily_limit else True

    def reserve(self, estimate: float):
        if not self.can_spend(estimate):
            raise RuntimeError("Cost Governor: budget limit reached")
        return {"reserved": estimate}

    def settle(self, reserved: float, actual: float):
        self.spent += actual
        return {"reserved": reserved, "actual": actual, "remaining_daily": max(0, self.daily_limit-self.spent) if self.daily_limit else None}
