def simplify(ui_state: dict) -> dict:
    """Keep complexity inside the engine, not on the user."""
    state = dict(ui_state)
    state.setdefault("advanced_visible", False)
    state.setdefault("show_only_important_alerts", True)
    state.setdefault("smart_defaults", True)
    return state
