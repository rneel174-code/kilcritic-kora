from ..models import Risk

def can_auto_repair(risk: Risk) -> bool:
    return risk in {Risk.LOW, Risk.MEDIUM}

def repair_flow(detect, repair, test, verify, rollback):
    """PREVENT -> DETECT -> REPAIR -> TEST -> VERIFY -> ROLLBACK."""
    issue = detect()
    if not issue:
        return {"status": "NO_ISSUE"}
    repair()
    if not test():
        rollback()
        return {"status": "ROLLED_BACK"}
    if not verify():
        rollback()
        return {"status": "ROLLED_BACK"}
    return {"status": "REPAIRED"}
