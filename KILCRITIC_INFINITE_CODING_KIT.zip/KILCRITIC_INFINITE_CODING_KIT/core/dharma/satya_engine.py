from enum import Enum

class TruthClass(str, Enum):
    FACT = "FACT"
    USER_PREFERENCE = "USER_PREFERENCE"
    GOAL = "GOAL"
    SOURCE_BASED = "SOURCE_BASED"
    INFERRED = "INFERRED"
    UNCERTAIN = "UNCERTAIN"
    UNAVAILABLE = "UNAVAILABLE"

def classify_fact(value, evidence=None):
    if evidence:
        return TruthClass.SOURCE_BASED
    if value is None:
        return TruthClass.UNAVAILABLE
    return TruthClass.UNCERTAIN
