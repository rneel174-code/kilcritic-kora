"""Owner preference store.

Owner rules affect configurable behavior only.
They cannot override hard security, legal, platform, or permission constraints.
"""

from pathlib import Path
import json

DEFAULT = {
    "version": 1,
    "rules": {},
    "history": []
}

def load(path: Path) -> dict:
    if not path.exists():
        return DEFAULT.copy()
    return json.loads(path.read_text(encoding="utf-8"))

def set_rule(path: Path, key: str, value):
    data = load(path)
    data["version"] += 1
    data["rules"][key] = value
    data["history"].append({"key": key, "value": value, "version": data["version"]})
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return data
