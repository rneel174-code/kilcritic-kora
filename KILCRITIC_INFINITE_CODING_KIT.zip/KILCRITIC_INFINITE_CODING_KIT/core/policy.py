from .models import Risk

HARD_BLOCKS = {
    "BYPASS_AUTH",
    "BYPASS_DRM",
    "STEAL_CREDENTIALS",
    "UNAUTHORIZED_ACCESS",
    "OFFENSIVE_ATTACK",
    "SILENT_PAYMENT",
    "SILENT_PUBLISH",
}

HIGH_RISK = {
    "MODIFY_CODE",
    "INSTALL_PACKAGE",
    "RUN_PROCESS",
    "UPLOAD_EXTERNAL",
    "PUBLISH_SOCIAL",
    "SEND_MESSAGE",
    "DELETE_DATA",
    "CHANGE_SECURITY",
    "CHANGE_CREDENTIALS",
    "DEPLOY_APP",
}

def evaluate(action: str, requested_risk: Risk) -> dict:
    action = action.upper()
    if action in HARD_BLOCKS:
        return {"decision": "BLOCK", "reason": "Hard safety/security policy"}
    if action in HIGH_RISK or requested_risk in {Risk.HIGH, Risk.CRITICAL}:
        return {"decision": "APPROVAL_REQUIRED", "reason": "High-impact action"}
    return {"decision": "ALLOW_WITH_GUARDS", "reason": "Low/medium governed action"}
