"""Automatic defensive recovery; no offensive counterattack."""

def emergency_pipeline():
    return [
        "DETECT",
        "ISOLATE",
        "QUARANTINE",
        "FREEZE_EXTERNAL_SIDE_EFFECTS",
        "REVOKE_RISKY_PERMISSIONS",
        "PRESERVE_LOGS",
        "DIAGNOSE",
        "AUTO_REPAIR_SAFE_ISSUES",
        "TEST",
        "VERIFY",
        "ROLLBACK_IF_NEEDED",
        "RESTORE_TRUSTED_STATE",
        "SECURITY_CHECK",
        "SAFE_MODE",
        "RESUME_AFTER_VERIFICATION",
    ]
