class Sena:
    def __init__(self, max_agents=10):
        self.max_agents = max_agents

    def run_parallel(self, jobs, worker):
        jobs = list(jobs)[:self.max_agents]
        return [worker(job) for job in jobs]

    def clone_team(self, roles):
        return [{"role": role, "permissions": "least_privilege"} for role in roles]
