Store persistent state here only after applying encryption/access controls appropriate to the deployment.
Do not put raw secrets in source control.
