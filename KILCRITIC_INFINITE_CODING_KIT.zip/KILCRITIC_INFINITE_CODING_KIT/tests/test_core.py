from core.models import Task, Risk
from core.engine import KilcriticEngine
from core.policy import evaluate

def test_low_action_allows():
    task = Task("make draft")
    assert KilcriticEngine().authorize("READ_LOCAL_FILE", task)["decision"] == "ALLOW_WITH_GUARDS"

def test_high_action_requires_approval():
    task = Task("publish")
    assert KilcriticEngine().authorize("PUBLISH_SOCIAL", task)["decision"] == "APPROVAL_REQUIRED"

def test_hard_block():
    task = Task("unsafe")
    assert evaluate("BYPASS_AUTH", Risk.LOW)["decision"] == "BLOCK"
