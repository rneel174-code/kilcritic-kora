"""10.5 freeze-phase tests (T152+): external verification, handler trust coverage, resource governor, Malak webhooks/escalation."""
import hashlib, hmac, io, json, os, tempfile, time
from kora.core.db import init_db, get_connection
from kora.services import social, malak_assist as M


def _db():
    p = os.path.join(tempfile.mkdtemp(prefix="kora-fz-"), "f.db"); init_db(p); return p


class _Env:
    def __init__(self, **kw): self.kw, self.old = kw, {}
    def __enter__(self):
        for k, v in self.kw.items():
            self.old[k] = os.environ.get(k)
            if v is None: os.environ.pop(k, None)
            else: os.environ[k] = v
    def __exit__(self, *a):
        for k, v in self.old.items():
            if v is None: os.environ.pop(k, None)
            else: os.environ[k] = v


def _published(db, platform="X", ext="12345"):
    from kora.core.queue import DurableQueue
    env = {"X_OAUTH2_USER_TOKEN": "tok-SECRET-abc123456789"}
    r = social.create_social_post(platform, "hello " + ext, "GENERAL", db_path=db, auto_approve=False, queue=DurableQueue(db, retry_base=0), env=env, auto_publish=False, asset_meta={"rights": "OWNED", "source": "original"})
    c = get_connection(db)
    try: c.execute("UPDATE social_posts SET status='PUBLISHED', external_id=?, approved_by='owner' WHERE id=?", (ext, r["post_id"]))
    finally: c.close()
    return r["post_id"]


def social_verification_truth():
    db = _db(); env = {"X_OAUTH2_USER_TOKEN": "tok-SECRET-abc123456789"}
    pid = _published(db)
    ok = lambda m, u, h, b, t: (200, {}, json.dumps({"data": {"id": "12345"}}))
    assert social.run_verify(pid, db, env, ok)["state"] == "VERIFIED"
    p = social.get_post(pid, db); assert p["verification_state"] == "VERIFIED" and p["verified_at"]
    assert social.run_verify(pid, db, env, lambda *a: 1 / 0).get("already") is True  # idempotent, no second network call
    pid2 = _published(db, ext="999")
    assert social.run_verify(pid2, db, env, lambda *a: (404, {}, "{}"))["state"] == "NOT_FOUND"
    assert social.get_post(pid2, db)["verified_at"] is None
    pid3 = _published(db, ext="777")
    assert social.run_verify(pid3, db, {}, ok)["state"] == "UNVERIFIED"          # no credentials => never VERIFIED
    pid4 = _published(db, ext="555")
    def boom(*a): raise OSError("tok-SECRET-abc123456789 net down")
    try: social.run_verify(pid4, db, env, boom); raise AssertionError("network error must be retried, not a result")
    except RuntimeError as e: assert "tok-SECRET" not in str(e)
    assert social.get_post(pid4, db)["verification_state"] != "VERIFIED"
    c = get_connection(db)
    try:
        blob = json.dumps([tuple(r) for r in c.execute("SELECT verification_detail,last_error FROM social_posts").fetchall()])
    finally: c.close()
    assert "tok-SECRET" not in blob
    try: social.run_verify("missing", db, env, ok); raise AssertionError
    except Exception as e: assert "nothing_to_verify" in str(e) or "PermanentJob" in type(e).__name__


def every_handler_is_trust_runnable():
    from kora.core.worker import HANDLERS
    import kora.services.handlers  # noqa: F401 registers
    from kora.services import trust
    db = _db(); trust.sync_skills(HANDLERS, db)
    for name in ("scheduled_autopilot", "fortress_watchdog", "social_verify", "social_publish"):
        assert name in HANDLERS and name in trust.SKILL_META, name
    unknown = sorted(n for n in HANDLERS if n not in trust.SKILL_META and not n.startswith(("t_", "fz_")))  # t_*/fz_* = other tests' probes
    assert not unknown, "handlers invisible to trust gate (would be refused live): %s" % unknown


def worker_yields_under_pressure():
    from kora.core.queue import DurableQueue
    from kora.core.worker import WorkerPool, register_handler
    seen = []
    register_handler("fz_probe")(lambda p: (seen.append(1), {"ok": True})[1])
    db = _db(); q = DurableQueue(db, retry_base=0); q.enqueue("fz_probe", {})
    pool = WorkerPool(db, size=1, poll_seconds=0.05)
    flag = {"p": True}; pool.pressure_check = lambda: flag["p"]
    pool.start()
    try:
        time.sleep(0.6)
        assert not seen and pool.status()["yielded_under_pressure"] >= 1
        flag["p"] = False
        end = time.time() + 6
        while not seen and time.time() < end: time.sleep(0.1)
        assert seen, "work resumes when pressure clears"
    finally:
        pool.stop()


def resource_governor_and_bounded_http():
    from kora.services import runtime_limits as R
    from kora.bridge import server as S
    rss = R.current_rss_mb()
    assert rss is None or rss > 1
    lim = R.env_limits({"KORA_MAX_RSS_MB": "bad", "KORA_MIN_FREE_DISK_MB": "7"})
    assert lim.max_rss_mb == 1536 and lim.min_free_disk_mb == 7
    tight = R.ResourceLimits(max_rss_mb=1, min_free_disk_mb=1)
    if rss is not None:
        assert R.pressure(tight)["under_pressure"] and "rss_high" in R.pressure(tight)["reasons"]
        try: R.enforce(tight); raise AssertionError
        except R.ResourceLimitError: pass
    assert R.pressure(R.ResourceLimits(max_rss_mb=10**6, min_free_disk_mb=1))["under_pressure"] is False
    # bounded request threads: with no free slot the connection is refused with an honest 503
    import threading
    class Sock:
        data = b""; closed = False
        def sendall(self, b): self.data += b
    srv = S._Threaded.__new__(S._Threaded)
    old = S._Threaded._slots
    S._Threaded._slots = threading.BoundedSemaphore(1); S._Threaded._slots.acquire()
    shut = []
    srv.shutdown_request = lambda r: shut.append(r)
    try:
        s = Sock(); before = S._Threaded.rejected
        srv.process_request(s, ("127.0.0.1", 1))
        assert s.data.startswith(b"HTTP/1.1 503") and S._Threaded.rejected == before + 1 and shut
    finally:
        S._Threaded._slots = old


def _app(db):
    from dataclasses import replace
    from kora.bridge.api import KoraApp
    from kora.config.settings import load_settings
    app = KoraApp(replace(load_settings({}, dotenv_path="/nonexistent"), auth_token="tok-abcdef123456", rate_write_per_min=10**6), db_path=db)
    def call(method, path, body=None, headers=None, query="", raw=None):
        raw = raw if raw is not None else (json.dumps(body).encode() if body is not None else b"")
        env = {"REQUEST_METHOD": method, "PATH_INFO": path, "QUERY_STRING": query, "REMOTE_ADDR": "203.0.113.9", "HTTP_HOST": "127.0.0.1:8080",
               "CONTENT_LENGTH": str(len(raw)) if raw else "", "CONTENT_TYPE": "application/json" if raw else "", "wsgi.input": io.BytesIO(raw)}
        for k, v in (headers or {}).items(): env["HTTP_" + k.upper().replace("-", "_")] = v
        out = {}; b = b"".join(app(env, lambda s, h, e=None: out.update(s=int(s.split()[0]))))
        return out["s"], (json.loads(b) if b[:1] == b"{" else b)
    return app, call


def malak_webhooks_authenticated():
    db = _db(); app, call = _app(db)
    envs = {"KORA_MALAK_TELEGRAM_WEBHOOK_SECRET": None, "KORA_MALAK_TELEGRAM_CHAT_ID": None, "KORA_WHATSAPP_APP_SECRET": None,
            "KORA_WHATSAPP_VERIFY_TOKEN": None, "KORA_MALAK_WHATSAPP_TO": None, "KORA_MALAK_TELEGRAM_BOT_TOKEN": None}
    with _Env(**envs):
        tg = {"message": {"chat": {"id": 4242}, "text": "x"}}
        assert call("POST", "/api/malak-assist/webhook/telegram", tg)[0] == 503, "NOT_CONFIGURED must be truthful"
        assert call("POST", "/api/malak-assist/webhook/whatsapp", {"entry": []})[0] == 503
        assert call("GET", "/api/malak-assist/webhook/whatsapp", query="hub.mode=subscribe&hub.verify_token=a&hub.challenge=1")[0] == 503
    with _Env(**{**envs, "KORA_MALAK_TELEGRAM_WEBHOOK_SECRET": "whsec-1234567890", "KORA_MALAK_TELEGRAM_CHAT_ID": "4242"}):
        t = M.pause_for_malak("OTP", {"step": 1}, db_path=db)
        tid, code = t["task_id"], t["resume_token"]
        H = {"X-Telegram-Bot-Api-Secret-Token": "whsec-1234567890"}
        msg = lambda chat, text: {"message": {"chat": {"id": chat}, "text": text}}
        assert call("POST", "/api/malak-assist/webhook/telegram", msg(4242, f"{tid} {code}"))[0] == 401, "no secret header"
        assert call("POST", "/api/malak-assist/webhook/telegram", msg(4242, f"{tid} {code}"), headers={"X-Telegram-Bot-Api-Secret-Token": "wrong"})[0] == 401
        s, b = call("POST", "/api/malak-assist/webhook/telegram", msg(999, f"{tid} {code}"), headers=H)
        assert s == 200 and b["status"] == "REJECTED"                      # unauthorized sender
        s, b = call("POST", "/api/malak-assist/webhook/telegram", msg(4242, f"{tid} WRONG123"), headers=H)
        assert b["status"] != "RESUMABLE"                                  # wrong code
        assert "checkpoint" not in json.dumps(b) and code not in json.dumps(b)
        s, b = call("POST", "/api/malak-assist/webhook/telegram", msg(4242, f"{tid} {code}"), headers=H)
        assert b["status"] == "RESUMABLE", b
        s, b = call("POST", "/api/malak-assist/webhook/telegram", msg(4242, f"{tid} {code}"), headers=H)
        assert b["status"] != "RESUMABLE", "duplicate/replayed code rejected"
        c = get_connection(db)
        try: blob = " ".join(str(tuple(r)) for r in c.execute("SELECT details FROM audit_events").fetchall())
        finally: c.close()
        assert code not in blob and "whsec-1234567890" not in blob
    secret = "wa-app-secret-xyz"
    with _Env(**{**envs, "KORA_WHATSAPP_APP_SECRET": secret, "KORA_WHATSAPP_VERIFY_TOKEN": "vt-123456", "KORA_MALAK_WHATSAPP_TO": "+91 98765-43210"}):
        t = M.pause_for_malak("CAPTCHA", {"s": 2}, db_path=db)
        payload = {"entry": [{"changes": [{"value": {"messages": [{"type": "text", "from": "919876543210", "text": {"body": f"{t['task_id']} {t['resume_token']}"}}]}}]}]}
        raw = json.dumps(payload).encode()
        sig = "sha256=" + hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
        assert call("POST", "/api/malak-assist/webhook/whatsapp", raw=raw)[0] == 401
        assert call("POST", "/api/malak-assist/webhook/whatsapp", raw=raw, headers={"X-Hub-Signature-256": "sha256=" + "0" * 64})[0] == 401
        assert call("POST", "/api/malak-assist/webhook/whatsapp", raw=raw + b" ", headers={"X-Hub-Signature-256": sig})[0] == 401, "signature covers exact body"
        s, b = call("POST", "/api/malak-assist/webhook/whatsapp", raw=raw, headers={"X-Hub-Signature-256": sig})
        assert s == 200 and b["statuses"] == ["RESUMABLE"], b                 # +91 98765-43210 == 919876543210
        s, b = call("GET", "/api/malak-assist/webhook/whatsapp", query="hub.mode=subscribe&hub.verify_token=vt-123456&hub.challenge=777")
        assert s == 200 and b == b"777"
        assert call("GET", "/api/malak-assist/webhook/whatsapp", query="hub.mode=subscribe&hub.verify_token=bad&hub.challenge=777")[0] == 403


def malak_escalation_and_recovery():
    db = _db()
    with _Env(KORA_MALAK_TELEGRAM_BOT_TOKEN=None, KORA_MALAK_TELEGRAM_CHAT_ID=None, KORA_WHATSAPP_CLOUD_TOKEN=None):
        t = M.pause_for_malak("PAYMENT", {"k": 1}, db_path=db, ttl_seconds=3600)
        assert t["notifiers"][0]["status"] == "NOT_CONFIGURED"
        now = time.time()
        assert M.escalate_overdue(db, after=900, now=now + 10)["escalated"] == []          # too early
        r = M.escalate_overdue(db, after=900, now=now + 1000)["escalated"]
        assert len(r) == 1 and r[0]["sent"] is False, "never claim SENT without a real send"
        assert M.escalate_overdue(db, after=900, now=now + 1100)["escalated"] == []         # spaced out
        for i in range(2, 8): M.escalate_overdue(db, after=1, now=now + 1000 + i * 10)
        c = get_connection(db)
        try: n = c.execute("SELECT escalations FROM malak_assist_tasks").fetchone()[0]
        finally: c.close()
        assert n == M.MAX_ESCALATIONS, n
        # expired tasks are expired by tick, not reminded; restart recovery keeps waiting tasks
        t2 = M.pause_for_malak("OTP", {"k": 2}, db_path=db, ttl_seconds=60)
        assert M.recover(db)["waiting"]
        c = get_connection(db)
        try: c.execute("UPDATE malak_assist_tasks SET expires_at=1 WHERE id=?", (t2["task_id"],))
        finally: c.close()
        out = M.tick(db); assert t2["task_id"] in out["expired"]
        assert M.resume(t2["task_id"], t2["resume_token"], db_path=db, authenticated_sender=True)["status"] != "RESUMABLE", "expired code rejected"


def growth_roi_truth():
    from kora.services import growth_loop as G, dhanda
    db = _db()
    c = G.create_campaign("Bebe Samosa", "2 naal 1 free", platform="instagram", hook="peela", cta="QR", post_hour=19, roi_target=500, cost=100, db_path=db)["campaign_id"]
    assert G.roi(c, db)["state"] == "ROI_TARGET" and G.roi(c, db)["roi_pct"] is None
    G.record_event(c, "SALE", amount=1000, db_path=db)                                 # self-reported
    r = G.roi(c, db); assert r["state"] == "ROI_ESTIMATE" and r["revenue"]["verified"] == 0
    e = G.record_event(c, "SALE", amount=2000, source="manual", evidence_ref="photo-1", db_path=db); assert e["evidence_level"] == 2
    assert G.roi(c, db)["state"] == "ROI_MEASURED"
    e = G.record_event(c, "SALE", amount=3000, source="pos:paytm", evidence_ref="stmt-9", db_path=db); assert e["evidence_level"] == 3
    r = G.roi(c, db); assert r["state"] == "ROI_MEASURED" and r["headline_revenue"] == 5000.0 and r["roi_pct"] == 4900.0
    try: G.record_event(c, "SALE", amount=9999, ledger_id=424242, db_path=db); raise AssertionError("fake ledger link accepted")
    except ValueError: pass
    est = dhanda.add_entry("revenue", 4000, "paid", currency="INR", evidence="upi-ref-1", source="upi", db_path=db)
    est2 = dhanda.add_entry("revenue", 50, "unverified", currency="INR", db_path=db)
    try: G.record_event(c, "SALE", amount=50, ledger_id=est2["id"], db_path=db); raise AssertionError("unverified ledger accepted")
    except ValueError: pass
    assert G.record_event(c, "PAYMENT", amount=4000, ledger_id=est["id"], db_path=db)["evidence_level"] == 4
    r = G.roi(c, db); assert r["state"] == "ROI_VERIFIED" and r["headline_revenue"] == 4000.0, r
    assert G.attribution_link("https://shop.example.com/offer", c, "poster1")["url"].count("utm_campaign=") == 1
    for bad in ("http://shop.example.com", "https://localhost", "javascript:alert(1)"):
        try: G.attribution_link(bad, c); raise AssertionError(bad)
        except ValueError: pass
    try: G.record_event(c, "VIRAL", db_path=db); raise AssertionError
    except ValueError: pass


def growth_pilot_and_dna_truth():
    from kora.services import growth_loop as G
    db = _db()
    assert G.pilot_summary(db)["status"] == "TEST_PLAN" and G.pilot_summary(db)["condition_met"] == 0
    s = G.pilot_add_shop("Chaat Corner", "food", 7, db)["shop_id"]
    assert G.pilot_evaluate(s, db)["state"] == "INSUFFICIENT_EVIDENCE"
    for i in range(7):
        G.pilot_record(s, "BEFORE", f"2026-10-0{i+1}", 1000, source="manual", evidence_ref="book-photo", db_path=db)
        G.pilot_record(s, "AFTER", f"2026-10-1{i}", 1900, source="manual", evidence_ref="book-photo", db_path=db)
    r = G.pilot_evaluate(s, db); assert r["incremental_sales"] == 6300 and r["state"] == "UNVERIFIED", r      # photo-only evidence => no fee claim
    s2 = G.pilot_add_shop("Bakery", "food", 7, db)["shop_id"]
    for i in range(7):
        G.pilot_record(s2, "BEFORE", f"2026-10-0{i+1}", 1000, source="pos:vyapar", evidence_ref=f"b{i}", db_path=db)
        G.pilot_record(s2, "AFTER", f"2026-10-1{i}", 1900, source="pos:vyapar", evidence_ref=f"a{i}", db_path=db)
    assert G.pilot_evaluate(s2, db)["state"] == "CONDITION_MET_PENDING_MALAK"
    s3 = G.pilot_add_shop("Flat", "food", 7, db)["shop_id"]
    for i in range(7):
        G.pilot_record(s3, "BEFORE", f"2026-10-0{i+1}", 1000, source="pos:x", evidence_ref="r", db_path=db); G.pilot_record(s3, "AFTER", f"2026-10-1{i}", 1100, source="pos:x", evidence_ref="r", db_path=db)
    assert G.pilot_evaluate(s3, db)["state"] == "CONDITION_NOT_MET"
    sm = G.pilot_summary(db); assert sm["condition_met"] == 1 and sm["unverified"] == 1 and sm["not_met"] == 1 and sm["status"] == "TEST_PLAN"
    # Marketing DNA: no winner on thin data; winner only with >=3 evidenced campaigns; secrets never stored
    for hook, n in (("peela", 1), ("laal", 3)):
        for _ in range(n):
            c = G.create_campaign("m", "o", hook=hook, cost=100, db_path=db)["campaign_id"]
            G.record_event(c, "SALE", amount=1000, source="pos:x", evidence_ref="r", db_path=db)
    d = G.marketing_dna("hook", db); assert d["winner"] == "laal"
    g = {x["value"]: x for x in d["groups"]}; assert g["peela"]["status"] == "INSUFFICIENT_DATA" and g["laal"]["status"] == "SOURCE_BASED"
    c = G.create_campaign("m", "o", hook="Bearer sk-abcdefghijklmnopqrstuvwx", db_path=db)["campaign_id"]
    cn = get_connection(db)
    try: assert "sk-abcdef" not in cn.execute("SELECT hook FROM growth_campaigns WHERE id=?", (c,)).fetchone()[0]
    finally: cn.close()
    # competitor radar: unevidenced capability ranks below an evidenced one with equal scores
    G.competitor_add("A no evidence", impact=.9, feasibility=.9, db_path=db); G.competitor_add("B evidenced", source="https://x.example", public_evidence="public pricing page", impact=.9, feasibility=.9, db_path=db)
    rk = G.competitor_rank(db); assert rk[0]["capability"] == "B evidenced" and rk[1]["evidence"] == "UNVERIFIED"
    p = G.festival_plan("Lohri", "2027-01-13", "bakery", "pa", 7)
    assert len(p["plan"]) == 7 and all(i["state"] == "TEMPLATE_IDEA" for i in p["plan"]) and "yellow" not in json.dumps(p).lower()


def growth_api_wired():
    db = _db(); app, call = _app(db)
    H = {"Authorization": "Bearer tok-abcdef123456"}
    s, b = call("POST", "/api/growth/campaigns", {"merchant": "Shop", "offer": "2+1", "cost": 100, "roi_target": 300}, headers=H); assert s == 201, b
    cid = b["campaign_id"]
    assert call("GET", f"/api/growth/campaigns/{cid}/roi", headers=H)[1]["state"] == "ROI_TARGET"
    assert call("POST", f"/api/growth/campaigns/{cid}/events", {"kind": "SALE", "amount": 500}, headers=H)[0] == 201
    assert call("GET", f"/api/growth/campaigns/{cid}/roi", headers=H)[1]["state"] == "ROI_ESTIMATE"
    assert call("POST", f"/api/growth/campaigns/{cid}/events", {"kind": "BOT_CLICKS", "amount": 5}, headers=H)[0] == 400
    assert call("GET", "/api/growth/pilot", headers=H)[1]["status"] == "TEST_PLAN"
    assert call("GET", "/api/growth/pilot")[0] in (401, 403)


def backup_321_truth():
    from kora.services import backup as B
    d = tempfile.mkdtemp(prefix="kora-321-"); src = os.path.join(d, "a.db"); open(src, "wb").write(os.urandom(5000))
    c1, c2 = os.path.join(d, "c1.db"), os.path.join(d, "off", "c2.db"); os.makedirs(os.path.dirname(c2))
    import shutil; shutil.copy(src, c1); shutil.copy(src, c2)
    r = B.backup_321_report(src, [c1, c2], os.path.join(d, "off"), offsite_attested=False)
    assert r["status"] != "PASS" and r["offsite"] == "OFFSITE_UNVERIFIED", r                # never auto-PASS offsite
    r = B.backup_321_report(src, [c1, c2], os.path.join(d, "off"), offsite_attested=True)
    assert r["verified_copies"] == 3 and (r["status"] == "PASS") == (r["distinct_devices"] >= 2)   # same disk => cannot be 2 media
    open(c1, "ab").write(b"x")
    r = B.backup_321_report(src, [c1, src, "/nonexistent"], "", True)
    assert r["verified_copies"] == 1 and r["status"] == "FAIL", r                            # tampered / same-file / missing copies do not count
    assert B.backup_321_report("/nonexistent", [])["status"] == "FAIL"


def register(run_test):
    run_test("T152", "Social external verification: VERIFIED/NOT_FOUND/UNVERIFIED(no creds)/network-retry, idempotent, no token leak", social_verification_truth)
    run_test("T153", "Every registered queue handler is visible to the trust gate (none silently refused live)", every_handler_is_trust_runnable)
    run_test("T154", "Worker pool yields under RAM/disk pressure and resumes when it clears", worker_yields_under_pressure)
    run_test("T155", "Resource governor: current RSS, env limits, pressure, enforce; HTTP request threads bounded (503 when full)", resource_governor_and_bounded_http)
    run_test("T156", "Malak webhooks: Telegram secret + WhatsApp HMAC/verify-challenge, NOT_CONFIGURED=503, wrong sender/code/replay rejected, no secret in audit", malak_webhooks_authenticated)
    run_test("T157", "Malak escalation/timeout: spaced reminders capped, never claim SENT unsent, expired code rejected, restart recovery", malak_escalation_and_recovery)
    run_test("T158", "Growth loop: ROI_TARGET/ESTIMATE/MEASURED/VERIFIED computed from evidence, ledger link must be VERIFIED dhanda row, attribution link validated", growth_roi_truth)
    run_test("T159", "10-shop pilot evidence framework + Rs500 rule needs tool-verified before/after; Marketing DNA needs real samples; competitor radar ranks evidence first", growth_pilot_and_dna_truth)
    run_test("T160", "Growth API wired, authenticated, rejects fake event kinds", growth_api_wired)
    run_test("T161", "Backup 3-2-1 truth: byte-identical copies, distinct devices, offsite only owner-attested; tampered/duplicate/missing copies never count", backup_321_truth)
