#!/usr/bin/env python3
"""Optional browser-level check of the MOUNTED '/' HUD (needs: playwright for Python + a Chromium, and ffmpeg).
Usage:  python3 scripts/ui_mounted_check.py            (starts its own server on a free port with a temp DB/media dir)
Exit code 0 only if every assertion passed; prints NOT RUN (exit 2) when playwright/chromium/ffmpeg are missing.
Headless Chromium builds usually lack H.264, so playback is tested with a WebM fixture; the H.264 case must show the honest decode error."""
import os, shutil, socket, subprocess, sys, tempfile, time, urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        print("NOT RUN: playwright for Python is not installed"); return 2
    if not (shutil.which("ffmpeg") and shutil.which("ffprobe")):
        print("NOT RUN: ffmpeg/ffprobe missing"); return 2
    tmp = tempfile.mkdtemp(prefix="kora-ui-")
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    env = dict(os.environ, KORA_PORT=str(port), KORA_DB_PATH=os.path.join(tmp, "ui.db"), KORA_MEDIA_DIR=os.path.join(tmp, "media"), KORA_RATE_HEAVY_PER_MIN="100")
    for k in list(env):
        if k.endswith(("_KEY", "_TOKEN")): env.pop(k)
    webm, mp4 = os.path.join(tmp, "f.webm"), os.path.join(tmp, "f.mp4")
    for out, vc, ac in ((webm, "libvpx", "libvorbis"), (mp4, "libx264", "aac")):
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", "testsrc=duration=3:size=320x180:rate=15", "-f", "lavfi", "-i", "sine=duration=3", "-c:v", vc, "-c:a", ac] + (["-pix_fmt", "yuv420p"] if vc == "libx264" else []) + [out], check=True, timeout=60)
    srv = subprocess.Popen([sys.executable, os.path.join(ROOT, "run.py")], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    base = f"http://127.0.0.1:{port}"
    try:
        for _ in range(60):
            try: urllib.request.urlopen(base + "/api/health", timeout=1); break
            except Exception: time.sleep(0.25)
        bad = []
        def check(name, cond, info=""):
            print(("PASS " if cond else "FAIL ") + name, info); (bad.append(name) if not cond else None)
        with sync_playwright() as p:
            b = p.chromium.launch(args=["--no-sandbox", "--autoplay-policy=no-user-gesture-required"])
            for label, vp in (("mobile", {"width": 390, "height": 780}), ("desktop", {"width": 1280, "height": 800})):
                pg = b.new_page(viewport=vp); errs = []
                pg.on("pageerror", lambda e: errs.append(str(e))); pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
                pg.goto(base + "/"); pg.wait_for_timeout(800)
                check(label + ": state badge + command bar + task panel visible", pg.locator("#faceState").is_visible() and pg.locator("#homeCommand").is_visible() and pg.locator("#taskPanel").is_visible())
                check(label + ": 10 floating tool buttons", pg.locator(".fab").count() == 10)
                check(label + ": no horizontal scroll", pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
                box = pg.locator("#homeCommand").bounding_box(); check(label + ": command bar inside viewport", box and box["y"] + box["height"] <= vp["height"] and box["x"] >= 0)
                pg.fill("#homeCommand", "zzzz qqq"); pg.press("#homeCommand", "Enter"); pg.wait_for_timeout(600)
                check(label + ": unknown command gives examples, not success", "Try:" in pg.inner_text("#taskResult") and pg.inner_text("#taskState") != "COMPLETE")
                for q, want in (("daily plan Diwali sale", ("Top 3 outcomes", "no AI model used")), ("aaj da plan Diwali sale", ("Top 3 outcomes", "tuhade topic")), ("daily plan weekly plan", ("Which one", "PRD-03"))):
                    pg.fill("#homeCommand", q); pg.press("#homeCommand", "Enter"); pg.wait_for_timeout(600)
                    txt = pg.inner_text("#taskResult"); check(label + ": library '" + q + "' answers through the same bar", all(w in txt for w in want), txt[:80].replace("\n", " "))
                pg.click("[data-go='platform:Amazon']"); check(label + ": Amazon says NOT IMPLEMENTED", "NOT IMPLEMENTED" in pg.inner_text("#taskResult"))
                pg.fill("#homeCommand", "studio kholo"); pg.press("#homeCommand", "Enter"); pg.wait_for_timeout(500)
                check(label + ": 'studio kholo' opens Studio", pg.locator("#studio").is_visible())
                pg.set_input_files("#importFile", webm); pg.wait_for_timeout(2500)
                check(label + ": WebM imported and verified", "IMPORTED_VERIFIED" in pg.inner_text("#importStatus"), pg.inner_text("#importStatus"))
                v = pg.evaluate("(()=>{const v=document.querySelector('video');return v?[v.readyState,v.duration]:null})()"); check(label + ": video element loaded real media", bool(v and v[0] >= 1 and v[1] > 2), str(v))
                pg.click("#pPlay"); pg.wait_for_timeout(800); t1 = pg.evaluate("document.querySelector('video').currentTime"); pl = pg.evaluate("!document.querySelector('video').paused")
                check(label + ": Play moves the real media clock", pl and t1 > 0.2, str(t1))
                pg.click("#pPause"); pg.wait_for_timeout(150); check(label + ": Pause pauses", pg.evaluate("document.querySelector('video').paused"))
                pg.evaluate("(()=>{const s=document.getElementById('pSeek');s.value=500;s.dispatchEvent(new Event('input'))})()"); pg.wait_for_timeout(250)
                check(label + ": Seek moves to ~50%", abs(pg.evaluate("document.querySelector('video').currentTime") - 1.5) < 0.3)
                pg.click("#pStop"); check(label + ": Stop resets to 0", pg.evaluate("document.querySelector('video').currentTime") == 0)
                pg.fill("#trStart", "0.5"); pg.fill("#trEnd", "2.0"); pg.click("[data-edit=trim]"); pg.wait_for_timeout(3500)
                check(label + ": Trim creates a verified new file", "verified by ffprobe" in pg.inner_text("#taskResult"), pg.inner_text("#taskResult")[:90])
                pg.click("#undoBtn"); pg.wait_for_timeout(1200); check(label + ": Undo reloads the previous asset", "f.webm" in pg.inner_text("#stageMsg") or "f-" in pg.inner_text("#stageMsg"), pg.inner_text("#stageMsg")[:60])
                pg.fill("#projName", "uicheck"); pg.click("#saveDraft"); pg.wait_for_timeout(700); check(label + ": draft saved (local, not published)", "Not published" in pg.inner_text("#taskResult"))
                pg.click("#approvalBtn"); pg.fill("#pubText", "hello"); pg.click("#pubDraft"); pg.wait_for_timeout(900)
                check(label + ": 'save for approval' creates a pending item and says NOT published", "NOT published" in pg.inner_text("#pubResult") and pg.inner_text("#taskState") == "NEEDS APPROVAL", pg.inner_text("#pubResult")[:110])
                pg.click("#back"); pg.click("#advanced"); pg.click("[data-sys=audit]"); pg.wait_for_timeout(700)
                check(label + ": Advanced → Audit chain answers", '"ok": true' in pg.inner_text("#sysOut"))
                check(label + ": no JS errors", not errs, str(errs[:2])); pg.close()
            pg = b.new_page(); pg.goto(base + "/"); pg.click("#masterFolder"); pg.click("[data-cat=studio]"); pg.set_input_files("#importFile", mp4); pg.wait_for_timeout(2500)
            msg = pg.inner_text("#stageMsg"); h264 = pg.evaluate("document.createElement('video').canPlayType('video/mp4; codecs=\"avc1.42E01E\"')")
            check("H.264 handling is honest (" + ("browser supports H.264" if h264 else "this Chromium cannot decode H.264") + ")", bool(h264) or "cannot be decoded" in msg, msg[:80])
            b.close()
        print("RESULT:", "PASS" if not bad else "FAIL " + str(bad)); return 0 if not bad else 1
    finally:
        srv.terminate()
        try: srv.wait(timeout=10)
        except Exception: srv.kill()
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
