// KORA UI intent router (pure, no DOM). Voice, text and touch ALL pass through dispatch() in creator.js, which calls this first.
// Anything that is not a clear local UI action goes to the one backend dispatcher (/api/brain). Nothing here publishes, pays or deletes.
(function(root){
  var RULES=[
    {act:'open_studio',rx:/\b(studio\s*(kholo|open|khol)|open\s*(the\s*)?(studio|media\s*folder)|media\s*folder\s*(kholo|open))\b/i},
    {act:'play',rx:/\b(preview\s*chalao|video\s*preview\s*chalao|play(\s*karo)?|chalao)\b/i},
    {act:'pause',rx:/\b(pause(\s*karo)?|rok(o)?)\b/i},
    {act:'stop',rx:/\b(stop(\s*karo)?|band\s*karo)\b/i},
    {act:'back',rx:/\b(pichhe\s*jao|pichhe|wapas\s*jao|go\s*back|back)\b/i},
    {act:'save_draft',rx:/\b(draft\s*save(\s*karo)?|save\s*(the\s*)?draft)\b/i},
    {act:'open_advanced',rx:/\b(advanced|system\s*panel|technical)\b/i}
  ];
  var HIGH=/\b(publish|post\s*kar|post\s*now|upload\s*to|purchase|buy|pay|delete|remove\s*all|charge)\b/i;
  function parse(text){
    var t=String(text||'').trim();
    if(!t)return {act:'empty'};
    for(var i=0;i<RULES.length;i++){if(RULES[i].rx.test(t))return {act:RULES[i].act,text:t,high_impact:false};}
    return {act:'brain',text:t,high_impact:HIGH.test(t)};
  }
  // Context resolution: media verbs only act locally when something is loaded; otherwise the brain gets them (e.g. "pause <task>").
  function resolve(intent,ctx){
    ctx=ctx||{};
    if((intent.act==='play'||intent.act==='pause'||intent.act==='stop')&&!ctx.mediaLoaded)return {act:'brain',text:intent.text,high_impact:false};
    if(intent.act==='save_draft'&&!ctx.studioOpen)return {act:'brain',text:intent.text,high_impact:false};
    return intent;
  }
  var api={parse:parse,resolve:resolve,STATES:['IDLE','LISTENING','THINKING','WORKING','NEEDS APPROVAL','ERROR','COMPLETE']};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.KoraIntent=api;
})(typeof window!=='undefined'?window:this);
