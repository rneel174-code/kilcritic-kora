"""Hollywood Studio orchestration contracts: original creation, quality and rights gates."""
from __future__ import annotations
from typing import Any, Dict

CATEGORIES = ("MOVIE_CINEMATIC", "FUNNY", "FUNNY_BABY", "CARTOON_ANIMATION", "REEL_SHORT", "STORY_SHORT_FILM",
              "PHOTO_TO_CINEMATIC", "GRAPHICS_VFX_MOTION", "AUDIO_VOICE_SFX", "SCRIPT_SUBTITLE", "COLOR_HDR", "ORIGINAL_AI")

STEPS = ("IMPORT", "DISCOVER", "RIGHTS", "ORIGINALITY", "EDIT", "COLOR", "VFX", "AUDIO", "SUBTITLES", "QUALITY", "PLATFORM", "PREVIEW", "APPROVAL", "POST", "VERIFY", "LEARN")

def quality_preflight(metrics: Dict[str, Any]) -> Dict[str, Any]:
    checks = {
        "resolution": bool(metrics.get("width", 0) and metrics.get("height", 0)),
        "duration": metrics.get("duration_s", 0) > 0,
        "frames": metrics.get("black_frame_ratio", 0) < 0.20,
        "audio": metrics.get("audio_clipping", False) is False,
        "subtitle_sync": metrics.get("subtitle_sync_ok", True) is True,
        "artifact": metrics.get("artifact_risk", False) is False,
    }
    return {"decision": "PASS" if all(checks.values()) else "REVIEW", "checks": checks, "measured": True}

def studio_plan(category: str, *, original: bool = True, manual: bool = True, automatic: bool = True) -> Dict[str, Any]:
    category = category.strip().upper()
    if category not in CATEGORIES:
        raise ValueError("unsupported studio category")
    return {"category": category, "automatic": automatic, "manual": manual, "original_required": original,
            "steps": list(STEPS), "copyright_guarantee": False,
            "rule": "original/authorized material only; exact unauthorized film/identity/voice copying is blocked or reviewed"}


# ---------------------------------------------------------------------------------------------- draft projects (PATCH4 additive)
import json as _json
import os as _os
import re as _re
import time as _time

_PROJ_RX = _re.compile(r"^[A-Za-z0-9][A-Za-z0-9 _.-]{0,59}$")
PROJECT_MAX_BYTES = 64 * 1024


def _proj_dir(media_root: str) -> str:
    d = _os.path.join(_os.path.realpath(media_root), "projects")
    _os.makedirs(d, exist_ok=True)
    return d


def _proj_path(media_root: str, name: str) -> str:
    if not isinstance(name, str) or not _PROJ_RX.match(name) or ".." in name:
        raise ValueError("invalid_project_name")
    return _os.path.join(_proj_dir(media_root), name.replace(" ", "_") + ".json")


def save_project(media_root: str, name: str, data: Dict[str, Any]) -> Dict[str, Any]:
    """Draft autosave: a bounded JSON document (asset id + ordered edit operations + notes). Local only; never publishes."""
    if not isinstance(data, dict):
        raise ValueError("project_must_be_object")
    raw = _json.dumps(data, sort_keys=True).encode("utf-8")
    if len(raw) > PROJECT_MAX_BYTES:
        raise ValueError("project_too_large")
    p = _proj_path(media_root, name)
    rev = 1
    if _os.path.isfile(p):
        try:
            rev = int(_json.load(open(p, encoding="utf-8")).get("revision", 0)) + 1
        except Exception:
            rev = 1
    doc = {"name": name, "revision": rev, "saved_at": int(_time.time()), "state": "DRAFT_LOCAL", "data": data}
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        _json.dump(doc, fh)
    _os.replace(tmp, p)
    return {"name": name, "revision": rev, "state": "DRAFT_LOCAL"}


def load_project(media_root: str, name: str) -> Dict[str, Any]:
    p = _proj_path(media_root, name)
    if not _os.path.isfile(p):
        raise ValueError("project_not_found")
    return _json.load(open(p, encoding="utf-8"))


def list_projects(media_root: str) -> list:
    d = _proj_dir(media_root)
    out = []
    for f in sorted(_os.listdir(d)):
        if f.endswith(".json"):
            try:
                doc = _json.load(open(_os.path.join(d, f), encoding="utf-8"))
                out.append({"name": doc.get("name", f[:-5]), "revision": doc.get("revision"), "saved_at": doc.get("saved_at")})
            except Exception:
                continue
    return out
