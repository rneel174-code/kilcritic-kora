"""KILCRITIC command library (Phase 2): 100 deterministic, OFFLINE command templates behind the EXISTING brain dispatcher.

Not an engine and not an LLM. `kora.services.brain.handle()` stays the only dispatcher; when none of its original intents match,
it asks `resolve()` here. Matching is plain token matching of normalised aliases (English / Roman Punjabi / Roman Hindi, plus a few
Gurmukhi and Devanagari aliases). The result is a fill-in scaffold (headings), clearly labelled "local template - no AI model used".
Nothing is sent, published, bought or executed. Ambiguity (two commands with the same best score) and unknown input never guess:
they return NEEDS_CLARIFICATION with candidates. No network, no paid API, no credentials.

CONTENT PROVENANCE: the uploaded/original "100-command library" file was NOT available, so these 100 entries are a designed set
(DESIGNED_SET) across the five roadmap categories. They are data (the DSL below) and can be replaced by the owner's own list
without touching the matcher.
"""
import re
import unicodedata
from typing import Any, Dict, List, Optional, Tuple

from kora.core.logger import redact_text

PROVENANCE = "DESIGNED_SET"
CATEGORIES = {"LRN": "Learning", "DEC": "Decision", "WRT": "Professional writing", "BIZ": "Business / creative", "PRD": "Productivity"}

# ID|Title|English aliases|Roman Punjabi aliases|Roman Hindi aliases|sections (comma = alias separator, / = section separator)
_DSL = """
LRN-01|Explain simply|explain simply,explain like i am five|saukha samjha,saukha samjhao|aasan samjhao,saral bhasha mein samjhao|One-line meaning/Everyday analogy/Step-by-step breakdown/Common mistakes/Check yourself (2 questions)
LRN-02|Summarize text|summarize this,tldr|saar dasso,chhota summary kar|saransh batao,sankshep mein batao|Main point in one sentence/5 key points/Details worth keeping/What to ignore/Next action
LRN-03|Study plan|study plan,exam study plan|padhai da plan,padhai plan|padhai ki yojana,padhai ka plan|Goal and exam date/Topics list/Daily time blocks/Weekly review/Backup day
LRN-04|Quiz me|quiz me,test me|mera quiz lao,meri test lao|mera quiz lo,mujhe quiz do|5 easy questions/5 medium questions/3 hard questions/Answer key (fill after attempting)/Weak areas to revise
LRN-05|Flashcards|flashcards,flash cards|flashcard bana,flashcard dasso|flashcard dikhao,flashcard batao|Term and meaning pairs (10)/Example for each/Memory trick/Review schedule (1-3-7 days)
LRN-06|Key points|key points,main points|mukh gallan,main gallan|mukhya baatein,mukhya bindu|Top 5 points/Why each matters/One example each/One open question
LRN-07|Compare topics|compare topics,difference between|farak dasso,vich farak|antar batao,farq batao|Both items defined/Side-by-side differences/Where they overlap/When to use which/One-line verdict
LRN-08|Glossary|glossary,key terms|shabdavali,mukh shabd|shabdkosh,mukhya shabd|Term/Plain meaning/Example sentence/Related term
LRN-09|Mind map outline|mind map,mind map outline|mind map dasso,mind map bana|mind map banao,mind map dikhao|Central idea/Main branches (4-6)/Sub-points/Links between branches
LRN-10|Lesson plan|lesson plan,teaching plan|lesson plan dasso,sikhaun da plan|paath yojana,padhane ka plan|Learning goal/Warm-up/Main activity/Practice/Recap and homework
LRN-11|Revision notes|revision notes,exam notes|revision de notes,exam de notes|revision ke notes,pariksha notes|Formulas and definitions/Must-remember list/Common traps/Last-day checklist
LRN-12|Analogy|analogy for,give analogy|analogy dasso,misaal nal samjha|udaharan se samjhao,upma batao|Concept/Analogy from daily life/Where the analogy breaks/Correct version
LRN-13|Practice questions|practice questions,practice problems|practice de sawal,abhyas de sawal|abhyas prashn,practice ke sawal|Warm-up questions/Application questions/Challenge question/Worked solution outline
LRN-14|Daily learning routine|daily learning routine,learning habit|roz sikhan da routine,roz padhan di aadat|roz seekhne ka routine,seekhne ki aadat|Fixed time slot/25-minute focus block/Note-taking step/Review step/Weekly reflection
LRN-15|Reading list|reading list,books to read|padhan wali list,kitaban di list|padhne ki suchi,kitabon ki list|Beginner picks/Intermediate picks/Advanced picks/Free sources first/Order to read
LRN-16|Teach-back check|teach back,feynman method|khud samjha ke dekho,teach back dasso|khud samjhakar dekho,teach back batao|Explain in own words/Gaps found/Re-study list/Re-explain
LRN-17|Skill roadmap|skill roadmap,learning roadmap|hunar da roadmap,sikhan da roadmap|kaushal roadmap,seekhne ka roadmap|Starting level/Milestones (30-60-90 days)/Practice projects/Resources (free first)/How to measure progress
LRN-18|Cheat sheet|cheat sheet,quick reference|cheat sheet dasso,jhat reference|cheat sheet dikhao,quick reference batao|Core commands or formulas/Common patterns/Gotchas/Where to look up more
LRN-19|Interview prep|interview prep,interview questions|interview di tayyari,interview de sawal|interview ki taiyari,interview ke sawal|Likely questions/Answer structure (STAR)/Your 3 stories/Questions to ask them/Day-before checklist
LRN-20|Language practice|language practice,vocabulary practice|bhasha da abhyas,shabd yaad karo|bhasha ka abhyas,shabd abhyas karo|Today's 10 words/Sentences using them/Speaking drill/Listening source (free)/Review tomorrow
DEC-01|Pros and cons|pros and cons,pros cons|faide nuksaan,faide te nuksan|fayde nuksan,labh haani|Option/Pros/Cons/Hidden costs/Leaning and why
DEC-02|Decision matrix|decision matrix,weighted decision|faisle da matrix,matrix nal faisla|nirnay matrix,matrix se faisla|Options/Criteria/Weights (1-5)/Scores/Total and winner
DEC-03|SWOT analysis|swot,swot analysis|swot dasso,swot vekh|swot batao,swot dikhao|Strengths/Weaknesses/Opportunities/Threats/Actions from the SWOT
DEC-04|Risk checklist|risk checklist,risk list|khatre di list,jokham di list|jokhim suchi,khatre ki list|What can go wrong/Likelihood/Impact/Prevention/Fallback
DEC-05|Compare options|compare options,which option|options de farak,kehda option|vikalp tulna,kaun sa vikalp|Options/Must-haves/Cost/Time/Reversibility/Leaning
DEC-06|Next best action|next best action,what should i do next|agla kam ki,hun ki karaan|agla kadam,ab kya karu|Goal/Smallest next step/Blocker/Time needed/Done when
DEC-07|Priority score|priority score,rank tasks|pehlan ki karaan,prathmikta score|prathamikta score,kaam ka kram|Task list/Impact (1-5)/Effort (1-5)/Urgency/Order
DEC-08|Go / no-go|go no go,go or no go|karaan jan nahi,karna ya nahi|karun ya nahi,karna hai ya nahi|Decision statement/Must-pass conditions/Evidence so far/Missing information/Verdict (go / no-go / wait)
DEC-09|Premortem|premortem,pre mortem|pehlan ton fail soch,fail hon de karan|pehle se fail socho,asafal hone ke karan|Imagine it failed/Top 5 reasons/Early warning signs/Prevent each/Contingency
DEC-10|Cost-benefit|cost benefit,cost benefit analysis|lagat labh,kharcha te fayda|lagat labh vishleshan,kharcha aur fayda|Costs (money/time/effort)/Benefits/Timeline/Net view/Uncertainty
DEC-11|Reversibility check|reversible or not,undo check|ulat sakda ya nahi,wapas ho sakda|ulta ho sakta hai,wapas ho sakta hai|Can it be undone?/Cost of undoing/Time window/Safer smaller test
DEC-12|10-10-10 rule|10 10 10 rule,ten ten ten|10 10 10 wala niyam,das das das|das das das niyam,10 10 10 niyam|Feeling in 10 minutes/Feeling in 10 months/Feeling in 10 years/Decision
DEC-13|Regret check|regret check,regret minimization|pachtaava check,pachtaave to bachna|pachtava jaanch,pachtave se bachna|Option A regret/Option B regret/What I would advise a friend/Choice
DEC-14|Assumptions list|assumptions list,list assumptions|mannyataavan di list,mandi hoyi gallan|manyatayein suchi,manyataon ki list|Assumption/Evidence for/Evidence against/How to test cheaply
DEC-15|Trade-off table|trade off,tradeoff table|ki chhadna pau,trade off dasso|kya chhodna padega,trade off batao|Gain/Give up/Who is affected/Reversible?/Acceptable?
DEC-16|Weekly decision review|weekly decision review,week review|hafte da review,hafte di samiksha|saptah samiksha,hafte ka review|Decisions made/Outcomes/What I would change/Rule for next week
DEC-17|Criteria weights|criteria weights,what matters most|sab ton zaroori ki,mukh sharta|sabse zaroori kya,mukhya maapdand|Candidate criteria/Rank them/Assign weights/Sanity check
DEC-18|Scenario planning|scenario planning,best worst case|best te worst case,teen scenario|teen sthitiyan,achha bura saamanya|Best case/Likely case/Worst case/Triggers/Plan per scenario
DEC-19|Stop rule|stop loss rule,quit rule|kado rukna,chhaddan da niyam|kab rukna hai,chhodne ka niyam|Maximum I will spend/Time limit/Signal to stop/Who I tell
DEC-20|Second opinion|second opinion,devils advocate|dooja nazariya,ulta pakkh|doosra nazariya,vipaksh ki baat|My view/Strongest counter-argument/What I may be missing/Who to ask/Revised view
WRT-01|Email draft|email draft,draft an email|email likh,email da draft|email likho,email ka draft|Subject line/Greeting/Purpose in one line/Details/Ask and deadline/Sign-off
WRT-02|Follow-up email|follow up email,follow up message|follow up email likh,dubara yaad karwao|follow up mail likho,yaad dilao email|Subject (Re:)/Reference to last contact/Gentle reminder/Clear next step/Thanks
WRT-03|Apology email|apology email,apology message|maafi di email,maafi wala message|maafi ka email,kshama patra|Acknowledge/Own the mistake/Impact/Fix and timeline/Closing
WRT-04|Meeting agenda|meeting agenda,agenda for meeting|meeting da agenda,meeting di agenda|meeting ka agenda,baithak ka agenda|Objective/Attendees/Topics with time/Decisions needed/Pre-reads
WRT-05|Meeting minutes|meeting minutes,minutes of meeting|meeting de minutes,meeting di report|meeting ke minutes,baithak ka vivaran|Date and attendees/Decisions/Action items with owner/Open questions/Next meeting
WRT-06|CV bullets|cv bullets,cv points|cv de bullet,cv de points|cv ke bullet,cv ke points|Action verb/What you did/Result with a real number/Tool or skill used
WRT-07|Cover letter|cover letter,job application letter|cover letter likh,naukri di arzi|cover letter likho,naukri ka aavedan|Opening hook/Why this role/Two proof points (real only)/Why this company/Closing
WRT-08|LinkedIn post|linkedin post,professional post|linkedin post likh,linkedin layi post|linkedin post likho,linkedin ke liye post|Hook line/Story or insight/Lesson/Call to conversation
WRT-09|Proposal outline|proposal outline,project proposal|proposal da dhancha,proposal di rooprekha|proposal ka dhancha,prastav ruprekha|Problem/Proposed solution/Scope and deliverables/Timeline/Price (your own number)/Next step
WRT-10|Report outline|report outline,report structure|report da dhancha,report di banawat|report ka dhancha,report ki sanrachna|Title and summary/Background/Findings/Recommendations/Appendix
WRT-11|Progress update|progress update,work update|kam di update,progress di khabar|kaam ki update,pragati ki jaankari|Done since last update/In progress/Blocked/Next/Help needed
WRT-12|Thank-you note|thank you note,thanks message|shukriya message,dhanwad note|shukriya sandesh,dhanyavaad patra|Specific thanks/What it enabled/Warm close
WRT-13|Polite decline|polite decline,say no politely|pyar naal na kar,namrta naal inkar|vinamrata se mana karo,vinamr inkar|Thanks/Clear no/Brief reason (optional)/Alternative/Warm close
WRT-14|Feedback message|feedback message,give feedback|feedback dena,feedback sandesh likh|feedback sandesh,feedback likho|Situation/Behaviour/Impact/Suggestion/Support offered
WRT-15|Announcement|announcement,team announcement|ailan likh,elaan likh|ghoshna likho,suchna likho|What is happening/Who it affects/When/What to do/Contact
WRT-16|Job description|job description,role description|naukri da vivaran,kam da vivaran|naukri ka vivaran,pad ka vivaran|Role summary/Responsibilities/Must-have skills/Nice-to-have/How to apply
WRT-17|Reference request|reference request,ask for reference|reference mangna,reference layi request|reference maangna,reference ke liye anurodh|Context/Why them/What to highlight/Deadline/Thanks
WRT-18|Complaint letter|complaint letter,complaint email|shikayat patar,shikayat di email|shikayat patra,shikayat ka email|Facts and dates/What went wrong/Impact/Requested fix/Deadline
WRT-19|Press note|press note,press release|press note likh,akhbaar layi note|press note likho,samachar vijnapti|Headline/What and who/Quote placeholder (never invent a quote)/Background/Contact
WRT-20|SOP outline|sop outline,standard procedure|sop da dhancha,kam karan da tarika|sop ka dhancha,karya vidhi|Purpose/Scope/Roles/Steps/Checks/Revision log
BIZ-01|Idea validation|idea validation,validate my idea|idea parakh,idea di jaanch|vichar parakho,idea ki jaanch|Problem/Who has it/Existing alternatives/Cheapest test/Signal that proves it
BIZ-02|Offer pitch|offer pitch,elevator pitch|pitch dasso,pitch likh|pitch batao,pitch likho|Who it is for/Pain/Your offer/Proof (real only)/Call to action
BIZ-03|Product description|product description,item description|product da vivaran,cheez di description|utpad vivaran,saaman ka vivaran|Headline/Benefits/Specs (real only)/Who it fits/FAQ
BIZ-04|Ad copy|ad copy,advert text|ad copy likh,ishtihar likh|vigyapan likho,ad copy likho|Hook/Benefit/Proof placeholder (real only)/Call to action/Platform policy check
BIZ-05|Tagline ideas|tagline ideas,slogan ideas|tagline dasso,slogan dasso|slogan batao,tagline batao|10 short options/Tone of each/Shortlist of 3/Availability check (manual)
BIZ-06|Content calendar|content calendar,posting plan|content calendar dasso,post da plan|content calendar banao,posting yojana|Goal and audience mode (Kids / General-Mixed / Adult 18+)/Weekly themes/Day-by-day slots/Formats/Review metrics (real data only)
BIZ-07|Video script outline|video script,script outline|script da dhancha,video script dasso|script ka dhancha,video script batao|Hook (first 3 seconds)/Setup/Main beats/Payoff/Call to action/Rights check for music and clips
BIZ-08|Reel hook ideas|reel hooks,hook ideas|reel hook dasso,hook de idea|reel hook batao,hook ke vichar|10 hook lines/Pattern of each/Best 3/Caption pairing
BIZ-09|Story outline|story outline,plot outline|kahani da dhancha,kahani di rooprekha|kahani ka dhancha,kahani ki ruprekha|Characters/Setting/Beginning/Conflict/Climax/Ending
BIZ-10|Brand voice|brand voice,tone of voice|brand di awaaz,brand da lehja|brand ki awaaz,brand ka lehja|Three adjectives/Words to use and avoid/Sample line/Audience fit
BIZ-11|Customer persona|customer persona,ideal customer|graahak persona,asli graahak|grahak parichay,aadarsh grahak|Who/Goal/Pain/Where they look/Objection/Message that fits
BIZ-12|Pricing tiers|pricing tiers,price plan|keemat de tier,rate de plan|mulya star,daam ke plan|Tier names/Included in each/Anchor tier/Cost check/Test plan (no revenue claims)
BIZ-13|Lead message|lead message,first outreach message|pehla message likh,sampark message|pehla sandesh likho,sampark sandesh|Personal line/Reason for contact/Value/Easy opt-out/No-pressure close (template only: nothing is sent)
BIZ-14|FAQ page|faq,faq page|faq likh,aam sawal|faq likho,aam sawal likho|Top questions/Short answers/Policy links/Contact route
BIZ-15|YouTube titles|youtube titles,title ideas|youtube de title,title de idea|youtube ke title,title ke vichar|10 titles/Keyword in each/Curiosity vs clarity/No-clickbait-lies check/Pick 3
BIZ-16|Caption ideas|caption ideas,post captions|caption dasso,post de caption|caption batao,post ke caption|5 captions/Length mix/Call to action/Hashtag set (relevant only)
BIZ-17|Podcast outline|podcast outline,episode outline|podcast da dhancha,episode da dhancha|podcast ka dhancha,episode ka dhancha|Title/Intro hook/Segments with timing/Guest questions/Outro
BIZ-18|Newsletter outline|newsletter outline,newsletter plan|newsletter da dhancha,newsletter da plan|newsletter ka dhancha,newsletter ki yojana|Subject lines/Lead story/2-3 sections/Link list/Sign-off
BIZ-19|Launch checklist|launch checklist,go live checklist|launch di checklist,live hon di checklist|launch ki checklist,shuruaat ki checklist|Offer ready/Page ready/Legal and rights/Support ready/Announce/Review after 7 days
BIZ-20|Competitor scan|competitor scan,competitor notes|muqable di jaanch,competitor de notes|pratispardhi jaanch,competitor ke notes|Who competes/What they offer/Gaps/Your angle/Sources (cite real ones; none are invented here)
PRD-01|To-do prioritiser|prioritise tasks,prioritize tasks,todo list,to do list|kamaan di list,kamaan nu ranking|kaamon ki suchi,kaam chhantni|Capture everything/Mark must-do today/Estimate time/Order/Defer or drop
PRD-02|Daily plan|daily plan,plan my day|roz da plan,aaj da plan|aaj ka plan,din ki yojana|Top 3 outcomes/Time blocks/Buffer/Evening review
PRD-03|Weekly plan|weekly plan,plan my week|hafte da plan,is hafte di yojana|saptah yojana,is hafte ka plan|Weekly goals/Fixed commitments/Daily themes/Buffer/Friday review
PRD-04|Pomodoro plan|pomodoro,pomodoro plan|pomodoro di vidhi,25 minute focus|pomodoro ka plan,25 minute ka focus|Task per block/25 on 5 off/Long break after 4/Log blocks
PRD-05|Habit tracker|habit tracker,habit plan|aadat di list,aadat tracker|aadat ka plan,aadat sudhaar|Tiny habit/Trigger/Reward/Tracking grid/Recovery rule after a miss
PRD-06|Goal breakdown|goal breakdown,break down goal|goal de tukde,goal tode|lakshya vibhajan,lakshya ke tukde|Big goal/Milestones/Weekly actions/First 15-minute step/Evidence of progress
PRD-07|OKR draft|okr,okr draft|okr likh,okr da draft|okr likho,okr ka draft|Objective/3 key results (measurable)/Initiatives/Check-in dates/Risks
PRD-08|Checklist builder|checklist for,build checklist|checklist dasso,checklist bana|checklist dikhao,checklist batao|Before/During/After/Owner of each item/Done definition
PRD-09|Time blocking|time blocking,time blocks|time block dasso,samay de block|samay khand,time block batao|Fixed events/Deep-work block/Admin block/Break blocks/Spare slot
PRD-10|Inbox triage|inbox triage,clear inbox|inbox sambhal,mails sambhalo|inbox sambhalo,mail chhantni|Scan/Do if under 2 minutes/Delegate/Schedule/Archive
PRD-11|Project plan|project plan,project timeline|project da plan,project di timeline|project ki yojana,project ka plan|Goal and success measure/Phases/Tasks and owners/Dates/Risks/Review points
PRD-12|Deadline planner|deadline plan,work backwards|deadline da plan,ulte kramm|deadline ki yojana,ulte kram se|Deadline/Work backwards/Milestones/Buffer/Daily minimum
PRD-13|Retrospective|retrospective,retro|retro dasso,ki changa riha|retro batao,kya achha raha|Went well/Went badly/Learned/One change for next time
PRD-14|Procrastination fix|procrastination fix,stop procrastinating|taal matol hatao,taal matol di dawai|taalmatol hatao,taalmatol chhodo|Name the fear in the task/Two-minute start/Remove friction/Reward/Accountability buddy
PRD-15|Meeting prep|meeting prep,prepare for meeting|meeting di tayyari,meeting layi tayyar|meeting ki taiyari,meeting ke liye taiyar|Goal/Know the people/Questions to ask/Your 3 points/Materials/Follow-up plan
PRD-16|Handover note|handover note,handoff document|handover note likh,kam sauppan da note|handover note likho,kaam saupne ka note|What it is/Current state/Next steps/Contacts/Pitfalls
PRD-17|Decision log|decision log,log decision|faisle da record,faisla likh|nirnay log,nirnay ka record|Date/Decision/Why/Alternatives/Review date
PRD-18|Energy plan|energy plan,energy management|energy da plan,takat da plan|urja yojana,urja ka plan|Peak hours/Hard tasks in peak hours/Low-energy tasks/Rest breaks/Meal and sleep reminders
PRD-19|Focus session|focus session,deep work|focus da session,deep work layi|focus satra,deep work ke liye|Single task/Phone away/Timer/Start ritual/End note
PRD-20|Shutdown routine|shutdown routine,end of day review|din khatam da routine,raat da review|din samapti routine,din ka samapan|Capture loose ends/Plan tomorrow's top 3/Clear desk/Done list/Stop time
"""

# a few native-script aliases (Gurmukhi / Devanagari); matched on exact NFC characters only
_NATIVE = {
    "LRN-01": ["ਸੌਖਾ ਸਮਝਾ", "सरल भाषा में समझाओ"], "LRN-03": ["ਪੜ੍ਹਾਈ ਦਾ ਪਲਾਨ", "पढ़ाई का प्लान"], "LRN-04": ["ਕਵਿਜ਼", "क्विज़"],
    "DEC-01": ["ਫਾਇਦੇ ਨੁਕਸਾਨ", "फायदे नुकसान"], "WRT-01": ["ਈਮੇਲ ਲਿਖ", "ईमेल लिखो"], "WRT-04": ["ਮੀਟਿੰਗ ਦਾ ਏਜੰਡਾ", "मीटिंग का एजेंडा"],
    "BIZ-05": ["ਟੈਗਲਾਈਨ", "टैगलाइन"], "PRD-02": ["ਅੱਜ ਦਾ ਪਲਾਨ", "आज का प्लान"], "PRD-03": ["ਹਫ਼ਤੇ ਦਾ ਪਲਾਨ", "इस हफ्ते का प्लान"],
}

_META_ALIASES = ["commands list", "command list", "list commands", "all commands", "100 commands", "commands dasso", "commands di list",
                 "commands dikhao", "commands ki suchi"]
_STOP = set("""karo kar de dedo do dena dasso batao dikhao mere meri mera mainu layi lyi lai ke ka ki ko nu da di te ate for on about of the a an please
plz bare baare vare wich mein par ton se to me my mujhe ik ek and or in is this that these those""".split())

FOOTERS = {
    "DEC": "Decision aid only. For legal, medical or financial matters, ask a qualified professional.",
}
_FRAMING = {"pa": "Eh scaffold tuhade topic layi tayyar hai (headings English ch):", "hi": "Yeh scaffold aapke topic ke liye taiyaar hai (headings English mein):",
            "en": "Scaffold ready for your topic:"}
_ID_RX = re.compile(r"^\s*cmd\s+([a-z]{3})[- ]?(\d{2})\b\s*(.*)$", re.I | re.S)


def _norm_token(raw: str) -> str:
    s = unicodedata.normalize("NFC", raw).lower().replace("'", "").replace("’", "")
    return "".join(ch if unicodedata.category(ch)[0] in "LNM" else " " for ch in s).strip()


def _tokens(text: str) -> List[Tuple[str, str, int]]:
    """(raw_word, normalised_part, word_index). A raw word that normalises to several parts (e.g. 'a=b', '10-10-10') repeats its raw word and index."""
    out: List[Tuple[str, str, int]] = []
    for gid, raw in enumerate(text.split()):
        for part in _norm_token(raw).split():
            out.append((raw, part, gid))
    return out


def _lang_of(alias_slot: int, alias: str) -> str:
    if any("਀" <= c <= "੿" for c in alias):
        return "pa"
    if any("ऀ" <= c <= "ॿ" for c in alias):
        return "hi"
    return ("en", "pa", "hi")[alias_slot]


def _build() -> Tuple[List[Dict[str, Any]], Dict[str, Dict[str, Any]]]:
    cmds: List[Dict[str, Any]] = []
    for line in _DSL.strip().splitlines():
        cid, title, en, pa, hi, secs = line.split("|")
        aliases: List[Tuple[Tuple[str, ...], str]] = []
        for slot, group in enumerate((en, pa, hi)):
            for a in group.split(","):
                toks = tuple(t for t in _norm_token(a).split() if t)
                aliases.append((toks, _lang_of(slot, a)))
        for a in _NATIVE.get(cid, []):
            aliases.append((tuple(_norm_token(a).split()), _lang_of(0, a)))
        cmds.append({"id": cid, "category": CATEGORIES[cid[:3]], "title": title, "aliases": aliases, "sections": secs.split("/")})
    return cmds, {c["id"]: c for c in cmds}


COMMANDS, _BY_ID = _build()


def catalogue() -> List[Dict[str, Any]]:
    return [{"id": c["id"], "category": c["category"], "title": c["title"], "aliases": [" ".join(a) for a, _ in c["aliases"]]} for c in COMMANDS]


def _find(tokens: List[str], alias: Tuple[str, ...]) -> int:
    n = len(alias)
    for i in range(len(tokens) - n + 1):
        if tuple(tokens[i:i + n]) == alias:
            return i
    return -1


def resolve(text: str) -> Optional[Dict[str, Any]]:
    """Pure matcher. None = not a library command. Otherwise {kind: run|ambiguous|list, ...}. Never raises, never does I/O."""
    m = _ID_RX.match(text or "")
    if m:
        cid = f"{m.group(1).upper()}-{m.group(2)}"
        if cid in _BY_ID:
            return {"kind": "run", "command": _BY_ID[cid], "lang": "en", "span": None, "tokens": _tokens(m.group(3)), "by_id": True}
        return {"kind": "ambiguous", "reason": "unknown_id", "candidates": [], "asked": cid}
    toks = _tokens(text or "")
    norm = [t[1] for t in toks]
    if not norm:
        return None
    for a in _META_ALIASES:
        at = tuple(a.split())
        if _find(norm, at) >= 0 and len(norm) <= len(at) + 3:
            return {"kind": "list"}
    best: Dict[str, Tuple[int, int, str, Tuple[str, ...]]] = {}
    for c in COMMANDS:
        for alias, lang in c["aliases"]:
            pos = _find(norm, alias)
            if pos >= 0 and (c["id"] not in best or len(alias) > best[c["id"]][0]):
                best[c["id"]] = (len(alias), pos, lang, alias)
    if not best:
        return None
    top = max(v[0] for v in best.values())
    winners = [cid for cid, v in best.items() if v[0] == top]
    if len(winners) > 1:
        return {"kind": "ambiguous", "reason": "tie", "candidates": [_BY_ID[w] for w in sorted(winners)][:4]}
    cid = winners[0]
    n, pos, lang, alias = best[cid]
    return {"kind": "run", "command": _BY_ID[cid], "lang": lang, "span": (pos, pos + n), "tokens": toks, "by_id": False}


def suggest(text: str, limit: int = 3) -> List[Dict[str, str]]:
    """Fallback hints for unmatched input: commands sharing a meaningful token (never auto-run)."""
    words = {t[1] for t in _tokens(text or "") if t[1] and t[1] not in _STOP and len(t[1]) > 2}
    scored = []
    for c in COMMANDS:
        vocab = {t for a, _ in c["aliases"] for t in a} | {_norm_token(c["title"])}
        hit = len(words & vocab)
        if hit:
            scored.append((-hit, c["id"]))
    return [{"id": cid, "title": _BY_ID[cid]["title"]} for _, cid in sorted(scored)[:limit]]


def _topic(res: Dict[str, Any]) -> str:
    toks = res["tokens"]
    span = res["span"]
    groups: Dict[int, List[Tuple[bool, str, str]]] = {}
    for i, (raw, n, gid) in enumerate(toks):
        groups.setdefault(gid, []).append((bool(span and span[0] <= i < span[1]), n, raw))
    words = [parts[0][2] for _, parts in sorted(groups.items()) if not any(d for d, _, _ in parts) and not all(n in _STOP for _, n, _ in parts)]
    return redact_text(" ".join(words))[:120].strip()


def execute(res: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
    """Render the deterministic scaffold. Returns (message, data) in the shape brain handlers use."""
    base = {"source": "local_template", "llm_used": False, "executed": False, "provenance": PROVENANCE}
    if res["kind"] == "list":
        by_cat: Dict[str, List[str]] = {}
        for c in COMMANDS:
            by_cat.setdefault(c["category"], []).append(c["title"])
        lines = [f"{len(COMMANDS)} local template commands ({PROVENANCE}). Say e.g. 'daily plan <topic>' or 'cmd PRD-02 <topic>'."]
        lines += [f"{cat} ({len(t)}): " + ", ".join(t[:4]) + ", ..." for cat, t in by_cat.items()]
        return "\n".join(lines), dict(base, state="CATALOGUE", count=len(COMMANDS), categories={k: len(v) for k, v in by_cat.items()})
    if res["kind"] == "ambiguous":
        cands = res.get("candidates", [])
        if res.get("reason") == "unknown_id":
            return "No such command id. Say 'commands list' to see the library.", dict(base, status_override="NEEDS_CLARIFICATION", state="NEEDS_CLARIFICATION", candidates=[])
        msg = "More than one command fits. Which one: " + "; ".join(f"{c['title']} (cmd {c['id']})" for c in cands) + "? Nothing was done."
        return msg, dict(base, status_override="NEEDS_CLARIFICATION", state="NEEDS_CLARIFICATION",
                         candidates=[{"id": c["id"], "title": c["title"], "category": c["category"]} for c in cands])
    c = res["command"]
    topic = _topic(res)
    lines = [f"{c['title']} [{c['id']}] - " + _FRAMING.get(res["lang"], _FRAMING["en"]), f"Topic: {topic or '(not given - fill in)'}"]
    lines += [f"{i}. {s}: ..." for i, s in enumerate(c["sections"], 1)]
    lines.append(FOOTERS.get(c["id"][:3], "Verify facts and numbers yourself."))
    lines.append("Local template - no AI model used; nothing was sent, published or executed.")
    return "\n".join(lines), dict(base, state="TEMPLATE_RENDERED", command_id=c["id"], category=c["category"], title=c["title"],
                                  topic=topic, language=res["lang"], sections=len(c["sections"]))
