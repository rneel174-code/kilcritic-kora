"""
KORA 8.8.5 - Media Pipeline (FFmpeg & FFprobe) with Subprocess Safety & Bounds
Enforces:
- Argument arrays strictly (NEVER shell=True)
- Path traversal prevention
- Dedicated temporary directories
- Strict subprocess timeout bounds (default 30s)
- Protected user exports directory (never pruned by temp cleanup)
"""
import os
import subprocess
import json
import shutil
import tempfile
from typing import Dict, Any, List, Optional, Tuple

TEMP_DIR_ROOT = os.path.abspath("data/temp")
EXPORTS_DIR_ROOT = os.path.abspath("data/exports")

os.makedirs(TEMP_DIR_ROOT, exist_ok=True)
os.makedirs(EXPORTS_DIR_ROOT, exist_ok=True)

class MediaPipelineError(Exception):
    pass

def sanitize_path(path: str, must_exist: bool = True) -> str:
    """Resolves path and prevents directory traversal outside safe boundaries."""
    abs_path = os.path.abspath(path)
    if must_exist and not os.path.exists(abs_path):
        raise MediaPipelineError(f"Target path does not exist: {abs_path}")
    return abs_path

def probe_media_duration(media_path: str, timeout_sec: float = 10.0) -> float:
    """Uses ffprobe to obtain exact media duration in seconds. Never guesses from word count."""
    safe_path = sanitize_path(media_path, must_exist=True)
    cmd = [
        "ffprobe",
        "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        safe_path
    ]

    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout_sec,
            shell=False  # Mandatory security requirement
        )
        if proc.returncode != 0:
            raise MediaPipelineError(f"ffprobe failed: {proc.stderr.strip()}")
        val = float(proc.stdout.strip())
        return val
    except subprocess.TimeoutExpired:
        raise MediaPipelineError("ffprobe execution timed out.")
    except ValueError:
        raise MediaPipelineError(f"Could not parse duration from ffprobe output: {proc.stdout}")

def generate_thumbnail(
    video_path: str,
    output_filename: str,
    time_offset_sec: float = 1.0,
    timeout_sec: float = 15.0
) -> str:
    """Extracts a thumbnail frame safely using FFmpeg argument array."""
    safe_input = sanitize_path(video_path, must_exist=True)
    out_path = os.path.join(TEMP_DIR_ROOT, os.path.basename(output_filename))

    cmd = [
        "ffmpeg",
        "-y",
        "-ss", str(max(0.0, float(time_offset_sec))),
        "-i", safe_input,
        "-vframes", "1",
        "-q:v", "2",
        out_path
    ]

    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout_sec,
            shell=False
        )
        if proc.returncode != 0 or not os.path.exists(out_path) or os.path.getsize(out_path) == 0:
            raise MediaPipelineError(f"Thumbnail generation failed: {proc.stderr.decode('utf-8', errors='ignore')}")
        return out_path
    except subprocess.TimeoutExpired:
        raise MediaPipelineError("Thumbnail generation timed out.")

def clean_temporary_files() -> int:
    """Safely cleans ONLY files inside data/temp, strictly preserving data/exports."""
    removed = 0
    for root, dirs, files in os.walk(TEMP_DIR_ROOT):
        for f in files:
            p = os.path.join(root, f)
            try:
                os.remove(p)
                removed += 1
            except Exception:
                pass
    return removed


# ----------------------------------------------------------------------------- real quality verification (measured, never assumed)
_RES_CLAIMS = {"4K": (3840, 2160), "2K": (2560, 1440), "1440P": (2560, 1440), "1080P": (1920, 1080), "HD": (1280, 720), "720P": (1280, 720)}


def verify_quality(media_path: str, claimed: Optional[Dict[str, Any]] = None, timeout_sec: float = 15.0) -> Dict[str, Any]:
    """Measure resolution/codec/bitrate/fps/audio with ffprobe and compare against what was CLAIMED (e.g. {"resolution": "4K"}).
    Missing ffprobe or an unreadable file => UNVERIFIED (never a guessed pass). A claim the measurement contradicts => FAIL."""
    import json as _json
    import shutil as _sh
    claimed = claimed or {}
    if not _sh.which("ffprobe"):
        return {"status": "UNVERIFIED", "reason": "ffprobe_not_installed", "measured": None, "mismatches": []}
    try:
        safe = sanitize_path(media_path, must_exist=True)
        proc = subprocess.run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", safe],
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout_sec, shell=False)
        if proc.returncode != 0:
            return {"status": "UNVERIFIED", "reason": "unreadable_or_corrupt_media", "detail": proc.stderr.strip()[:160], "measured": None, "mismatches": []}
        info = _json.loads(proc.stdout or "{}")
    except MediaPipelineError as exc:
        return {"status": "UNVERIFIED", "reason": str(exc)[:160], "measured": None, "mismatches": []}
    except (subprocess.TimeoutExpired, ValueError):
        return {"status": "UNVERIFIED", "reason": "ffprobe_timeout_or_bad_output", "measured": None, "mismatches": []}
    v = next((s for s in info.get("streams", []) if s.get("codec_type") == "video"), {})
    a = next((s for s in info.get("streams", []) if s.get("codec_type") == "audio"), {})
    fmt = info.get("format", {})

    def num(x):
        try:
            return float(x)
        except (TypeError, ValueError):
            return None
    fr = v.get("avg_frame_rate", "0/1").split("/")
    fps = round(float(fr[0]) / float(fr[1]), 2) if len(fr) == 2 and num(fr[1]) else None
    m = {"width": v.get("width"), "height": v.get("height"), "video_codec": v.get("codec_name"), "fps": fps,
         "bitrate_bps": int(num(fmt.get("bit_rate")) or 0) or None, "duration_s": num(fmt.get("duration")),
         "has_audio": bool(a), "audio_codec": a.get("codec_name")}
    mism = []
    rc = str(claimed.get("resolution", "")).upper().replace(" ", "")
    if rc:
        want = _RES_CLAIMS.get(rc)
        if not want:
            mism.append(f"unknown_resolution_claim:{rc}")
        elif not (m["width"] and m["height"]) or max(m["width"], m["height"]) < want[0]:  # long side must reach the claimed class
            mism.append(f"claimed {rc} but measured {m['width']}x{m['height']}")
    if claimed.get("audio") is True and not m["has_audio"]:
        mism.append("claimed audio but no audio stream")
    if claimed.get("min_bitrate_bps") and (m["bitrate_bps"] or 0) < int(claimed["min_bitrate_bps"]):
        mism.append(f"bitrate {m['bitrate_bps']} below claimed minimum {claimed['min_bitrate_bps']}")
    if claimed.get("codec") and m["video_codec"] != str(claimed["codec"]).lower():
        mism.append(f"codec {m['video_codec']} != claimed {claimed['codec']}")
    if not v:
        mism.append("no video stream")
    return {"status": "FAIL" if mism else "PASS", "measured": m, "mismatches": mism}


CONVERT_TARGETS = {
    "vertical_1080x1920": ("1080:1920", "mp4"),
    "square_1080": ("1080:1080", "mp4"),
    "landscape_1920x1080": ("1920:1080", "mp4"),
    "landscape_1280x720": ("1280:720", "mp4"),
}


def convert_variant(source_path: str, target: str, media_root: str = "data/media", timeout_sec: float = 300.0) -> Dict[str, Any]:
    """Real ffmpeg transcode of a file that already exists inside media_root to a platform size.
    state is EXPORTED_VERIFIED only if the output file exists AND ffprobe measures the requested size;
    ffmpeg missing -> UNAVAILABLE (never a fake export). No shell, fixed argv, source confined to media_root."""
    import shutil as _sh
    import json as _json
    if target not in CONVERT_TARGETS:
        raise MediaPipelineError("unknown_target:" + ",".join(sorted(CONVERT_TARGETS)))
    root = os.path.realpath(media_root)
    src = os.path.realpath(sanitize_path(source_path, must_exist=True))
    if os.path.commonpath([root, src]) != root or not os.path.isfile(src):
        raise MediaPipelineError("source_outside_media_root")
    if not (_sh.which("ffmpeg") and _sh.which("ffprobe")):
        return {"state": "UNAVAILABLE", "reason": "ffmpeg_not_installed", "output": None}
    size, ext = CONVERT_TARGETS[target]
    w, h = size.split(":")
    out_dir = os.path.join(root, "converted")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, f"{os.path.splitext(os.path.basename(src))[0]}.{target}.{ext}")
    vf = f"scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1"
    try:
        proc = subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", src, "-vf", vf, "-c:v", "libx264", "-pix_fmt", "yuv420p",
                               "-c:a", "aac", "-movflags", "+faststart", out],
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout_sec, shell=False)
    except subprocess.TimeoutExpired:
        return {"state": "FAILED", "reason": "ffmpeg_timeout", "output": None}
    if proc.returncode != 0 or not os.path.isfile(out) or os.path.getsize(out) == 0:
        return {"state": "FAILED", "reason": "ffmpeg_error", "detail": (proc.stderr or "")[-200:], "output": None}
    try:
        pr = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height",
                             "-of", "json", out], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30, shell=False)
        st = _json.loads(pr.stdout)["streams"][0]
        ok = (str(st["width"]), str(st["height"])) == (w, h)
    except Exception:
        return {"state": "UNVERIFIED", "reason": "ffprobe_failed", "output": out}
    return {"state": "EXPORTED_VERIFIED" if ok else "FAILED", "output": out if ok else None,
            "measured": {"width": st["width"], "height": st["height"]}, "bytes": os.path.getsize(out)}


# ============================================================================================ Studio: import / library / edit (PATCH4 additive)
# One engine: the same ffmpeg/ffprobe conventions as above (fixed argv, shell=False, root-confined, bounded timeout, measured output).
import re as _re

STUDIO_EXT = {".mp4": "video", ".mov": "video", ".webm": "video", ".mkv": "video",
              ".mp3": "audio", ".wav": "audio", ".m4a": "audio", ".ogg": "audio",
              ".png": "image", ".jpg": "image", ".jpeg": "image", ".webp": "image"}
_NAME_RX = _re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$")
ASPECTS = {"9:16": (9, 16), "16:9": (16, 9), "1:1": (1, 1), "4:5": (4, 5), "4:3": (4, 3)}
FILTERS = {"grayscale": "hue=s=0", "sepia": "colorchannelmixer=.393:.769:.189:0:.349:.686:.168:0:.272:.534:.131", "blur": "boxblur=3:1", "sharpen": "unsharp=5:5:1.0"}
EXPORT_PRESETS = dict(CONVERT_TARGETS) if "CONVERT_TARGETS" in globals() else {}
EXPORT_PRESETS.update({"compressed_720p": ("1280:720", "mp4"), "preview_480p": ("854:480", "mp4")})
PREVIEW_MAX_BYTES = 24 * 1024 * 1024
_CAP_CACHE: Dict[str, Any] = {}


def studio_max_bytes() -> int:
    try:
        mb = int(os.environ.get("KORA_STUDIO_MAX_MB", "200"))
    except ValueError:
        mb = 200
    return max(1, min(mb, 2048)) * 1024 * 1024


def studio_capabilities() -> Dict[str, Any]:
    """Truthful capability report (cached per process). Nothing is claimed that the installed tools cannot do."""
    if _CAP_CACHE:
        return dict(_CAP_CACHE)
    have = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))
    drawtext = x264 = False
    if have:
        try:
            f = subprocess.run(["ffmpeg", "-hide_banner", "-filters"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=15, shell=False).stdout
            e = subprocess.run(["ffmpeg", "-hide_banner", "-encoders"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=15, shell=False).stdout
            drawtext = " drawtext " in f
            x264 = "libx264" in e
        except Exception:
            pass
    _CAP_CACHE.update({
        "ffmpeg": have, "drawtext_text_overlay": drawtext, "libx264": x264,
        "ops": ["trim", "crop", "rotate", "resize", "brightness", "contrast", "saturation", "filter", "audio", "export_preset"] + (["text"] if drawtext else []),
        "export_presets": sorted(EXPORT_PRESETS), "aspects": sorted(ASPECTS), "filters": sorted(FILTERS),
        "formats": sorted(STUDIO_EXT), "max_upload_mb": studio_max_bytes() // (1024 * 1024),
        "not_implemented": ["3D/4D/5D rendering", "AI/generative video", "multi-track timeline", "cloud rendering"],
        "uhd_4k_export": "NOT OFFERED (no 4K preset; encoder/device support not verified)",
    })
    return dict(_CAP_CACHE)


def _lib(media_root: str) -> str:
    d = os.path.join(os.path.realpath(media_root), "library")
    os.makedirs(os.path.join(d, ".uploads"), exist_ok=True)
    return d


def _check_name(name: str) -> Tuple[str, str]:
    if not isinstance(name, str) or not _NAME_RX.match(name) or ".." in name:
        raise MediaPipelineError("invalid_name")
    ext = os.path.splitext(name)[1].lower()
    if ext not in STUDIO_EXT:
        raise MediaPipelineError("unsupported_format:" + ",".join(sorted(STUDIO_EXT)))
    return name, ext


def resolve_asset(media_root: str, asset_id: str) -> str:
    name, _ = _check_name(asset_id)
    root = _lib(media_root)
    p = os.path.realpath(os.path.join(root, name))
    if os.path.commonpath([root, p]) != root or not os.path.isfile(p):
        raise MediaPipelineError("asset_not_found")
    return p


def _probe(path: str, timeout: float = 20.0) -> Dict[str, Any]:
    pr = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,width,height,codec_name:format=duration,size",
                         "-of", "json", path], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout, shell=False)
    if pr.returncode != 0:
        raise MediaPipelineError("ffprobe_failed")
    d = json.loads(pr.stdout or "{}")
    v = next((s for s in d.get("streams", []) if s.get("codec_type") == "video"), None)
    a = next((s for s in d.get("streams", []) if s.get("codec_type") == "audio"), None)
    try:
        dur = float(d.get("format", {}).get("duration"))
    except (TypeError, ValueError):
        dur = None
    return {"width": v.get("width") if v else None, "height": v.get("height") if v else None, "has_video": bool(v), "has_audio": bool(a),
            "duration_s": dur, "bytes": os.path.getsize(path)}


def asset_record(media_root: str, name: str) -> Dict[str, Any]:
    p = resolve_asset(media_root, name)
    rec = {"id": name, "kind": STUDIO_EXT[os.path.splitext(name)[1].lower()], "bytes": os.path.getsize(p), "mtime": int(os.path.getmtime(p))}
    if shutil.which("ffprobe"):
        try:
            rec["measured"] = _probe(p)
        except Exception:
            rec["measured"] = None
            rec["warning"] = "unreadable_or_corrupt"
    return rec


def list_assets(media_root: str, limit: int = 200) -> List[Dict[str, Any]]:
    root = _lib(media_root)
    names = sorted((n for n in os.listdir(root) if os.path.isfile(os.path.join(root, n)) and _NAME_RX.match(n) and os.path.splitext(n)[1].lower() in STUDIO_EXT),
                   key=lambda n: -os.path.getmtime(os.path.join(root, n)))[:limit]
    out = []
    for n in names:
        p = os.path.join(root, n)
        out.append({"id": n, "kind": STUDIO_EXT[os.path.splitext(n)[1].lower()], "bytes": os.path.getsize(p), "mtime": int(os.path.getmtime(p))})
    return out


def upload_chunk(media_root: str, name: str, index: int, total: int, data: bytes) -> Dict[str, Any]:
    """Chunked import (JSON-only API). Parts are kept under library/.uploads and assembled only when all arrive in order.
    The assembled file is rejected (and removed) if ffprobe is available and cannot read it. Never overwrites an existing asset."""
    name, ext = _check_name(name)
    if not (isinstance(index, int) and isinstance(total, int) and 1 <= total <= 4096 and 0 <= index < total):
        raise MediaPipelineError("invalid_chunk_index")
    if not data or len(data) > 768 * 1024:
        raise MediaPipelineError("invalid_chunk_size")
    lib = _lib(media_root)
    upd = os.path.join(lib, ".uploads")
    part = os.path.join(upd, f"{name}.{index:05d}.part")
    with open(part, "wb") as fh:
        fh.write(data)
    if index != total - 1:
        return {"state": "RECEIVING", "received_index": index, "total": total}
    parts = [os.path.join(upd, f"{name}.{i:05d}.part") for i in range(total)]
    missing = [i for i, p in enumerate(parts) if not os.path.isfile(p)]
    if missing:
        raise MediaPipelineError("missing_chunks:" + ",".join(str(i) for i in missing[:10]))
    size = sum(os.path.getsize(p) for p in parts)
    if size > studio_max_bytes():
        for p in parts:
            os.remove(p)
        raise MediaPipelineError("file_too_large")
    base, final = os.path.splitext(name)[0], name
    n = 1
    while os.path.exists(os.path.join(lib, final)):
        final = f"{base}-{n}{ext}"
        n += 1
    tmp = os.path.join(upd, f"{final}.assembling")
    with open(tmp, "wb") as out:
        for p in parts:
            with open(p, "rb") as fh:
                shutil.copyfileobj(fh, out)
    for p in parts:
        os.remove(p)
    verified = None
    if shutil.which("ffprobe"):
        try:
            _probe(tmp)
            verified = True
        except Exception:
            os.remove(tmp)
            raise MediaPipelineError("corrupt_or_unsupported_media")
    os.replace(tmp, os.path.join(lib, final))
    rec = asset_record(media_root, final)
    rec.update({"state": "IMPORTED_VERIFIED" if verified else "IMPORTED_UNVERIFIED", "verified": bool(verified)})
    return rec


def read_preview(media_root: str, asset_id: str) -> Dict[str, Any]:
    p = resolve_asset(media_root, asset_id)
    size = os.path.getsize(p)
    if size > PREVIEW_MAX_BYTES:
        raise MediaPipelineError("too_large_for_inline_preview:export_preview_480p_first")
    import base64
    with open(p, "rb") as fh:
        raw = fh.read()
    ext = os.path.splitext(p)[1].lower()
    mime = {".mp4": "video/mp4", ".mov": "video/quicktime", ".webm": "video/webm", ".mkv": "video/x-matroska", ".mp3": "audio/mpeg", ".wav": "audio/wav",
            ".m4a": "audio/mp4", ".ogg": "audio/ogg", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp"}[ext]
    return {"id": asset_id, "mime": mime, "bytes": size, "data_b64": base64.b64encode(raw).decode("ascii")}


def _num(v: Any, lo: float, hi: float, name: str) -> float:
    if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v or v in (float("inf"), float("-inf")) or not (lo <= v <= hi):
        raise MediaPipelineError(f"invalid_{name}")
    return float(v)


def build_edit_plan(ops: Dict[str, Any], kind: str, src_info: Dict[str, Any]) -> Dict[str, Any]:
    """Pure function: validate ops and build ffmpeg filter/arg lists. Unit-testable without ffmpeg."""
    if not isinstance(ops, dict) or not ops:
        raise MediaPipelineError("no_operations")
    known = {"trim", "crop", "rotate", "resize", "brightness", "contrast", "saturation", "filter", "text", "audio", "export_preset"}
    bad = sorted(set(ops) - known)
    if bad:
        raise MediaPipelineError("unknown_ops:" + ",".join(bad))
    vf: List[str] = []
    af: List[str] = []
    pre: List[str] = []
    expect: Dict[str, Any] = {}
    dur = src_info.get("duration_s")
    if "trim" in ops:
        if kind == "image":
            raise MediaPipelineError("trim_not_for_images")
        t = ops["trim"] if isinstance(ops["trim"], dict) else {}
        start = _num(t.get("start", 0), 0, 86400, "trim_start")
        end = t.get("end")
        if end is not None:
            end = _num(end, 0, 86400, "trim_end")
            if end <= start:
                raise MediaPipelineError("trim_end_before_start")
        if dur is not None and start >= dur:
            raise MediaPipelineError("trim_start_beyond_duration")
        pre += ["-ss", f"{start:.3f}"]
        if end is not None:
            pre += ["-to", f"{min(end, dur) if dur else end:.3f}"]
        eff_end = min(end, dur) if (end is not None and dur) else (end if end is not None else dur)
        expect["duration_s"] = None if eff_end is None else round(eff_end - start, 3)
    if "crop" in ops:
        c = ops["crop"]
        if not isinstance(c, dict):
            raise MediaPipelineError("invalid_crop")
        if "aspect" in c:
            if c["aspect"] not in ASPECTS:
                raise MediaPipelineError("invalid_aspect:" + ",".join(sorted(ASPECTS)))
            aw, ah = ASPECTS[c["aspect"]]
            vf.append(f"crop='if(gte(iw/ih,{aw}/{ah}),trunc(ih*{aw}/{ah}/2)*2,trunc(iw/2)*2)':'if(gte(iw/ih,{aw}/{ah}),trunc(ih/2)*2,trunc(iw*{ah}/{aw}/2)*2)'")
        else:
            x, y = int(_num(c.get("x", 0), 0, 16384, "crop_x")), int(_num(c.get("y", 0), 0, 16384, "crop_y"))
            w, h = int(_num(c.get("w"), 2, 16384, "crop_w")), int(_num(c.get("h"), 2, 16384, "crop_h"))
            vf.append(f"crop={w - w % 2}:{h - h % 2}:{x}:{y}")
    if "rotate" in ops:
        r = ops["rotate"]
        if r not in (90, 180, 270):
            raise MediaPipelineError("invalid_rotate:90,180,270")
        vf.append({90: "transpose=1", 180: "hflip,vflip", 270: "transpose=2"}[r])
    if "resize" in ops:
        s = ops["resize"] if isinstance(ops["resize"], dict) else {}
        w, h = int(_num(s.get("width"), 16, 3840, "resize_width")), int(_num(s.get("height"), 16, 2160, "resize_height"))
        w, h = w - w % 2, h - h % 2
        vf.append(f"scale={w}:{h}")
        expect["width"], expect["height"] = w, h
    if "export_preset" in ops:
        p = ops["export_preset"]
        if p not in EXPORT_PRESETS:
            raise MediaPipelineError("invalid_export_preset:" + ",".join(sorted(EXPORT_PRESETS)))
        w, h = EXPORT_PRESETS[p][0].split(":")
        vf.append(f"scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1")
        expect["width"], expect["height"] = int(w), int(h)
    eq = []
    if "brightness" in ops:
        eq.append(f"brightness={_num(ops['brightness'], -1, 1, 'brightness'):.3f}")
    if "contrast" in ops:
        eq.append(f"contrast={_num(ops['contrast'], 0, 3, 'contrast'):.3f}")
    if "saturation" in ops:
        eq.append(f"saturation={_num(ops['saturation'], 0, 3, 'saturation'):.3f}")
    if eq:
        vf.append("eq=" + ":".join(eq))
    if "filter" in ops:
        if ops["filter"] not in FILTERS:
            raise MediaPipelineError("invalid_filter:" + ",".join(sorted(FILTERS)))
        vf.append(FILTERS[ops["filter"]])
    textfile = None
    if "text" in ops:
        t = ops["text"] if isinstance(ops["text"], dict) else {}
        txt = t.get("text")
        if not isinstance(txt, str) or not txt.strip() or len(txt) > 120 or any(ord(ch) < 32 for ch in txt):
            raise MediaPipelineError("invalid_text")
        pos = {"top": "y=h*0.06", "center": "y=(h-text_h)/2", "bottom": "y=h-text_h-h*0.06"}.get(t.get("position", "bottom"))
        if pos is None:
            raise MediaPipelineError("invalid_text_position")
        size = int(_num(t.get("size", 36), 12, 160, "text_size"))
        color = t.get("color", "white")
        if color not in ("white", "yellow", "black", "red", "cyan"):
            raise MediaPipelineError("invalid_text_color")
        textfile = txt
        vf.append(f"drawtext=textfile=@@TEXTFILE@@:fontsize={size}:fontcolor={color}:x=(w-text_w)/2:{pos}:borderw=2:bordercolor=black")
    if "audio" in ops:
        if kind == "image":
            raise MediaPipelineError("audio_not_for_images")
        a = ops["audio"] if isinstance(ops["audio"], dict) else {}
        if a.get("mute") is True:
            expect["muted"] = True
        else:
            if "volume" in a:
                af.append(f"volume={_num(a['volume'], 0, 4, 'volume'):.3f}")
            if "fade_in" in a:
                af.append(f"afade=t=in:st=0:d={_num(a['fade_in'], 0.1, 30, 'fade_in'):.2f}")
            if "fade_out" in a:
                fo = _num(a["fade_out"], 0.1, 30, "fade_out")
                total = expect.get("duration_s") or dur
                if not total or fo >= total:
                    raise MediaPipelineError("fade_out_longer_than_clip")
                af.append(f"afade=t=out:st={total - fo:.3f}:d={fo:.2f}")
        expect["audio_ops"] = True
    if not (vf or af or pre or expect.get("muted")):
        raise MediaPipelineError("no_operations")
    return {"pre": pre, "vf": vf, "af": af, "textfile": textfile, "expect": expect, "mute": bool(expect.get("muted"))}


def edit_media(media_root: str, asset_id: str, ops: Dict[str, Any], out_name: Optional[str] = None, timeout_sec: float = 300.0) -> Dict[str, Any]:
    """Real ffmpeg edit of a library asset. The state is EDITED_VERIFIED only when the output exists and ffprobe measures what was requested
    (size / duration); ffmpeg or a needed filter missing -> UNAVAILABLE. Never overwrites an asset; no shell; bounded threads and time."""
    src = resolve_asset(media_root, asset_id)
    kind = STUDIO_EXT[os.path.splitext(src)[1].lower()]
    caps = studio_capabilities()
    if not caps["ffmpeg"]:
        return {"state": "UNAVAILABLE", "reason": "ffmpeg_not_installed", "output": None}
    timeout_sec = max(5.0, min(float(timeout_sec), 600.0))
    info = _probe(src)
    plan = build_edit_plan(ops, kind, info)
    if plan["textfile"] is not None and not caps["drawtext_text_overlay"]:
        return {"state": "UNAVAILABLE", "reason": "ffmpeg_drawtext_filter_missing", "output": None}
    lib = _lib(media_root)
    if kind == "video" and not caps["libx264"]:
        return {"state": "UNAVAILABLE", "reason": "libx264_missing", "output": None}
    ext = ".m4a" if kind == "audio" else (".mp4" if kind == "video" else os.path.splitext(src)[1].lower())
    base = out_name if out_name else os.path.splitext(asset_id)[0] + "-edit"
    base = _re.sub(r"[^A-Za-z0-9._-]", "-", base)[:60].strip(".-") or "edit"
    final, n = base + ext, 1
    while os.path.exists(os.path.join(lib, final)):
        final = f"{base}-{n}{ext}"
        n += 1
    tmpd = tempfile.mkdtemp(prefix="studio-", dir=TEMP_DIR_ROOT)
    out_tmp = os.path.join(tmpd, "out" + ext)
    try:
        vf = list(plan["vf"])
        if plan["textfile"] is not None:
            tf = os.path.join(tmpd, "t.txt")
            with open(tf, "w", encoding="utf-8") as fh:
                fh.write(plan["textfile"])
            vf = [x.replace("@@TEXTFILE@@", tf.replace("\\", "/").replace(":", "\\:")) for x in vf]
        cmd = ["ffmpeg", "-nostdin", "-y", "-v", "error", "-threads", "2", "-i", src] + plan["pre"]
        if kind in ("video", "image") and vf:
            cmd += ["-vf", ",".join(vf)]
        if kind != "image" and plan["mute"]:
            cmd += ["-an"]
        elif kind != "image" and plan["af"]:
            cmd += ["-af", ",".join(plan["af"])]
        if kind == "video":
            cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p", "-c:a", "aac", "-movflags", "+faststart"]
        elif kind == "audio":
            cmd += ["-vn", "-c:a", "aac"]
        elif ext == ".png" or ext == ".webp":
            cmd += ["-frames:v", "1"]
        else:
            cmd += ["-frames:v", "1", "-q:v", "2"]
        cmd.append(out_tmp)
        try:
            proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout_sec, shell=False)
        except subprocess.TimeoutExpired:
            return {"state": "FAILED", "reason": "ffmpeg_timeout", "output": None}
        if proc.returncode != 0 or not os.path.isfile(out_tmp) or os.path.getsize(out_tmp) == 0:
            return {"state": "FAILED", "reason": "ffmpeg_error", "detail": (proc.stderr or "")[-200:], "output": None}
        try:
            got = _probe(out_tmp)
        except Exception:
            return {"state": "UNVERIFIED", "reason": "ffprobe_failed", "output": None}
        exp = plan["expect"]
        problems = []
        if "width" in exp and (got["width"], got["height"]) != (exp["width"], exp["height"]):
            problems.append(f"size {got['width']}x{got['height']} != {exp['width']}x{exp['height']}")
        if exp.get("duration_s") is not None and got["duration_s"] is not None and abs(got["duration_s"] - exp["duration_s"]) > 0.75:
            problems.append(f"duration {got['duration_s']:.2f}s != {exp['duration_s']:.2f}s")
        if exp.get("muted") and got["has_audio"]:
            problems.append("audio still present")
        if problems:
            return {"state": "FAILED", "reason": "verification_mismatch", "detail": "; ".join(problems), "output": None, "measured": got}
        os.replace(out_tmp, os.path.join(lib, final))
        return {"state": "EDITED_VERIFIED", "output": final, "measured": got, "expected": exp, "source": asset_id}
    finally:
        shutil.rmtree(tmpd, ignore_errors=True)
