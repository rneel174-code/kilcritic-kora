"""T170-T178: the MOUNTED '/' HUD and the Studio routes (PATCH4). Real HTTP-level calls into the WSGI app, real ffmpeg fixtures when ffmpeg exists.
When ffmpeg is absent the Studio tests assert the truthful UNAVAILABLE/UNVERIFIED behaviour instead of pretending to edit."""
import base64, hashlib, io, json, os, re, shutil, subprocess, tempfile
from dataclasses import replace

HUD = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "hud")
TOK = "tok-abcdef123456"
H = {"Authorization": "Bearer " + TOK}


def _read(n): return open(os.path.join(HUD, n), encoding="utf-8").read()


def _app(heavy=10**6):
    from kora.bridge.api import KoraApp
    from kora.config.settings import load_settings
    from kora.core.db import init_db
    root = tempfile.mkdtemp(prefix="kora-hs-")
    db = os.path.join(root, "h.db"); init_db(db)
    app = KoraApp(replace(load_settings({}, dotenv_path="/nonexistent"), auth_token=TOK, rate_write_per_min=10**6, rate_read_per_min=10**6, rate_heavy_per_min=heavy), db_path=db)
    def call(method, path, body=None, headers=None, raw=None):
        raw = raw if raw is not None else (json.dumps(body).encode() if body is not None else b"")
        env = {"REQUEST_METHOD": method, "PATH_INFO": path, "QUERY_STRING": "", "REMOTE_ADDR": "203.0.113.9", "HTTP_HOST": "127.0.0.1:8080",
               "CONTENT_LENGTH": str(len(raw)) if raw else "", "CONTENT_TYPE": "application/json" if raw else "", "wsgi.input": io.BytesIO(raw)}
        for k, v in (headers or {}).items(): env["HTTP_" + k.upper().replace("-", "_")] = v
        out = {}
        b = b"".join(app(env, lambda s, h, e=None: out.update(s=int(s.split()[0]), h=dict(h))))
        return out["s"], (json.loads(b) if b[:1] == b"{" else b), out["h"]
    return app, call, root, db


class _Media:
    def __init__(self, root): self.root, self.old = os.path.join(root, "media"), None
    def __enter__(self): self.old = os.environ.get("KORA_MEDIA_DIR"); os.environ["KORA_MEDIA_DIR"] = self.root; return self
    def __exit__(self, *a):
        if self.old is None: os.environ.pop("KORA_MEDIA_DIR", None)
        else: os.environ["KORA_MEDIA_DIR"] = self.old


def _fixture(root, name="fix.mp4", secs=3):
    p = os.path.join(root, name)
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", f"testsrc=duration={secs}:size=640x360:rate=15", "-f", "lavfi", "-i", f"sine=frequency=440:duration={secs}",
                    "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", p], check=True, timeout=60)
    return p


def _upload(call, name, data, chunk=200000):
    parts = [data[i:i + chunk] for i in range(0, len(data), chunk)] or [b""]
    last = None
    for i, c in enumerate(parts):
        last = call("POST", "/api/studio/upload", {"name": name, "index": i, "total": len(parts), "data_b64": base64.b64encode(c).decode()}, headers=H)
        if last[0] != 200: return last
    return last


def _probe(path):
    d = json.loads(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,width,height:format=duration", "-of", "json", path],
                                  stdout=subprocess.PIPE, text=True, timeout=30).stdout)
    v = next((s for s in d["streams"] if s["codec_type"] == "video"), {})
    return v.get("width"), v.get("height"), float(d["format"]["duration"]), any(s["codec_type"] == "audio" for s in d["streams"])


# ------------------------------------------------------------------------------------------------- T170 mounted HUD
def mounted_hud_is_the_repaired_one():
    app, call, root, db = _app()
    s, html, hdr = call("GET", "/")
    assert s == 200, s
    html = html.decode()
    for need in ('data-hud="kora-main"', 'id="faceState"', 'id="homeCommand"', 'id="taskPanel"', 'id="taskState"', 'class="float-ring"', 'id="sysPanel"',
                 'id="masterFolder"', 'id="studio"', 'id="publishPanel"', "/intent.js", "/creator.js", 'viewport-fit=cover'):
        assert need in html, "mounted '/' lacks " + need     # the old HUD problem: '/' served a screen without these
    for st in ("/intent.js", "/creator.js", "/creator.css", "/kora_avatar.jpg", "/advanced", "/legacy-hud", "/hud.js"):
        assert call("GET", st)[0] == 200, st                 # nothing preserved was lost, legacy console still reachable
    assert "<script>" not in html and "onclick=" not in html and ' style="' not in html, "inline code/style would be blocked by the CSP"
    csp = hdr["Content-Security-Policy"]
    assert "media-src 'self' blob:" in csp and "img-src 'self' data: blob:" in csp and "script-src 'self'" in csp and "'unsafe-inline'" not in csp
    css = _read("creator.css")
    assert "safe-area-inset" in css and "@media(max-width:700px)" in css
    adv = call("GET", "/advanced")[1].decode()
    for keep in ('id="doctor"', 'id="backup"', 'id="evolve"', 'id="voiceDock"'):
        assert keep in adv, "legacy console lost " + keep


# ------------------------------------------------------------------------------------------------- T171 one dispatcher
def one_dispatcher_voice_text_touch():
    js = _read("creator.js")
    assert js.count("'/api/brain'") == 1, "exactly one place may call the backend dispatcher"
    for wire in ("$('commandForm').onsubmit=e=>{e.preventDefault();const t=$('command').value;$('command').value='';dispatch(t,'text')}",
                 "$('homeCommandForm').onsubmit", "dispatch(t,'voice')", "dispatch('Open '+c.name+' workflow','touch')"):
        assert wire in js, wire
    assert not re.search(r"fetch\(\s*['\"]/api/brain", js), "no second dispatcher"
    node = shutil.which("node")
    src = _read("intent.js")
    if node:
        prog = ("const vm=require('vm');const w={};vm.runInNewContext(process.argv[1],{window:w});const I=w.KoraIntent;const o={};"
                "const t=(k,x)=>{o[k]=x};"
                "t('studio',I.parse('KORA, studio kholo').act);t('play',I.resolve(I.parse('video preview chalao'),{mediaLoaded:true}).act);"
                "t('play_noctx',I.resolve(I.parse('video preview chalao'),{}).act);t('pause',I.resolve(I.parse('pause karo'),{mediaLoaded:true}).act);"
                "t('pause_task',I.resolve(I.parse('pause amazon task'),{}).act);t('back',I.parse('pichhe jao').act);t('draft',I.resolve(I.parse('draft save karo'),{studioOpen:true}).act);"
                "t('draft_noctx',I.resolve(I.parse('draft save karo'),{}).act);t('health',I.parse('health check karo').act);t('pub',I.parse('publish this on youtube').high_impact);"
                "t('empty',I.parse('   ').act);t('states',I.STATES);console.log(JSON.stringify(o));")
        out = json.loads(subprocess.run([node, "-e", prog, src], stdout=subprocess.PIPE, text=True, timeout=30, check=True).stdout)
        assert out["studio"] == "open_studio" and out["play"] == "play" and out["play_noctx"] == "brain" and out["pause"] == "pause"
        assert out["pause_task"] == "brain" and out["back"] == "back" and out["draft"] == "save_draft" and out["draft_noctx"] == "brain"
        assert out["health"] == "brain" and out["pub"] is True and out["empty"] == "empty"
        assert out["states"] == ["IDLE", "LISTENING", "THINKING", "WORKING", "NEEDS APPROVAL", "ERROR", "COMPLETE"]
    else:   # no node (e.g. Pydroid): static check only
        for rule in ("open_studio", "save_draft", "pichhe", "chalao", "NEEDS APPROVAL"): assert rule in src


# ------------------------------------------------------------------------------------------------- T172 Advanced / System
def advanced_system_exposes_everything():
    app, call, root, db = _app()
    html, js = _read("creator_index.html"), _read("creator.js")
    routes = {(m, rx.pattern) for m, rx, fn, k in app.routes}
    need = {("POST", "/api/doctor/heal"), ("GET", "/api/providers"), ("POST", "/api/backup/create"), ("GET", "/api/evolution/scan"), ("GET", "/api/ops"),
            ("GET", "/api/active"), ("GET", "/api/audit/verify"), ("POST", "/api/tests/run")}
    for m, u in need:
        assert ("^" + u + "$") in {p for mm, p in routes if mm == m}, "no such route " + m + u
        assert u in js, "Advanced panel does not call " + u
    for key in ("doctor", "discovery", "backup", "improve", "resources", "events", "audit", "tests", "voice", "token"):
        assert f'data-sys="{key}"' in html and f"kind==='{key}'" in js, key
    assert 'href="/advanced"' in html


# ------------------------------------------------------------------------------------------------- T173 no dead controls
def every_visible_control_is_wired_or_labelled():
    html, js = _read("creator_index.html"), _read("creator.js")
    ids = set(re.findall(r'<(?:button|a|input|select|form|label)\b[^>]*\bid="([^"]+)"', html))
    for i in re.findall(r"\$\('([A-Za-z0-9_]+)'\)", js): assert i in re.findall(r'id="([^"]+)"', html), "JS references missing element #" + i
    handled = set(re.findall(r"\$\('([A-Za-z0-9_]+)'\)\s*\.(?:onclick|onsubmit|onchange|oninput)", js)) | set(re.findall(r"\$\('([A-Za-z0-9_]+)'\)\.addEventListener", js))
    passive = {"importFile", "newName", "newType", "projName", "projList", "pSeek", "trStart", "trEnd", "cropAspect", "rotDeg", "rsW", "rsH", "clBr", "clCo", "clFilter", "txText",
               "txPos", "auVol", "auFi", "auFo", "auMute", "exPreset", "pubPlatform", "pubAudience", "schedulePostId", "scheduleWhen", "scheduleTz", "scheduleFreq", "homeCommand", "command"}
    for i in ids - handled - passive:
        assert re.search(r'<form[^>]*id="%s"' % re.escape(i), html) is None or i in handled, "dead control #" + i
    for attr, fn in (("data-go", "[data-go]"), ("data-sys", "[data-sys]"), ("data-edit", "[data-edit]"), ("data-tool", "[data-tool]")):
        assert re.search(r"querySelectorAll\('\%s'\)" % fn.replace("[", "[").replace("]", "]"), js) or fn in js, "no handler for " + attr
    for g in set(re.findall(r'data-go="([a-z]+)', html)): assert f"k==='{g}'" in js, "data-go " + g + " unhandled"
    for e in set(re.findall(r'data-edit="([a-z]+)"', html)): assert f"kind==='{e}'" in js, "data-edit " + e + " unhandled"
    assert "NOT IMPLEMENTED" in js and "OPTIONAL HEAVY" in js          # Amazon / 3D-4D-5D are labelled, never faked
    assert "/api/social/posts/" not in js and "/approve" not in js     # the UI has no direct-publish/approve path
    assert "published successfully" not in js.lower()


# ------------------------------------------------------------------------------------------------- T174 import / library / preview
def studio_import_library_preview():
    app, call, root, db = _app()
    with _Media(root):
        assert call("GET", "/api/studio/assets")[0] in (401, 403)
        assert call("POST", "/api/studio/upload", {"name": "a.mp4", "index": 0, "total": 1, "data_b64": "AA=="})[0] in (401, 403)
        caps = call("GET", "/api/studio/capabilities", headers=H)[1]
        assert "ffmpeg" in caps and "not_implemented" in caps and "3D/4D/5D rendering" in caps["not_implemented"] and "ops" in caps
        bad = lambda n, i=0, t=1, d="AA==": call("POST", "/api/studio/upload", {"name": n, "index": i, "total": t, "data_b64": d}, headers=H)[0]
        for n in ("../x.mp4", "a/b.mp4", "evil.exe", "noext", ".hidden.mp4", "x" * 90 + ".mp4"): assert bad(n) == 400, n
        assert bad("ok.mp4", i=5, t=2) == 400 and bad("ok.mp4", d="not base64!!") == 400
        assert call("POST", "/api/studio/upload", {"name": "ok.mp4", "index": 0, "total": 1}, headers=H)[0] == 400
        assert call("POST", "/api/studio/preview", {"id": "../../etc/passwd"}, headers=H)[0] in (400, 404)
        assert call("POST", "/api/studio/preview", {"id": "missing.mp4"}, headers=H)[0] == 404
        if not shutil.which("ffmpeg"):
            r = _upload(call, "a.mp4", b"x" * 100)
            assert r[0] == 200 and r[1]["state"] == "IMPORTED_UNVERIFIED" and r[1]["verified"] is False, r
            return
        fx = _fixture(root); raw = open(fx, "rb").read()
        s, r, _ = _upload(call, "clip.mp4", raw); assert s == 200 and r["state"] == "IMPORTED_VERIFIED" and r["measured"]["width"] == 640, r
        s, r2, _ = _upload(call, "clip.mp4", raw); assert r2["id"] == "clip-1.mp4", "an existing asset must never be overwritten"
        items = call("GET", "/api/studio/assets", headers=H)[1]["items"]; assert {i["id"] for i in items} == {"clip.mp4", "clip-1.mp4"} and all(not i["id"].startswith(".") for i in items)
        p = call("POST", "/api/studio/preview", {"id": "clip.mp4"}, headers=H)[1]
        assert p["mime"] == "video/mp4" and base64.b64decode(p["data_b64"]) == raw, "preview must be the real bytes"
        assert _upload(call, "junk.mp4", os.urandom(5000))[0] == 400, "corrupt media must be rejected, not stored"
        assert "junk.mp4" not in [i["id"] for i in call("GET", "/api/studio/assets", headers=H)[1]["items"]]
        os.environ["KORA_STUDIO_MAX_MB"] = "1"
        try:
            assert _upload(call, "big.mp4", os.urandom(1100 * 1024))[0] == 400, "size cap"
        finally:
            os.environ.pop("KORA_STUDIO_MAX_MB", None)
        assert not [f for f in os.listdir(os.path.join(root, "media", "library", ".uploads")) if f.startswith("big")], "partial parts must be cleaned on rejection"


# ------------------------------------------------------------------------------------------------- T175 edits (measured)
def studio_edit_operations_measured():
    from kora.services import media_pipeline as mp
    # pure validation (no ffmpeg needed)
    info = {"duration_s": 3.0}
    for ops in ({}, {"bogus": 1}, {"trim": {"start": 2, "end": 1}}, {"trim": {"start": 9}}, {"rotate": 45}, {"crop": {"aspect": "7:3"}}, {"resize": {"width": 0, "height": 10}},
                {"brightness": 5}, {"brightness": float("nan")}, {"audio": {"volume": 99}}, {"filter": "rm -rf"}, {"text": {"text": ""}}, {"text": {"text": "a\nb"}},
                {"export_preset": "8k"}, {"audio": {"fade_out": 99}}):
        try: mp.build_edit_plan(ops, "video", info)
        except mp.MediaPipelineError: continue
        raise AssertionError("accepted invalid ops %r" % (ops,))
    try: mp.build_edit_plan({"trim": {"start": 0}}, "image", info); raise AssertionError("trim on image")
    except mp.MediaPipelineError: pass
    app, call, root, db = _app()
    with _Media(root):
        if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
            mp._CAP_CACHE.clear(); r = _upload(call, "a.mp4", b"x" * 50)
            s, b, _ = call("POST", "/api/studio/edit", {"id": r[1]["id"], "ops": {"rotate": 90}}, headers=H)
            assert s == 400 or b.get("state") == "UNAVAILABLE", b   # honest: nothing is edited without ffmpeg
            return
        fx = _fixture(root); raw = open(fx, "rb").read(); assert _upload(call, "clip.mp4", raw)[0] == 200
        lib = os.path.join(root, "media", "library"); before = hashlib.sha256(open(os.path.join(lib, "clip.mp4"), "rb").read()).hexdigest()
        def edit(ops): return call("POST", "/api/studio/edit", {"id": "clip.mp4", "ops": ops}, headers=H)
        s, b, _ = edit({"trim": {"start": 0.5, "end": 2.5}}); assert s == 200 and b["state"] == "EDITED_VERIFIED" and abs(_probe(os.path.join(lib, b["output"]))[2] - 2.0) < 0.5, b
        s, b, _ = edit({"crop": {"aspect": "9:16"}}); w, h, d, a = _probe(os.path.join(lib, b["output"])); assert s == 200 and abs(w / h - 9 / 16) < 0.02, (w, h)
        s, b, _ = edit({"rotate": 90}); w, h, d, a = _probe(os.path.join(lib, b["output"])); assert (w, h) == (360, 640)
        s, b, _ = edit({"resize": {"width": 320, "height": 180}}); assert _probe(os.path.join(lib, b["output"]))[:2] == (320, 180)
        s, b, _ = edit({"audio": {"mute": True}}); assert _probe(os.path.join(lib, b["output"]))[3] is False
        s, b, _ = edit({"audio": {"volume": 0.5, "fade_in": 0.3, "fade_out": 0.3}}); assert s == 200 and _probe(os.path.join(lib, b["output"]))[3] is True
        s, b, _ = edit({"brightness": 0.1, "contrast": 1.2, "filter": "sepia"}); assert s == 200
        s, b, _ = edit({"export_preset": "preview_480p"}); assert _probe(os.path.join(lib, b["output"]))[:2] == (854, 480)
        if mp.studio_capabilities()["drawtext_text_overlay"]:
            s, b, _ = edit({"text": {"text": "KORA: it's 100%", "position": "top"}}); assert s == 200 and b["state"] == "EDITED_VERIFIED", b
        # failures are reported as failures, never as success
        assert edit({"trim": {"start": 9}})[0] == 400 and edit({"rotate": 45})[0] == 400 and edit({})[0] == 400
        assert call("POST", "/api/studio/edit", {"id": "../x.mp4", "ops": {"rotate": 90}}, headers=H)[0] in (400, 404)
        assert call("POST", "/api/studio/edit", {"id": "nope.mp4", "ops": {"rotate": 90}}, headers=H)[0] in (400, 404)
        assert call("POST", "/api/studio/edit", {"id": "clip.mp4"}, headers=H)[0] == 400
        nan = b'{"id":"clip.mp4","ops":{"brightness":NaN}}'; assert call("POST", "/api/studio/edit", headers=H, raw=nan)[0] == 400
        assert hashlib.sha256(open(os.path.join(lib, "clip.mp4"), "rb").read()).hexdigest() == before, "the original must never be modified"
        assert not [f for f in os.listdir(mp.TEMP_DIR_ROOT) if f.startswith("studio-")], "temp dirs must be cleaned"
        q = call("POST", "/api/studio/quality", {"id": "clip.mp4"}, headers=H)[1]
        assert q["decision"] == "PASS" and q["checks"]["audio_present"] is True and "NOT_EVALUATED" in q["destination_policy"]
        # ffmpeg missing -> UNAVAILABLE, never a fake export
        old = shutil.which
        mp._CAP_CACHE.clear(); shutil.which = lambda n, *a, **k: None
        try:
            assert mp.edit_media(os.path.join(root, "media"), "clip.mp4", {"rotate": 90})["state"] == "UNAVAILABLE"
        finally:
            shutil.which = old; mp._CAP_CACHE.clear()


# ------------------------------------------------------------------------------------------------- T176 drafts / projects
def studio_projects_roundtrip():
    app, call, root, db = _app()
    with _Media(root):
        d = {"asset": "clip.mp4", "history": ["clip.mp4", "clip-edit.mp4"], "idx": 1}
        s, b, _ = call("POST", "/api/studio/projects/save", {"name": "My Draft 1", "data": d}, headers=H); assert s == 200 and b["revision"] == 1 and b["state"] == "DRAFT_LOCAL", b
        assert call("POST", "/api/studio/projects/save", {"name": "My Draft 1", "data": d}, headers=H)[1]["revision"] == 2
        assert [p["name"] for p in call("GET", "/api/studio/projects", headers=H)[1]["items"]] == ["My Draft 1"]
        got = call("POST", "/api/studio/projects/load", {"name": "My Draft 1"}, headers=H)[1]; assert got["data"] == d and got["state"] == "DRAFT_LOCAL"
        for n in ("../evil", "a/b", "", "x" * 80, ".hidden"): assert call("POST", "/api/studio/projects/save", {"name": n, "data": d}, headers=H)[0] == 400, n
        assert call("POST", "/api/studio/projects/save", {"name": "big", "data": {"x": "y" * 70000}}, headers=H)[0] == 400
        assert call("POST", "/api/studio/projects/load", {"name": "nope"}, headers=H)[0] == 404
        assert call("GET", "/api/studio/projects")[0] in (401, 403)
        assert not any(f for f in os.listdir(os.path.join(root, "media")) if f.endswith(".json")), "drafts stay inside media/projects"


# ------------------------------------------------------------------------------------------------- T177 preview != publish
def preview_is_not_publish():
    app, call, root, db = _app()
    with _Media(root):
        for k in ("YOUTUBE_ACCESS_TOKEN", "X_OAUTH2_USER_TOKEN", "FACEBOOK_PAGE_ACCESS_TOKEN"): os.environ.pop(k, None)
        s, b, _ = call("POST", "/api/social/posts", {"platform": "X", "content": "draft from studio", "audience": "GENERAL", "idempotency_key": "ui-1"}, headers=H)
        assert s == 201 and "PUBLISHED" not in json.dumps(b).upper().replace("NOT_PUBLISHED", ""), b
        assert str(b.get("status", "")).upper() != "PUBLISHED", b
        assert call("POST", "/api/social/posts", {"platform": "X", "content": "x"})[0] in (401, 403)
        assert call("POST", "/api/social/posts", {"platform": "X", "content": "x", "studio_asset": "../../etc/passwd"}, headers=H)[0] == 400
        assert call("POST", "/api/social/posts", {"platform": "X", "content": "x", "studio_asset": "missing.mp4"}, headers=H)[0] == 400
        if shutil.which("ffmpeg") and shutil.which("ffprobe"):   # regression: a Studio asset attached from the UI used to fail with media_path_outside_media_root
            assert _upload(call, "att.mp4", open(_fixture(root), "rb").read())[0] == 200
            s2, b2, _ = call("POST", "/api/social/posts", {"platform": "X", "content": "with media", "studio_asset": "att.mp4", "idempotency_key": "ui-att"}, headers=H)
            assert s2 == 201 and str(b2.get("status")).upper().startswith("PENDING"), (s2, b2)
        js = _read("creator.js")
        assert "'/api/social/posts'" in js and "NOT published" in js
        pre = [m for m in re.findall(r"api\('([A-Z]+)','(/api/[^']+)'", js)]
        assert not [u for m, u in pre if "publish" in u or u.endswith("/approve")], "UI must have no publish/approve call"


# ------------------------------------------------------------------------------------------------- T178 security
def studio_security_and_audit():
    from kora.bridge import api
    from kora.core.db import get_connection
    app, call, root, db = _app()
    reg = {fn.__name__: k for m, rx, fn, k in app.routes}
    assert reg["studio_edit"] == "heavy" and reg["studio_upload"] == "write" and reg["studio_preview"] == "read"
    for name in ("studio_capabilities", "studio_assets", "studio_upload", "studio_preview", "studio_edit", "studio_quality", "studio_projects", "studio_project_save", "studio_project_load"):
        assert name not in api.ROUTE_PERMS and name not in api.SELF_AUTHORIZING, name + " must stay owner-only"
    for p in ("/api/studio/capabilities", "/api/studio/assets", "/api/studio/projects"): assert call("GET", p)[0] in (401, 403), p
    assert call("POST", "/api/studio/edit", {"id": "a.mp4", "ops": {"rotate": 90}}, headers={"Authorization": "Bearer wrong-token-000000"})[0] in (401, 403)
    app2, call2, root2, db2 = _app(heavy=6)    # default-class limit: heavy Studio edits are rate limited (bounded CPU) and say so
    codes = [call2("POST", "/api/studio/edit", {"id": "a.mp4", "ops": {"rotate": 45}}, headers=H)[0] for _ in range(8)]
    first = codes.index(429); assert 1 <= first <= 6 and set(codes[:first]) == {400} and set(codes[first:]) == {429}, codes   # bounded: never more than the per-minute heavy budget
    csrf = call("POST", "/api/studio/edit", headers=H, raw=b'{"id":"a.mp4","ops":{"rotate":90}}')   # JSON content type is enforced by the bridge
    with _Media(root):
        if shutil.which("ffmpeg") and shutil.which("ffprobe"):
            fx = _fixture(root); assert _upload(call, "c.mp4", open(fx, "rb").read())[0] == 200
            assert call("POST", "/api/studio/edit", {"id": "c.mp4", "ops": {"rotate": 90}}, headers=H)[0] == 200
            conn = get_connection(db)
            try: ev = [r[0] for r in conn.execute("SELECT event_type FROM audit_events").fetchall()]
            finally: conn.close()
            assert "studio_import" in ev and "studio_edit" in ev, ev
            assert api.verify_audit_chain(db)["ok"] if isinstance(api.verify_audit_chain(db), dict) else True
        os.makedirs(os.path.join(root, "media", "library"), exist_ok=True)
        os.symlink("/etc/hostname", os.path.join(root, "media", "library", "link.mp4")) if os.path.exists("/etc/hostname") else None
        assert call("POST", "/api/studio/preview", {"id": "link.mp4"}, headers=H)[0] in (404, 400), "a symlink escaping the library must not be readable"


def register(run_test):
    run_test("T170", "Mounted '/' HUD is the repaired screen (state, command bar, task panel, ring, Advanced, Studio); legacy console + assets preserved; CSP allows blob media only", mounted_hud_is_the_repaired_one)
    run_test("T171", "Voice/text/touch share one dispatcher (single /api/brain call site; intent router tested in node when present)", one_dispatcher_voice_text_touch)
    run_test("T172", "Advanced/System exposes Doctor, Discovery, Backup, Improve Me, Resources, Events, Audit, Tests, Voice, token and the full console", advanced_system_exposes_everything)
    run_test("T173", "Every visible control is wired or honestly labelled (Amazon/3D-4D-5D NOT IMPLEMENTED); UI has no publish/approve call", every_visible_control_is_wired_or_labelled)
    run_test("T174", "Studio import/library/preview with real fixtures: validation, corrupt/oversize rejected, no overwrite, auth required", studio_import_library_preview)
    run_test("T175", "Studio edits (trim/crop/rotate/resize/mute/audio/color/export/text) measured by ffprobe; invalid ops 400; original untouched; ffmpeg missing -> UNAVAILABLE", studio_edit_operations_measured)
    run_test("T176", "Studio drafts: save/list/load round trip, revisions, traversal/oversize rejected", studio_projects_roundtrip)
    run_test("T177", "Preview is not publish: social draft stays unpublished without credentials/approval; UI cannot publish", preview_is_not_publish)
    run_test("T178", "Studio security: owner-only routes, heavy/write classes, symlink escape blocked, import/edit audited", studio_security_and_audit)
