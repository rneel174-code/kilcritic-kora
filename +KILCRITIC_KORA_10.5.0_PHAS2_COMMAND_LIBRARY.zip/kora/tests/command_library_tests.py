"""T179-T184: Phase 2 offline command library behind the EXISTING brain dispatcher (recognition, routing, multilingual, ambiguity, fallback, no network/LLM)."""
import os
import re
import socket
import tempfile

OWNER = {"id": "owner", "role": "owner"}


def _db():
    from kora.core.db import init_db
    p = os.path.join(tempfile.mkdtemp(prefix="kora-cl-"), "c.db")
    init_db(p)
    return p


def register(run_test):
    from kora.services import brain, command_library as L

    def integrity():
        assert len(L.COMMANDS) == 100, len(L.COMMANDS)
        ids = [c["id"] for c in L.COMMANDS]
        assert len(set(ids)) == 100
        cats = {}
        for c in L.COMMANDS:
            cats[c["category"]] = cats.get(c["category"], 0) + 1
            langs = {l for _, l in c["aliases"]}
            assert {"en", "pa", "hi"} <= langs, (c["id"], langs)
            assert len(c["sections"]) >= 3, c["id"]
        assert sorted(cats.values()) == [20] * 5, cats
        seen = {}
        for c in L.COMMANDS:
            for a, _ in c["aliases"]:
                assert a not in seen, ("duplicate alias", a, c["id"], seen.get(a))
                seen[a] = c["id"]
        for c in L.COMMANDS:                      # every alias resolves to its own command (100/100 recognition, all languages)
            for a, _ in c["aliases"]:
                r = L.resolve(" ".join(a) + " topic")
                assert r and r["kind"] == "run" and r["command"]["id"] == c["id"], (c["id"], a, r and r["kind"])
        native = [(c["id"], a) for c in L.COMMANDS for a, _ in c["aliases"] if any(ord(ch) > 0x0900 for ch in "".join(a))]
        assert len(native) >= 16, len(native)     # Gurmukhi + Devanagari aliases exist and resolved above
        for cid, a in native:
            assert L.resolve(" ".join(a))["command"]["id"] == cid
        for c in L.COMMANDS:                      # a library alias must never be captured by an ORIGINAL intent (original behaviour wins, so that would be a dead alias)
            for a, _ in c["aliases"]:
                for name, rx, *_ in brain.INTENTS:
                    assert not re.search(rx, " ".join(a), re.I), ("shadowed by original intent", c["id"], a, name)
    run_test("T179", "Command library: 100 commands (5x20), unique ids/aliases, EN+Roman Punjabi+Roman Hindi (+native script), 100% self-recognition, none shadowed by an original intent", integrity)

    def routing():
        db = _db()
        r = brain.handle("daily plan Diwali sale", principal=OWNER, db_path=db)
        assert r["status"] == "OK" and r["intent"] == "command_library" and r["data"]["command_id"] == "PRD-02", r
        d = r["data"]
        assert d["llm_used"] is False and d["executed"] is False and d["source"] == "local_template" and d["topic"] == "Diwali sale", d
        assert "Top 3 outcomes" in r["message"] and "no AI model used" in r["message"]
        for text, cid, lang in (("aaj da plan Diwali sale", "PRD-02", "pa"), ("aaj ka plan Diwali sale", "PRD-02", "hi"), ("plan my day diwali", "PRD-02", "en"),
                                ("ਅੱਜ ਦਾ ਪਲਾਨ ਦੀਵਾਲੀ", "PRD-02", "pa"), ("आज का प्लान दिवाली", "PRD-02", "hi"),
                                ("saukha samjha photosynthesis", "LRN-01", "pa"), ("faide nuksaan nawi gaddi", "DEC-01", "pa"), ("email likho boss ko leave", "WRT-01", "hi")):
            x = brain.handle(text, principal=OWNER, db_path=db)
            assert x["status"] == "OK" and x["data"]["command_id"] == cid and x["data"]["language"] == lang, (text, x)
        assert brain.handle("cmd DEC-03 my cafe", principal=OWNER, db_path=db)["data"]["command_id"] == "DEC-03"
        assert brain.handle("tldr this long report", principal=OWNER, db_path=db)["data"]["topic"] == "long report"
        # same permission engine: guest denied, unknown voice is a guest, voice off processes nothing
        assert brain.handle("daily plan", principal={"id": "g", "role": "guest"}, db_path=db)["status"] == "DENIED"
        assert brain.handle("daily plan", principal=OWNER, source="voice", db_path=db)["status"] == "VOICE_OFF"
        brain.set_voice(True, "t", db)
        assert brain.handle("daily plan", principal=OWNER, source="voice", db_path=db, voice_verified=False)["status"] == "DENIED"
        v = brain.handle("daily plan", principal=OWNER, source="voice", db_path=db, voice_verified=True)
        assert v["status"] == "OK" and v["speech"] and v["source"] == "voice"
        assert brain.handle("daily plan", principal=OWNER, source="touch", db_path=db)["status"] == "OK"
        # audited through the existing audit chain
        from kora.core.db import get_connection
        conn = get_connection(db)
        try:
            ev = [r[0] for r in conn.execute("SELECT event_type FROM audit_events").fetchall()]
        finally:
            conn.close()
        assert ev.count("brain_command") >= 10, ev
        # real HTTP-level route: still the single /api/brain dispatcher
        from kora.tests.hud_studio_tests import _app, H
        app, call, root, db2 = _app()
        s, body, _h = call("POST", "/api/brain", {"text": "weekly plan exam week", "source": "text"}, headers=H)
        assert s == 200 and body["ok"] is True and body["intent"] == "command_library" and body["data"]["command_id"] == "PRD-03", (s, body)
        assert call("POST", "/api/brain", {"text": "weekly plan"})[0] in (401, 403)
    run_test("T180", "Library routes through the single brain dispatcher (typed/touch/voice, EN/PA/HI/native script, guest/voice gates, audit, /api/brain)", routing)

    def preserved():
        db = _db()
        assert brain.HELP[0] == "ho ja shuru" and len(brain.HELP) == 15
        u = brain.handle("blah blah", principal=OWNER, db_path=db)
        assert u["status"] == "NEEDS_CLARIFICATION" and u["examples"] == brain.HELP and "suggestions" not in u
        assert brain.handle("status", principal=OWNER, db_path=db)["intent"] == "status"
        assert brain.handle("health", principal=OWNER, db_path=db)["intent"] == "health"
        p = brain.handle("make a video for youtube", principal=OWNER, db_path=db)
        assert p["intent"] == "create_plan" and p["status"] == "PLANNED" and p["data"]["executed"] is False
        assert brain.handle("amazon resume", principal=OWNER, db_path=db)["intent"] == "resume"
        assert brain.handle("cv bullets resume", principal=OWNER, db_path=db)["intent"] == "resume", "original intents take precedence over the library"
        assert brain.handle("x" * 501, principal=OWNER, db_path=db)["status"] == "INVALID"
        assert brain.handle("voice off", principal=OWNER, db_path=db)["intent"] == "voice_off"
        assert brain.handle("safe mode", principal=OWNER, db_path=db)["intent"] == "safe_mode"
    run_test("T181", "Original dispatcher unchanged: HELP/examples, status/health/resume/create_plan/voice/safe-mode precedence, 500-char limit", preserved)

    def ambiguity_fallback():
        db = _db()
        a = brain.handle("daily plan weekly plan", principal=OWNER, db_path=db)
        assert a["status"] == "NEEDS_CLARIFICATION" and a["data"]["executed"] is False and a["data"]["llm_used"] is False
        assert {c["id"] for c in a["data"]["candidates"]} == {"PRD-02", "PRD-03"} and "cmd PRD-02" in a["message"] and "Nothing was done" in a["message"]
        assert brain.handle("cmd PRD-02 week", principal=OWNER, db_path=db)["data"]["command_id"] == "PRD-02"
        z = brain.handle("cmd ZZZ-99", principal=OWNER, db_path=db)
        assert z["status"] == "NEEDS_CLARIFICATION" and z["data"]["candidates"] == []
        s = brain.handle("i need help with my study", principal=OWNER, db_path=db)
        assert s["status"] == "NEEDS_CLARIFICATION" and s["examples"] == brain.HELP and s["suggestions"] and "cmd " in s["message"], s
        assert all(x["id"].startswith(("LRN", "DEC", "WRT", "BIZ", "PRD")) for x in s["suggestions"])
        g = brain.handle("zzzz qqqq", principal=OWNER, db_path=db)
        assert g["status"] == "NEEDS_CLARIFICATION" and "suggestions" not in g
        assert L.resolve("") is None and L.resolve("   ") is None and L.resolve("!!! ???") is None
        for evil in ("daily plan; rm -rf /", "daily plan ${jndi:x}", "daily plan <script>alert(1)</script>", "daily plan " + "a" * 400):
            r = brain.handle(evil, principal=OWNER, db_path=db)
            assert r["status"] == "OK" and r["data"]["executed"] is False and len(r["data"]["topic"]) <= 120
    run_test("T182", "Ambiguity/unknown never guess: tie -> candidates, cmd <id>, unknown id, suggestions fallback, junk input, hostile text only echoed as inert topic", ambiguity_fallback)

    def catalogue_and_footer():
        db = _db()
        for t in ("commands list", "commands dasso", "commands dikhao", "100 commands"):
            r = brain.handle(t, principal=OWNER, db_path=db)
            assert r["status"] == "OK" and r["data"]["count"] == 100 and len(r["data"]["categories"]) == 5, (t, r)
        assert "Decision aid only" in brain.handle("pros and cons new car", principal=OWNER, db_path=db)["message"]
        assert "Verify facts" in brain.handle("email draft to landlord", principal=OWNER, db_path=db)["message"]
        assert "not given" in brain.handle("daily plan", principal=OWNER, db_path=db)["message"]
    run_test("T183", "Catalogue command (EN/PA/HI), decision-category safety footer, topic-optional rendering", catalogue_and_footer)

    def offline_no_llm_no_secret():
        db = _db()
        from kora.services import ai_failover
        real_q, real_sock = ai_failover.query_ai_model, socket.socket

        def boom(*a, **k): raise AssertionError("library must not call an LLM or the network")
        ai_failover.query_ai_model = boom
        socket.socket = boom
        try:
            for c in L.COMMANDS:
                r = brain.handle(f"cmd {c['id']} sample topic", principal=OWNER, db_path=db)
                assert r["status"] == "OK" and r["data"]["command_id"] == c["id"] and r["data"]["llm_used"] is False, c["id"]
        finally:
            ai_failover.query_ai_model, socket.socket = real_q, real_sock
        src = open(L.__file__, encoding="utf-8").read()
        assert not re.search(r"^\s*(import|from)\s+(socket|urllib|http|requests|ssl|subprocess|kora\.services\.ai_failover|kora\.core\.http)", src, re.M), "library imports a network/exec module"
        r = brain.handle("daily plan password=hunter2secret99", principal=OWNER, db_path=db)
        assert "hunter2secret99" not in r["message"] and "hunter2secret99" not in str(r["data"]), "secret-like text must be redacted from the echoed topic"
    run_test("T184", "Library is offline and deterministic: 100/100 commands run with LLM+socket forbidden, no network/exec imports, secrets redacted from echoed topic", offline_no_llm_no_secret)
