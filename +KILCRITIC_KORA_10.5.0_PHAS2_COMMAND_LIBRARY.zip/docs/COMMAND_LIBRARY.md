# Command library (Phase 2)

- Code: `kora/services/command_library.py` (data DSL + pure matcher). Wired in one place: `kora/services/brain.py` `handle()`, after the original `INTENTS` loop found nothing.
- Dispatcher unchanged: UI/voice/touch -> `dispatch()` -> `POST /api/brain` -> `brain.handle`. No new route, no new engine, no new UI.
- Matching: normalise (NFC, lowercase, punctuation removed) -> token sequence -> longest alias wins. Equal best score from two commands = ambiguity -> `NEEDS_CLARIFICATION` + candidates; `cmd <ID> <topic>` (e.g. `cmd PRD-02 diwali`) selects one explicitly.
- Languages: English, Roman Punjabi, Roman Hindi for all 100 (>=1 alias each); Gurmukhi/Devanagari aliases for 9 commands (exact characters only). Output headings are English.
- Output: scaffold with `state: TEMPLATE_RENDERED`, `llm_used: false`, `executed: false`, `source: local_template`. Decision commands add a "consult a professional" footer. Topic text is redacted for secret shapes and capped at 120 chars.
- Catalogue: `commands list` / `commands dasso` / `commands dikhao`.
- Provenance: `DESIGNED_SET` - the owner's original 100-command file was not available. Replace the `_DSL` block (same format) to load the real list; tests T179-T184 will re-verify uniqueness, shadowing and recognition.
- Gen AI: not required. `ai_failover.py` (optional paid providers) is not called; an LLM refiner would need a separate, explicit approval.
- Precedence limit: original intents win. Phrases containing `resume`, `status` at the start, `health`, `pause`, or `create|make|generate|edit|convert|... + video|story|reel|image...` are handled by the original intents.
- Not in this phase: Fast Filter + JEV, Target Client Hunter, Secure Deal Vault, Agency/DHANDA safeguards, offline decision engine.
