# KORA Guardian — LOCK-11 MALAK-ASSIST Audit

## Change
Added a governed human-in-the-loop module under `kora/services/malak_assist.py` and four protected API routes.

## Behavior
OTP / CAPTCHA / PAYMENT / APPROVAL / OAUTH / HUMAN_INPUT dependencies no longer need to be treated as a task failure. The module:

`DETECT HUMAN DEPENDENCY -> CHECKPOINT -> WAITING_FOR_MALAK -> NOTIFY -> AUTHENTICATE RESPONSE -> RESUMABLE -> CONTINUE -> VERIFY -> AUDIT`

It never bypasses OTP, CAPTCHA, MFA, payment authorization, OAuth, platform restrictions, or required approvals.

## Notification truth
Telegram and WhatsApp Cloud API are supported as optional configured notification channels. If their credentials are absent, the result is explicitly `NOT_CONFIGURED`; no fake `SENT` state is produced.

## Security
- one-time short resume code
- only code hash is stored
- expiry enforced
- wrong code rejected
- already-resumed task cannot be resumed again
- checkpoint stored durably in SQLite
- audit events recorded
- credentials are read from environment only and are not placed in normal memory/audit records
- existing auth/permission/rate-limit layer remains in front of the API

## API
- `POST /api/malak-assist/pause`
- `GET /api/malak-assist`
- `GET /api/malak-assist/{task_id}`
- `POST /api/malak-assist/{task_id}/resume`

## Tests
- Guardian suite: **11/11 PASS**
- Existing regression suite: **75/75 PASS**
- Python compile: **PASS**
- Direct LOCK-11 service smoke: **PASS**
- Live WSGI pause/get/resume-route smoke: **PASS for pause/get and invalid-code rejection**
- External Telegram/WhatsApp delivery: **NOT CONFIGURED** in this test environment, therefore no external message was falsely claimed.

## Remaining gap
Real external notification delivery requires the owner's own Telegram bot/chat configuration and/or WhatsApp Cloud API credentials. Those credentials were deliberately not embedded in the release.
