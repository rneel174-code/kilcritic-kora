# KORA / KILCRITIC — GODFATHER META-ARCHITECTURE 5.0

This layer is an orchestration/decision layer, not a duplicate scheduler, queue,
security engine, permission engine, repair engine, or social publisher.

## New architecture intelligence
- Meta-orchestration: understand → existing-capability check → route → resource check → preflight → execute → verify → provenance → checkpoint → learn.
- Adaptive execution mode: sequential on constrained/risky work; bounded parallelism otherwise.
- Capability-aware planning using the existing handler registry.
- Measured resource profile through Infinite Core; no fake RAM/CPU/network multipliers.
- Evidence hash for tamper-evident proposal/evidence references (not a blockchain claim).
- Evidence-based Evolution Judge: REFUSE / HOLD / PROPOSE.
- Duplicate-control/refusal: a capability that already exists is not recreated.
- External side effects remain behind the existing permission/approval gates.
- Truthful planning: this layer never claims that a task was executed.

## Existing architecture reused
Durable Queue, Scheduler, Worker Pool, Idempotency, Circuit Breaker/anti-loop,
Policy/Permission, Trust, Legal/Platform Guard, Social approval flow,
Cost Governor, Infinite Core, Self-Evolution, Checkpoints, Backup, Offline Queue,
Provider routing, Observability and existing tests.

## Explicit non-goals
- No unlimited workers.
- No fake hardware power.
- No hidden credentials.
- No automatic payment.
- No bypass of platform/API permissions.
- No silent production self-modification.
- No literal consciousness or unlimited AGI claim.

## API
`POST /api/godfather/plan` can be added as a read-only planning surface when the
bridge is enabled. It produces a plan only; it does not execute external actions.
