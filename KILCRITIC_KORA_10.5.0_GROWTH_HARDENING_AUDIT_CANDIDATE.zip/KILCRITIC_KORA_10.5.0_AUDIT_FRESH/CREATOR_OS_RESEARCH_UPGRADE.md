# KORA Creator OS — Research Upgrade

This release keeps the existing KORA backend and adds a creator-first desktop shell.

## Design references researched
- WebOS: draggable desktop icons, persisted positions, folders/files, context actions.
- daedalOS: file manager, drag/drop, conversion and archive-oriented desktop concepts.
- Hierarchical agent orchestration research (2026): lazy/hierarchical capability discovery reduces routing/search space.
- IBM RO (2026): deterministic runtime bookkeeping should be separated from nondeterministic model judgment.
- Trace-based agent assurance (2026): explicit contracts, replay, fault injection and runtime governance improve long-horizon reliability.
- C2PA: provenance/history can be attached to media; it is not a guarantee that content is truthful or copyright-free.

## Applied to KORA
1. One front-door Creator Desktop instead of exposing technical cards.
2. One master `MEDIA + SOCIAL + STUDIO` folder for creator work.
3. Sub-workflows: social publishing, studio, editing, 3D/4D/5D visual modes, funny/baby/cartoon, media, conversion/quality, story-to-movie, voice/text, publishing/autopilot, research/search, growth/dhanda.
4. Human-controlled front desktop: add, move, hide, restore. Hide never deletes.
5. Full-body KORA visual with transparent floating UI and touch/voice/text controls.
6. Existing permission, approval, verification, queue, legal, rights and provenance layers remain authoritative.
7. No UI state is allowed to claim that media was exported, posted, viral, or successful unless the backend actually verifies it.

## Important limitation
This upgrade does not invent a new video/image/3D renderer. It exposes the existing KORA capabilities through a unified workflow shell. Actual rendering/export/publishing remains dependent on the configured local tools, providers, official platform APIs and permissions.
