# Guardian Layer — Change Log

## Added
- Supreme Guardian service with LOCK-01..LOCK-10.
- SQLite schema v5 for durable Guardian state.
- Guardian API surface under `/api/guardian/*`.
- Maintenance-path background supervisor tick.
- Guardian regression suite.

## Modified
- `kora/core/db.py` — additive schema v5.
- `kora/bridge/api.py` — additive routes and handlers.
- `kora/services/handlers.py` — existing maintenance handler calls bounded Guardian supervisor tick.

## Preserved
All existing source modules, queues, workers, scheduler, permissions, auth, social adapters, DNA, ATMA, Emergency, Trust, Governance, Self-Evolution, research and tests were preserved.

## No deletion/cut
No working feature was intentionally removed, disabled or replaced.
