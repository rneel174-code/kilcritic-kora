# KORA/KILCRITIC Supreme Runtime — Release Notes

This package is based on the existing Godfather full system. It does not rebuild the system.

## New integrated layer
`kora/supreme_runtime/runtime_assurance.py`

The layer provides bounded contracts, horizon reduction, trajectory checks, watchdog decisions, execution proofs, state-memory branches, delegation/supply-chain records, evidence freshness, objective drift, blast radius, recovery proof and complexity debt.

## Integration
`kora/services/godfather.py` now performs a planning-only Supreme Runtime preflight. Existing queue, scheduler, permission, security, provider, checkpoint, repair and approval systems remain authoritative.

## Verification
- Python compile: PASS
- New Supreme Runtime tests: 11/11 PASS
- Existing KORA regression suite: 75/75 PASS
- Godfather GF01: PASS
- No claim is made that external social providers, credentials, or deployment permissions are configured by this package.
