# KILCRITIC/KORA 10.5.0 — Growth-loop hardening candidate

Status: **AUDIT CANDIDATE — NOT A PRODUCTION RELEASE**

## Scope
- Kept the original uploaded ZIP unchanged; edits are in this separate extracted copy.
- Modified only `kora/services/growth_loop.py` and the relevant growth assertions in `kora/tests/freeze_tests.py`.
- `kora/bridge/api.py`, `server.ts`, KORA 8.8.5 foundation identity, and the VERSION constant were not changed in this candidate.

## Changes
1. Evidence level 3 is no longer granted from caller-controlled `api:`, `pos:`, or `upi:` source labels. A reference can support level 2; level 4 still requires a qualifying DHANDA ledger row.
2. Reject NaN/Infinity and out-of-range campaign costs, ROI targets, event counts, event amounts, and pilot sales.
3. Validate calendar dates, not just the `YYYY-MM-DD` text shape, for pilot observations and festival planning.
4. Prevent duplicate pilot observations for the same shop/phase/date and reject reuse of a DHANDA ledger row for another growth event (application-level checks; not a concurrency-proof database uniqueness guarantee).
5. Narrow secret redaction so ordinary prose containing “OTP” is not automatically corrupted, while bearer tokens, API-key-like strings, and explicit `password:`/`otp:` values are redacted.
6. Updated the growth regression assertions to match the stricter evidence model: caller-provided source labels do not establish tool verification, so no ROI/pilot claim can be promoted on that basis alone.

## Verification performed
- Python compilation: PASS for `growth_loop.py`, `api.py`, and `freeze_tests.py`.
- Focused regression checks: PASS for finite-number rejection, invalid calendar dates, ordinary OTP wording, duplicate pilot observations, and caller-controlled source labels.
- Existing growth tests: PASS — `growth_roi_truth`, `growth_pilot_and_dna_truth`, and `growth_api_wired` (corresponding to T158–T160).
- Full `python3 -m kora.tests.run_all`: **TIMED OUT** at the tool's 180-second limit after showing T01–T78 PASS; this is not a full-suite pass. Remaining tests were not confirmed in this run.
- Not verified: frontend build/typecheck, phone/device performance, real social integrations, live AI/media generation, actual publishing, bank reconciliation, measured revenue/ROI, and production deployment.

## Limitations / follow-up
- The growth module has no authenticated POS/UPI verification adapter in this scope; therefore source labels cannot elevate evidence. Add a real authenticated verifier with replay/idempotency controls before allowing level 3.
- Ledger attribution and duplicate pilot protection are application-level checks; stronger transaction/unique constraints require a reviewed migration that safely handles existing rows.
- This ZIP is an audit candidate for review and additional testing, not a claim of complete release readiness.
