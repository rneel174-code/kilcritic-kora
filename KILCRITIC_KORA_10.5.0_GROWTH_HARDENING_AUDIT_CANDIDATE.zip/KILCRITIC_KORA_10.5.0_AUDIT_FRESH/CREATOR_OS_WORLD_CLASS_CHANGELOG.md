# KORA Creator OS — World-Class Integration Upgrade

## User-facing changes
- Main `/` is now a creator-first full-screen desktop.
- Full-body KORA remains the visual center.
- Transparent floating/dragable front icons are supported.
- Default front door is one master folder: `MEDIA + SOCIAL + STUDIO`.
- Social publishing is grouped together: YouTube, Facebook, Instagram, TikTok, X.
- Creator/studio work is grouped into the master folder instead of forcing File Manager navigation.
- Story → Movie, media creation, editing, conversion/quality, 3D/4D/5D visual modes, funny/baby/cartoon, research, growth and publishing are presented as unified sub-workflows.
- Touch, voice and text share the same command path.
- Hide/show/add/move controls remain human-controlled; hiding never deletes.
- Technical controls remain under `/advanced`.

## Engineering additions
- `/api/studio/plan` — real studio workflow contract, planning only.
- `/api/assets/variants` — real master-to-platform variant planning using the existing asset compiler.
- `/api/workflow/plan` — unified creator workflow planner with explicit non-success state.
- Existing permission, legal, rights, approval, queue, verification, provenance and social publishing gates remain authoritative.

## Research used
- Browser desktop patterns: WebOS and daedalOS.
- Agent orchestration: hierarchical/lazy capability discovery; deterministic runtime separation from model judgment; trace contracts/replay/runtime governance.
- Media provenance: C2PA Content Credentials principles.

## Truth rule
This shell does not claim that rendering, export, publishing, revenue or virality happened merely because a button was pressed. Actual success must come from the underlying verified service/platform result.
