"""Self-evolution safety tests: scan, path validation and environment profile bounds."""
import os, tempfile
from pathlib import Path

from kora.services import self_evolution, ops

def register(run_test):
    def t_scan():
        root = self_evolution.repo_root()
        r = self_evolution.scan(str(root))
        assert r["ok"] is True
        assert r["markers"]["self_evolution_engine"] is True
        assert "gaps" in r
    run_test("T70", "Self-Evolution Repository Scan Is Real", t_scan)

    def t_patch_paths():
        root = self_evolution.repo_root()
        good = """--- a/kora/services/self_evolution.py
+++ b/kora/services/self_evolution.py
@@ -1 +1 @@
-\"\"\"KORA Self-Evolution Engine.
+\"\"\"KORA Self-Evolution Engine.
"""
        bad = """--- a/../../evil.py
+++ b/../../evil.py
@@ -1 +1 @@
-x
+y
"""
        assert self_evolution.validate_patch(good, root)["ok"] is True
        assert self_evolution.validate_patch(bad, root)["ok"] is False
    run_test("T71", "Self-Evolution Patch Path Guard Blocks Traversal", t_patch_paths)

    def t_environment():
        with tempfile.TemporaryDirectory() as td:
            db=os.path.join(td,"k.db")
            from kora.core.db import init_db
            init_db(db)
            assert ops.environment_get(db)["profile"] == "EARTH"
            assert ops.environment_set("OCEAN","owner",db)["profile"] == "OCEAN"
            try:
                ops.environment_set("MOON","owner",db)
                assert False
            except ValueError:
                pass
    run_test("T72", "Adaptive Environment Profile Validation", t_environment)

    # Self-Evolution 2.0 intelligence layer: observe/rank only, never auto-apply.
    from kora.services import self_evolution_2

    def t_audit_is_observational():
        with tempfile.TemporaryDirectory() as td:
            db=os.path.join(td,"se2.db")
            from kora.core.db import init_db
            init_db(db)
            out=self_evolution_2.audit(self_evolution.repo_root(), db, env={})
            assert out["status"] == "AUDITED"
            assert out["auto_apply"] is False
            assert "improvements" in out
            assert out["repository"]["file_count"] > 0
    run_test("T73", "Self-Evolution 2.0 Observational Audit", t_audit_is_observational)

    def t_dependency_truthfulness():
        d=self_evolution_2.dependency_status(env={"OPENAI_API_KEY":"x"})
        assert "OPENAI_API_KEY" in d["configured"]
        assert "BRAVE_SEARCH_API_KEY" in d["missing"]
    run_test("T74", "Self-Evolution 2.0 Dependency Availability Truthfulness", t_dependency_truthfulness)

    def t_plan_no_mutation():
        with tempfile.TemporaryDirectory() as td:
            db=os.path.join(td,"se2plan.db")
            from kora.core.db import init_db
            init_db(db)
            before=self_evolution_2.repository_fingerprint(self_evolution.repo_root())["sha256"]
            plan=self_evolution_2.evolution_plan("improve reliability", self_evolution.repo_root(), db, {})
            after=self_evolution_2.repository_fingerprint(self_evolution.repo_root())["sha256"]
            assert plan["status"] == "PLAN_READY"
            assert plan["production_mutation"] is False
            assert before == after
    run_test("T75", "Self-Evolution 2.0 Planning Never Mutates Production", t_plan_no_mutation)
