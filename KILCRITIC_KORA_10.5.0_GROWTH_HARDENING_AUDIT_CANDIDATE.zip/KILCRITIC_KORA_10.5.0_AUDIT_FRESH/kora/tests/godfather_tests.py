import os
import tempfile
from kora.core.db import init_db
from kora.services.godfather import plan_goal, evolution_decision, evidence_hash, capability_health


def run():
    db = os.path.join(tempfile.gettempdir(), "kora_godfather_test.db")
    try:
        os.remove(db)
    except FileNotFoundError:
        pass
    init_db(db)
    p = plan_goal("research trends and prepare a social post", db_path=db)
    assert p["planned_only"] is True
    assert "EXISTING_CAPABILITY_CHECK" in p["pipeline"]
    assert p["side_effect_gate"] == "approval_and_existing_permission_gate"
    assert p["execution_mode"] in ("sequential", "bounded_parallel")
    assert len(evidence_hash(p)) == 64
    assert evolution_decision(benefit=80, risk=10, complexity=10, measurable=True, reversible=True)["decision"] == "PROPOSE"
    assert evolution_decision(benefit=20, risk=40, complexity=40, measurable=True, reversible=True)["decision"] == "REFUSE"
    assert evolution_decision(benefit=90, risk=5, complexity=5, measurable=False, reversible=True)["decision"] == "HOLD"
    assert evolution_decision(benefit=90, risk=5, complexity=5, measurable=True, reversible=True, duplicate=True)["decision"] == "REFUSE"
    h = capability_health(db)
    assert h["handler_count"] >= 1
    return True
