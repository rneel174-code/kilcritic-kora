import tempfile, os
from kora.services.media_rights import make_record, preflight
from kora.services.hollywood_studio import studio_plan, quality_preflight
from kora.services.platform_readiness import readiness
from kora.services.asset_compiler import compile_variants
from kora.services.android_compat import load_avg_1m


def run():
    results=[]
    def t(name, fn):
        try:
            assert fn() is not False, 'assertion expression was False'
            results.append((name,'PASS'))
        except Exception as e: results.append((name,'FAIL:'+str(e)))
    t('rights_unknown_never_passes', lambda: (_ for _ in ()).throw(AssertionError()) if preflight(make_record('a','url','UNKNOWN'))['decision']=='PASS' else None)
    t('rights_owned_passes', lambda: (_ for _ in ()).throw(AssertionError()) if preflight(make_record('a','local','USER_OWNED'))['decision']!='PASS' else None)
    t('studio_categories', lambda: (_ for _ in ()).throw(AssertionError()) if 'FUNNY_BABY' not in studio_plan('FUNNY_BABY')['category'] else None)
    t('quality_gate_real_metrics', lambda: (_ for _ in ()).throw(AssertionError()) if quality_preflight({'width':1920,'height':1080,'duration_s':5,'black_frame_ratio':0,'audio_clipping':False})['decision']!='PASS' else None)
    t('platform_truth_tiktok', lambda: (_ for _ in ()).throw(AssertionError()) if readiness('TIKTOK', {})['status']!='AUTH_REQUIRED' else None)
    t('platform_truth_youtube', lambda: (_ for _ in ()).throw(AssertionError()) if readiness('YOUTUBE', {})['status']!='AUTH_REQUIRED' else None)
    t('asset_compiler', lambda: (_ for _ in ()).throw(AssertionError()) if compile_variants('master.mp4')['variant_count'] < 5 else None)
    t('android_loadavg_safe', lambda: load_avg_1m() is None or isinstance(load_avg_1m(), float))
    return results

if __name__ == '__main__':
    for name,status in run(): print(f'[{status}] {name}')
