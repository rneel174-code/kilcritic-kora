import unittest
from kora.supreme_runtime import (
    AgentContract, ExecutionProof, HorizonReducer, TrajectoryGuard,
    RuntimeWatchdog, StateMemoryTree, EvidenceRecord, ComplexityDebt,
    ObjectiveDrift, RecoveryProof, SupremeRuntime,
)

class SupremeRuntimeTests(unittest.TestCase):
    def test_horizon_reduction(self):
        self.assertEqual(HorizonReducer().reduce(["a","b","c","d"], 2), [["a","b"],["c","d"]])

    def test_contract_child_cannot_gain_authority(self):
        p = AgentContract("p", "g", ("read", "write"), max_steps=10, max_seconds=100, max_cost=5)
        c = p.child("c", "sub", ("write", "delete"))
        self.assertEqual(c.allowed_actions, ("write",))
        self.assertLessEqual(c.max_steps, p.max_steps)
        self.assertLessEqual(c.max_seconds, p.max_seconds)

    def test_trajectory_guard(self):
        g = TrajectoryGuard([["publish", "delete"]])
        self.assertFalse(g.check(["publish", "delete"])["safe"])
        self.assertTrue(g.check(["publish", "verify"])["safe"])

    def test_watchdog(self):
        w = RuntimeWatchdog(max_steps=2, max_errors=2)
        self.assertEqual(w.inspect(step=2, errors=0, action="x")["decision"], "STOP")

    def test_execution_proof_detects_tamper(self):
        p = ExecutionProof("c")
        p.append({"action":"read"})
        self.assertTrue(p.verify())
        p.events[0]["event"]["action"] = "delete"
        self.assertFalse(p.verify())

    def test_state_memory_trust(self):
        m = StateMemoryTree("root")
        m.add("a", "root", {"x":1})
        m.add("b", "a", {"x":2})
        self.assertEqual(len(m.trusted_path("b")), 2)
        m.mark_stale("a")
        self.assertEqual(m.trusted_path("b"), [])

    def test_evidence_freshness(self):
        e = EvidenceRecord("api", "official", max_age_seconds=3600)
        self.assertEqual(e.freshness(), "CURRENT")

    def test_complexity_debt(self):
        self.assertGreater(ComplexityDebt(10,1,1,1).score(), 0)

    def test_drift(self):
        self.assertTrue(ObjectiveDrift("a", "b").detected())
        self.assertFalse(ObjectiveDrift("a", "a").detected())

    def test_recovery_proof(self):
        self.assertTrue(RecoveryProof("x","cp",rollback_verified=True).valid())
        self.assertFalse(RecoveryProof("x","cp").valid())

    def test_facade(self):
        r = SupremeRuntime()
        c = AgentContract("c", "make content", ("research", "draft"))
        out = r.preflight(c, ["research","draft"])
        self.assertTrue(out["ready"])

if __name__ == "__main__":
    unittest.main()
