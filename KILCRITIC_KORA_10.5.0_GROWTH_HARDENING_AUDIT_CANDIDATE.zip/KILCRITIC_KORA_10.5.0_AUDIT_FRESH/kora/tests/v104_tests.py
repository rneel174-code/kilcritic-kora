"""10.4 hardening suites (registered into run_all as T122+). Every test is real: temp DBs, fake transports, no network, no credentials."""
import json, os, re, shutil, subprocess, tempfile, threading, time
from kora.core.db import init_db, get_connection


def _db(prefix="kora-v104-"):
    p = os.path.join(tempfile.mkdtemp(prefix=prefix), "t.db"); init_db(p); return p


# ---- LOCK-11 MALAK-ASSIST ----
def malak_guards():
    from kora.services import malak_assist as m
    db = _db()
    for reason in ("OTP", "CAPTCHA", "PAYMENT", "APPROVAL", "OAUTH", "HUMAN_INPUT"):
        p = m.pause_for_malak(reason, {"step": "x", "otp": "123456", "password": "hunter2", "note": "token abc12345"}, db_path=db, channels=["telegram"])
        assert p["status"] == "WAITING_FOR_MALAK" and p["checkpoint_saved"]
        t = m.get_task(p["task_id"], db)["task"]
        assert "123456" not in t["checkpoint"] and "hunter2" not in t["checkpoint"], "secret persisted"
        assert p["resume_token"] not in json.dumps(t), "one-time code must not be stored"
        r = m.resume(p["task_id"], p["resume_token"], db_path=db)
        assert r["status"] == "RESUMABLE"
        pol = r["policy"]
        assert pol["auto_pay"] is False and pol["payment_executed"] is False and pol["captcha_bypassed"] is False and pol["otp_value_stored"] is False
        assert pol["payment_requires_separate_explicit_approval"] is (reason == "PAYMENT")
    try:
        m.pause_for_malak("BYPASS_OTP", {}, db_path=db); raise AssertionError("unsupported reason accepted")
    except ValueError:
        pass


def malak_wrong_expired_duplicate():
    from kora.services import malak_assist as m
    db = _db(); p = m.pause_for_malak("OTP", {"a": 1}, db_path=db, channels=[])
    assert m.resume(p["task_id"], "nope", db_path=db)["status"] == "REJECTED"
    assert m.resume("missing", "x", db_path=db)["status"] == "NOT_FOUND"
    assert m.get_task(p["task_id"], db)["task"]["state"] == "WAITING_FOR_MALAK", "wrong reply must not resume"
    ok = m.resume(p["task_id"], p["resume_token"], db_path=db); assert ok["status"] == "RESUMABLE"
    assert m.resume(p["task_id"], p["resume_token"], db_path=db)["status"] == "REJECTED", "duplicate reply accepted"
    # token bound to its own task
    a = m.pause_for_malak("OTP", {}, db_path=db, channels=[]); b = m.pause_for_malak("OTP", {}, db_path=db, channels=[])
    assert m.resume(a["task_id"], b["resume_token"], db_path=db)["status"] == "REJECTED", "token reused across tasks"
    # lockout
    c = m.pause_for_malak("OTP", {}, db_path=db, channels=[])
    for _ in range(m.MAX_ATTEMPTS): m.resume(c["task_id"], "bad", db_path=db)
    assert m.resume(c["task_id"], c["resume_token"], db_path=db)["status"] == "LOCKED", "correct code accepted after lockout"
    # expiry
    d = m.pause_for_malak("OTP", {}, db_path=db, channels=[])
    cx = get_connection(db); cx.execute("UPDATE malak_assist_tasks SET expires_at=? WHERE id=?", (time.time() - 5, d["task_id"])); cx.close()
    assert m.resume(d["task_id"], d["resume_token"], db_path=db)["status"] == "EXPIRED"
    assert m.get_task(d["task_id"], db)["task"]["state"] == "EXPIRED"


def malak_unauthorized_inbound():
    from kora.services import malak_assist as m
    db = _db(); p = m.pause_for_malak("APPROVAL", {"job": 7}, db_path=db, channels=[])
    keep = {k: os.environ.pop(k, None) for k in ("KORA_MALAK_TELEGRAM_CHAT_ID", "KORA_MALAK_WHATSAPP_TO")}
    try:
        assert m.handle_inbound("telegram", "999", f"{p['task_id']} {p['resume_token']}", db_path=db)["status"] == "NOT_CONFIGURED"
        os.environ["KORA_MALAK_TELEGRAM_CHAT_ID"] = "4242"
        bad = m.handle_inbound("telegram", "9999", f"{p['task_id']} {p['resume_token']}", db_path=db)
        assert bad["status"] == "REJECTED" and bad["reason"] == "unauthorized_sender"
        assert m.handle_inbound("sms", "4242", f"{p['task_id']} {p['resume_token']}", db_path=db)["status"] in ("REJECTED", "NOT_CONFIGURED")
        assert m.handle_inbound("telegram", "4242", f"{p['resume_token']}", db_path=db)["reason"] == "no_matching_task_id", "reply must be task-bound"
        assert m.get_task(p["task_id"], db)["task"]["state"] == "WAITING_FOR_MALAK"
        ok = m.handle_inbound("telegram", "4242", f"{p['task_id']} {p['resume_token']}", db_path=db)
        assert ok["status"] == "RESUMABLE"
    finally:
        for k, v in keep.items():
            if v is None: os.environ.pop(k, None)
            else: os.environ[k] = v
        os.environ.pop("KORA_MALAK_TELEGRAM_CHAT_ID", None) if keep["KORA_MALAK_TELEGRAM_CHAT_ID"] is None else None


def malak_restart_consume_once():
    from kora.services import malak_assist as m
    db = _db(); p = m.pause_for_malak("PAYMENT", {"cart": "c1", "resume_at": "step3"}, db_path=db, channels=[])
    # "restart": brand-new connections only; durable state must survive
    rec = m.recover(db); assert [w["id"] for w in rec["waiting"]] == [p["task_id"]]
    assert m.resume(p["task_id"], p["resume_token"], db_path=db)["status"] == "RESUMABLE"
    results = []
    def take(): results.append(m.consume(p["task_id"], db_path=db)["status"])
    ts = [threading.Thread(target=take) for _ in range(6)]; [t.start() for t in ts]; [t.join() for t in ts]
    assert results.count("RESUMED") == 1 and results.count("REJECTED") == 5, results
    got = m.consume(p["task_id"], db_path=db); assert got["status"] == "REJECTED"
    assert m.recover(db)["interrupted_needs_review"] == [p["task_id"]], "crash mid-execution must be reported, not re-run"
    assert m.complete(p["task_id"], verified=False, outcome="otp=998877 failed", db_path=db)["status"] == "FAILED"
    assert "998877" not in m.get_task(p["task_id"], db)["task"].get("outcome", "") 
    assert m.complete(p["task_id"], verified=True, db_path=db)["status"] == "REJECTED", "completed twice"


def malak_notification_truth():
    from kora.services import malak_assist as m
    db = _db()
    keep = {k: os.environ.pop(k, None) for k in ("KORA_MALAK_TELEGRAM_BOT_TOKEN", "KORA_MALAK_TELEGRAM_CHAT_ID", "KORA_WHATSAPP_CLOUD_TOKEN", "KORA_WHATSAPP_PHONE_NUMBER_ID", "KORA_MALAK_WHATSAPP_TO")}
    try:
        p = m.pause_for_malak("OTP", {}, db_path=db)
        assert {x["channel"]: x["status"] for x in p["notifiers"]} == {"telegram": "NOT_CONFIGURED", "whatsapp": "NOT_CONFIGURED"}
        assert m.get_task(p["task_id"], db)["task"]["notifier_status"] == "NOT_CONFIGURED"
        assert m.get_task(p["task_id"], db)["task"]["state"] == "WAITING_FOR_MALAK", "notification failure must not fake SENT/RESUMED"
    finally:
        for k, v in keep.items():
            if v is not None: os.environ[k] = v
    # configured-but-unreachable adapter => FAILED, never SENT
    os.environ["KORA_MALAK_TELEGRAM_BOT_TOKEN"] = "123:SECRETTOKEN"; os.environ["KORA_MALAK_TELEGRAM_CHAT_ID"] = "1"
    real = m.urllib.request.urlopen
    m.urllib.request.urlopen = lambda *a, **k: (_ for _ in ()).throw(OSError("net down"))
    try:
        p = m.pause_for_malak("OTP", {}, db_path=db, channels=["telegram"])
        assert p["notifiers"][0]["status"] == "FAILED" and "SECRETTOKEN" not in json.dumps(p["notifiers"])
        assert m.get_task(p["task_id"], db)["task"]["notifier_status"] == "FAILED"
    finally:
        m.urllib.request.urlopen = real
        os.environ.pop("KORA_MALAK_TELEGRAM_BOT_TOKEN", None); os.environ.pop("KORA_MALAK_TELEGRAM_CHAT_ID", None)


def malak_redaction_and_audit():
    from kora.services import malak_assist as m
    from kora.core.db import verify_audit_chain
    db = _db()
    r = m.redact({"otp": "1", "nested": {"api_key": "k"}, "shipping": "ok", "text": "my otp: 554433 and Bearer abcdefgh12345678 and card 4111111111111111"})
    s = json.dumps(r)
    for leak in ("554433", "abcdefgh12345678", "4111111111111111"): assert leak not in s, leak
    assert r["shipping"] == "ok" and r["otp"] == "[REDACTED]" and r["nested"]["api_key"] == "[REDACTED]"
    p = m.pause_for_malak("OTP", {"x": 1}, db_path=db, channels=[]); m.resume(p["task_id"], "bad", db_path=db)
    c = get_connection(db); rows = c.execute("SELECT payload FROM audit_log").fetchall() if _has(c, "audit_log") else []; c.close()
    assert p["resume_token"] not in json.dumps([dict(x) if hasattr(x, "keys") else x for x in rows]), "code leaked into audit"
    assert verify_audit_chain(db)["ok"] if isinstance(verify_audit_chain(db), dict) else verify_audit_chain(db)


def _has(c, t):
    return c.execute("SELECT 1 FROM sqlite_master WHERE name=?", (t,)).fetchone() is not None


# ---- capability truth + media convert ----
def capability_truth():
    from kora.services import capability_audit as ca
    a = ca.audit()["capabilities"]
    assert a["studio.pipeline"]["state"] == "PLANNING_ONLY"
    assert a["media.create"]["state"] == "NOT_IMPLEMENTED"
    assert all(v["state"] != "IMPLEMENTED" for v in a.values()), "legacy IMPLEMENTED label must not exist"
    for k, v in a.items():
        if k.startswith("social."): assert v["state"] == "READY_WITH_EXTERNAL_SETUP" and v["live_verified"] is False
    assert a["passkeys"]["state"] == "UNAVAILABLE"
    has = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))
    assert a["media.convert"]["state"] == ("IMPLEMENTED_VERIFIED" if has else "UNAVAILABLE")


def media_convert_real():
    from kora.services import media_pipeline as mp
    root = tempfile.mkdtemp(prefix="kora-media-")
    try:
        mp.convert_variant("/etc/passwd", "square_1080", media_root=root); raise AssertionError("outside root accepted")
    except mp.MediaPipelineError:
        pass
    try:
        mp.convert_variant("/etc/passwd", "bogus", media_root=root); raise AssertionError("bad target accepted")
    except mp.MediaPipelineError:
        pass
    if not (shutil.which("ffmpeg") and shutil.which("ffprobe")):
        r = None
        src = os.path.join(root, "a.mp4"); open(src, "wb").write(b"x")
        assert mp.convert_variant(src, "square_1080", media_root=root)["state"] == "UNAVAILABLE"; return
    src = os.path.join(root, "src.mp4")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i", "testsrc=size=640x360:rate=10:duration=1", "-pix_fmt", "yuv420p", src], check=True, timeout=60)
    out = mp.convert_variant(src, "vertical_1080x1920", media_root=root)
    assert out["state"] == "EXPORTED_VERIFIED" and os.path.getsize(out["output"]) > 0 and out["measured"] == {"width": 1080, "height": 1920}, out
    bad = os.path.join(root, "broken.mp4"); open(bad, "wb").write(b"not a video")
    r = mp.convert_variant(bad, "square_1080", media_root=root)
    assert r["state"] in ("FAILED", "UNVERIFIED") and r["output"] is None, "garbage input must never report EXPORTED"
    link = os.path.join(root, "evil.mp4")
    try:
        os.symlink("/etc/passwd", link)
        mp.convert_variant(link, "square_1080", media_root=root); raise AssertionError("symlink escape accepted")
    except mp.MediaPipelineError:
        pass


def register(run_test):
    register2(run_test)
    _register_guardian(run_test)
    _hyg(run_test)
    run_test("T122", "LOCK-11 OTP/CAPTCHA/PAYMENT/APPROVAL guards: never auto-pay, never store OTP/secret, unsupported reason refused", malak_guards)
    run_test("T123", "LOCK-11 wrong / expired / duplicate / cross-task replies rejected; lockout after repeated wrong codes", malak_wrong_expired_duplicate)
    run_test("T124", "LOCK-11 unauthorized sender + task-unbound reply rejected; authorized Malak reply resumes; NOT_CONFIGURED truthful", malak_unauthorized_inbound)
    run_test("T125", "LOCK-11 restart recovery of checkpoints + checkpoint consumed exactly once under 6-thread race + crash mid-run reported", malak_restart_consume_once)
    run_test("T126", "LOCK-11 notification failure/NOT_CONFIGURED never fakes SENT; bot token never leaks", malak_notification_truth)
    run_test("T127", "LOCK-11 secret/OTP/card/bearer redaction (keys + free text) and audit never contains the one-time code", malak_redaction_and_audit)
    run_test("T128", "Capability truth: planning != IMPLEMENTED, media.create NOT_IMPLEMENTED, social READY_WITH_EXTERNAL_SETUP unverified", capability_truth)
    run_test("T129", "media.convert real ffmpeg: size verified by ffprobe, garbage never EXPORTED, outside-root/symlink/bad-target refused", media_convert_real)


# ---- scheduler / rights / instagram / recovery (10.4) ----
OWNED = {"rights": "OWNED", "source": "original"}


def _xenv(**kw):
    return {"X_OAUTH2_USER_TOKEN": "xtok", **kw}


def _fake(sent, script=None):
    script = list(script or [])
    def tr(method, url, headers, body, timeout):
        sent.append(url)
        if script: return script.pop(0)
        return 201, {}, json.dumps({"data": {"id": "tweet-%d" % len(sent)}}).encode()
    return tr


class _Rig:
    """Install a fake transport/env into the real publish handler; always restore."""
    def __init__(self, sent, script=None, env=None):
        self.sent, self.script, self.env = sent, script, env if env is not None else _xenv()
    def __enter__(self):
        from kora.services import handlers as H
        self.H = H; H.SOCIAL_TRANSPORT, H.SOCIAL_ENV = _fake(self.sent, self.script), self.env
        self.old = os.environ.get("X_OAUTH2_USER_TOKEN"); os.environ["X_OAUTH2_USER_TOKEN"] = "xtok"
        return self
    def __exit__(self, *a):
        self.H.SOCIAL_TRANSPORT = self.H.SOCIAL_ENV = None
        if self.old is None: os.environ.pop("X_OAUTH2_USER_TOKEN", None)
        else: os.environ["X_OAUTH2_USER_TOKEN"] = self.old


def _mk(db, q, text="hello", platform="X", approve=False, **kw):
    from kora.services import social
    meta = kw.pop("asset_meta", OWNED)
    r = social.create_social_post(platform, text, "GENERAL", db_path=db, auto_approve=False, queue=q, env=_xenv(), auto_publish=False, asset_meta=meta, **kw)
    if approve: social.approve_and_publish_post(r["post_id"], db, env=_xenv(), queue=q, auto_publish=False)
    return r


def _sched(db, pid, secs=3600):
    from kora.services import scheduled_autopilot as sa
    when = time.strftime("%Y-%m-%dT%H:%M", time.gmtime(time.time() + secs))
    return sa.create_schedule(pid, when, "UTC", "ONCE", db)


def rights_gate():
    from kora.services import legal_guard, social
    from kora.core.queue import DurableQueue
    bad = [{"platform": "X", "content": "x", "rights": "UNKNOWN"}, {"platform": "X", "content": "full pirated movie download", "rights": "OWNED", "source": "original"},
           {"platform": "X", "content": "x", "rights": "COPIED_FROM_WEB"}, {"platform": "X", "content": "x", "adult_content": True, "rights": "OWNED", "source": "original"},
           {"platform": "X", "content": "celebrity voice clone ad", "rights": "OWNED", "source": "original"}, {"platform": "X", "content": "plain text, nothing declared"}]
    for b in bad:
        r = legal_guard.preflight(b)
        assert r.get("status", r.get("verdict")) not in ("PASS", "AUTO_FIXED"), (b, r)
    ok = legal_guard.preflight({"platform": "X", "content": "my own words", "rights": "OWNED", "source": "original"})
    assert ok.get("status", ok.get("verdict")) in ("PASS", "AUTO_FIXED"), ok
    db = _db(); q = DurableQueue(db, retry_base=0)
    sent = []
    with _Rig(sent):
        p = social.create_social_post("X", "undeclared rights", "GENERAL", db_path=db, auto_approve=True, queue=q, env=_xenv(), auto_publish=True)
        assert p["status"] != "PUBLISHED" and p["status"] in ("PENDING_APPROVAL", "HUMAN_REVIEW", "BLOCKED"), p
        try:
            p2 = social.create_social_post("X", "pirated movie full copy", "GENERAL", db_path=db, auto_approve=True, queue=q, env=_xenv(), auto_publish=True, asset_meta={"rights": "UNKNOWN"})
            assert p2["status"] != "PUBLISHED"
        except social.SocialPublishError as e:
            assert "legal_preflight_blocked" in str(e)
    assert sent == [], "risky content reached the platform"
    # even a human approve of a non-PASS post must not be silently auto-approved by the scheduler
    from kora.services import scheduled_autopilot as sa
    s = _sched(db, p["post_id"]); r = sa.process_due(db, q, now=time.time() + 7200, auto_approve=True)
    assert all(x["status"] != "PUBLISHED" for x in r) and not sent, r


def schedule_lifecycle_truth():
    from kora.services import scheduled_autopilot as sa, social
    from kora.core.queue import DurableQueue
    from kora_core.worker import SafeWorker
    db = _db(); q = DurableQueue(db, retry_base=0); sent = []
    with _Rig(sent):
        p = _mk(db, q); s = _sched(db, p["post_id"]); due = time.time() + 7200
        r = sa.process_due(db, q, now=due)
        assert r[0]["status"] == "WAITING_APPROVAL" and sa.get_schedule(s["id"], db)["status"] == "WAITING_APPROVAL" and not sent
        assert sa.process_due(db, q, now=due + 1)[0]["status"] == "WAITING_APPROVAL", "WAITING_APPROVAL must be re-checked each tick"
        social.approve_and_publish_post(p["post_id"], db, env=_xenv(), queue=q, auto_publish=False)
        r = sa.process_due(db, q, now=due + 2)
        assert sa.get_schedule(s["id"], db)["status"] in ("QUEUED", "PUBLISHED"), r
        w = SafeWorker(q, "w"); w.process_one()
        sa.process_due(db, q, now=due + 3)
        row = sa.get_schedule(s["id"], db)
        assert row["status"] == "PUBLISHED" and row["external_id"], row
        assert len(sent) == 1, "exactly one external call"
        assert sa.process_due(db, q, now=due + 4) == [] and len(sent) == 1
        rep = sa.replay_from_audit(db); assert rep.get("match", rep.get("ok")) in (True,), rep


def schedule_credentials_truth():
    from kora.services import scheduled_autopilot as sa, social
    from kora.core.queue import DurableQueue
    from kora_core.worker import SafeWorker
    db = _db(); q = DurableQueue(db, retry_base=0); sent = []
    old = os.environ.pop("X_OAUTH2_USER_TOKEN", None)
    try:
        r = social.create_social_post("X", "needs creds", "GENERAL", db_path=db, auto_approve=False, queue=q, env={}, auto_publish=False, asset_meta=OWNED)
        res = social.approve_and_publish_post(r["post_id"], db, env={}, queue=q, auto_publish=False)
        assert res["status"] == "APPROVED_AWAITING_CREDENTIALS", res
        s = _sched(db, r["post_id"]); due = time.time() + 7200
        out = sa.process_due(db, q, now=due)
        row = sa.get_schedule(s["id"], db)
        assert row["status"] == "WAITING_CREDENTIALS" and "credentials_missing" in (row["last_error"] or ""), row
        assert row["approval_state"] != "PENDING_APPROVAL", "must not be mislabeled as awaiting approval"
        assert not sent
        with _Rig(sent):  # credentials arrive later -> next tick re-checks and proceeds
            sa.process_due(db, q, now=due + 1); SafeWorker(q, "w").process_one(); sa.process_due(db, q, now=due + 2)
            assert sa.get_schedule(s["id"], db)["status"] == "PUBLISHED" and len(sent) == 1
    finally:
        if old is not None: os.environ["X_OAUTH2_USER_TOKEN"] = old


def schedule_state_guards():
    from kora.services import scheduled_autopilot as sa
    from kora.core.queue import DurableQueue
    db = _db(); q = DurableQueue(db, retry_base=0)
    p = _mk(db, q); s = _sched(db, p["post_id"])
    try:
        r = sa.resume(s["id"], db); assert r is False, "resume of non-paused must not succeed"
    except sa.ScheduleStateError: pass
    assert sa.pause(s["id"], db) and sa.get_schedule(s["id"], db)["status"] == "PAUSED"
    assert sa.process_due(db, q, now=time.time() + 99999) == [], "paused schedules never fire"
    assert sa.resume(s["id"], db) and sa.get_schedule(s["id"], db)["status"] == "SCHEDULED"
    assert sa.cancel(s["id"], db)
    for fn in (sa.pause, sa.resume, sa.cancel):
        try:
            assert fn(s["id"], db) is False
        except sa.ScheduleStateError: pass
    assert sa.get_schedule(s["id"], db)["status"] == "CANCELLED", "cancelled must stay cancelled"
    try: sa.edit_schedule(s["id"], db_path=db); raise AssertionError("edit after cancel")
    except sa.ScheduleStateError: pass
    assert sa.pause("nope", db) is False
    # a published schedule cannot be cancelled/paused/edited
    from kora.core.db import get_connection as gc
    s2 = _sched(db, _mk(db, q, "two")["post_id"]); c = gc(db); c.execute("UPDATE autopilot_schedules SET status='PUBLISHED' WHERE id=?", (s2["id"],)); c.close()
    for fn in (sa.pause, sa.cancel):
        try: assert fn(s2["id"], db) is False
        except sa.ScheduleStateError: pass
    assert sa.get_schedule(s2["id"], db)["status"] == "PUBLISHED"
    # edit + calendar
    s3 = _sched(db, _mk(db, q, "three")["post_id"])
    when = time.strftime("%Y-%m-%dT%H:%M", time.gmtime(time.time() + 9000))
    assert sa.edit_schedule(s3["id"], when, "UTC", "DAILY", db_path=db)["frequency"] == "DAILY"
    cal = sa.create_calendar([{"post_id": _mk(db, q, f"d{i}")["post_id"], "scheduled_for": time.strftime("%Y-%m-%dT%H:%M", time.gmtime(time.time() + 3600 * (i + 2))), "timezone": "UTC"} for i in range(30)], db)
    assert cal["count"] == 30
    n = len(sa.list_schedules(db, 500))
    try: sa.create_calendar([{"post_id": "ghost", "scheduled_for": when}], db); raise AssertionError
    except ValueError: pass
    assert len(sa.list_schedules(db, 500)) == n, "bad calendar must not leave half a calendar"


def schedule_restart_and_race():
    from kora.services import scheduled_autopilot as sa, social
    from kora.core.queue import DurableQueue
    from kora.core.db import get_connection as gc
    from kora_core.worker import SafeWorker
    db = _db(); q = DurableQueue(db, retry_base=0); sent = []
    with _Rig(sent):
        p = _mk(db, q, approve=True); s = _sched(db, p["post_id"]); due = time.time() + 7200
        # crash window: claimed (QUEUED) but process died before dispatch -> no job exists
        c = gc(db); c.execute("UPDATE autopilot_schedules SET status='QUEUED', claimed_at=? WHERE id=?", (due - 1000, s["id"])); c.close()
        res = []
        ts = [threading.Thread(target=lambda: res.append(sa.process_due(db, DurableQueue(db, retry_base=0), now=due))) for _ in range(6)]
        [t.start() for t in ts]; [t.join() for t in ts]
        c = gc(db); jobs = c.execute("SELECT COUNT(*) n FROM jobs WHERE handler_name='social_publish'").fetchone()["n"]; c.close()
        assert jobs == 1, f"duplicate jobs after crash+race: {jobs}"
        for _ in range(4): SafeWorker(DurableQueue(db, retry_base=0), "w").process_one()
        sa.process_due(db, q, now=due + 5)
        assert len(sent) == 1 and social.get_post(p["post_id"], db)["status"] == "PUBLISHED"
        assert sa.get_schedule(s["id"], db)["status"] == "PUBLISHED"
        # restart: nothing re-fires, nothing duplicated
        q2 = DurableQueue(db, retry_base=0); assert sa.process_due(db, q2, now=due + 99) == [] and len(sent) == 1
        assert len({x["id"] for x in sa.list_schedules(db)}) == len(sa.list_schedules(db))


def schedule_retry_and_failures():
    from kora.services import scheduled_autopilot as sa, social
    from kora.core.queue import DurableQueue
    from kora_core.worker import SafeWorker
    db = _db(); q = DurableQueue(db, retry_base=0); sent = []
    boom = (500, {}, b"err")
    with _Rig(sent, script=[boom, boom, (201, {}, json.dumps({"data": {"id": "ok1"}}).encode())]):
        p = _mk(db, q, approve=True); s = _sched(db, p["post_id"]); due = time.time() + 7200
        sa.process_due(db, q, now=due)
        for _ in range(6): SafeWorker(q, "w").process_one(); sa.process_due(db, q, now=due + 1)
        assert sa.get_schedule(s["id"], db)["status"] == "PUBLISHED" and len(sent) == 3, (sa.get_schedule(s["id"], db), len(sent))
    sent2 = []
    with _Rig(sent2, script=[(200, {}, b"<html>not json")]):  # malformed 2xx must not crash or fake success
        p = _mk(db, q, "bad", approve=True); s = _sched(db, p["post_id"]); due = time.time() + 7200
        sa.process_due(db, q, now=due); SafeWorker(q, "w").process_one(); sa.process_due(db, q, now=due + 1)
        row = sa.get_schedule(s["id"], db); post = social.get_post(p["post_id"], db)
        assert row["status"] == "FAILED" and post["status"] == "FAILED" and not post.get("external_id"), (row, post)
        assert "malformed" in (post.get("last_error") or "") + (row.get("last_error") or "")
    sent3 = []
    with _Rig(sent3, script=[(401, {}, b"nope")]):
        p = _mk(db, q, "auth", approve=True); s = _sched(db, p["post_id"]); due = time.time() + 7200
        sa.process_due(db, q, now=due); SafeWorker(q, "w").process_one(); sa.process_due(db, q, now=due + 1)
        assert sa.get_schedule(s["id"], db)["status"] == "FAILED" and len(sent3) == 1, "401 is permanent: one call, FAILED"
        try: sa.retry(s["id"], db); raise AssertionError("retry of a FAILED post would allow a duplicate-prone re-send")
        except sa.ScheduleStateError: pass


def instagram_readiness():
    from kora.services import social
    from kora.core.queue import DurableQueue
    db = _db(); q = DurableQueue(db, retry_base=0)
    env = {"INSTAGRAM_ACCESS_TOKEN": "t", "INSTAGRAM_BUSINESS_ACCOUNT_ID": "1784140000000"}
    def mk(**kw):
        return social.create_social_post("INSTAGRAM", "ig", "GENERAL", db_path=db, auto_approve=False, queue=q, env=env, auto_publish=False, asset_meta=OWNED, **kw)
    r = mk(); assert r["status"] == "PENDING_APPROVAL"
    try: social.approve_and_publish_post(r["post_id"], db, env=env, queue=q, auto_publish=False); raise AssertionError("IG approved without media")
    except social.SocialPublishError as e: assert "media_required" in str(e), e
    for bad in ("http://cdn.example.com/a.mp4", "https://127.0.0.1/a.mp4", "https://169.254.169.254/latest", "ftp://x/a.mp4", "https://localhost/a.mp4", "file:///etc/passwd", "https://10.0.0.5/a.mp4"):
        try: mk(public_media_url=bad, media_type="REEL"); raise AssertionError("unsafe media url accepted: " + bad)
        except Exception as e:
            assert not isinstance(e, AssertionError), str(e)
    ok = mk(public_media_url="https://cdn.example.com/a.mp4", media_type="REEL")
    assert social.get_post(ok["post_id"], db)["media_url"] == "https://cdn.example.com/a.mp4"
    # account readiness: an OFF account is not silently used
    social.account_set("owner-1", "INSTAGRAM", "OFF", db_path=db) if hasattr(social, "account_set") else None
    pf = social.posting_preflight("owner-1", "INSTAGRAM", db, env)
    assert pf["ready"] is False, pf


def touch_workflow():
    from kora.services import brain
    db = _db()
    for name in ("Social Publishing", "Hollywood Studio", "Editing", "Convert + Quality", "Post + Autopilot", "Research + Search"):
        r = brain.handle(f"Open {name} workflow", principal={"role": "OWNER", "id": "t"}, source="touch", db_path=db)
        assert r["status"] not in ("INVALID", "ERROR"), r
        assert r.get("executed") in (False, None), "planning must not claim execution"
        assert r["status"] in ("PLANNED", "OK", "NEEDS_CLARIFICATION"), r


def _brain_takes_dict():
    import inspect
    from kora.services import brain
    return list(inspect.signature(brain.handle).parameters)[0] in ("body", "payload", "req")


def register2(run_test):
    run_test("T130", "Rights/safety gate: UNKNOWN/pirated/copied/adult/voice-clone/undeclared never PASS or auto-publish; scheduler cannot force them", rights_gate)
    run_test("T131", "Schedule lifecycle truth: SCHEDULED->WAITING_APPROVAL (re-checked)->QUEUED->PUBLISHED w/ external id, one external call, audit replay matches", schedule_lifecycle_truth)
    run_test("T132", "Credentials truth: WAITING_CREDENTIALS (not 'approval'), re-checked every tick, proceeds once credentials exist", schedule_credentials_truth)
    run_test("T133", "Pause/Resume/Cancel/Edit state guards + 30-item calendar all-or-nothing", schedule_state_guards)
    run_test("T134", "Crash-after-claim recovery + 6-thread race => exactly one job / one external call; restart does not re-fire", schedule_restart_and_race)
    run_test("T135", "Retry 500x2 then success (3 calls); malformed 2xx => FAILED not crash; 401 permanent 1 call; no duplicate-prone retry", schedule_retry_and_failures)
    run_test("T136", "Instagram: media required, SSRF/unsafe media URL refused, media_url persisted, OFF account not ready", instagram_readiness)
    run_test("T137", "Touch -> valid PLANNED workflow for categories (never INVALID, never claims execution)", touch_workflow)


def _guardian():
    from kora.tests import guardian_tests as g
    g.run(); g.test_malak_assist()


def _register_guardian(run_test):
    run_test("T150", "Supreme Guardian LOCK-01..10 + LOCK-11 basic malak flow (previously unregistered suite)", _guardian)


def hygiene():
    """Release hygiene: no merge-conflict markers, no secrets in shipped files, and the safe rights contract stays the only contract."""
    from kora.services import legal_guard
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    rx_conf = re.compile(r"^(<{7}( |$)|={7}$|>{7}( |$))", re.M)
    rx_sec = re.compile(r"sk-[A-Za-z0-9_\-]{20,}|AIza[0-9A-Za-z_\-]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|-----BEGIN [A-Z ]*PRIVATE KEY-----|AKIA[0-9A-Z]{16}")
    conf, sec = [], []
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in ("data", "__pycache__", "node_modules", "_quarantine", ".git")]
        for f in fn:
            if not f.endswith((".py", ".ts", ".tsx", ".js", ".json", ".html", ".css", ".md", ".txt", ".toml", ".cfg")): continue
            p = os.path.join(dp, f); t = open(p, encoding="utf-8", errors="ignore").read()
            if rx_conf.search(t): conf.append(os.path.relpath(p, root))
            if rx_sec.search(t) and "/tests/" not in p.replace("\\", "/") and f not in ("fortress.py", "malak_assist.py", "supreme_guardian.py"): sec.append(os.path.relpath(p, root))
    assert not conf, "merge conflict markers: %s" % conf
    assert not sec, "secret-looking strings: %s" % sec
    for body in ({"platform": "X", "content": "hello"}, {"platform": "X", "content": "hello", "rights": "UNKNOWN"}, {"platform": "X", "content": "hi", "media": True}):
        st = legal_guard.preflight(body).get("status")
        assert st in ("HUMAN_REVIEW", "BLOCKED"), (body, st)


def _hyg(run_test):
    run_test("T151", "Release hygiene: zero conflict markers, no secrets in shipped files, undeclared/unknown rights => HUMAN_REVIEW/BLOCKED", hygiene)
