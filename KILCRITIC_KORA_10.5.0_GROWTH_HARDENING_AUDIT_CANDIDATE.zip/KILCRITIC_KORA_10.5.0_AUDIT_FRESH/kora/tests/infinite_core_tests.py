import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from kora.core.infinite_core import InfiniteReactor

class InfiniteCoreTests(unittest.TestCase):
    def test_logical_capacity_is_truthful(self):
        r = InfiniteReactor(logical_capacity_gb=10000)
        self.assertTrue(r.validate_large_workload(10000)["supported_out_of_core"])
        self.assertFalse(r.profile()["fake_hardware_power"])

    def test_large_stream_is_bounded(self):
        r = InfiniteReactor()
        with TemporaryDirectory() as d:
            p = Path(d) / "sample.bin"
            p.write_bytes(b"x" * (2 * 1024 * 1024))
            chunks = list(r.stream_big(p, chunk_mb=1, max_mmap_mb=0))
            self.assertEqual(sum(map(len, chunks)), 2 * 1024 * 1024)
            self.assertLessEqual(max(map(len, chunks)), 1024 * 1024)

if __name__ == "__main__":
    unittest.main()
