"""Creator OS / gap-closure / regional / final-upgrade suites, registered into the single run_all runner (strict: any FAIL fails)."""
from kora.tests import final_upgrade_tests, gap_closure_tests, regionalization_tests


def _suite(label, rows):
    bad = [f"{n}: {s}" for n, s in rows if s != "PASS"]
    assert rows and not bad, f"{label}: {bad}"


def register(run_test):
    run_test("T119", "Instagram Graph + TikTok Direct Post adapters (fake transport), vault, outbox, resource guard, truth matrix",
             lambda: _suite("gap_closure", gap_closure_tests.run()))
    run_test("T120", "Rights gate, studio categories, quality gate, platform truth, asset compiler, android-safe loadavg",
             lambda: _suite("final_upgrade", final_upgrade_tests.run()))

    def regional():
        names = [n for n in dir(regionalization_tests) if n.startswith("test_")]
        assert len(names) >= 3
        for n in names:
            getattr(regionalization_tests, n)()
    run_test("T121", "CA/US/IN regional profiles: locales, currencies, Amazon marketplaces, unknown region rejected", regional)
