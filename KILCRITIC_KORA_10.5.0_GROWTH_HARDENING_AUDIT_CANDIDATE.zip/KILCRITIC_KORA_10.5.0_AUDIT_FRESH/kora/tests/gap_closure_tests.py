import os, tempfile, json
from kora.services.publishers import publish_instagram, publish_tiktok, PublishError
from kora.services.platform_readiness import readiness
from kora.services.secure_vault import seal, open_sealed
from kora.services.runtime_limits import enforce, ResourceLimits
from kora.services.notification_outbox import enqueue, pending
from kora.services.capability_audit import audit
from kora.core.db import init_db, get_connection

def run():
    results=[]
    def t(name, fn):
        try:
            assert fn() is not False, 'assertion expression was False'
            results.append((name,'PASS'))
        except Exception as e: results.append((name,'FAIL:'+str(e)))
    def transport(method,url,headers,body,timeout):
        if 'instagram' in url or 'graph.facebook.com' in url:
            if url.endswith('/media'): return 200,{},b'{"id":"container-1"}'
            if url.endswith('/media_publish'): return 200,{},b'{"id":"ig-1"}'
        raise AssertionError(url)
    t('instagram_adapter_mock', lambda: publish_instagram({'content':'hi','media_url':'https://cdn.example/x.mp4','media_type':'REEL'},{'INSTAGRAM_ACCESS_TOKEN':'t','INSTAGRAM_USER_ID':'123'},transport)=='ig-1')
    with tempfile.TemporaryDirectory() as d:
        path=os.path.join(d,'v.mp4'); open(path,'wb').write(b'12345')
        def tt(method,url,headers,body,timeout):
            if url.endswith('/creator_info/query/'): return 200,{},b'{"data":{"privacy_level_options":["SELF_ONLY"]}}'
            if url.endswith('/video/init/'): return 200,{},b'{"data":{"publish_id":"pub-1","upload_url":"https://open-upload.tiktokapis.com/u/1"}}'
            if url.startswith('https://open-upload'): return 200,{},b''
            if url.endswith('/status/fetch/'): return 200,{},b'{"data":{"status":"PUBLISH_COMPLETE"}}'
            raise AssertionError(url)
        t('tiktok_adapter_mock', lambda: __import__('kora.services.publishers',fromlist=['publish_tiktok']).publish_tiktok({'content':'hi','media_path':path},{'TIKTOK_ACCESS_TOKEN':'t'},tt)=='pub-1')
    t('readiness_ig_auth', lambda: readiness('INSTAGRAM', {})['status']=='AUTH_REQUIRED')
    t('readiness_tiktok_auth', lambda: readiness('TIKTOK', {})['status']=='AUTH_REQUIRED')
    t('vault_roundtrip', lambda: open_sealed(seal({'x':'secret'},'pw'),'pw')['x']=='secret')
    t('resource_guard', lambda: enforce(ResourceLimits(max_rss_mb=100000,min_free_disk_mb=1)))
    with tempfile.TemporaryDirectory() as d:
        db=os.path.join(d,'x.db'); init_db(db); n=enqueue('LOCAL',{'ok':1},db); t('notification_outbox', lambda: pending(10,db)[0]['id']==n)
        c=get_connection(db); cols={r[1] for r in c.execute('PRAGMA table_info(social_posts)').fetchall()}; c.close(); t('social_media_columns', lambda: {'media_url','media_type','ai_generated'} <= cols)
    t('capability_truth', lambda: audit()['capabilities']['passkeys']['state']=='UNAVAILABLE')
    return results
if __name__=='__main__':
    for n,s in run(): print(f'[{s}] {n}')
