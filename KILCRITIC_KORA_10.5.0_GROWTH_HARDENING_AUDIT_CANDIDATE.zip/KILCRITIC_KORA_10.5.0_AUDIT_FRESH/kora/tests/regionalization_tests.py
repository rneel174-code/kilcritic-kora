import os
from kora.services.regionalization import get_region, localized_defaults


def test_regions():
    assert get_region("IN")["currency"] == "INR"
    assert get_region("US")["currency"] == "USD"
    assert get_region("CA")["currency"] == "CAD"


def test_amazon_locales_are_separate():
    assert get_region("IN")["amazon"]["associates_locale"] == "IN"
    assert get_region("US")["amazon"]["associates_locale"] == "US"
    assert get_region("CA")["amazon"]["associates_locale"] == "CA"
    assert all(get_region(x)["amazon"]["requires_separate_associate_registration"] for x in ("IN","US","CA"))


def test_unknown_region_rejected():
    try:
        get_region("XX")
    except ValueError:
        return
    raise AssertionError("unknown region must be rejected")
