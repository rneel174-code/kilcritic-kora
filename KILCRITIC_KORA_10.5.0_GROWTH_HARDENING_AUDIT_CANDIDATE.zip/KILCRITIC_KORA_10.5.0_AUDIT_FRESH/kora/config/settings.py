"""KORA PRO configuration: one typed Settings object, loaded from the environment.

* A `.env` file (KEY=VALUE lines) is read if present, WITHOUT overriding real environment variables.
* No secret has a built-in default. An unset token means "remote access denied", never "default password".
* Values are clamped to safe ranges so a typo cannot create an unbounded queue/pool.
"""
from __future__ import annotations
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional, Tuple

_TRUE = {"1", "true", "yes", "on"}


def load_dotenv(path: str = ".env", environ: Optional[Dict[str, str]] = None) -> int:
    """Minimal .env loader. Returns number of variables set. Never overrides existing variables."""
    env = os.environ if environ is None else environ
    p = Path(path)
    if not p.is_file():
        return 0
    n = 0
    for raw in p.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        if k and k not in env:
            env[k] = v
            n += 1
    return n


def _int(env, key: str, default: int, lo: int, hi: int) -> int:
    try:
        v = int(str(env.get(key, default)).strip())
    except ValueError:
        v = default
    return max(lo, min(hi, v))


def _float(env, key: str, default: float, lo: float, hi: float) -> float:
    try:
        v = float(str(env.get(key, default)).strip())
    except ValueError:
        v = default
    return max(lo, min(hi, v))


def _bool(env, key: str, default: bool) -> bool:
    raw = env.get(key)
    return default if raw is None or str(raw).strip() == "" else str(raw).strip().lower() in _TRUE


def _csv(env, key: str, default: str = "") -> Tuple[str, ...]:
    return tuple(x.strip() for x in str(env.get(key, default)).split(",") if x.strip())


@dataclass(frozen=True)
class Settings:
    # region / localization
    region: str = "IN"
    # server / bridge
    bind_host: str = "127.0.0.1"
    port: int = 8000
    auth_token: str = ""                 # empty => only local clients are allowed
    require_auth_local: bool = False     # true => even localhost must present the token
    trust_proxy: bool = False            # true => honour X-Forwarded-For (ONLY behind your own proxy)
    allowed_hosts: Tuple[str, ...] = ("127.0.0.1", "localhost", "[::1]")
    allowed_origins: Tuple[str, ...] = ()
    max_body_bytes: int = 1024 * 1024
    # rate limit (token bucket per client+class)
    rate_limit_enabled: bool = True
    rate_read_per_min: int = 240
    rate_write_per_min: int = 60
    rate_heavy_per_min: int = 6
    # storage
    db_path: str = "data/kora_authoritative.db"
    # queue / worker
    worker_pool_size: int = 2
    worker_poll_seconds: float = 1.0
    job_timeout_seconds: float = 300.0
    max_queue_capacity: int = 5000
    retry_base_seconds: float = 2.0
    retry_max_seconds: float = 900.0
    # cron
    cron_enabled: bool = True
    cron_tick_seconds: float = 5.0
    cron_backup_daily: bool = False
    # social
    social_auto_publish: bool = True     # after human approval, dispatch automatically via worker
    social_auto_approve: bool = False    # DANGEROUS opt-in: skip the human approval gate
    # research / rag
    research_max_bytes: int = 2 * 1024 * 1024
    research_timeout_seconds: float = 10.0
    research_allowed_domains: Tuple[str, ...] = ()  # empty => any PUBLIC host (SSRF-guarded)
    rag_max_chunks: int = 5000
    # cost governor caps ("resource=limit,..."); 0/absent resource = no cap. No money is ever spent automatically.
    budget_daily: str = "ai_calls=500,net_calls=2000"
    budget_monthly: str = "ai_calls=10000,net_calls=40000"
    # logging
    log_level: str = "INFO"
    log_file: str = ""
    # provider credentials (presence only is reported; values never logged)
    keys: Dict[str, str] = field(default_factory=dict, repr=False)

    def credential_present(self, name: str) -> bool:
        return bool(self.keys.get(name))


KEY_NAMES = (
    "GEMINI_API_KEY", "OPENAI_API_KEY", "GROQ_API_KEY", "BRAVE_SEARCH_API_KEY",
    "X_OAUTH2_USER_TOKEN", "FACEBOOK_PAGE_ID", "FACEBOOK_PAGE_ACCESS_TOKEN",
    "YOUTUBE_ACCESS_TOKEN", "INSTAGRAM_ACCESS_TOKEN", "TIKTOK_ACCESS_TOKEN",
)


def load_settings(env: Optional[Dict[str, str]] = None, dotenv_path: Optional[str] = None) -> Settings:
    if env is None:
        env = os.environ
        if dotenv_path is None:
            dotenv_path = os.environ.get("KORA_ENV_FILE", ".env")
        load_dotenv(dotenv_path, env)
    port = _int(env, "KORA_PORT", 8000, 1, 65535)
    hosts = _csv(env, "KORA_ALLOWED_HOSTS") or ("127.0.0.1", "localhost", "[::1]")
    return Settings(
        region=str(env.get("KORA_REGION", "IN")).strip().upper() or "IN",
        bind_host=str(env.get("KORA_BIND_HOST", "127.0.0.1")).strip() or "127.0.0.1",
        port=port,
        auth_token=str(env.get("KORA_AUTH_TOKEN", "")).strip(),
        require_auth_local=_bool(env, "KORA_REQUIRE_AUTH_LOCAL", False),
        trust_proxy=_bool(env, "KORA_TRUST_PROXY", False),
        allowed_hosts=hosts,
        allowed_origins=_csv(env, "KORA_ALLOWED_ORIGINS"),
        max_body_bytes=_int(env, "KORA_MAX_BODY_BYTES", 1024 * 1024, 1024, 64 * 1024 * 1024),
        rate_limit_enabled=_bool(env, "KORA_RATE_LIMIT", True),
        rate_read_per_min=_int(env, "KORA_RATE_READ_PER_MIN", 240, 1, 100000),
        rate_write_per_min=_int(env, "KORA_RATE_WRITE_PER_MIN", 60, 1, 100000),
        rate_heavy_per_min=_int(env, "KORA_RATE_HEAVY_PER_MIN", 6, 1, 10000),
        db_path=str(env.get("KORA_DB_PATH", "data/kora_authoritative.db")),
        worker_pool_size=_int(env, "KORA_WORKER_POOL_SIZE", 2, 1, 8),
        worker_poll_seconds=_float(env, "KORA_WORKER_POLL_SECONDS", 1.0, 0.05, 60.0),
        job_timeout_seconds=_float(env, "KORA_JOB_TIMEOUT_SECONDS", 300.0, 1.0, 3600.0),
        max_queue_capacity=_int(env, "KORA_MAX_QUEUE_CAPACITY", 5000, 1, 100000),
        retry_base_seconds=_float(env, "KORA_RETRY_BASE_SECONDS", 2.0, 0.0, 3600.0),
        retry_max_seconds=_float(env, "KORA_RETRY_MAX_SECONDS", 900.0, 1.0, 86400.0),
        cron_enabled=_bool(env, "KORA_CRON_ENABLED", True),
        cron_tick_seconds=_float(env, "KORA_CRON_TICK_SECONDS", 5.0, 0.05, 300.0),
        cron_backup_daily=_bool(env, "KORA_CRON_BACKUP_DAILY", False),
        social_auto_publish=_bool(env, "KORA_SOCIAL_AUTO_PUBLISH", True),
        social_auto_approve=_bool(env, "KORA_SOCIAL_AUTO_APPROVE", False),
        research_max_bytes=_int(env, "KORA_RESEARCH_MAX_BYTES", 2 * 1024 * 1024, 1024, 32 * 1024 * 1024),
        research_timeout_seconds=_float(env, "KORA_RESEARCH_TIMEOUT_SECONDS", 10.0, 1.0, 120.0),
        research_allowed_domains=tuple(x.lower() for x in _csv(env, "KORA_RESEARCH_ALLOWED_DOMAINS")),
        rag_max_chunks=_int(env, "KORA_RAG_MAX_CHUNKS", 5000, 10, 200000),
        budget_daily=str(env.get("KORA_BUDGET_DAILY", "ai_calls=500,net_calls=2000")).strip(),
        budget_monthly=str(env.get("KORA_BUDGET_MONTHLY", "ai_calls=10000,net_calls=40000")).strip(),
        log_level=str(env.get("KORA_LOG_LEVEL", "INFO")).strip().upper() or "INFO",
        log_file=str(env.get("KORA_LOG_FILE", "")).strip(),
        keys={k: str(env.get(k, "")).strip() for k in KEY_NAMES if str(env.get(k, "")).strip()},
    )


_cached: Optional[Settings] = None


def get_settings(refresh: bool = False) -> Settings:
    global _cached
    if _cached is None or refresh:
        _cached = load_settings()
    return _cached
