"""Small integration contract for the existing KORA bridge.

Existing routes/approval/security logic must remain the authority.
This helper only supplies a measured execution profile.
"""

from kora.core.infinite_core import REACTOR


def resource_execution_profile() -> dict:
    return REACTOR.profile()


def evidence_gate_mode() -> str:
    # 2–4 GB class devices stay sequential; larger devices use bounded
    # parallelism, never unlimited concurrency.
    return REACTOR.evidence_mode
