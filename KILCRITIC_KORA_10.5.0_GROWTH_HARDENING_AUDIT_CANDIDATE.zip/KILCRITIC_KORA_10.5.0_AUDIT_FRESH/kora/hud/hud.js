// KORA HUD 10.2.1 — full-screen holographic command center.
// One brain: active work, owner approvals, self-evolution, measured resources and adaptive environment.
// textContent/createElement only; no injected HTML.
(function(){
  var $=function(id){return document.getElementById(id);};
  var token='',voiceOn=false,rec=null,lang='pa-IN',active=null,evolution=null,environment='EARTH';
  try{token=sessionStorage.getItem('kora_token')||'';lang=sessionStorage.getItem('kora_lang')||lang;}catch(e){}
  function hdr(){var h={'Content-Type':'application/json'};if(token)h.Authorization='Bearer '+token;return h;}
  function call(method,url,body){
    return fetch(url,{method:method,headers:hdr(),body:body?JSON.stringify(body):undefined}).then(function(r){
      return r.json().catch(function(){return {};}).then(function(j){j._status=r.status;return j;});
    });
  }
  function row(name,sub,tag,bad){
    var r=document.createElement('div');r.className='row';
    var n=document.createElement('div');n.className='name';n.textContent=name;
    if(sub){var s=document.createElement('div');s.className='sub';s.textContent=sub;n.appendChild(s);}
    r.appendChild(n);if(tag){var t=document.createElement('span');t.className='tag'+(bad?' bad':'');t.textContent=tag;r.appendChild(t);}
    return r;
  }
  function setState(state){$('faceState').textContent=state;$('livePill').textContent=state==='OFFLINE'?'● OFFLINE':'● LIVE';}
  function showModal(title,lines){
    var b=$('modalBody');b.textContent='';
    var h=document.createElement('h2');h.textContent=title;b.appendChild(h);
    (lines||[]).forEach(function(x){
      var p=document.createElement('p');p.textContent=x;b.appendChild(p);
    });
    $('modal').hidden=false;
  }
  $('modalClose').onclick=function(){$('modal').hidden=true;};
  $('modal').onclick=function(e){if(e.target===$('modal'))$('modal').hidden=true;};

  function render(d,evo,ops,providers){
    active=d||{};evolution=evo||{};
    var running=(d&&d.running)||[],queued=(d&&d.queued)||[],decisions=(d&&d.proposals)||[],social=(d&&d.needs_approval)||[];
    var focus=running[0]||queued[0];
    $('focusLine').textContent=focus ? ((focus.handler_name||'Task')+' • '+(focus.status||'QUEUED')) : 'No active job — KORA is ready.';
    $('cFocus').textContent=focus ? (focus.handler_name||'Working') : 'Ready';
    $('focusStatus').textContent=focus ? (focus.status||'WORKING') : 'READY';
    $('cApproval').textContent=(decisions.length+social.length)+' decision'+((decisions.length+social.length)===1?'':'s');
    $('cEvolution').textContent=evo&&evo.status ? (evo.gaps&&evo.gaps.length ? evo.gaps.length+' gap(s) found' : 'No known gaps') : 'Scan unavailable';
    var workers=d&&d.workers?d.workers:{};
    $('cMesh').textContent=(workers.threads_alive||0)+' workers • '+((d&&d.queued)||[]).length+' queued';
    $('cHealth').textContent=(ops&&ops.health_score!=null?ops.health_score:'—')+' measured';
    if(ops&&ops.resources){
      $('cResources').textContent=Math.round(ops.resources.process_max_rss_mb||0)+' MB RSS • '+Math.round(ops.resources.disk_free_mb||0)+' MB free';
    }else $('cResources').textContent='Measured resources';
    $('cResearch').textContent=providers&&providers.items ? providers.items.filter(function(x){return x.state==='HEALTHY'||x.state==='AVAILABLE';}).length+' sources/providers ready' : 'Provider status';
    $('cEnvironment').textContent=environment;
    $('activity').textContent='';
    var items=[];
    running.slice(0,3).forEach(function(j){items.push(row('Running: '+(j.handler_name||'job'), 'attempt '+j.attempts+'/'+j.max_retries,'RUNNING'));});
    queued.slice(0,3).forEach(function(j){items.push(row('Queued: '+(j.handler_name||'job'),j.error||'waiting','QUEUED'));});
    decisions.slice(0,4).forEach(function(p){
      var rr=row('Owner decision: '+p.action,p.reason,p.risk,true);
      if(p.id){
        var a=document.createElement('button');a.textContent='Approve';a.onclick=function(){call('POST','/api/governance/proposals/'+p.id+'/approve').then(refresh);};
        var rj=document.createElement('button');rj.textContent='Reject';rj.onclick=function(){call('POST','/api/governance/proposals/'+p.id+'/reject').then(refresh);};
        rr.appendChild(a);rr.appendChild(rj);
      }
      items.push(rr);
    });
    social.slice(0,3).forEach(function(p){
      var rr=row('Social approval: '+(p.platform||'post'),p.id,'APPROVAL',true);
      if(p.id){
        var a=document.createElement('button');a.textContent='Approve';a.onclick=function(){call('POST','/api/social/posts/'+p.id+'/approve').then(refresh);};
        rr.appendChild(a);
      }
      items.push(rr);
    });
    if(!items.length)items.push(row('System ready','Automatic when safe • ask Malak only when necessary','READY'));
    items.forEach(function(x){$('activity').appendChild(x);});
    setState(d&&d.safe_mode?'SAFE MODE':d&&d.kill_switch?'FROZEN':focus?'WORKING':'IDLE');
  }

  function refresh(){
    return Promise.all([call('GET','/api/active'),call('GET','/api/evolution/scan'),call('GET','/api/ops'),call('GET','/api/providers'),call('GET','/api/environment')])
      .then(function(v){
        if(v[0]._status!==200){$('say').textContent='Access needs your KORA owner token.';$('network').textContent='×';return;}
        if(v[4]._status===200)environment=v[4].profile||'EARTH';
        var ops=v[2]._status===200?v[2]:{};
        // ops endpoint already reports measured resource data; preserve truthful status.
        render(v[0],v[1]._status===200?v[1]:{},ops,v[3]._status===200?v[3]:{});
      }).catch(function(){setState('OFFLINE');$('network').textContent='×';});
  }

  function ask(text,source){
    if(!text)return Promise.resolve();
    $('say').textContent='…';setState('THINKING');
    return call('POST','/api/brain',{text:text,source:source||'text',voice_verified:source==='voice'}).then(function(r){
      $('say').textContent=r.message||r.error||r.status||'';
      if(r.status==='STEP_UP_REQUIRED'){
        var code=window.prompt('Malak owner one-time code');
        if(code)return call('POST','/api/brain',{text:text,source:'text',totp:code.trim()}).then(function(x){$('say').textContent=x.message||x.status;});
      }
      if(r.speech&&voiceOn&&window.speechSynthesis){
        var u=new SpeechSynthesisUtterance(r.speech);u.lang=lang;window.speechSynthesis.cancel();window.speechSynthesis.speak(u);
      }
    }).then(refresh).catch(function(){$('say').textContent='KORA could not complete that request.';setState('ERROR');});
  }

  function improve(){
    var goal=window.prompt('What should KORA inspect/improve?','Scan yourself, find missing capabilities and prepare the best safe improvement.');
    if(!goal)return;
    $('say').textContent='Scanning system → researching → preparing owner proposal…';setState('THINKING');
    call('POST','/api/evolution/prepare',{goal:goal,generate_patch:true}).then(function(r){
      if(r._status===200){$('say').textContent=r.patch_ready?'Improvement proposal ready. Malak approval required before production change.':'Gap found, but no safe patch was generated yet.';}
      else $('say').textContent=r.detail||r.error||'Improvement request failed.';
      return refresh();
    }).catch(function(){$('say').textContent='Self-evolution request failed.';setState('ERROR');});
  }

  function backup(){call('POST','/api/backup/create').then(function(r){$('say').textContent=r.ok?'Verified backup created.':'Backup could not be completed.';refresh();});}
  function doctor(){call('POST','/api/doctor/heal').then(function(r){$('say').textContent=r.ok?'System Doctor completed.':'Doctor could not complete.';refresh();});}

  $('bar').onsubmit=function(e){e.preventDefault();var t=$('cmd').value.trim();$('cmd').value='';ask(t,'text');};
  $('search').onclick=function(){var q=$('cmd').value.trim();if(!q)return;call('POST','/api/rag/query',{question:q,answer:true}).then(function(r){$('say').textContent=r.answer||r.error||'No stored knowledge matched.';});};
  $('backup').onclick=backup;$('evolve').onclick=improve;$('doctor').onclick=doctor;$('voiceDock').onclick=function(){voiceToggle();};

  document.querySelectorAll('.card').forEach(function(c){
    c.onclick=function(){
      var type=c.getAttribute('data-card');
      if(type==='evolution')improve();
      else if(type==='focus')showModal('Current Task',[(active.running||[]).length+' running', (active.queued||[]).length+' queued', 'KORA remembers checkpoints when tasks are switched.']);
      else if(type==='approvals')showModal('Malak Decisions',[(active.proposals||[]).length+' system proposals', (active.needs_approval||[]).length+' external-action approvals','High-impact changes remain owner-approved.']);
      else if(type==='health')showModal('Measured Health',['Health is based on real probes/resources; no fake 99.99% guarantee.','Use Doctor Heal for diagnostics and safe repair.']);
      else if(type==='resources')showModal('Resource Governor',['KORA tracks RAM/CPU/disk/network/time/tokens where available.','Virtual power profiles never create physical power.']);
      else if(type==='environment')showModal('Environment Profile',['Current profile: '+environment,'EARTH = stable/offline-first','OCEAN = resilient flow','SKY = lightweight parallel work','SPACE = isolated simulation','REGION = localization']);
      else if(type==='research')showModal('Discovery',['KORA uses authorized web research when configured.','If a provider/key is unavailable, it reports the real limitation and can use available alternatives.']);
      else showModal('System Mesh',['Workers: '+((active.workers||{}).threads_alive||0),'Queued: '+((active.queued||[]).length),'Safe mode: '+(active.safe_mode?'ON':'off')]);
    };
  });

  function voiceToggle(){
    var SR=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SR){$('say').textContent='Voice input is not supported in this browser.';return;}
    if(voiceOn){
      voiceOn=false;$('voice').setAttribute('aria-pressed','false');if(rec){try{rec.onend=null;rec.stop();}catch(e){}}rec=null;return;
    }
    call('POST','/api/voice',{enabled:true}).then(function(r){
      if(!r.voice){$('say').textContent=r.reason||'Voice could not be enabled.';return;}
      voiceOn=true;$('voice').setAttribute('aria-pressed','true');setState('LISTENING');
      rec=new SR();rec.lang=lang;rec.continuous=true;rec.interimResults=false;
      rec.onresult=function(ev){var t=ev.results[ev.results.length-1][0].transcript.trim();if(/^voice off$/i.test(t)){voiceToggle();return;}ask(t,'voice');};
      rec.onend=function(){if(voiceOn)try{rec.start();}catch(e){}};
      rec.onerror=function(){voiceOn=false;$('voice').setAttribute('aria-pressed','false');};
      try{rec.start();}catch(e){}
    });
  }
  $('voice').onclick=voiceToggle;

  $('full').onclick=function(){
    if(!document.fullscreenElement){document.documentElement.requestFullscreen().catch(function(){});}
    else document.exitFullscreen().catch(function(){});
  };
  $('menuBtn').onclick=function(){var open=$('drawer').hidden;$('drawer').hidden=!open;$('menuBtn').setAttribute('aria-expanded',String(open));if(open)loadAdvanced();};
  $('closeDrawer').onclick=function(){$('drawer').hidden=true;};
  $('safe').onclick=function(){call('POST','/api/safe-mode',{active:true}).then(refresh);};
  $('export').onclick=function(){fetch('/api/data/export',{headers:hdr()}).then(function(r){if(!r.ok)throw 0;return r.blob();}).then(function(b){var a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='kora-export.zip';a.click();}).catch(function(){$('say').textContent='Export failed.';});};
  $('envSelect').onchange=function(){environment=this.value;call('POST','/api/environment',{profile:environment}).then(refresh);};

  function loadAdvanced(){
    var adv=$('adv');adv.textContent='';
    call('GET','/api/security').then(function(s){if(s._status===200)adv.appendChild(row('Owner 2FA',s.totp_enrolled?'Protected':'Setup recommended',s.totp_enrolled?'ON':'SETUP',!s.totp_enrolled));});
    call('GET','/api/providers').then(function(p){if(p._status===200)(p.items||[]).forEach(function(i){adv.appendChild(row(i.provider,i.cost_hint+' · '+i.capabilities,i.state,i.state!=='HEALTHY'&&i.state!=='AVAILABLE'));});});
    call('GET','/api/evolution/scan').then(function(e){if(e._status===200)adv.appendChild(row('Self scan',e.gaps&&e.gaps.length?e.gaps.length+' gap(s)':'no known gaps',e.status,e.gaps&&e.gaps.length>0));});
  }

  // token prompt
  document.addEventListener('keydown',function(e){if(e.key==='Escape')$('drawer').hidden=true;});
  var tokenBtn=document.createElement('button');tokenBtn.className='icon-btn';tokenBtn.textContent='KEY';tokenBtn.title='Owner access token';tokenBtn.onclick=function(){var t=window.prompt('KORA owner access token');if(t!=null){token=t.trim();try{sessionStorage.setItem('kora_token',token);}catch(e){}refresh();}};document.querySelector('.top-right').appendChild(tokenBtn);

  setInterval(function(){var d=new Date();$('clock').textContent=d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',hour12:false});},1000);
  $('clock').textContent=new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',hour12:false});
  refresh();setInterval(refresh,5000);
})();