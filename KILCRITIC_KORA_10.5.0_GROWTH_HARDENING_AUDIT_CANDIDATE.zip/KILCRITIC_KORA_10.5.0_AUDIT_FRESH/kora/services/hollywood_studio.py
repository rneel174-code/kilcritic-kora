"""Hollywood Studio orchestration contracts: original creation, quality and rights gates."""
from __future__ import annotations
from typing import Any, Dict

CATEGORIES = ("MOVIE_CINEMATIC", "FUNNY", "FUNNY_BABY", "CARTOON_ANIMATION", "REEL_SHORT", "STORY_SHORT_FILM",
              "PHOTO_TO_CINEMATIC", "GRAPHICS_VFX_MOTION", "AUDIO_VOICE_SFX", "SCRIPT_SUBTITLE", "COLOR_HDR", "ORIGINAL_AI")

STEPS = ("IMPORT", "DISCOVER", "RIGHTS", "ORIGINALITY", "EDIT", "COLOR", "VFX", "AUDIO", "SUBTITLES", "QUALITY", "PLATFORM", "PREVIEW", "APPROVAL", "POST", "VERIFY", "LEARN")

def quality_preflight(metrics: Dict[str, Any]) -> Dict[str, Any]:
    checks = {
        "resolution": bool(metrics.get("width", 0) and metrics.get("height", 0)),
        "duration": metrics.get("duration_s", 0) > 0,
        "frames": metrics.get("black_frame_ratio", 0) < 0.20,
        "audio": metrics.get("audio_clipping", False) is False,
        "subtitle_sync": metrics.get("subtitle_sync_ok", True) is True,
        "artifact": metrics.get("artifact_risk", False) is False,
    }
    return {"decision": "PASS" if all(checks.values()) else "REVIEW", "checks": checks, "measured": True}

def studio_plan(category: str, *, original: bool = True, manual: bool = True, automatic: bool = True) -> Dict[str, Any]:
    category = category.strip().upper()
    if category not in CATEGORIES:
        raise ValueError("unsupported studio category")
    return {"category": category, "automatic": automatic, "manual": manual, "original_required": original,
            "steps": list(STEPS), "copyright_guarantee": False,
            "rule": "original/authorized material only; exact unauthorized film/identity/voice copying is blocked or reviewed"}
