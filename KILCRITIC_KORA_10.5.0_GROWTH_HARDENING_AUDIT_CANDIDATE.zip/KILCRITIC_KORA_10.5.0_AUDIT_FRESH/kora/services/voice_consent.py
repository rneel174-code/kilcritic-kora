"""Voice/face consent gate. KORA does NOT clone voices or faces; this only records consent and refuses unsafe requests.
A consent record needs: explicit permission statement + live confirmation + valid one-time TOTP + adult subject.
Children are always refused. Stored in the settings table (JSON) with an audit event."""
import json
import time
from typing import Any, Dict

from kora.core import identity
from kora.core.db import DEFAULT_DB_PATH, get_setting, record_audit, set_setting

KEY = "voice_face_consent"


def record_consent(subject: str, scope: str, *, adult: bool, explicit_permission: bool, live_confirmation: bool, totp_code: str,
                   db_path: str = DEFAULT_DB_PATH, now: float = None) -> Dict[str, Any]:
    if not adult:
        return {"status": "REFUSED", "reason": "child_voice_or_face_never_allowed"}
    if scope not in ("voice", "face", "both"):
        return {"status": "REFUSED", "reason": "scope must be voice|face|both"}
    if not (explicit_permission and live_confirmation):
        return {"status": "REFUSED", "reason": "explicit permission and live confirmation are both required"}
    if identity.step_up(totp_code, db_path) != "OK":
        return {"status": "REFUSED", "reason": "valid one-time code (TOTP) required"}
    recs = json.loads(get_setting(KEY, "[]", db_path) or "[]")
    recs.append({"subject": subject[:80], "scope": scope, "at": time.time() if now is None else now, "revoked": False})
    set_setting(KEY, json.dumps(recs[-100:]), db_path)
    record_audit("voice_face_consent", "owner", {"subject": subject[:80], "scope": scope}, db_path)
    return {"status": "RECORDED", "note": "consent only; no voice/face cloning capability exists in this build"}


def has_consent(subject: str, scope: str, db_path: str = DEFAULT_DB_PATH) -> bool:
    return any(r["subject"] == subject[:80] and r["scope"] in (scope, "both") and not r["revoked"] for r in json.loads(get_setting(KEY, "[]", db_path) or "[]"))
