"""
KORA PRO - Platform publishers (official HTTPS APIs only, via the guarded transport).

STATUS (truthful):
  X          request/response handling implemented  - UNVERIFIED against the live API (no credentials in this build)
  FACEBOOK   Page feed post implemented             - UNVERIFIED against the live API
  YOUTUBE    resumable video upload implemented     - UNVERIFIED against the live API
  INSTAGRAM  Graph media-container + media_publish implemented; public media URL required
  TIKTOK     Content Posting API Direct Post implemented; approval/authorization still required
A publisher returns an external id ONLY when the platform response contains one; anything else is a failure.
"""
import json
import os
import re
import urllib.parse
import time
from typing import Any, Callable, Dict, Mapping, Optional

from kora.core.http import TransportError, https_request


class PublishError(Exception):
    def __init__(self, code: str, retryable: bool = False, detail: str = ""):
        super().__init__(f"{code}{': ' + detail if detail else ''}")
        self.code = code
        self.retryable = retryable


def _loads(body: bytes) -> dict:
    """A 2xx with an unparseable / non-object body is a failure, never a crash and never a fake success."""
    try:
        data = json.loads(body or b"{}")
    except (ValueError, UnicodeDecodeError):
        raise PublishError("malformed_response", retryable=False)
    if not isinstance(data, dict):
        raise PublishError("malformed_response", retryable=False)
    return data


def _http_failure(status: int, body: bytes) -> PublishError:
    detail = body[:200].decode("utf-8", "replace") if body else ""
    retry = status == 429 or status >= 500
    return PublishError(f"http_{status}", retryable=retry, detail=re.sub(r"(?i)(token|key)[^,}\s]*", "[redacted]", detail))


def credential_requirements(platform: str) -> Dict[str, Any]:
    return {
        "X": {"env": ["X_OAUTH2_USER_TOKEN"], "implemented": True},
        "FACEBOOK": {"env": ["FACEBOOK_PAGE_ID", "FACEBOOK_PAGE_ACCESS_TOKEN"], "implemented": True},
        "YOUTUBE": {"env": ["YOUTUBE_ACCESS_TOKEN"], "implemented": True},
        "INSTAGRAM": {"env": ["INSTAGRAM_ACCESS_TOKEN", "INSTAGRAM_USER_ID"], "implemented": True},
        "TIKTOK": {"env": ["TIKTOK_ACCESS_TOKEN"], "implemented": True},
    }[platform]


def missing_credentials(platform: str, env: Mapping[str, str]) -> list:
    return [k for k in credential_requirements(platform)["env"] if not str(env.get(k, "")).strip()]


def publish_x(post: Dict[str, Any], env: Mapping[str, str], transport: Callable) -> str:
    text = post["content"].strip()
    if len(text) > 280:
        raise PublishError("content_too_long_for_x", retryable=False, detail=f"{len(text)}>280")
    try:
        status, _h, body = transport("POST", "https://api.twitter.com/2/tweets",
                                     {"Authorization": "Bearer " + env["X_OAUTH2_USER_TOKEN"], "Content-Type": "application/json"},
                                     json.dumps({"text": text}).encode(), 30.0)
    except TransportError as exc:
        raise PublishError("network", retryable=True, detail=str(exc))
    if status not in (200, 201):
        raise _http_failure(status, body)
    ext = ((_loads(body).get("data") or {}).get("id"))
    if not ext:
        raise PublishError("no_external_id_in_response", retryable=False)
    return str(ext)


def publish_facebook(post: Dict[str, Any], env: Mapping[str, str], transport: Callable) -> str:
    page_id = env["FACEBOOK_PAGE_ID"].strip()
    if not re.fullmatch(r"\d{3,30}", page_id):
        raise PublishError("invalid_facebook_page_id", retryable=False)
    form = urllib.parse.urlencode({"message": post["content"], "access_token": env["FACEBOOK_PAGE_ACCESS_TOKEN"]}).encode()
    try:
        status, _h, body = transport("POST", f"https://graph.facebook.com/v19.0/{page_id}/feed",
                                     {"Content-Type": "application/x-www-form-urlencoded"}, form, 30.0)
    except TransportError as exc:
        raise PublishError("network", retryable=True, detail=str(exc))
    if status != 200:
        raise _http_failure(status, body)
    ext = _loads(body).get("id")
    if not ext:
        raise PublishError("no_external_id_in_response", retryable=False)
    return str(ext)


CHUNK = 8 * 1024 * 1024  # multiple of 256 KiB, as the resumable protocol requires


def publish_youtube(post: Dict[str, Any], env: Mapping[str, str], transport: Callable) -> str:
    path = post.get("media_path")
    if not path or not os.path.isfile(path):
        raise PublishError("media_file_missing", retryable=False)
    total = os.path.getsize(path)
    if total <= 0:
        raise PublishError("media_file_empty", retryable=False)
    auth = {"Authorization": "Bearer " + env["YOUTUBE_ACCESS_TOKEN"]}
    privacy = env.get("YOUTUBE_PRIVACY", "private") if env.get("YOUTUBE_PRIVACY") in ("private", "unlisted", "public") else "private"
    meta = {"snippet": {"title": (post.get("title") or post["content"])[:100], "description": post["content"][:5000]},
            "status": {"privacyStatus": privacy, "selfDeclaredMadeForKids": post.get("audience") == "KIDS"}}
    try:
        status, hdr, body = transport(
            "POST", "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
            {**auth, "Content-Type": "application/json; charset=UTF-8", "X-Upload-Content-Length": str(total),
             "X-Upload-Content-Type": "video/*"}, json.dumps(meta).encode(), 30.0)
        if status != 200 or not hdr.get("location"):
            raise _http_failure(status, body) if status != 200 else PublishError("no_upload_session", retryable=True)
        session = hdr["location"]
        offset = 0
        with open(path, "rb") as fh:  # streamed in 8 MiB chunks: bounded memory regardless of file size
            while offset < total:
                fh.seek(offset)
                data = fh.read(CHUNK)
                end = offset + len(data) - 1
                status, hdr, body = transport("PUT", session, {**auth, "Content-Length": str(len(data)),
                                              "Content-Range": f"bytes {offset}-{end}/{total}"}, data, 300.0)
                if status in (200, 201):
                    ext = _loads(body).get("id")
                    if not ext:
                        raise PublishError("no_external_id_in_response", retryable=False)
                    return str(ext)
                if status == 308:
                    rng = hdr.get("range", "")
                    offset = int(rng.rsplit("-", 1)[-1]) + 1 if rng.startswith("bytes=") else end + 1
                    continue
                raise _http_failure(status, body)
    except TransportError as exc:
        raise PublishError("network", retryable=True, detail=str(exc))
    raise PublishError("upload_incomplete", retryable=True)


def _json_response(status: int, body: bytes) -> Dict[str, Any]:
    if status < 200 or status >= 300:
        raise _http_failure(status, body)
    try:
        data = _loads(body)
    except Exception as exc:
        raise PublishError("invalid_json_response", retryable=False, detail=str(exc))
    if isinstance(data, dict) and data.get("error"):
        err = data.get("error") or {}
        raise PublishError("provider_error", retryable=False, detail=str(err.get("message") or err)[:200])
    return data


def _public_media_url(post: Dict[str, Any], env: Mapping[str, str]) -> str:
    url = str(post.get("media_url") or post.get("public_media_url") or "").strip()
    if not url:
        url = str(env.get("KORA_PUBLIC_MEDIA_URL", "")).strip()
    if not url:
        raise PublishError("public_media_url_required", retryable=False)
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" or not parsed.netloc:
        raise PublishError("public_media_url_must_be_https", retryable=False)
    return url


def publish_instagram(post: Dict[str, Any], env: Mapping[str, str], transport: Callable) -> str:
    """Official Instagram Graph API publishing for image feed posts and Reels.

    Instagram must be able to fetch the media from a public HTTPS URL. This adapter
    deliberately refuses to expose local files or bypass Meta access requirements.
    """
    token = env["INSTAGRAM_ACCESS_TOKEN"]
    ig_user = str(env["INSTAGRAM_USER_ID"]).strip()
    if not re.fullmatch(r"\d+", ig_user):
        raise PublishError("invalid_instagram_user_id", retryable=False)
    version = str(env.get("META_GRAPH_VERSION", "v23.0")).strip() or "v23.0"
    url = _public_media_url(post, env)
    media_kind = str(post.get("media_type") or "REEL").upper()
    caption = str(post.get("content") or "")[:2200]
    base = f"https://graph.facebook.com/{version}/{ig_user}/media"
    form = {"access_token": token, "caption": caption}
    if media_kind in ("IMAGE", "PHOTO", "FEED"):
        form.update({"image_url": url})
    else:
        form.update({"media_type": "REELS", "video_url": url})
    body = urllib.parse.urlencode(form).encode()
    try:
        status, _h, raw = transport("POST", base, {"Content-Type": "application/x-www-form-urlencoded"}, body, 60.0)
        created = _json_response(status, raw).get("id")
        if not created:
            raise PublishError("instagram_container_id_missing", retryable=False)
        publish_body = urllib.parse.urlencode({"access_token": token, "creation_id": str(created)}).encode()
        status, _h, raw = transport("POST", base.replace("/media", "/media_publish"), {"Content-Type": "application/x-www-form-urlencoded"}, publish_body, 60.0)
        ext = _json_response(status, raw).get("id")
        if not ext:
            raise PublishError("instagram_media_id_missing", retryable=False)
        return str(ext)
    except TransportError as exc:
        raise PublishError("network", retryable=True, detail=str(exc))


def publish_tiktok(post: Dict[str, Any], env: Mapping[str, str], transport: Callable) -> str:
    """Official TikTok Content Posting API Direct Post for video files.

    Requires an approved/authorized video.publish scope. The adapter never claims
    success until TikTok returns a publish_id and a final PUBLISHED status.
    """
    path = post.get("media_path")
    if not path or not os.path.isfile(path):
        raise PublishError("media_file_missing", retryable=False)
    total = os.path.getsize(path)
    if total <= 0:
        raise PublishError("media_file_empty", retryable=False)
    token = env["TIKTOK_ACCESS_TOKEN"]
    api = "https://open.tiktokapis.com/v2/post/publish"
    auth = {"Authorization": "Bearer " + token, "Content-Type": "application/json; charset=UTF-8"}
    try:
        status, _h, raw = transport("POST", api + "/creator_info/query/", auth, b"{}", 30.0)
        creator = _json_response(status, raw).get("data") or {}
        options = creator.get("privacy_level_options") or ["SELF_ONLY"]
        privacy = str(env.get("TIKTOK_PRIVACY", "SELF_ONLY"))
        if privacy not in options:
            privacy = options[0]
        chunk = 10 * 1024 * 1024
        count = (total + chunk - 1) // chunk
        payload = {
            "post_info": {
                "title": str(post.get("content") or "")[:2200],
                "privacy_level": privacy,
                "disable_duet": bool(env.get("TIKTOK_DISABLE_DUET", "false").lower() == "true"),
                "disable_comment": False,
                "disable_stitch": False,
                "is_aigc": bool(str(post.get("ai_generated", "false")).lower() == "true"),
            },
            "source_info": {"source": "FILE_UPLOAD", "video_size": total, "chunk_size": chunk, "total_chunk_count": count},
        }
        status, hdr, raw = transport("POST", api + "/video/init/", auth, json.dumps(payload).encode(), 30.0)
        data = _json_response(status, raw).get("data") or {}
        publish_id, upload_url = data.get("publish_id"), data.get("upload_url")
        if not publish_id or not upload_url:
            raise PublishError("tiktok_upload_session_missing", retryable=False)
        offset = 0
        while offset < total:
            with open(path, "rb") as fh:
                fh.seek(offset)
                chunk_data = fh.read(min(chunk, total - offset))
            end = offset + len(chunk_data) - 1
            up_headers = {"Content-Type": "video/mp4", "Content-Length": str(len(chunk_data)), "Content-Range": f"bytes {offset}-{end}/{total}"}
            status, _h, raw = transport("PUT", upload_url, up_headers, chunk_data, 300.0)
            if status not in (200, 201, 206):
                raise _http_failure(status, raw)
            offset = end + 1
        # Poll a bounded number of times; never claim success on mere initialization.
        for _ in range(12):
            status, _h, raw = transport("POST", api + "/status/fetch/", auth, json.dumps({"publish_id": publish_id}).encode(), 30.0)
            data = _json_response(status, raw).get("data") or {}
            state = str(data.get("status") or data.get("publish_status") or "").upper()
            if state in {"PUBLISHED", "SUCCESS", "COMPLETE", "PUBLISH_COMPLETE"}:
                return str(publish_id)
            if state in {"FAILED", "ERROR"}:
                raise PublishError("tiktok_publish_failed", retryable=False, detail=str(data)[:200])
            time.sleep(1.0)
        raise PublishError("tiktok_publish_status_timeout", retryable=True, detail=str(publish_id))
    except TransportError as exc:
        raise PublishError("network", retryable=True, detail=str(exc))


class VerifyResult(dict):
    """state: VERIFIED (platform confirms the object exists) | PENDING (still processing: retry) | NOT_FOUND | UNVERIFIED (could not check)."""


def _vr(state: str, detail: str = "") -> "VerifyResult":
    return VerifyResult(state=state, detail=detail[:200])


def verify_x(post, env, transport):
    ext = str(post["external_id"])
    if not re.fullmatch(r"\d{1,25}", ext): return _vr("UNVERIFIED", "unexpected_id_format")
    status, _h, body = transport("GET", f"https://api.twitter.com/2/tweets/{ext}", {"Authorization": "Bearer " + env["X_OAUTH2_USER_TOKEN"]}, None, 30.0)
    if status == 200: return _vr("VERIFIED" if (_loads(body).get("data") or {}).get("id") == ext else "NOT_FOUND")
    if status == 404: return _vr("NOT_FOUND", "http_404")
    return _vr("UNVERIFIED", f"http_{status}")


def verify_facebook(post, env, transport):
    ext = str(post["external_id"])
    if not re.fullmatch(r"[\d_]{3,60}", ext): return _vr("UNVERIFIED", "unexpected_id_format")
    q = urllib.parse.urlencode({"fields": "id", "access_token": env["FACEBOOK_PAGE_ACCESS_TOKEN"]})
    status, _h, body = transport("GET", f"https://graph.facebook.com/v19.0/{ext}?{q}", {}, None, 30.0)
    if status == 200: return _vr("VERIFIED" if _loads(body).get("id") == ext else "NOT_FOUND")
    if status in (400, 404): return _vr("NOT_FOUND", f"http_{status}")
    return _vr("UNVERIFIED", f"http_{status}")


def verify_youtube(post, env, transport):
    ext = str(post["external_id"])
    if not re.fullmatch(r"[A-Za-z0-9_\-]{6,20}", ext): return _vr("UNVERIFIED", "unexpected_id_format")
    status, _h, body = transport("GET", "https://www.googleapis.com/youtube/v3/videos?" + urllib.parse.urlencode({"part": "status", "id": ext}),
                                 {"Authorization": "Bearer " + env["YOUTUBE_ACCESS_TOKEN"]}, None, 30.0)
    if status != 200: return _vr("UNVERIFIED", f"http_{status}")
    items = _loads(body).get("items") or []
    if not items: return _vr("NOT_FOUND", "no_items")
    up = str((items[0].get("status") or {}).get("uploadStatus", "")).lower()
    if up in ("processed", "uploaded"): return _vr("VERIFIED", "uploadStatus=" + up)
    if up in ("failed", "rejected", "deleted"): return _vr("NOT_FOUND", "uploadStatus=" + up)
    return _vr("PENDING", "uploadStatus=" + (up or "unknown"))


def verify_instagram(post, env, transport):
    ext = str(post["external_id"])
    if not re.fullmatch(r"\d{5,30}", ext): return _vr("UNVERIFIED", "unexpected_id_format")
    version = str(env.get("META_GRAPH_VERSION", "v23.0")).strip() or "v23.0"
    q = urllib.parse.urlencode({"fields": "id,permalink", "access_token": env["INSTAGRAM_ACCESS_TOKEN"]})
    status, _h, body = transport("GET", f"https://graph.facebook.com/{version}/{ext}?{q}", {}, None, 30.0)
    if status == 200: return _vr("VERIFIED" if _loads(body).get("id") == ext else "NOT_FOUND")
    if status in (400, 404): return _vr("NOT_FOUND", f"http_{status}")
    return _vr("UNVERIFIED", f"http_{status}")


def verify_tiktok(post, env, transport):
    ext = str(post["external_id"])
    auth = {"Authorization": "Bearer " + env["TIKTOK_ACCESS_TOKEN"], "Content-Type": "application/json; charset=UTF-8"}
    status, _h, body = transport("POST", "https://open.tiktokapis.com/v2/post/publish/status/fetch/", auth, json.dumps({"publish_id": ext}).encode(), 30.0)
    if status != 200: return _vr("UNVERIFIED", f"http_{status}")
    d = _loads(body).get("data") or {}
    st = str(d.get("status") or d.get("publish_status") or "").upper()
    if st in {"PUBLISHED", "SUCCESS", "COMPLETE", "PUBLISH_COMPLETE"}: return _vr("VERIFIED", st)
    if st in {"FAILED", "ERROR"}: return _vr("NOT_FOUND", st)
    return _vr("PENDING", st or "unknown")


VERIFIERS: Dict[str, Callable] = {"X": verify_x, "FACEBOOK": verify_facebook, "YOUTUBE": verify_youtube, "INSTAGRAM": verify_instagram, "TIKTOK": verify_tiktok}


PUBLISHERS: Dict[str, Callable] = {
    "X": publish_x, "FACEBOOK": publish_facebook, "YOUTUBE": publish_youtube,
    "INSTAGRAM": publish_instagram, "TIKTOK": publish_tiktok,
}
