"""Private encrypted monthly "moat" store (PARMANU gap). Reuses secure_vault AES-256-GCM (no new crypto).

WHY_EXISTING_COMPONENT_IS_INSUFFICIENT: secure_vault seals one blob; nothing provided consent-gated, append-only,
monthly-partitioned, checksum-indexed, atomically-written storage or an anonymised export.
Collection is OFF until the owner turns consent on. Nothing here transmits data anywhere.
"""
from __future__ import annotations
import hashlib, json, os, re, tempfile, time
from typing import Any, Dict, List
from kora.services import secure_vault as V

_PII_KEYS = {"name", "phone", "mobile", "email", "address", "shop_name", "owner", "customer", "contact", "gps", "lat", "lng"}
_PHONE = re.compile(r"\+?\d[\d\s\-]{8,}\d")
_EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
MAX_RECORD_BYTES = 64 * 1024

class MoatError(RuntimeError):
    pass

def _p(root, *a): return os.path.join(root, *a)

def _atomic_write(path: str, data: str) -> None:
    d = os.path.dirname(path); os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as fh:
            fh.write(data); fh.flush(); os.fsync(fh.fileno())
        os.replace(tmp, path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise

def consent_state(root: str) -> Dict[str, Any]:
    try:
        return json.load(open(_p(root, "consent.json")))
    except Exception:
        return {"collection": "OFF", "export": "OFF"}

def set_consent(root: str, *, collection: bool, export: bool = False, actor: str = "owner") -> Dict[str, Any]:
    st = {"collection": "ON" if collection else "OFF", "export": "ON" if (collection and export) else "OFF", "actor": actor, "at": time.time()}
    _atomic_write(_p(root, "consent.json"), json.dumps(st)); return st

def anonymize(rec: Dict[str, Any], salt: str = "") -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for k, v in rec.items():
        if k.lower() in _PII_KEYS:
            out[k + "_hash"] = hashlib.sha256((salt + str(v)).encode()).hexdigest()[:12]; continue
        out[k] = _EMAIL.sub("[email]", _PHONE.sub("[phone]", v)) if isinstance(v, str) else v
    return out

def _month(ts: float) -> str: return time.strftime("%Y-%m", time.gmtime(ts))

def _load(root, month, pw) -> List[dict]:
    f = _p(root, f"moat-{month}.sealed")
    return V.open_sealed(open(f).read(), pw).get("records", []) if os.path.exists(f) else []

def _index(root) -> Dict[str, Any]:
    try: return json.load(open(_p(root, "moat_index.json")))
    except Exception: return {}

def put(root: str, password: str, record: Dict[str, Any], *, now: float = 0.0) -> Dict[str, Any]:
    if consent_state(root).get("collection") != "ON":
        raise MoatError("consent_off")
    if not isinstance(record, dict) or len(json.dumps(record, default=str)) > MAX_RECORD_BYTES:
        raise MoatError("bad_or_oversized_record")
    ts = now or time.time(); m = _month(ts)
    recs = _load(root, m, password); recs.append({"ts": ts, **record})
    blob = V.seal({"records": recs}, password)
    _atomic_write(_p(root, f"moat-{m}.sealed"), blob)
    idx = _index(root); idx[m] = {"sha256": V.fingerprint(blob), "count": len(recs)}
    _atomic_write(_p(root, "moat_index.json"), json.dumps(idx, sort_keys=True))
    return {"month": m, "count": len(recs)}

def verify(root: str, password: str) -> Dict[str, Any]:
    idx, bad = _index(root), []
    for m, e in idx.items():
        f = _p(root, f"moat-{m}.sealed")
        try:
            blob = open(f).read()
            if V.fingerprint(blob) != e["sha256"]: bad.append({"month": m, "why": "checksum_mismatch"}); continue
            if len(V.open_sealed(blob, password).get("records", [])) != e["count"]: bad.append({"month": m, "why": "count_mismatch"})
        except Exception as exc:
            bad.append({"month": m, "why": type(exc).__name__})
    return {"status": "PASS" if idx and not bad else ("UNKNOWN" if not idx else "FAIL"), "months": len(idx), "bad": bad}

def export_anonymized(root: str, password: str, month: str, salt: str) -> List[Dict[str, Any]]:
    if consent_state(root).get("export") != "ON":
        raise MoatError("export_consent_off")
    return [anonymize(r, salt) for r in _load(root, month, password)]
