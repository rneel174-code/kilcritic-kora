"""KORA Self-Evolution Engine.

Detect -> Research -> Propose -> Owner approval -> Isolated patch -> Test -> Canary -> Apply -> Verify -> Rollback.

The engine never executes arbitrary code from an API request. AI output is treated as an
untrusted patch artifact. Only owner-approved, path-validated unified diffs can be applied,
and the affected files are snapshotted before mutation.
"""
from __future__ import annotations
import hashlib, json, os, re, shutil, subprocess, tempfile, time
from pathlib import Path
from typing import Any, Dict, List, Optional

from kora.core.db import DEFAULT_DB_PATH, get_connection, record_audit
from kora.services import governance
from kora.services.ai_failover import query_ai_model
from kora.services import fusion, research

MAX_PATCH_BYTES = 512 * 1024
MAX_FILES = 24
PATCH_ROOT_NAME = "evolution"

def repo_root(root: Optional[str] = None) -> Path:
    if root:
        return Path(root).resolve()
    return Path(__file__).resolve().parents[2]

def _safe_rel(path: str) -> bool:
    p = Path(path)
    return not p.is_absolute() and ".." not in p.parts and str(p) not in ("", ".")

def _files(root: Path) -> List[Path]:
    skip = {".git", "node_modules", "dist", "__pycache__", ".venv", "venv", "data"}
    out=[]
    for base in (root/"kora", root/"src", root/"app"):
        if base.exists():
            for p in base.rglob("*"):
                rel = p.relative_to(root)
                if p.is_file() and not any(part in skip for part in rel.parts):
                    out.append(p)
    return sorted(out)

def _readable(p: Path) -> bool:
    return p.suffix.lower() in {".py",".ts",".tsx",".js",".jsx",".css",".json",".md",".yaml",".yml",".toml",".html"}

def scan(root: Optional[str]=None, db_path: str=DEFAULT_DB_PATH) -> Dict[str, Any]:
    r=repo_root(root)
    fs=_files(r)
    files=[str(p.relative_to(r)) for p in fs]
    markers={
        "governance_approval": (r/"kora/services/governance.py").exists(),
        "owner_identity": (r/"kora/core/identity.py").exists(),
        "web_research": (r/"kora/services/research.py").exists(),
        "ai_router": (r/"kora/services/ai_failover.py").exists(),
        "rollback_capable_migrations": (r/"kora/services/ops.py").exists(),
        "self_evolution_engine": (r/"kora/services/self_evolution.py").exists(),
        "python_tests": (r/"kora/tests/run_all.py").exists(),
        "frontend_hud": (r/"src/components/KoraFaceHud.tsx").exists(),
    }
    gaps=[]
    if not markers["self_evolution_engine"]:
        gaps.append({"id":"SELF_EVOLUTION_ENGINE","severity":"HIGH","reason":"No governed self-evolution service detected."})
    if not markers["governance_approval"]:
        gaps.append({"id":"OWNER_APPROVAL","severity":"CRITICAL","reason":"No proposal approval service detected."})
    if not markers["web_research"]:
        gaps.append({"id":"SOURCE_RESEARCH","severity":"MEDIUM","reason":"No research service detected."})
    if not markers["python_tests"]:
        gaps.append({"id":"TEST_GATE","severity":"HIGH","reason":"No test runner detected."})
    return {
        "ok": True, "root": str(r), "file_count": len(files), "markers": markers,
        "gaps": gaps, "status": "GAPS_FOUND" if gaps else "HEALTHY",
        "source": "local_repository_scan", "timestamp": time.time()
    }

def research_gap(goal: str, urls: Optional[List[str]]=None, env=None, db_path: str=DEFAULT_DB_PATH) -> Dict[str,Any]:
    urls=[u for u in (urls or []) if isinstance(u,str) and u.strip()][:8]
    if urls:
        return fusion.deep_research(goal[:500], urls, fetch=lambda u: research.fetch_page(u), max_sources=6)
    # Search only when the configured search provider exists. Otherwise be truthful.
    return fusion.deep_research(goal[:500], [], max_sources=6)

def _extract_patch(text: str) -> str:
    t=(text or "").strip()
    m=re.search(r"```(?:diff|patch)?\s*(.*?)```", t, re.S|re.I)
    if m: t=m.group(1).strip()
    if "--- " not in t or "+++ " not in t:
        return ""
    return t

def validate_patch(patch: str, root: Path) -> Dict[str,Any]:
    if not patch or len(patch.encode()) > MAX_PATCH_BYTES:
        return {"ok":False,"error":"patch_missing_or_too_large"}
    paths=[]
    for line in patch.splitlines():
        if line.startswith(("--- ","+++ ")):
            raw=line[4:].split("\t",1)[0].strip()
            raw=raw[2:] if raw.startswith(("a/","b/")) else raw
            if raw == "/dev/null":
                return {"ok":False,"error":"file_create_delete_not_allowed_in_first_pass"}
            if not _safe_rel(raw):
                return {"ok":False,"error":"unsafe_patch_path"}
            paths.append(raw)
    paths=list(dict.fromkeys(paths))
    if not paths or len(paths)>MAX_FILES:
        return {"ok":False,"error":"invalid_patch_file_count"}
    for rel in paths:
        p=root/rel
        if not p.exists() or not p.is_file():
            return {"ok":False,"error":f"target_missing:{rel}"}
        if not _readable(p):
            return {"ok":False,"error":f"target_type_not_allowed:{rel}"}
    return {"ok":True,"files":paths,"sha256":hashlib.sha256(patch.encode()).hexdigest()}

def prepare(goal: str, db_path: str=DEFAULT_DB_PATH, root: Optional[str]=None, urls: Optional[List[str]]=None,
            files: Optional[List[str]]=None, generate_patch: bool=True, env=None) -> Dict[str,Any]:
    r=repo_root(root)
    scan_result=scan(str(r),db_path)
    selected=[]
    for rel in (files or []):
        if _safe_rel(rel) and (r/rel).is_file() and _readable(r/rel):
            selected.append(rel)
    if not selected:
        selected=[x for x in ["kora/services/self_evolution.py","kora/services/governance.py","kora/core/identity.py",
                              "kora/bridge/api.py","src/components/KoraFaceHud.tsx","src/components/Header.tsx"] if (r/x).exists()]
    context=[]
    for rel in selected[:8]:
        p=r/rel
        data=p.read_text(encoding="utf-8",errors="replace")
        context.append(f"\n===== {rel} =====\n{data[:18000]}")
    evidence=research_gap(goal,urls,env,db_path) if urls else {"status":"LOCAL_ONLY","references":[],"limits":"No external source URLs/search key supplied."}
    prompt=f"""You are KILCRITIC's governed code-improvement planner.
Goal: {goal[:500]}
Local scan: {json.dumps(scan_result,ensure_ascii=False)[:8000]}
Evidence: {json.dumps(evidence,ensure_ascii=False)[:6000]}
Return ONLY a unified diff patch using paths relative to repository root.
Rules: modify existing files only; no new files; no shell commands; no secrets; minimal change;
preserve public APIs unless necessary; add tests when practical; do not bypass authentication,
permissions, safety or approval gates. The patch is a proposal only and will be tested before
owner-approved application.
Context:
{''.join(context)[:90000]}"""
    patch=""
    ai={}
    if generate_patch:
        ai=query_ai_model(prompt,env=env)
        patch=_extract_patch(ai.get("output",""))
    pv=validate_patch(patch,r) if patch else {"ok":False,"error":"no_patch_generated"}
    changes=[{"goal":goal[:500],"scan":scan_result,"evidence":evidence,"patch_sha256":pv.get("sha256"),"files":pv.get("files",[])}]
    tests=["python -m compileall kora app","python -m kora.tests.run_all","frontend build/lint when toolchain is available"]
    pid=governance.create_proposal("MODIFY_CODE",f"Self-improvement proposal: {goal[:500]}","HIGH",changes,tests,
                                   "Restore pre-apply snapshot of every affected file",db_path)
    if patch and pv["ok"]:
        base=r/"data"/PATCH_ROOT_NAME/"proposals"
        base.mkdir(parents=True,exist_ok=True)
        (base/f"{pid}.patch").write_text(patch,encoding="utf-8")
    record_audit("self_evolution_prepared","system",{"proposal_id":pid,"goal":goal[:200],"patch_ready":bool(patch and pv["ok"]),"patch_sha256":pv.get("sha256")},db_path)
    return {"status":"PENDING_APPROVAL","proposal_id":pid,"scan":scan_result,"evidence":evidence,
            "patch_ready":bool(patch and pv["ok"]),"patch_validation":pv,"provider":ai.get("provider") if ai else None}

def _proposal_status(pid: str, db_path: str) -> Optional[Dict[str,Any]]:
    conn=get_connection(db_path)
    try:
        r=conn.execute("SELECT * FROM proposals WHERE id=?;",(pid,)).fetchone()
        return dict(r) if r else None
    finally: conn.close()

def _affected(patch: str) -> List[str]:
    out=[]
    for line in patch.splitlines():
        if line.startswith("--- "):
            raw=line[4:].split("\t",1)[0].strip()
            raw=raw[2:] if raw.startswith("a/") else raw
            if raw != "/dev/null": out.append(raw)
    return list(dict.fromkeys(out))

def apply_approved(proposal_id: str, db_path: str=DEFAULT_DB_PATH, root: Optional[str]=None, _gate_ok: bool=False) -> Dict[str,Any]:
    """Applies an APPROVED patch with its own dry-run, compile+suite verification and rollback. Production apply must come through
    self_evolution_3.promote() (evidence gate); a direct call is refused so the gate cannot be bypassed."""
    if not _gate_ok:
        return {"status":"GATE_REQUIRED","detail":"use self_evolution_3.promote(): evidence-based promotion gate"}
    from kora.services import self_evolution_3 as se3
    if se3.frozen(db_path):
        return {"status":"FROZEN"}
    r=repo_root(root)
    prop=_proposal_status(proposal_id,db_path)
    if not prop: return {"status":"NOT_FOUND"}
    if prop["status"]!="APPROVED": return {"status":"NOT_APPROVED","current":prop["status"]}
    patch_file=r/"data"/PATCH_ROOT_NAME/"proposals"/f"{proposal_id}.patch"
    if not patch_file.is_file(): return {"status":"PATCH_NOT_FOUND"}
    patch=patch_file.read_text(encoding="utf-8")
    pv=validate_patch(patch,r)
    if not pv["ok"]: return {"status":"PATCH_INVALID","detail":pv}
    affected=pv["files"]
    backup=r/"data"/PATCH_ROOT_NAME/"restore_points"/f"{proposal_id}"
    backup.mkdir(parents=True,exist_ok=True)
    for rel in affected:
        dst=backup/rel
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(r/rel,dst)
    # Dry-run first, then apply. Paths were validated above.
    # Prefer git apply when available; fall back to the standard patch utility because
    # a distributed ZIP release does not necessarily contain a .git directory.
    use_git = subprocess.run(["git","rev-parse","--is-inside-work-tree"], cwd=str(r),
                             capture_output=True, text=True, timeout=10).returncode == 0
    if use_git:
        dry_cmd=["git","apply","--check","--whitespace=nowarn"]
        run_cmd=["git","apply","--whitespace=nowarn"]
    else:
        dry_cmd=["patch","-p1","--dry-run","--forward","--batch"]
        run_cmd=["patch","-p1","--forward","--batch"]
    dry=subprocess.run(dry_cmd,input=patch,text=True,cwd=str(r),
                       capture_output=True,timeout=30)
    if dry.returncode!=0:
        return {"status":"CANARY_FAILED","phase":"dry_run","error":(dry.stderr or dry.stdout)[-1000:],"backup":str(backup)}
    run=subprocess.run(run_cmd,input=patch,text=True,cwd=str(r),
                       capture_output=True,timeout=30)
    if run.returncode!=0:
        return {"status":"APPLY_FAILED","error":run.stderr[-1000:],"backup":str(backup)}
    # Verification gate: syntax first, then the authoritative behavioural suite.
    comp=subprocess.run(["python3","-m","compileall","-q","kora","app"],cwd=str(r),capture_output=True,text=True,timeout=60)
    if comp.returncode!=0:
        rollback(r,affected,backup)
        governance._finish(proposal_id,"FAILED",{"phase":"compile","error":comp.stderr[-1000:],"rolled_back":True},db_path)
        return {"status":"ROLLED_BACK","phase":"compile","error":comp.stderr[-1000:],"backup":str(backup)}
    tests=subprocess.run(["python3","-m","kora.tests.run_all"],cwd=str(r),capture_output=True,text=True,timeout=180)
    if tests.returncode!=0:
        rollback(r,affected,backup)
        governance._finish(proposal_id,"FAILED",{"phase":"tests","error":(tests.stderr or tests.stdout)[-2000:],"rolled_back":True},db_path)
        return {"status":"ROLLED_BACK","phase":"tests","error":(tests.stderr or tests.stdout)[-2000:],"backup":str(backup)}
    governance._finish(proposal_id,"EXECUTED",{"applied_files":affected,"backup":str(backup),"tests":"PASS"},db_path)
    record_audit("self_evolution_applied","owner",{"proposal_id":proposal_id,"files":affected,"backup":str(backup),"tests":"PASS"},db_path)
    return {"status":"APPLIED_VERIFIED","files":affected,"backup":str(backup),"tests":"PASS"}

def rollback(root: Path, affected: List[str], backup: Path) -> None:
    for rel in affected:
        src=backup/rel
        if src.exists():
            dst=root/rel
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,dst)

def rollback_proposal(proposal_id: str, db_path: str=DEFAULT_DB_PATH, root: Optional[str]=None) -> Dict[str,Any]:
    r=repo_root(root)
    backup=r/"data"/PATCH_ROOT_NAME/"restore_points"/proposal_id
    if not backup.is_dir(): return {"status":"NO_RESTORE_POINT"}
    affected=[str(p.relative_to(backup)) for p in backup.rglob("*") if p.is_file()]
    rollback(r,affected,backup)
    record_audit("self_evolution_rollback","owner",{"proposal_id":proposal_id,"files":affected},db_path)
    return {"status":"ROLLED_BACK","files":affected}
