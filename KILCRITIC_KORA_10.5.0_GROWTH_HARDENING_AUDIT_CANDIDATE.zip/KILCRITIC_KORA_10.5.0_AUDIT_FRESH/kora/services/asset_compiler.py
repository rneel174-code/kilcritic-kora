"""One-master-asset to platform variants. Planning only; never claims export/post succeeded."""
from __future__ import annotations
from typing import Any, Dict

TARGETS = {
    "YOUTUBE": {"video": "16:9", "short": "9:16"},
    "FACEBOOK": {"video": "platform-default", "reel": "9:16"},
    "TIKTOK": {"video": "9:16", "photo": "platform-default"},
    "INSTAGRAM": {"reel": "9:16", "story": "9:16", "feed": "4:5"},
    "X": {"video": "platform-default", "image": "platform-default"},
}

def compile_variants(master_asset: str, platforms=None) -> Dict[str, Any]:
    selected = [p.upper() for p in (platforms or TARGETS.keys())]
    variants = []
    for p in selected:
        if p in TARGETS:
            for kind, ratio in TARGETS[p].items():
                variants.append({"platform": p, "kind": kind, "aspect_ratio": ratio, "source": master_asset})
    return {"master_asset": master_asset, "variant_count": len(variants), "variants": variants,
            "state": "PLANNED_NOT_EXPORTED"}
