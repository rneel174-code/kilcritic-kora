"""Deep research / source fusion + Science Lab report.

SEARCH -> DISCOVER -> DEEPEN -> CROSS-CHECK -> DATE -> SOURCE QUALITY -> CONTRADICTIONS -> SYNTHESIZE -> CITE -> CONFIDENCE.
Only pages that were REALLY fetched are cited (with fetch time). Without a search key the caller must pass URLs; nothing
is invented. Output is labelled fresh web evidence (never stored/internal knowledge). Status: VERIFIED needs >=2 independent
domains incl. one official/academic source and no contradiction; one source or any contradiction is never VERIFIED.
Fetch is SSRF-guarded by research.fetch_page; paywalls/logins are not bypassed (a blocked page is reported as failed).
"""
import re
import time
import urllib.parse
from typing import Any, Callable, Dict, List, Optional

from kora.core.contracts import Truth
from kora.services import research

OFFICIAL_SUFFIX = (".gov", ".edu", ".int", ".mil")
ACADEMIC_HOSTS = ("arxiv.org", "doi.org", "nature.com", "science.org", "pubmed.ncbi.nlm.nih.gov", "ncbi.nlm.nih.gov", "who.int", "ieee.org", "acm.org", "springer.com", "sciencedirect.com", "plos.org")
MONTHS = "january february march april may june july august september october november december".split()
STOP = set("the a an of and or to in on for with is are was were be by as at from that this it its".split())


def source_class(host: str) -> str:
    host = host.lower().split(":")[0]
    if host.endswith(OFFICIAL_SUFFIX) or ".gov." in host or ".ac." in host or ".edu." in host:
        return "OFFICIAL_OR_UNIVERSITY"
    if any(host == h or host.endswith("." + h) for h in ACADEMIC_HOSTS):
        return "ACADEMIC"
    return "OTHER"


def find_date(text: str) -> Optional[str]:
    t = text[:4000]
    m = re.search(r"\b(20\d{2}|19\d{2})-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])\b", t)
    if m:
        return m.group(0)
    m = re.search(r"\b(" + "|".join(MONTHS) + r")\s+(\d{1,2}),?\s+(20\d{2}|19\d{2})\b", t, re.I)
    if m:
        return f"{m.group(3)}-{MONTHS.index(m.group(1).lower()) + 1:02d}-{int(m.group(2)):02d}"
    return None


def _terms(s: str) -> set:
    return {w for w in re.findall(r"[a-z0-9]{3,}", s.lower()) if w not in STOP}


def _numbers(s: str) -> set:
    return set(re.findall(r"\d+(?:\.\d+)?", s))


def _sentences(text: str) -> List[str]:
    return [x.strip() for x in re.split(r"(?<=[.!?])\s+", text[:60000]) if 30 < len(x.strip()) < 400]


def contradictions(sources: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Sentences from DIFFERENT sources that share >=4 content terms but carry conflicting figures."""
    out: List[Dict[str, Any]] = []
    sents = [(i, s, _terms(s), _numbers(s)) for i, src in enumerate(sources) for s in src["claims"]]
    for a in range(len(sents)):
        for b in range(a + 1, len(sents)):
            (i, s1, t1, n1), (j, s2, t2, n2) = sents[a], sents[b]
            if i != j and (n1 - n2) and (n2 - n1) and len(t1 & t2) >= 4 and len(out) < 10:  # each side has a figure the other lacks
                out.append({"sources": [sources[i]["url"], sources[j]["url"]], "claims": [s1[:200], s2[:200]]})
    return out


def deep_research(question: str, urls: Optional[List[str]] = None, *, search: Optional[Callable] = None, fetch: Optional[Callable] = None,
                  max_sources: int = 6, now: Optional[float] = None, max_bytes: int = 2 * 1024 * 1024, timeout: float = 10.0) -> Dict[str, Any]:
    question = (question or "").strip()
    if not question or len(question) > 500:
        raise ValueError("question 1-500 chars")
    now = time.time() if now is None else now
    fetch = fetch or (lambda u: research.fetch_page(u, max_bytes, timeout))
    discovered: List[str] = list(urls or [])
    search_status = "SKIPPED_URLS_PROVIDED"
    if not discovered:
        res = (search or research.search_web)(question)
        search_status = res.get("status", "OK" if res.get("ok") else "FAILED")
        if not res.get("ok"):
            return {"status": Truth.UNAVAILABLE.value, "evidence_origin": "none", "search": search_status, "reason": res.get("error", ""),
                    "sources": [], "references": [], "note": "no web evidence was gathered; nothing is fabricated"}
        discovered = [r["url"] for r in res["results"] if r.get("url")]
    # prefer distinct domains first (max 2 per domain)
    per: Dict[str, int] = {}
    picked: List[str] = []
    for u in discovered:
        host = urllib.parse.urlparse(u).hostname or ""
        if per.get(host, 0) < 2 and len(picked) < max(1, min(10, max_sources)):
            per[host] = per.get(host, 0) + 1
            picked.append(u)
    qt = _terms(question)
    sources: List[Dict[str, Any]] = []
    failed: List[Dict[str, str]] = []
    for u in picked:
        try:
            page = fetch(u)
        except Exception as exc:  # noqa: BLE001 - blocked/paywalled/failed pages are reported, never worked around
            failed.append({"url": u, "error": str(exc)[:120]})
            continue
        text = page["text"]
        host = urllib.parse.urlparse(page.get("url", u)).hostname or ""
        claims = [s for s in _sentences(text) if len(qt & _terms(s)) >= 2][:12]
        rel = len(qt & _terms(text[:20000])) / max(1, len(qt))
        d = find_date(text)
        cls = source_class(host)
        w = {"OFFICIAL_OR_UNIVERSITY": 0.5, "ACADEMIC": 0.5, "OTHER": 0.2}[cls]
        age_years = None
        recency = 0.0
        if d:
            age_years = max(0.0, (now - time.mktime(time.strptime(d, "%Y-%m-%d"))) / (365 * 86400))
            recency = max(0.0, 1 - age_years / 10)
        sources.append({"url": page.get("url", u), "domain": host, "class": cls, "title": page.get("title", ""), "date": d, "date_label": "INFERRED" if d else "UNAVAILABLE",
                        "relevance": round(rel, 2), "evidence_score": round(w + 0.3 * rel + 0.2 * recency, 2), "claims": claims, "fetched_at": now,
                        "injection_flagged": bool(page.get("injection_flagged"))})
    sources.sort(key=lambda s: s["evidence_score"], reverse=True)
    conflicts = contradictions(sources)
    # a page that tried to instruct the system is not trusted as independent evidence
    domains = {s["domain"] for s in sources if s["relevance"] >= 0.3 and not s["injection_flagged"]}
    strong = any(s["class"] != "OTHER" and s["relevance"] >= 0.3 and not s["injection_flagged"] for s in sources)
    if not sources:
        status, conf = Truth.UNAVAILABLE, 0.0
    elif conflicts:
        status, conf = Truth.UNCERTAIN, 0.3
    elif len(domains) >= 2 and strong:
        status, conf = Truth.VERIFIED, min(0.9, 0.5 + 0.1 * len(domains))
    elif len(domains) >= 2:
        status, conf = Truth.SOURCE_BASED, 0.6
    else:
        status, conf = Truth.UNCERTAIN, 0.35
    return {"status": status.value, "confidence": round(conf, 2), "evidence_origin": "fresh_web", "search": search_status,
            "question": question, "independent_domains": len(domains), "contradictions": conflicts,
            "sources": [{k: v for k, v in s.items() if k != "claims"} | {"key_claims": s["claims"][:3]} for s in sources],
            "references": [{"url": s["url"], "title": s["title"], "fetched_at": s["fetched_at"]} for s in sources],
            "failed_sources": failed, "stored_knowledge_used": False,
            "injection_flagged_sources": [s["url"] for s in sources if s["injection_flagged"]],
            "limits": "relevance/contradiction checks are lexical heuristics; read the sources before relying on a conclusion"}


def science_report(hypothesis: str, research_result: Dict[str, Any], calculation: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Structured Science Lab record. No experiment is ever invented: `experiments_run` stays [] unless real data is supplied."""
    if not (hypothesis or "").strip():
        raise ValueError("hypothesis required")
    out = {"hypothesis": hypothesis.strip(), "sources": research_result.get("references", []), "evidence_status": research_result.get("status", "UNAVAILABLE"),
           "evidence_confidence": research_result.get("confidence", 0.0), "contradictions": research_result.get("contradictions", []),
           "experiments_run": [], "simulation": "NOT_RUN", "uncertainty": "high" if research_result.get("status") in ("UNCERTAIN", "UNAVAILABLE") else "moderate"}
    if calculation:
        vals = calculation.get("values") or []
        if not vals or not all(isinstance(v, (int, float)) for v in vals):
            raise ValueError("calculation.values must be numbers supplied by the caller")
        n, mean = len(vals), sum(vals) / len(vals)
        sd = (sum((v - mean) ** 2 for v in vals) / (n - 1)) ** 0.5 if n > 1 else None
        out["calculation"] = {"n": n, "mean": mean, "sample_sd": sd, "provenance": "values supplied by caller; not measured by KORA"}
    out["conclusion"] = ("Insufficient or conflicting evidence - no conclusion supported." if out["evidence_status"] in ("UNCERTAIN", "UNAVAILABLE")
                         else "Evidence supports the hypothesis only to the stated confidence; see references.")
    return out
