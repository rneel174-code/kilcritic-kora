"""KORA Supreme Guardian layer.

Additive governance facade over existing Anti-Loop, Trust, DNA, Governance,
System Doctor and Meta-Tool concepts. It does not create a second queue,
permission engine or scheduler. State is durable in SQLite and every action is
fail-closed, auditable and bounded.
"""
from __future__ import annotations
import base64, hashlib, json, os, re, secrets, threading, time
from typing import Any, Callable, Dict, List, Optional

from cryptography.fernet import Fernet, InvalidToken

from kora.core.db import DEFAULT_DB_PATH, get_connection, record_audit
from kora.core.contracts import Risk
from kora.core import policy, anti_loop
from kora.services import dna, governance, trust

LOCKS = [
    "AUTO_ANTIBODY", "FUTURE_PREDICTOR", "MEMORY_POISON_DEFENSE", "TOOL_FUSION",
    "MALAK_DECISION_PROFILE", "SELF_RECYCLING", "DISTRIBUTED_SECRET_VAULT",
    "INDEPENDENT_RUNTIME_WATCHDOG", "SELF_REFUSAL", "BACKGROUND_SUPERVISOR", "MALAK_ASSIST_HUMAN_IN_LOOP",
]

SECRET_PATTERNS = [
    re.compile(r"(?i)(api[_-]?key|access[_-]?token|refresh[_-]?token|password|secret|private[_-]?key)\s*[:=]"),
    re.compile(r"\bsk-[A-Za-z0-9_-]{12,}\b"),
    re.compile(r"\b(?:ghp|github_pat)_[A-Za-z0-9_]{20,}\b"),
]
INJECTION_PATTERNS = [
    re.compile(r"(?i)ignore\s+(all|any|previous|prior)\s+instructions"),
    re.compile(r"(?i)reveal\s+(the\s+)?system\s+prompt"),
    re.compile(r"(?i)bypass\s+(security|permission|approval)"),
    re.compile(r"(?i)disable\s+(logging|audit|safety)"),
]
UNSAFE_ACTIONS = {"publish", "send_message", "payment", "purchase", "credential_change", "account_change", "delete_data", "deploy", "change_security"}


def _now() -> float:
    return time.time()


def _json(v: Any, limit: int = 20000) -> str:
    return json.dumps(v, sort_keys=True, default=str)[:limit]


def _db(db_path: str):
    return get_connection(db_path)


def init(db_path: str = DEFAULT_DB_PATH) -> None:
    conn = _db(db_path)
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS guardian_incidents (
            id TEXT PRIMARY KEY, kind TEXT NOT NULL, subject TEXT NOT NULL, status TEXT NOT NULL,
            evidence TEXT NOT NULL, proposed_fix TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL,
            resolved_at REAL, resolution TEXT NOT NULL DEFAULT '')""")
        conn.execute("""CREATE TABLE IF NOT EXISTS guardian_predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, prediction TEXT NOT NULL,
            confidence REAL NOT NULL, evidence TEXT NOT NULL, created_at REAL NOT NULL)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS guardian_meta_tools (
            name TEXT PRIMARY KEY, steps TEXT NOT NULL, status TEXT NOT NULL,
            benchmark TEXT NOT NULL DEFAULT '{}', created_at REAL NOT NULL, updated_at REAL NOT NULL)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS guardian_recycle (
            path TEXT PRIMARY KEY, status TEXT NOT NULL, evidence TEXT NOT NULL, replacement TEXT NOT NULL DEFAULT '',
            created_at REAL NOT NULL)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS guardian_vault (
            name TEXT PRIMARY KEY, token TEXT NOT NULL, created_at REAL NOT NULL, expires_at REAL,
            revoked_at REAL, version INTEGER NOT NULL DEFAULT 1)""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_guardian_incidents_status ON guardian_incidents(status);")
    finally:
        conn.close()


def status(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    init(db_path)
    conn = _db(db_path)
    try:
        counts = {}
        for table in ("guardian_incidents", "guardian_predictions", "guardian_meta_tools", "guardian_recycle"):
            counts[table] = conn.execute(f"SELECT COUNT(*) n FROM {table};").fetchone()["n"]
        vault = conn.execute("SELECT COUNT(*) n FROM guardian_vault WHERE revoked_at IS NULL AND (expires_at IS NULL OR expires_at>?)", (_now(),)).fetchone()["n"]
    finally:
        conn.close()
    return {"locks": LOCKS, "state": counts, "active_vault_entries": vault, "truth": "IMPLEMENTED additive guardian layer; external providers remain separately configured"}


def inspect_tool(tool_id: str, failure_count: int = 0, payload: str = "", db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Auto-Antibody detector. It quarantines only after a concrete trigger."""
    reasons = []
    if failure_count >= 3:
        reasons.append("repeated_failure_threshold")
    if any(p.search(payload or "") for p in INJECTION_PATTERNS):
        reasons.append("prompt_injection_pattern")
    if any(p.search(payload or "") for p in SECRET_PATTERNS):
        reasons.append("secret_exposure_pattern")
    if not reasons:
        return {"status": "HEALTHY", "tool": tool_id, "reasons": []}
    incident = "inc-" + secrets.token_hex(8)
    init(db_path)
    conn = _db(db_path)
    try:
        conn.execute("INSERT INTO guardian_incidents(id,kind,subject,status,evidence,created_at) VALUES (?,?,?,?,?,?);",
                     (incident, "TOOL", tool_id, "QUARANTINED", _json({"reasons": reasons, "failure_count": failure_count}), _now()))
    finally:
        conn.close()
    try:
        trust.set_trust("skill", tool_id, "BLOCKED", evidence=_json({"guardian_incident": incident}), db_path=db_path)
    except Exception:
        pass
    record_audit("guardian_quarantine", "system", {"incident": incident, "tool": tool_id, "reasons": reasons}, db_path)
    return {"status": "QUARANTINED", "incident_id": incident, "tool": tool_id, "reasons": reasons,
            "next": "diagnose -> repair proposal -> sandbox test -> owner approval if required -> verify -> rollback on failure"}


def resolve_incident(incident_id: str, resolution: str, *, verified: bool, actor: str = "owner", db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    init(db_path)
    conn = _db(db_path)
    try:
        row = conn.execute("SELECT * FROM guardian_incidents WHERE id=?", (incident_id,)).fetchone()
        if not row:
            return {"status": "NOT_FOUND"}
        status = "RESOLVED" if verified else "QUARANTINED"
        conn.execute("UPDATE guardian_incidents SET status=?,resolved_at=?,resolution=? WHERE id=?", (status, _now() if verified else None, resolution[:2000], incident_id))
        if verified:
            try:
                trust.set_trust("skill", row["subject"], "VERIFIED", evidence=_json({"guardian_incident": incident_id, "resolution": resolution}), db_path=db_path)
            except Exception:
                pass
    finally:
        conn.close()
    record_audit("guardian_incident_resolution", actor, {"incident": incident_id, "verified": verified}, db_path)
    return {"status": status, "incident_id": incident_id}


def future_predictor(db_path: str = DEFAULT_DB_PATH, *, window: int = 30) -> Dict[str, Any]:
    """Evidence-based bounded predictor using durable audit events; never presents guarantees."""
    init(db_path)
    conn = _db(db_path)
    try:
        since = _now() - max(1, min(90, window)) * 86400
        rows = conn.execute("SELECT event_type,created_at FROM audit_events WHERE created_at>=? ORDER BY created_at", (since,)).fetchall()
    finally:
        conn.close()
    total = len(rows)
    buckets: Dict[str, int] = {}
    for r in rows:
        k = r["event_type"]
        buckets[k] = buckets.get(k, 0) + 1
    failures = sum(v for k, v in buckets.items() if "fail" in k or "error" in k or "blocked" in k)
    top = sorted(buckets.items(), key=lambda x: x[1], reverse=True)[:5]
    conf = min(0.85, 0.25 + min(total, 200) / 400)
    if total < 10:
        conf = min(conf, 0.35)
    result = {"status": "PREDICTION", "window_days": window, "sample_events": total,
              "forecast": {"failure_pressure": round(failures / max(1, total), 3), "busy_event_types": top},
              "confidence": round(conf, 2), "evidence": "audit_events only", "guarantee": False}
    conn = _db(db_path)
    try:
        conn.execute("INSERT INTO guardian_predictions(kind,prediction,confidence,evidence,created_at) VALUES (?,?,?,?,?)",
                     ("system", _json(result), conf, f"audit_events:{total}", _now()))
    finally:
        conn.close()
    return result


def inspect_memory(text: str, source: str = "unknown", confidence: float = 0.5, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Memory poison firewall: secrets/instructions/contradictions are quarantined, not remembered."""
    text = (text or "")[:10000]
    reasons = []
    if any(p.search(text) for p in SECRET_PATTERNS): reasons.append("secret_pattern")
    if any(p.search(text) for p in INJECTION_PATTERNS): reasons.append("instruction_injection")
    if not source or source == "unknown": reasons.append("missing_provenance")
    if confidence < 0.35: reasons.append("low_confidence")
    safe = not reasons
    record_audit("memory_screen", "system", {"safe": safe, "source": source, "reasons": reasons}, db_path)
    return {"status": "ACCEPT" if safe else "QUARANTINED", "source": source, "confidence": max(0, min(1, confidence)), "reasons": reasons,
            "store": safe, "never_store_credentials": True}


def register_meta_tool(name: str, steps: List[str], *, benchmark: Optional[Dict[str, Any]] = None, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Verified Tool Fusion: register only after benchmark evidence."""
    if not re.match(r"^[A-Za-z0-9_.-]{1,80}$", name or "") or not steps or len(steps) > 30:
        raise ValueError("invalid meta-tool")
    benchmark = benchmark or {}
    if benchmark.get("status") != "PASS":
        return {"status": "PENDING_VERIFICATION", "name": name, "reason": "benchmark status must be PASS"}
    init(db_path)
    conn = _db(db_path)
    try:
        now = _now()
        conn.execute("INSERT INTO guardian_meta_tools(name,steps,status,benchmark,created_at,updated_at) VALUES (?,?,?,?,?,?) ON CONFLICT(name) DO UPDATE SET steps=excluded.steps,status=excluded.status,benchmark=excluded.benchmark,updated_at=excluded.updated_at",
                     (name, _json(steps, 10000), "VERIFIED", _json(benchmark), now, now))
    finally: conn.close()
    record_audit("meta_tool_verified", "system", {"name": name, "steps": steps}, db_path)
    return {"status": "VERIFIED", "name": name, "steps": steps}


def malak_profile(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Read-only aggregate of existing DNA decisions; DNA remains authoritative."""
    out = {}
    for kind in dna.KINDS:
        data = dna.get(kind, db_path)["data"]
        out[kind] = {k: {"value": v["value"], "confidence": v["confidence"], "source": v["source"]} for k, v in data.items() if v.get("source") == "explicit" or v.get("confidence", 0) >= 0.7}
    return {"status": "VERIFIED_PROFILE", "source": "existing DNA vault", "profile": out,
            "authority": "assistive only; safety/permission/approval always override"}


def recycle_scan(root: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Non-destructive source scan. It archives findings as candidates; it never deletes."""
    from pathlib import Path
    p = Path(root).resolve()
    if not p.exists(): raise ValueError("root does not exist")
    files = [x for x in p.rglob("*.py") if "__pycache__" not in x.parts]
    hashes: Dict[str, List[str]] = {}
    for f in files:
        try: hashes.setdefault(hashlib.sha256(f.read_bytes()).hexdigest(), []).append(str(f))
        except OSError: continue
    duplicates = [v for v in hashes.values() if len(v) > 1]
    init(db_path)
    conn = _db(db_path)
    try:
        for group in duplicates:
            for path in group:
                conn.execute("INSERT OR REPLACE INTO guardian_recycle(path,status,evidence,replacement,created_at) VALUES (?,?,?,?,?)",
                             (path, "CANDIDATE_DUPLICATE", _json({"group": group}), "REVIEW_BEFORE_ARCHIVE", _now()))
    finally: conn.close()
    return {"status": "SCAN_COMPLETE", "python_files": len(files), "duplicate_groups": duplicates, "destructive_delete": False}


def refusal(action: str, context: str = "", db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    a = (action or "").lower().strip()
    if a in UNSAFE_ACTIONS:
        d = policy.evaluate(a, db_path=db_path)
        if d["decision"] in ("BLOCK", "APPROVAL_REQUIRED"):
            record_audit("guardian_refusal", "system", {"action": a, "reason": d["reason"]}, db_path)
            return {"decision": "REFUSE_OR_APPROVAL", "action": a, "reason": d["reason"], "risk": d["risk"]}
    if any(p.search(context or "") for p in INJECTION_PATTERNS):
        record_audit("guardian_refusal", "system", {"action": a, "reason": "injection_pattern"}, db_path)
        return {"decision": "REFUSE", "action": a, "reason": "unsafe_instruction_pattern"}
    return {"decision": "ALLOW_SUBJECT_TO_EXISTING_POLICY", "action": a}


def watchdog(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Independent read-only runtime check; it does not mutate or auto-repair."""
    from kora.services.system_doctor import run_system_doctor_inspection
    health = run_system_doctor_inspection(db_path)
    return {"status": "HEALTHY" if not health.get("critical") else "DEGRADED", "health_score": health.get("health_score"),
            "critical": health.get("critical", []), "mutations": "NONE"}


def supervisor_tick(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Auditable background supervisor tick; bounded, observe-only."""
    w = watchdog(db_path)
    p = future_predictor(db_path, window=30)
    record_audit("background_supervisor_tick", "system", {"watchdog": w, "prediction_confidence": p["confidence"]}, db_path)
    return {"status": "OBSERVED", "watchdog": w, "prediction": p, "actions": []}


# ---------------------------------------------------------------- Secret vault (Fernet + optional Shamir-style threshold recovery for key material)
def _master_key() -> bytes:
    raw = os.environ.get("KORA_VAULT_MASTER_KEY", "")
    if not raw:
        raise RuntimeError("KORA_VAULT_MASTER_KEY is not configured; vault is unavailable")
    try:
        b = raw.encode()
        Fernet(b)
        return b
    except Exception as exc:
        raise RuntimeError("KORA_VAULT_MASTER_KEY must be a Fernet key") from exc


def vault_put(name: str, value: str, *, ttl_seconds: Optional[int] = None, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    init(db_path); f = Fernet(_master_key()); now = _now(); exp = now + ttl_seconds if ttl_seconds else None
    token = f.encrypt(value.encode()).decode()
    conn = _db(db_path)
    try:
        conn.execute("INSERT INTO guardian_vault(name,token,created_at,expires_at,revoked_at,version) VALUES (?,?,?,?,?,1) ON CONFLICT(name) DO UPDATE SET token=excluded.token,created_at=excluded.created_at,expires_at=excluded.expires_at,revoked_at=NULL,version=guardian_vault.version+1", (name, token, now, exp, None))
    finally: conn.close()
    record_audit("vault_put", "owner", {"name": name, "expires": exp is not None}, db_path)
    return {"status": "STORED", "name": name, "expires_at": exp, "plaintext_returned": False}


def vault_get(name: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    init(db_path); f = Fernet(_master_key()); conn = _db(db_path)
    try:
        r = conn.execute("SELECT * FROM guardian_vault WHERE name=?", (name,)).fetchone()
    finally: conn.close()
    if not r or r["revoked_at"] is not None or (r["expires_at"] is not None and r["expires_at"] <= _now()):
        return {"status": "UNAVAILABLE", "reason": "missing_revoked_or_expired"}
    try: value = f.decrypt(r["token"].encode()).decode()
    except InvalidToken: return {"status": "REFUSED", "reason": "ciphertext_invalid"}
    return {"status": "REVEALED_TO_CALLER", "name": name, "value": value}


def vault_revoke(name: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    init(db_path); conn = _db(db_path)
    try: n = conn.execute("UPDATE guardian_vault SET revoked_at=? WHERE name=? AND revoked_at IS NULL", (_now(), name)).rowcount
    finally: conn.close()
    record_audit("vault_revoke", "owner", {"name": name}, db_path)
    return {"status": "REVOKED" if n else "NOT_FOUND", "name": name}


def rotate_master_key(old_key: str, new_key: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Rotate encrypted entries without exposing plaintext in logs."""
    old, new = Fernet(old_key.encode()), Fernet(new_key.encode()); init(db_path); conn = _db(db_path)
    try:
        rows = conn.execute("SELECT name,token FROM guardian_vault WHERE revoked_at IS NULL").fetchall()
        updated = 0
        for r in rows:
            val = old.decrypt(r["token"].encode())
            conn.execute("UPDATE guardian_vault SET token=?,version=version+1 WHERE name=?", (new.encrypt(val).decode(), r["name"]))
            updated += 1
    finally: conn.close()
    record_audit("vault_rotate", "owner", {"entries": updated}, db_path)
    return {"status": "ROTATED", "entries": updated}


def split_secret(secret: bytes, threshold: int = 2, shares: int = 3) -> List[str]:
    """Simple Shamir-style byte sharing over prime 257. Shares are recovery material only; not stored by KORA."""
    if not (1 < threshold <= shares <= 10): raise ValueError("require 2 <= threshold <= shares <= 10")
    out: List[str] = []
    coeffs = [[b] + [secrets.randbelow(257) for _ in range(threshold - 1)] for b in secret]
    for x in range(1, shares + 1):
        vals = []
        for coeff in coeffs:
            y = sum(c * (x ** i) for i, c in enumerate(coeff)) % 257
            vals.append(y)
        raw = bytes([x]) + b"".join(int(v).to_bytes(2, "big") for v in vals)
        out.append(base64.b64encode(raw).decode())
    return out


def combine_shares(share_texts: List[str], threshold: int = 2) -> bytes:
    if len(share_texts) < threshold: raise ValueError("not enough shares")
    decoded = []
    for s in share_texts[:threshold]:
        raw = base64.b64decode(s.encode())
        if len(raw) < 3 or (len(raw)-1) % 2: raise ValueError("invalid share")
        decoded.append((raw[0], [int.from_bytes(raw[i:i+2], "big") for i in range(1, len(raw), 2)]))
    length = len(decoded[0][1]); out = bytearray()
    if any(len(v) != length for _, v in decoded): raise ValueError("share length mismatch")
    for j in range(length):
        val = 0
        for i, (xi, vals) in enumerate(decoded):
            yi = vals[j]; li = 1
            for k, (xk, _) in enumerate(decoded):
                if i != k: li = (li * (-xk) * pow(xi - xk, -1, 257)) % 257
            val = (val + yi * li) % 257
        if val > 255: raise ValueError("invalid shares")
        out.append(val)
    return bytes(out)
