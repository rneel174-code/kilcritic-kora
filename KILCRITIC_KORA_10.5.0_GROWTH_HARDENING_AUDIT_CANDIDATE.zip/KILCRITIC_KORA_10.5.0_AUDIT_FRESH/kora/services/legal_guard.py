"""Legal/platform preflight. Heuristic checks on declared metadata - NOT a legal guarantee and never claimed as one.

Statuses: PASS | AUTO_FIXED | HUMAN_REVIEW | BLOCKED.  Unknown rights are never assumed to be permitted.
"""
import re
from typing import Any, Dict, List, Optional

BLOCK_SOURCES = {"UNAUTHORIZED", "DRM", "PAYWALL_BYPASS", "STOLEN", "SCRAPED_PRIVATE"}
KNOWN_RIGHTS = {"OWNED", "LICENSED", "PUBLIC_DOMAIN", "CC_BY", "CC0"}
MAX_HASHTAGS = 30
MAX_LEN = {"X": 280}

# Risk signals that never depend on a declared flag (the declared metadata can be missing or wrong).
_SOURCE_BLOCK_RX = re.compile(r"(?i)\b(copied|scrap(ed|ing)?|ripped?|pirat\w*|stolen|leak(ed)?|torrent|cracked|drm[- ]?(free|removed))\b")
_PIRACY_RX = re.compile(r"(?i)\b(pirat\w+|torrent|cracked\s+(software|app|game)|full\s+movie\s+(free|download)|free\s+download\s+(of\s+)?(the\s+)?(full\s+)?(movie|film|series|album)|leaked\s+(movie|film|album|episode))\b")
_IMPERSONATION_RX = re.compile(r"(?i)\b(deep\s*fake|voice\s*clon\w*|clone[d]?\s+(of\s+)?\w*\s*(voice|face)|face\s*swap|exact\s+voice)\b")
_RIGHTS_MAP = {"OWNED": "USER_OWNED", "ORIGINAL": "ORIGINAL", "USER_OWNED": "USER_OWNED", "LICENSED": "LICENSED", "CC_BY": "LICENSED",
               "PUBLIC_DOMAIN": "PUBLIC_DOMAIN", "CC0": "PUBLIC_DOMAIN", "UNAUTHORIZED": "RESTRICTED"}
DISCLOSURE = "[AI-generated]"


def preflight(asset: Dict[str, Any]) -> Dict[str, Any]:
    """asset keys (all optional): platform, content, audience, media (bool), rights, source, adult_content, ai_generated,
    disclosure, duplicate_risk, platform_risk."""
    issues: List[str] = []
    fixes: List[str] = []
    review: List[str] = []
    fixed = dict(asset)
    content = str(fixed.get("content") or "")
    audience = str(fixed.get("audience") or "GENERAL").upper()
    rights = str(fixed.get("rights") or "").upper()
    source = str(fixed.get("source") or "").upper()

    if source in BLOCK_SOURCES or rights == "UNAUTHORIZED":
        issues.append(f"unauthorized_or_protected_source:{source or rights}")
    if audience == "KIDS" and fixed.get("adult_content"):
        issues.append("adult_content_for_kids_audience")

    if fixed.get("media") and rights not in KNOWN_RIGHTS:
        review.append("media_rights_unknown_or_undeclared")

    # ---- hardened gate (audit R1): unknown/undeclared rights and risky content can never PASS, with or without media ----
    if source and _SOURCE_BLOCK_RX.search(source) and f"unauthorized_or_protected_source:{source}" not in issues:
        issues.append(f"unauthorized_or_protected_source:{source}")
    if _PIRACY_RX.search(content):
        issues.append("protected_content_distribution_risk")
    if audience != "ADULT" and fixed.get("adult_content"):
        issues.append("adult_content_for_non_adult_audience")
    elif fixed.get("adult_content"):
        review.append("adult_content_requires_human_review")
    try:
        from kora.services import media_rights as _mr
        rec = _mr.RightsRecord(asset_id="preflight", source=source or "undeclared", rights_status=_RIGHTS_MAP.get(rights, "UNKNOWN"),
                               ai_generated=bool(fixed.get("ai_generated")),
                               identity_risk=bool(fixed.get("identity_risk")),
                               voice_imitation_risk=bool(fixed.get("voice_imitation_risk")) or bool(_IMPERSONATION_RX.search(content)),
                               copyrighted_source_risk=bool(fixed.get("copyrighted_source_risk")) or bool(_PIRACY_RX.search(content)))
        verdict = _mr.preflight(rec)
        if verdict["decision"] == "BLOCK":
            issues.extend(f"rights:{r}" for r in verdict["reasons"] if f"rights:{r}" not in issues)
        elif verdict["decision"] == "REVIEW":
            review.extend(f"rights:{r}" for r in (verdict["reasons"] or ["rights_unknown_or_undeclared"]))
    except Exception:  # the evidence layer must never silently turn into a PASS
        review.append("rights_check_unavailable")
    if fixed.get("duplicate_risk"):
        review.append("possible_duplicate_or_reused_content")
    if fixed.get("platform_risk"):
        review.append("possible_platform_policy_issue")

    tags = re.findall(r"(?<!\w)#\w+", content)
    if len(tags) > MAX_HASHTAGS:  # spam signal with a safe fix: drop the surplus hashtags
        seen = 0

        def _trim(m):
            nonlocal seen
            seen += 1
            return m.group(0) if seen <= MAX_HASHTAGS else ""
        content = re.sub(r"(?<!\w)#\w+", _trim, content)
        fixes.append(f"trimmed_hashtags_to_{MAX_HASHTAGS}")
        fixed["content"] = content
    if fixed.get("ai_generated") and not fixed.get("disclosure") and DISCLOSURE not in content:
        fixed["content"] = (content + "\n" + DISCLOSURE).strip()
        fixed["disclosure"] = True
        fixes.append("added_ai_disclosure")
    limit = MAX_LEN.get(str(fixed.get("platform") or "").upper())
    if limit and len(fixed.get("content", content)) > limit:
        review.append(f"exceeds_{limit}_chars_for_platform")

    if issues:
        status = "BLOCKED"
    elif review:
        status = "HUMAN_REVIEW"
    elif fixes:
        status = "AUTO_FIXED"
    else:
        status = "PASS"
    return {"status": status, "issues": issues + review, "fixes": fixes, "asset": fixed, "legal_guarantee": False}
