"""Emergency recovery / safe mode. Defensive only: freeze, preserve, repair safe issues, verify - never retaliate.

Each step reports what REALLY happened. Steps this build cannot automate (process quarantine, restoring a trusted
baseline after a severe compromise) are reported as REQUIRES_OPERATOR instead of being claimed.
Resume is refused unless a fresh health inspection has no CRITICAL probe.
"""
import json
from typing import Any, Dict, List

from kora.core import policy
from kora.core.contracts import Risk
from kora.core.db import DEFAULT_DB_PATH, record_audit, set_setting
from kora.core.queue import DurableQueue
from kora.services import dharma


def _risky() -> List[str]:
    return sorted(k for k, r in policy.PERMISSIONS.items() if r in (Risk.HIGH, Risk.CRITICAL))


def _health(db_path: str) -> Dict[str, Any]:
    from kora.services.system_doctor import run_system_doctor_inspection
    rep = run_system_doctor_inspection(db_path)
    crit = [p for p in rep["probes"] if p.get("status") == "CRITICAL"]
    return {"score": rep["health_score"], "critical": [p.get("component") for p in crit]}


def set_safe_mode(active: bool, actor: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    set_setting(policy.SAFE_MODE_KEY, "1" if active else "0", db_path)
    DurableQueue(db_path).set_kill_switch(active)
    record_audit("safe_mode", actor, {"active": active}, db_path)
    return {"safe_mode": active, "kill_switch": active}


def emergency_recovery(actor: str = "operator", db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    steps: List[Dict[str, Any]] = []

    def step(name: str, status: str, detail: Any = None) -> None:
        steps.append({"step": name, "status": status, "detail": detail})

    before = {}
    try:
        before = _health(db_path)
        step("DETECT", "DONE", before)
    except Exception as exc:  # noqa: BLE001
        step("DETECT", "FAILED", str(exc)[:200])
    set_safe_mode(True, actor, db_path)
    step("ISOLATE_AND_FREEZE_EXTERNAL_SIDE_EFFECTS", "DONE", "kill switch + safe mode ON: no new jobs, cron or publishing")
    set_setting(policy.REVOKED_KEY, json.dumps(_risky()), db_path)
    step("REVOKE_RISKY_PERMISSIONS", "DONE", _risky())
    q = DurableQueue(db_path)
    record_audit("emergency_snapshot", actor, {"queue": q.get_stats(), "health": before}, db_path)
    step("PRESERVE_LOGS", "DONE", "audit/log tables untouched; snapshot recorded")
    try:
        from kora.services.system_doctor import execute_safe_self_healing
        res = dharma.repair_flow(
            detect=lambda: True, repair=lambda: execute_safe_self_healing(db_path),
            test=lambda: not _health(db_path)["critical"], verify=lambda: not _health(db_path)["critical"],
            rollback_fn=lambda: None, risk=Risk.LOW)
        step("AUTO_REPAIR_SAFE_ISSUES", "DONE" if res["status"] == "REPAIRED" else "NOT_FIXED", res)
    except Exception as exc:  # noqa: BLE001
        step("AUTO_REPAIR_SAFE_ISSUES", "FAILED", str(exc)[:200])
    try:
        after = _health(db_path)
        step("VERIFY", "PASS" if not after["critical"] else "FAIL", after)
    except Exception as exc:  # noqa: BLE001
        after = {"critical": ["inspection_failed"]}
        step("VERIFY", "FAILED", str(exc)[:200])
    step("QUARANTINE_PROCESSES", "REQUIRES_OPERATOR", "no process sandboxing is implemented in this build")
    step("RESTORE_TRUSTED_BASELINE", "REQUIRES_OPERATOR", "use the verified backup flow if compromise is suspected")
    ok = not after["critical"]
    record_audit("emergency_recovery", actor, {"resume_allowed": ok}, db_path)
    return {"status": "SAFE_MODE_ACTIVE", "resume_allowed": ok, "steps": steps}


def resume(actor: str = "operator", db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    h = _health(db_path)
    if h["critical"]:
        return {"status": "REFUSED", "reason": "critical_probes_failing", "critical": h["critical"]}
    set_setting(policy.REVOKED_KEY, "[]", db_path)
    set_safe_mode(False, actor, db_path)
    record_audit("resume_after_verification", actor, h, db_path)
    return {"status": "RESUMED", "health": h}
