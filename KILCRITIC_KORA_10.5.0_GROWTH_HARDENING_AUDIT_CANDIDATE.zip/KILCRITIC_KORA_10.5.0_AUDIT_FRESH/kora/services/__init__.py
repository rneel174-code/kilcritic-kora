# Additive final-upgrade capability discovery (no duplicate engine/queue/scheduler).
try:
    from kora.services.supreme_upgrade import capability_manifest as supreme_upgrade_capability_manifest
except Exception:
    supreme_upgrade_capability_manifest = None
# Region-aware localization/compliance profiles
from .regionalization import get_region, localized_defaults  # noqa: F401
