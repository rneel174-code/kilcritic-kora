"""
KORA 8.8.5 - Media Pipeline (FFmpeg & FFprobe) with Subprocess Safety & Bounds
Enforces:
- Argument arrays strictly (NEVER shell=True)
- Path traversal prevention
- Dedicated temporary directories
- Strict subprocess timeout bounds (default 30s)
- Protected user exports directory (never pruned by temp cleanup)
"""
import os
import subprocess
import json
import shutil
import tempfile
from typing import Dict, Any, List, Optional, Tuple

TEMP_DIR_ROOT = os.path.abspath("data/temp")
EXPORTS_DIR_ROOT = os.path.abspath("data/exports")

os.makedirs(TEMP_DIR_ROOT, exist_ok=True)
os.makedirs(EXPORTS_DIR_ROOT, exist_ok=True)

class MediaPipelineError(Exception):
    pass

def sanitize_path(path: str, must_exist: bool = True) -> str:
    """Resolves path and prevents directory traversal outside safe boundaries."""
    abs_path = os.path.abspath(path)
    if must_exist and not os.path.exists(abs_path):
        raise MediaPipelineError(f"Target path does not exist: {abs_path}")
    return abs_path

def probe_media_duration(media_path: str, timeout_sec: float = 10.0) -> float:
    """Uses ffprobe to obtain exact media duration in seconds. Never guesses from word count."""
    safe_path = sanitize_path(media_path, must_exist=True)
    cmd = [
        "ffprobe",
        "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        safe_path
    ]

    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout_sec,
            shell=False  # Mandatory security requirement
        )
        if proc.returncode != 0:
            raise MediaPipelineError(f"ffprobe failed: {proc.stderr.strip()}")
        val = float(proc.stdout.strip())
        return val
    except subprocess.TimeoutExpired:
        raise MediaPipelineError("ffprobe execution timed out.")
    except ValueError:
        raise MediaPipelineError(f"Could not parse duration from ffprobe output: {proc.stdout}")

def generate_thumbnail(
    video_path: str,
    output_filename: str,
    time_offset_sec: float = 1.0,
    timeout_sec: float = 15.0
) -> str:
    """Extracts a thumbnail frame safely using FFmpeg argument array."""
    safe_input = sanitize_path(video_path, must_exist=True)
    out_path = os.path.join(TEMP_DIR_ROOT, os.path.basename(output_filename))

    cmd = [
        "ffmpeg",
        "-y",
        "-ss", str(max(0.0, float(time_offset_sec))),
        "-i", safe_input,
        "-vframes", "1",
        "-q:v", "2",
        out_path
    ]

    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout_sec,
            shell=False
        )
        if proc.returncode != 0 or not os.path.exists(out_path) or os.path.getsize(out_path) == 0:
            raise MediaPipelineError(f"Thumbnail generation failed: {proc.stderr.decode('utf-8', errors='ignore')}")
        return out_path
    except subprocess.TimeoutExpired:
        raise MediaPipelineError("Thumbnail generation timed out.")

def clean_temporary_files() -> int:
    """Safely cleans ONLY files inside data/temp, strictly preserving data/exports."""
    removed = 0
    for root, dirs, files in os.walk(TEMP_DIR_ROOT):
        for f in files:
            p = os.path.join(root, f)
            try:
                os.remove(p)
                removed += 1
            except Exception:
                pass
    return removed


# ----------------------------------------------------------------------------- real quality verification (measured, never assumed)
_RES_CLAIMS = {"4K": (3840, 2160), "2K": (2560, 1440), "1440P": (2560, 1440), "1080P": (1920, 1080), "HD": (1280, 720), "720P": (1280, 720)}


def verify_quality(media_path: str, claimed: Optional[Dict[str, Any]] = None, timeout_sec: float = 15.0) -> Dict[str, Any]:
    """Measure resolution/codec/bitrate/fps/audio with ffprobe and compare against what was CLAIMED (e.g. {"resolution": "4K"}).
    Missing ffprobe or an unreadable file => UNVERIFIED (never a guessed pass). A claim the measurement contradicts => FAIL."""
    import json as _json
    import shutil as _sh
    claimed = claimed or {}
    if not _sh.which("ffprobe"):
        return {"status": "UNVERIFIED", "reason": "ffprobe_not_installed", "measured": None, "mismatches": []}
    try:
        safe = sanitize_path(media_path, must_exist=True)
        proc = subprocess.run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", safe],
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout_sec, shell=False)
        if proc.returncode != 0:
            return {"status": "UNVERIFIED", "reason": "unreadable_or_corrupt_media", "detail": proc.stderr.strip()[:160], "measured": None, "mismatches": []}
        info = _json.loads(proc.stdout or "{}")
    except MediaPipelineError as exc:
        return {"status": "UNVERIFIED", "reason": str(exc)[:160], "measured": None, "mismatches": []}
    except (subprocess.TimeoutExpired, ValueError):
        return {"status": "UNVERIFIED", "reason": "ffprobe_timeout_or_bad_output", "measured": None, "mismatches": []}
    v = next((s for s in info.get("streams", []) if s.get("codec_type") == "video"), {})
    a = next((s for s in info.get("streams", []) if s.get("codec_type") == "audio"), {})
    fmt = info.get("format", {})

    def num(x):
        try:
            return float(x)
        except (TypeError, ValueError):
            return None
    fr = v.get("avg_frame_rate", "0/1").split("/")
    fps = round(float(fr[0]) / float(fr[1]), 2) if len(fr) == 2 and num(fr[1]) else None
    m = {"width": v.get("width"), "height": v.get("height"), "video_codec": v.get("codec_name"), "fps": fps,
         "bitrate_bps": int(num(fmt.get("bit_rate")) or 0) or None, "duration_s": num(fmt.get("duration")),
         "has_audio": bool(a), "audio_codec": a.get("codec_name")}
    mism = []
    rc = str(claimed.get("resolution", "")).upper().replace(" ", "")
    if rc:
        want = _RES_CLAIMS.get(rc)
        if not want:
            mism.append(f"unknown_resolution_claim:{rc}")
        elif not (m["width"] and m["height"]) or max(m["width"], m["height"]) < want[0]:  # long side must reach the claimed class
            mism.append(f"claimed {rc} but measured {m['width']}x{m['height']}")
    if claimed.get("audio") is True and not m["has_audio"]:
        mism.append("claimed audio but no audio stream")
    if claimed.get("min_bitrate_bps") and (m["bitrate_bps"] or 0) < int(claimed["min_bitrate_bps"]):
        mism.append(f"bitrate {m['bitrate_bps']} below claimed minimum {claimed['min_bitrate_bps']}")
    if claimed.get("codec") and m["video_codec"] != str(claimed["codec"]).lower():
        mism.append(f"codec {m['video_codec']} != claimed {claimed['codec']}")
    if not v:
        mism.append("no video stream")
    return {"status": "FAIL" if mism else "PASS", "measured": m, "mismatches": mism}


CONVERT_TARGETS = {
    "vertical_1080x1920": ("1080:1920", "mp4"),
    "square_1080": ("1080:1080", "mp4"),
    "landscape_1920x1080": ("1920:1080", "mp4"),
    "landscape_1280x720": ("1280:720", "mp4"),
}


def convert_variant(source_path: str, target: str, media_root: str = "data/media", timeout_sec: float = 300.0) -> Dict[str, Any]:
    """Real ffmpeg transcode of a file that already exists inside media_root to a platform size.
    state is EXPORTED_VERIFIED only if the output file exists AND ffprobe measures the requested size;
    ffmpeg missing -> UNAVAILABLE (never a fake export). No shell, fixed argv, source confined to media_root."""
    import shutil as _sh
    import json as _json
    if target not in CONVERT_TARGETS:
        raise MediaPipelineError("unknown_target:" + ",".join(sorted(CONVERT_TARGETS)))
    root = os.path.realpath(media_root)
    src = os.path.realpath(sanitize_path(source_path, must_exist=True))
    if os.path.commonpath([root, src]) != root or not os.path.isfile(src):
        raise MediaPipelineError("source_outside_media_root")
    if not (_sh.which("ffmpeg") and _sh.which("ffprobe")):
        return {"state": "UNAVAILABLE", "reason": "ffmpeg_not_installed", "output": None}
    size, ext = CONVERT_TARGETS[target]
    w, h = size.split(":")
    out_dir = os.path.join(root, "converted")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, f"{os.path.splitext(os.path.basename(src))[0]}.{target}.{ext}")
    vf = f"scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1"
    try:
        proc = subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", src, "-vf", vf, "-c:v", "libx264", "-pix_fmt", "yuv420p",
                               "-c:a", "aac", "-movflags", "+faststart", out],
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout_sec, shell=False)
    except subprocess.TimeoutExpired:
        return {"state": "FAILED", "reason": "ffmpeg_timeout", "output": None}
    if proc.returncode != 0 or not os.path.isfile(out) or os.path.getsize(out) == 0:
        return {"state": "FAILED", "reason": "ffmpeg_error", "detail": (proc.stderr or "")[-200:], "output": None}
    try:
        pr = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height",
                             "-of", "json", out], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30, shell=False)
        st = _json.loads(pr.stdout)["streams"][0]
        ok = (str(st["width"]), str(st["height"])) == (w, h)
    except Exception:
        return {"state": "UNVERIFIED", "reason": "ffprobe_failed", "output": out}
    return {"state": "EXPORTED_VERIFIED" if ok else "FAILED", "output": out if ok else None,
            "measured": {"width": st["width"], "height": st["height"]}, "bytes": os.path.getsize(out)}
