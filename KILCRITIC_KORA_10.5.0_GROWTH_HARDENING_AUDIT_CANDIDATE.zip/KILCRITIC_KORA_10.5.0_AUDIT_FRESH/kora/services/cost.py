"""Cost governor: persistent, atomic reserve -> settle/release per day and per month (SQLite).

Counts operations (ai_calls, net_calls, ...), never spends money, never buys anything. At a cap `reserve` raises
BudgetExceeded; callers must stop (safe behaviour), not look for a way around the limit.
"""
import time
from typing import Dict, Optional

from kora.core.db import DEFAULT_DB_PATH, get_connection


class BudgetExceeded(Exception):
    def __init__(self, resource: str, period: str, limit: float):
        super().__init__(f"budget_exceeded:{resource}:{period}:{limit:g}")
        self.resource, self.period, self.limit = resource, period, limit


def parse_caps(spec: str) -> Dict[str, float]:
    caps: Dict[str, float] = {}
    for part in (spec or "").split(","):
        if "=" in part:
            k, v = part.split("=", 1)
            try:
                caps[k.strip()] = max(0.0, float(v))
            except ValueError:
                continue
    return caps


def _periods(now: float):
    t = time.gmtime(now)
    return time.strftime("d:%Y-%m-%d", t), time.strftime("m:%Y-%m", t)


def reserve(resource: str, amount: float, daily: Dict[str, float], monthly: Dict[str, float],
            db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> Dict[str, object]:
    if amount <= 0:
        raise ValueError("amount must be > 0")
    d, m = _periods(time.time() if now is None else now)
    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        for period, caps in ((d, daily), (m, monthly)):
            cap = caps.get(resource, 0)
            row = conn.execute("SELECT used, reserved FROM budget_usage WHERE period=? AND resource=?;", (period, resource)).fetchone()
            cur = (row["used"] + row["reserved"]) if row else 0.0
            if cap and cur + amount > cap:
                conn.execute("ROLLBACK;")
                raise BudgetExceeded(resource, period, cap)
        for period in (d, m):
            conn.execute("INSERT INTO budget_usage(period,resource,used,reserved) VALUES (?,?,0,?) "
                         "ON CONFLICT(period,resource) DO UPDATE SET reserved=reserved+excluded.reserved;", (period, resource, amount))
        conn.execute("COMMIT;")
    except BudgetExceeded:
        raise
    except Exception:
        try:
            conn.execute("ROLLBACK;")
        except Exception:
            pass
        raise
    finally:
        conn.close()
    return {"resource": resource, "reserved": amount, "periods": (d, m)}


def settle(reservation: Dict[str, object], actual: Optional[float] = None, db_path: str = DEFAULT_DB_PATH) -> None:
    """Move the reservation to 'used' (actual defaults to the reserved amount; 0 releases it entirely)."""
    res, amt = str(reservation["resource"]), float(reservation["reserved"])  # type: ignore[arg-type]
    used = amt if actual is None else max(0.0, float(actual))
    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        for period in reservation["periods"]:  # type: ignore[union-attr]
            conn.execute("UPDATE budget_usage SET reserved=MAX(0, reserved-?), used=used+? WHERE period=? AND resource=?;", (amt, used, period, res))
        conn.execute("COMMIT;")
    finally:
        conn.close()


def charge(resource: str, daily: Dict[str, float], monthly: Dict[str, float], db_path: str = DEFAULT_DB_PATH, amount: float = 1.0) -> None:
    """Reserve + settle in one step for a single operation about to run (raises BudgetExceeded at the cap)."""
    settle(reserve(resource, amount, daily, monthly, db_path), None, db_path)


def snapshot(daily: Dict[str, float], monthly: Dict[str, float], db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> Dict[str, object]:
    d, m = _periods(time.time() if now is None else now)
    conn = get_connection(db_path)
    try:
        rows = conn.execute("SELECT period,resource,used,reserved FROM budget_usage WHERE period IN (?,?);", (d, m)).fetchall()
    finally:
        conn.close()
    out: Dict[str, object] = {"day": d[2:], "month": m[2:], "usage": {}}
    for r in rows:
        caps = daily if r["period"] == d else monthly
        out["usage"].setdefault(r["resource"], {})["day" if r["period"] == d else "month"] = {  # type: ignore[union-attr]
            "used": r["used"], "reserved": r["reserved"], "cap": caps.get(r["resource"], 0) or None}
    out["caps"] = {"daily": daily, "monthly": monthly}
    return out
