"""Scheduled social autopilot.

One-time or recurring schedules are stored durably and handed to the existing social approval/publish + durable queue
engines. No direct platform call is made by the scheduler. Automatic approval is an explicit opt-in setting and is still
refused for any post whose preflight is not PASS/AUTO_FIXED.

Truthful states (a schedule row always mirrors what is really known about its post):
  SCHEDULED            waiting for its time
  WAITING_APPROVAL     due, post still needs a human decision (re-checked every tick)
  WAITING_CREDENTIALS  due + approved, but platform credentials/prerequisites are missing (re-checked every tick)
  QUEUED               handed to the durable queue (job exists)
  PUBLISHING           a worker is publishing right now
  PUBLISHED            platform returned an external id (no read-back verification is claimed)
  FAILED               the post failed / was dead-lettered, or the schedule could not be processed (last_error says why)
  PAUSED / CANCELLED   operator decisions

Every transition is written to the hash-chained audit log, so the table can be replayed and compared (replay_from_audit).
"""
import json
import time
import uuid
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from typing import Any, Dict, Optional, List

from kora.core.db import DEFAULT_DB_PATH, get_connection, record_audit
from kora.core.queue import DurableQueue
from kora.services import social

STATUSES = ("SCHEDULED", "WAITING_APPROVAL", "WAITING_CREDENTIALS", "QUEUED", "PUBLISHING", "PUBLISHED", "FAILED", "PAUSED", "CANCELLED")
FREQUENCIES = ("ONCE", "DAILY", "WEEKLY")
DEFAULT_RETRY_POLICY = {"max_attempts": 3, "backoff_s": 60}
CLAIM_STALE_SECONDS = 120.0
MAX_CALENDAR_ITEMS = 100

# Which operator action is legal from which state (state guards: an action never rewrites history).
_PAUSE_FROM = ("SCHEDULED", "WAITING_APPROVAL", "WAITING_CREDENTIALS")
_RESUME_FROM = ("PAUSED",)
_CANCEL_FROM = ("SCHEDULED", "WAITING_APPROVAL", "WAITING_CREDENTIALS", "PAUSED", "FAILED")
_EDIT_FROM = ("SCHEDULED", "WAITING_APPROVAL", "WAITING_CREDENTIALS", "PAUSED", "FAILED")


class ScheduleStateError(ValueError):
    """Raised when an action is not legal from the schedule's current state (API maps this to 409)."""


def _utc_epoch(when: str, tz_name: str) -> float:
    try:
        dt = datetime.fromisoformat(str(when).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=ZoneInfo(tz_name))
        else:
            dt = dt.astimezone(ZoneInfo(tz_name))
        return dt.astimezone(timezone.utc).timestamp()
    except Exception as exc:
        raise ValueError(f"invalid_schedule_time:{exc}")


def _transition(conn, sid: str, new: str, *, expect: Optional[tuple] = None, error: Optional[str] = None, extra: Optional[Dict[str, Any]] = None,
                db_path: str = DEFAULT_DB_PATH) -> bool:
    """Compare-and-set status change + audit event. Returns False when the row is not in an expected state."""
    row = conn.execute("SELECT status FROM autopilot_schedules WHERE id=?", (sid,)).fetchone()
    if not row or (expect is not None and row["status"] not in expect):
        return False
    sets, args = ["status=?", "updated_at=?", "last_error=?"], [new, time.time(), error]
    for k, v in (extra or {}).items():
        sets.append(f"{k}=?")
        args.append(v)
    q = f"UPDATE autopilot_schedules SET {', '.join(sets)} WHERE id=? AND status=?"
    n = conn.execute(q, (*args, sid, row["status"])).rowcount
    if n == 1:
        record_audit("autopilot_transition", "autopilot", {"schedule_id": sid, "from": row["status"], "to": new, "error": error}, db_path)
    return n == 1


def create_schedule(post_id: str, scheduled_for: str, timezone_name: str = "UTC", frequency: str = "ONCE",
                    db_path: str = DEFAULT_DB_PATH, retry_policy: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if frequency not in FREQUENCIES:
        raise ValueError("frequency_must_be_ONCE_DAILY_WEEKLY")
    try:
        ZoneInfo(timezone_name)
    except Exception:
        raise ValueError("invalid_timezone")
    post = social.get_post(post_id, db_path)
    if not post:
        raise ValueError("post_not_found")
    due = _utc_epoch(scheduled_for, timezone_name)
    if due <= time.time() and frequency == "ONCE":
        raise ValueError("scheduled_time_must_be_in_the_future")
    policy = _clean_policy(retry_policy)
    sid = "sched-" + uuid.uuid4().hex[:10]
    now = time.time()
    conn = get_connection(db_path)
    try:
        conn.execute("""INSERT INTO autopilot_schedules
            (id,post_id,scheduled_for_utc,timezone,frequency,status,created_at,updated_at,attempts,last_error,retry_policy,content_id,approval_state)
            VALUES (?,?,?,?,?,'SCHEDULED',?,?,0,NULL,?,?,?)""",
                     (sid, post_id, due, timezone_name, frequency, now, now, json.dumps(policy), post_id, post["status"]))
    finally:
        conn.close()
    record_audit("autopilot_schedule_created", "operator", {"schedule_id": sid, "post_id": post_id,
                    "scheduled_for": scheduled_for, "timezone": timezone_name, "frequency": frequency}, db_path)
    return get_schedule(sid, db_path)


def _clean_policy(p: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    out = dict(DEFAULT_RETRY_POLICY)
    if p:
        try:
            out["max_attempts"] = max(1, min(10, int(p.get("max_attempts", out["max_attempts"]))))
            out["backoff_s"] = max(0, min(86400, int(p.get("backoff_s", out["backoff_s"]))))
        except (TypeError, ValueError):
            raise ValueError("invalid_retry_policy")
    return out


def create_calendar(items: List[Dict[str, Any]], db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Bulk (e.g. 30-day) calendar. All-or-nothing validation first, so a bad row never leaves half a calendar behind."""
    if not isinstance(items, list) or not items or len(items) > MAX_CALENDAR_ITEMS:
        raise ValueError(f"calendar_needs_1_to_{MAX_CALENDAR_ITEMS}_items")
    planned = []
    for i, it in enumerate(items):
        if not isinstance(it, dict):
            raise ValueError(f"item_{i}_must_be_object")
        pid, when, tz = str(it.get("post_id", "")), str(it.get("scheduled_for", "")), str(it.get("timezone") or "UTC")
        freq = str(it.get("frequency") or "ONCE")
        if not social.get_post(pid, db_path):
            raise ValueError(f"item_{i}_post_not_found")
        try:
            ZoneInfo(tz)
        except Exception:
            raise ValueError(f"item_{i}_invalid_timezone")
        due = _utc_epoch(when, tz)
        if freq not in FREQUENCIES or (freq == "ONCE" and due <= time.time()):
            raise ValueError(f"item_{i}_invalid_frequency_or_time")
        _clean_policy(it.get("retry_policy"))
        planned.append((pid, when, tz, freq, it.get("retry_policy")))
    created = [create_schedule(pid, when, tz, freq, db_path, rp)["id"] for pid, when, tz, freq, rp in planned]
    return {"created": created, "count": len(created)}


def get_schedule(schedule_id: str, db_path: str = DEFAULT_DB_PATH) -> Optional[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        r = conn.execute("SELECT * FROM autopilot_schedules WHERE id=?", (schedule_id,)).fetchone()
        return dict(r) if r else None
    finally:
        conn.close()


def list_schedules(db_path: str = DEFAULT_DB_PATH, limit: int = 100) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        return [dict(r) for r in conn.execute("SELECT * FROM autopilot_schedules ORDER BY scheduled_for_utc ASC LIMIT ?", (max(1, min(500, limit)),)).fetchall()]
    finally:
        conn.close()


def set_status(schedule_id: str, status: str, db_path: str = DEFAULT_DB_PATH) -> bool:
    """Low-level setter kept for compatibility; operator actions use the guarded pause/resume/cancel below."""
    if status not in STATUSES:
        raise ValueError("invalid_schedule_status")
    conn = get_connection(db_path)
    try:
        return conn.execute("UPDATE autopilot_schedules SET status=?, updated_at=? WHERE id=?", (status, time.time(), schedule_id)).rowcount == 1
    finally:
        conn.close()


def _guarded(schedule_id: str, new: str, allowed: tuple, db_path: str) -> bool:
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT status FROM autopilot_schedules WHERE id=?", (schedule_id,)).fetchone()
        if not row:
            return False
        if row["status"] not in allowed:
            raise ScheduleStateError(f"cannot_{new.lower()}_from_{row['status']}")
        if not _transition(conn, schedule_id, new, expect=allowed, db_path=db_path):
            raise ScheduleStateError("state_changed_concurrently")
        return True
    finally:
        conn.close()


def cancel(schedule_id: str, db_path: str = DEFAULT_DB_PATH) -> bool:
    return _guarded(schedule_id, "CANCELLED", _CANCEL_FROM, db_path)


def pause(schedule_id: str, db_path: str = DEFAULT_DB_PATH) -> bool:
    return _guarded(schedule_id, "PAUSED", _PAUSE_FROM, db_path)


def resume(schedule_id: str, db_path: str = DEFAULT_DB_PATH) -> bool:
    return _guarded(schedule_id, "SCHEDULED", _RESUME_FROM, db_path)


def edit_schedule(schedule_id: str, scheduled_for: Optional[str] = None, timezone_name: Optional[str] = None,
                  frequency: Optional[str] = None, retry_policy: Optional[Dict[str, Any]] = None, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    cur = get_schedule(schedule_id, db_path)
    if not cur:
        raise KeyError("schedule_not_found")
    if cur["status"] not in _EDIT_FROM:
        raise ScheduleStateError(f"cannot_edit_from_{cur['status']}")
    tz = timezone_name or cur["timezone"]
    freq = frequency or cur["frequency"]
    if freq not in FREQUENCIES:
        raise ValueError("frequency_must_be_ONCE_DAILY_WEEKLY")
    try:
        ZoneInfo(tz)
    except Exception:
        raise ValueError("invalid_timezone")
    due = _utc_epoch(scheduled_for, tz) if scheduled_for else cur["scheduled_for_utc"]
    if freq == "ONCE" and due <= time.time():
        raise ValueError("scheduled_time_must_be_in_the_future")
    pol = json.dumps(_clean_policy(retry_policy)) if retry_policy else cur.get("retry_policy")
    conn = get_connection(db_path)
    try:
        n = conn.execute("UPDATE autopilot_schedules SET scheduled_for_utc=?, timezone=?, frequency=?, retry_policy=?, status='SCHEDULED', last_error=NULL, claimed_at=NULL, updated_at=? "
                         "WHERE id=? AND status IN (%s)" % ",".join("?" * len(_EDIT_FROM)), (due, tz, freq, pol, time.time(), schedule_id, *_EDIT_FROM)).rowcount
    finally:
        conn.close()
    if n != 1:
        raise ScheduleStateError("state_changed_concurrently")
    record_audit("autopilot_transition", "operator", {"schedule_id": schedule_id, "from": cur["status"], "to": "SCHEDULED", "error": None, "edit": True}, db_path)
    return get_schedule(schedule_id, db_path)


def retry(schedule_id: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Operator retry. Allowed only when it cannot create a duplicate post: the post must still be dispatchable."""
    cur = get_schedule(schedule_id, db_path)
    if not cur:
        raise KeyError("schedule_not_found")
    if cur["status"] not in ("FAILED", "WAITING_APPROVAL", "WAITING_CREDENTIALS"):
        raise ScheduleStateError(f"cannot_retry_from_{cur['status']}")
    post = social.get_post(cur["post_id"], db_path)
    if not post or post["status"] in ("PUBLISHED", "PUBLISHING", "FAILED", "REJECTED"):
        raise ScheduleStateError(f"not_retryable: post is {post['status'] if post else 'missing'}; create a new post instead (prevents duplicates)")
    conn = get_connection(db_path)
    try:
        _transition(conn, schedule_id, "SCHEDULED", expect=("FAILED", "WAITING_APPROVAL", "WAITING_CREDENTIALS"), extra={"claimed_at": None, "next_retry_at": None}, db_path=db_path)
    finally:
        conn.close()
    return get_schedule(schedule_id, db_path)


def _next_recurring(ts: float, frequency: str, now: Optional[float] = None) -> float:
    """Next occurrence strictly after `now` (never a burst of catch-up runs after downtime)."""
    from datetime import timedelta
    step = timedelta(days=1).total_seconds() if frequency == "DAILY" else timedelta(days=7).total_seconds()
    nxt = ts + step
    if now is not None and nxt <= now:
        nxt += step * (int((now - nxt) // step) + 1)
    return nxt


def recover_stale_claims(db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None, stale_seconds: float = CLAIM_STALE_SECONDS) -> List[str]:
    """Crash-after-claim recovery: a QUEUED row whose post has NO live job and whose claim is old goes back to SCHEDULED.
    The durable queue's idempotency key (social-publish:<post>) guarantees re-dispatch can never publish twice."""
    now = time.time() if now is None else now
    recovered = []
    conn = get_connection(db_path)
    try:
        rows = conn.execute("SELECT s.id, s.post_id, s.claimed_at, s.updated_at, p.job_id, p.status AS pstatus FROM autopilot_schedules s "
                            "LEFT JOIN social_posts p ON p.id=s.post_id WHERE s.status='QUEUED'").fetchall()
        for r in rows:
            claimed = r["claimed_at"] or r["updated_at"] or 0
            if now - claimed < stale_seconds:
                continue
            if r["pstatus"] in ("PUBLISHED", "PUBLISHING", "FAILED"):
                continue  # reconcile() reports these truthfully
            has_job = bool(r["job_id"]) and conn.execute("SELECT 1 FROM jobs WHERE id=? AND status IN ('QUEUED','RUNNING')", (r["job_id"],)).fetchone()
            if has_job:
                continue
            if _transition(conn, r["id"], "SCHEDULED", expect=("QUEUED",), error="recovered_after_interrupted_claim", extra={"claimed_at": None}, db_path=db_path):
                recovered.append(r["id"])
    finally:
        conn.close()
    return recovered


def reconcile(db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> List[Dict[str, Any]]:
    """Make QUEUED/PUBLISHING rows mirror the post's real state (PUBLISHED needs an external id; FAILED carries the reason)."""
    now = time.time() if now is None else now
    out = []
    conn = get_connection(db_path)
    try:
        rows = conn.execute("SELECT s.id, s.frequency, s.scheduled_for_utc, s.status, p.status AS pstatus, p.external_id, p.last_error "
                            "FROM autopilot_schedules s JOIN social_posts p ON p.id=s.post_id WHERE s.status IN ('QUEUED','PUBLISHING')").fetchall()
        for r in rows:
            new, err, extra = None, None, {}
            if r["pstatus"] == "PUBLISHED" and r["external_id"]:
                new, extra = "PUBLISHED", {"external_id": r["external_id"]}
            elif r["pstatus"] == "FAILED":
                new, err = "FAILED", (r["last_error"] or "post_failed")[:300]
            elif r["pstatus"] == "PUBLISHING":
                new = "PUBLISHING"
            elif r["pstatus"] == "APPROVED" and r["status"] == "PUBLISHING":
                new = "QUEUED"  # retryable error: the worker put it back for another attempt
            if new and new != r["status"] and _transition(conn, r["id"], new, expect=(r["status"],), error=err, extra=extra, db_path=db_path):
                out.append({"schedule_id": r["id"], "status": new})
                if new == "PUBLISHED" and r["frequency"] != "ONCE":
                    nxt = _next_recurring(r["scheduled_for_utc"], r["frequency"], now)
                    conn.execute("UPDATE autopilot_schedules SET scheduled_for_utc=?, status='SCHEDULED', claimed_at=NULL, updated_at=? WHERE id=?", (nxt, time.time(), r["id"]))
    finally:
        conn.close()
    return out


def process_due(db_path: str = DEFAULT_DB_PATH, queue: Optional[DurableQueue] = None, now: Optional[float] = None,
                auto_approve: bool = False, auto_publish: bool = True) -> List[Dict[str, Any]]:
    now = time.time() if now is None else now
    q = queue or DurableQueue(db_path)
    out: List[Dict[str, Any]] = []
    for sid in recover_stale_claims(db_path, now):
        out.append({"schedule_id": sid, "status": "SCHEDULED", "recovered": True})
    out.extend(reconcile(db_path, now))
    conn = get_connection(db_path)
    try:
        rows = conn.execute("SELECT * FROM autopilot_schedules WHERE status IN ('SCHEDULED','WAITING_APPROVAL','WAITING_CREDENTIALS') AND scheduled_for_utc<=? ORDER BY scheduled_for_utc", (now,)).fetchall()
    finally:
        conn.close()
    for row in rows:
        sid, pid, prev = row["id"], row["post_id"], row["status"]
        conn = get_connection(db_path)
        try:
            # compare-and-set claim: of any number of racing ticks/processes exactly one wins
            claimed = conn.execute("UPDATE autopilot_schedules SET status='QUEUED',updated_at=?,claimed_at=?,attempts=attempts+1,last_error=NULL "
                                   "WHERE id=? AND status=?", (now, now, sid, prev)).rowcount == 1
        finally:
            conn.close()
        if not claimed:
            continue
        record_audit("autopilot_transition", "autopilot", {"schedule_id": sid, "from": prev, "to": "QUEUED", "error": None, "claim": True}, db_path)
        try:
            out.append(_dispatch_one(sid, pid, row, q, db_path, now, auto_approve, auto_publish))
        except Exception as exc:  # never leave a claimed row dangling
            conn = get_connection(db_path)
            try:
                _transition(conn, sid, "FAILED", error=str(exc)[:500], db_path=db_path)
            finally:
                conn.close()
            record_audit("autopilot_schedule_failed", "autopilot", {"schedule_id": sid, "error": str(exc)[:300]}, db_path)
            out.append({"schedule_id": sid, "status": "FAILED", "error": str(exc)})
    return out


def _dispatch_one(sid: str, pid: str, row, q: DurableQueue, db_path: str, now: float, auto_approve: bool, auto_publish: bool) -> Dict[str, Any]:
    def park(state: str, reason: str, approval: str) -> Dict[str, Any]:
        conn = get_connection(db_path)
        try:
            _transition(conn, sid, state, expect=("QUEUED",), error=reason, extra={"claimed_at": None, "approval_state": approval}, db_path=db_path)
        finally:
            conn.close()
        return {"schedule_id": sid, "status": state, "reason": reason}

    post = social.get_post(pid, db_path)
    if not post:
        raise RuntimeError("post_not_found")
    st = post["status"]
    if st == "APPROVED_AWAITING_CREDENTIALS":
        st = social.recheck_credentials(pid, db_path)["status"]
        post = social.get_post(pid, db_path)
    if st == "PUBLISHED":
        result = {"status": "PUBLISHED", "post_id": pid, "external_id": post.get("external_id")}
    elif st == "APPROVED":
        owner = post.get("owner")
        if owner:
            apf = social.posting_preflight(owner, post["platform"], db_path)
            if not apf["ready"] and apf["reason"] in ("account_off", "needs_reconnect"):
                return park("WAITING_CREDENTIALS", f"account_unavailable:{apf['reason']}", "APPROVED")
        result = social.dispatch_post(pid, db_path, q)  # the schedule time itself is the operator's dispatch authorisation
    elif st == "APPROVED_AWAITING_CREDENTIALS":
        miss = social.missing_credentials_for(post["platform"])
        return park("WAITING_CREDENTIALS", "credentials_missing:" + ",".join(miss), "APPROVED")
    elif st == "PENDING_APPROVAL" and auto_approve:
        try:
            result = social.approve_and_publish_post(pid, db_path, actor="autopilot", queue=q, auto_publish=auto_publish)
        except social.SocialPublishError as exc:
            return park("WAITING_APPROVAL", str(exc)[:200], "PENDING_APPROVAL")
        if result.get("status") == "APPROVED_AWAITING_CREDENTIALS":
            return park("WAITING_CREDENTIALS", "credentials_missing", "APPROVED")
        if result.get("status") == "APPROVED":
            result = social.dispatch_post(pid, db_path, q)
    elif st == "PENDING_APPROVAL":
        return park("WAITING_APPROVAL", "approval_required", "PENDING_APPROVAL")
    else:  # REJECTED / FAILED / PUBLISHING etc.: report exactly that, never pretend
        conn = get_connection(db_path)
        try:
            _transition(conn, sid, "FAILED", expect=("QUEUED",), error=f"post_is_{st}", extra={"claimed_at": None}, db_path=db_path)
        finally:
            conn.close()
        return {"schedule_id": sid, "status": "FAILED", "reason": f"post_is_{st}"}

    new_status = "PUBLISHED" if result.get("status") == "PUBLISHED" or result.get("external_id") else "QUEUED"
    conn = get_connection(db_path)
    try:
        extra = {"external_id": result.get("external_id")} if new_status == "PUBLISHED" else {}
        extra["approval_state"] = "APPROVED"
        _transition(conn, sid, new_status, expect=("QUEUED",), extra=extra, db_path=db_path)
        if new_status == "PUBLISHED" and row["frequency"] != "ONCE":
            nxt = _next_recurring(row["scheduled_for_utc"], row["frequency"], now)
            conn.execute("UPDATE autopilot_schedules SET scheduled_for_utc=?, status='SCHEDULED', claimed_at=NULL, updated_at=? WHERE id=?", (nxt, time.time(), sid))
    finally:
        conn.close()
    return {"schedule_id": sid, "post_id": pid, "status": new_status, "result": result}


def replay_from_audit(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Deterministic replay: rebuild every schedule's status purely from the hash-chained audit events and compare with the table."""
    conn = get_connection(db_path)
    try:
        events = conn.execute("SELECT event_type, details FROM audit_events WHERE event_type IN ('autopilot_schedule_created','autopilot_transition') ORDER BY id").fetchall()
        table = {r["id"]: r["status"] for r in conn.execute("SELECT id,status FROM autopilot_schedules").fetchall()}
    finally:
        conn.close()
    rebuilt: Dict[str, str] = {}
    for e in events:
        d = json.loads(e["details"])
        sid = d.get("schedule_id")
        if not sid:
            continue
        rebuilt[sid] = "SCHEDULED" if e["event_type"] == "autopilot_schedule_created" else d.get("to", rebuilt.get(sid, "SCHEDULED"))
    mismatches = {sid: {"table": table.get(sid), "replayed": rebuilt.get(sid)} for sid in set(table) | set(rebuilt) if table.get(sid) != rebuilt.get(sid)}
    # Rows that pre-date audit transitions (e.g. migrated v6 rows) are reported as UNREPLAYABLE, not as agreement.
    unreplayable = sorted(sid for sid in table if sid not in rebuilt)
    return {"ok": not {k: v for k, v in mismatches.items() if k not in unreplayable}, "schedules": len(table), "replayed": len(rebuilt),
            "mismatches": {k: v for k, v in mismatches.items() if k not in unreplayable}, "unreplayable": unreplayable}
