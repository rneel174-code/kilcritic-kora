"""KORA GODFATHER META-ARCHITECTURE.

A coordination layer, not a replacement engine. It composes existing queue,
resource, trust, provider, policy and evolution capabilities without creating
another scheduler/queue/security system.

Design goals: better routing, measured resource adaptation, evidence-aware
planning, complexity control, and evidence-based refusal of low-value changes.
No production mutation is performed here.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from typing import Any, Dict, Iterable, Mapping, Optional

from kora.core.infinite_core import REACTOR
from kora.core.queue import DurableQueue
from kora.core.db import DEFAULT_DB_PATH
from kora.services import trust
from kora.supreme_runtime import AgentContract, SupremeRuntime


def _safe_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def evidence_hash(record: Mapping[str, Any]) -> str:
    """Stable hash for a proposal/evidence record; no blockchain claim."""
    return hashlib.sha256(_safe_json(dict(record)).encode("utf-8")).hexdigest()


def _resource_snapshot(db_path: str) -> Dict[str, Any]:
    q = DurableQueue(db_path).get_stats()
    return {
        "reactor": REACTOR.profile(),
        "queue": q,
        "cpu_count": os.cpu_count() or 1,
        "measured_at": time.time(),
    }


def _choose_mode(task: str, resource: Mapping[str, Any]) -> str:
    tier = resource["reactor"]["tier"]
    low_memory = tier == "LITE"
    risky_or_stateful = any(k in task.lower() for k in ("publish", "delete", "credential", "payment", "account", "deploy"))
    return "sequential" if low_memory or risky_or_stateful else "bounded_parallel"


def plan_goal(task: str, *, capabilities: Optional[Iterable[str]] = None,
              db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Build a safe execution plan from existing capabilities.

    This function plans only. It never publishes, modifies code, installs
    packages, changes credentials, or bypasses permissions.
    """
    task = (task or "").strip()
    if not task or len(task) > 2000:
        raise ValueError("task must be 1..2000 characters")

    try:
        from kora.core.worker import HANDLERS
        available = sorted(set(capabilities or HANDLERS.keys()))
    except Exception:
        available = sorted(set(capabilities or []))

    resource = _resource_snapshot(db_path)
    text = task.lower()
    required = []
    if any(x in text for x in ("research", "search", "trend", "source")):
        required.append("research")
    if any(x in text for x in ("video", "image", "media", "subtitle")):
        required.append("media")
    if any(x in text for x in ("youtube", "facebook", "instagram", "tiktok", "x.com", "social", "post", "publish")):
        required.append("social")
    if any(x in text for x in ("voice", "audio", "speak")):
        required.append("voice")
    if not required:
        required.append("general")

    mode = _choose_mode(text, resource)
    # Next-gen assurance is planning-only here; existing execution engines remain authoritative.
    runtime = SupremeRuntime()
    contract = AgentContract(
        contract_id=f"plan-{evidence_hash({"task": task})[:16]}",
        goal=task,
        allowed_actions=tuple(available),
        max_steps=50, max_seconds=900, max_cost=0.0,
    )
    assurance = runtime.preflight(contract, ["UNDERSTAND", "PLAN", "EXECUTE", "VERIFY"])
    side_effect = any(x in text for x in ("publish", "post", "send", "delete", "payment", "credential", "deploy", "account"))
    if side_effect:
        gate = "approval_and_existing_permission_gate"
    else:
        gate = "existing_permission_policy"

    pressure = "LOW"
    queued = sum(int(v or 0) for k, v in resource["queue"].items() if k in ("QUEUED", "RUNNING"))
    if queued >= 100:
        pressure = "HIGH"
    elif queued >= 25:
        pressure = "MEDIUM"

    return {
        "architecture": "GODFATHER_META_ORCHESTRATOR",
        "task": task,
        "capability_domains": sorted(set(required)),
        "available_handlers": available,
        "execution_mode": mode,
        "resource_pressure": pressure,
        "resource": resource,
        "side_effect_gate": gate,
        "pipeline": [
            "UNDERSTAND", "EXISTING_CAPABILITY_CHECK", "CAPABILITY_ROUTE",
            "RESOURCE_CHECK", "LEGAL_SAFETY_PLATFORM_PREFLIGHT",
            "EXECUTE_WITH_EXISTING_ENGINES", "VERIFY", "PROVENANCE",
            "CHECKPOINT", "LEARN"
        ],
        "constraints": [
            "reuse_existing_engines",
            "bounded_concurrency",
            "no_fake_capability_or_performance",
            "no_silent_production_mutation",
            "external_side_effects_require_existing_permission_and_approval",
        ],
        "supreme_runtime_assurance": assurance,
        "planned_only": True,
    }


def evolution_decision(*, benefit: float, risk: float, complexity: float,
                       measurable: bool, reversible: bool, duplicate: bool = False) -> Dict[str, Any]:
    """Evidence-based refusal/hold/propose gate for an evolution candidate."""
    vals = [float(benefit), float(risk), float(complexity)]
    if any(v < 0 or v > 100 for v in vals):
        raise ValueError("benefit/risk/complexity must be 0..100")
    if duplicate:
        decision = "REFUSE"
        reason = "existing capability already covers the candidate"
    elif not measurable or not reversible:
        decision = "HOLD"
        reason = "missing measurable evidence or rollback path"
    elif benefit <= (risk + complexity) * 0.6:
        decision = "REFUSE"
        reason = "expected value does not justify risk and complexity"
    else:
        decision = "PROPOSE"
        reason = "candidate has measurable value with a reversible path"
    return {"decision": decision, "reason": reason, "benefit": benefit,
            "risk": risk, "complexity": complexity, "measurable": measurable,
            "reversible": reversible, "duplicate": duplicate}


def capability_health(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Small truthful snapshot for the HUD/diagnostics layer."""
    from kora.core.worker import HANDLERS
    skills = trust.sync_skills(HANDLERS, db_path)
    suspicious = sorted(k for k, v in skills.items() if v == "SUSPICIOUS")
    return {
        "handler_count": len(HANDLERS),
        "suspicious_skills": suspicious,
        "resource": REACTOR.profile(),
        "safe_to_mutate": not bool(suspicious),
    }
