"""
KORA 8.8.5 - Subtitle Engine with Rigorous Duration Bounds & Font Validation
"""
import os
import subprocess
from typing import List, Dict, Any, Optional
from kora.services.media_pipeline import probe_media_duration, TEMP_DIR_ROOT, EXPORTS_DIR_ROOT

class SubtitleValidationError(Exception):
    pass

def validate_subtitle_cue(start: float, end: float, media_duration: float, text: str) -> None:
    if start < 0.0:
        raise SubtitleValidationError(f"Subtitle start time cannot be negative: {start}")
    if end <= start:
        raise SubtitleValidationError(f"Subtitle end time ({end}) must be strictly greater than start time ({start}).")
    if end > media_duration + 0.05:  # small tolerance for frame rounding
        raise SubtitleValidationError(
            f"Subtitle end time ({end:.2f}s) exceeds media duration ({media_duration:.2f}s). Impossible script duration."
        )
    if not text or not text.strip():
        raise SubtitleValidationError("Subtitle cue text cannot be empty.")

def generate_srt_file(cues: List[Dict[str, Any]], media_duration: float, output_path: str) -> str:
    """Generates and validates an SRT subtitle file against real media duration."""
    if not cues:
        raise SubtitleValidationError("Script contains no subtitle cues.")

    lines = []
    for idx, cue in enumerate(cues, 1):
        start = float(cue.get("start", 0))
        end = float(cue.get("end", 0))
        text = str(cue.get("text", "")).strip()

        validate_subtitle_cue(start, end, media_duration, text)

        # Format HH:MM:SS,mmm
        s_h, s_rem = divmod(start, 3600)
        s_m, s_s = divmod(s_rem, 60)
        s_ms = int((s_s - int(s_s)) * 1000)

        e_h, e_rem = divmod(end, 3600)
        e_m, e_s = divmod(e_rem, 60)
        e_ms = int((e_s - int(e_s)) * 1000)

        start_str = f"{int(s_h):02d}:{int(s_m):02d}:{int(s_s):02d},{s_ms:03d}"
        end_str = f"{int(e_h):02d}:{int(e_m):02d}:{int(e_s):02d},{e_ms:03d}"

        lines.append(f"{idx}\n{start_str} --> {end_str}\n{text}\n")

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    return output_path

def burn_subtitles(
    video_path: str,
    srt_path: str,
    output_filename: str,
    font_size: int = 24,
    timeout_sec: float = 60.0
) -> str:
    """Burns subtitles into video with font validation, safe path escaping, and non-zero output check."""
    if font_size < 10 or font_size > 72:
        raise SubtitleValidationError(f"Invalid font size: {font_size}. Allowed range: 10 to 72.")

    if not os.path.exists(video_path):
        raise SubtitleValidationError(f"Source video not found: {video_path}")
    if not os.path.exists(srt_path):
        raise SubtitleValidationError(f"SRT file not found: {srt_path}")

    duration = probe_media_duration(video_path)
    output_path = os.path.join(EXPORTS_DIR_ROOT, os.path.basename(output_filename))

    # Escape subtitle path for ffmpeg subtitles filter
    escaped_srt = srt_path.replace(":", "\\:").replace("'", "\\'")
    vf_filter = f"subtitles='{escaped_srt}':force_style='FontSize={font_size}'"

    cmd = [
        "ffmpeg",
        "-y",
        "-i", video_path,
        "-vf", vf_filter,
        "-c:a", "copy",
        output_path
    ]

    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout_sec,
            shell=False
        )
        if proc.returncode != 0 or not os.path.exists(output_path) or os.path.getsize(output_path) == 0:
            raise SubtitleValidationError(f"Subtitle burning failed: {proc.stderr.decode('utf-8', errors='ignore')}")
        return output_path
    except subprocess.TimeoutExpired:
        raise SubtitleValidationError("Subtitle rendering timed out.")
