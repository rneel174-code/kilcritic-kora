"""User DNA vault + Time Machine (SQLite, versioned).  Kinds: style, editing, hooks, audience, success_pattern (+ learn log).

* Every entry keeps value, source (explicit|learned), confidence, updated, corrections.
* Priority when resolving: explicit instruction in the current request > stored DNA > defaults. A LEARNED value never
  overwrites an EXPLICIT one. Safety/legal/platform rules are enforced elsewhere and are not DNA keys.
* Time Machine: every change is a new version; restore = preview (diff) then a NEW version copied from the old one.
* voice_face is NOT implemented (it would need real encryption + explicit consent) and is refused.
"""
import json
import re
import time
from typing import Any, Dict, List, Optional

from kora.core.db import DEFAULT_DB_PATH, get_connection, record_audit

KINDS = ("style", "editing", "hooks", "audience", "success_pattern")
_KEY = re.compile(r"^[A-Za-z0-9_.\-]{1,60}$")
MAX_KEYS, MAX_VALUE = 200, 2000
DAY = 86400


class DnaError(ValueError):
    pass


def _kind(kind: str) -> str:
    if kind == "voice_face":
        raise DnaError("voice_face is not implemented: it requires encryption and explicit consent")
    if kind not in KINDS:
        raise DnaError(f"kind must be one of {KINDS}")
    return kind


def _latest(conn, kind):
    r = conn.execute("SELECT version,data,created_at FROM dna_versions WHERE kind=? ORDER BY version DESC LIMIT 1;", (kind,)).fetchone()
    return (r["version"], json.loads(r["data"]), r["created_at"]) if r else (0, {}, 0.0)


def get(kind: str, db_path: str = DEFAULT_DB_PATH, version: Optional[int] = None) -> Dict[str, Any]:
    _kind(kind)
    conn = get_connection(db_path)
    try:
        if version is None:
            v, data, _ = _latest(conn, kind)
        else:
            r = conn.execute("SELECT data FROM dna_versions WHERE kind=? AND version=?;", (kind, version)).fetchone()
            if not r:
                raise DnaError("unknown version")
            v, data = version, json.loads(r["data"])
        return {"kind": kind, "version": v, "data": data}
    finally:
        conn.close()


def _write(conn, kind, data, actor, note, now) -> int:
    v, _, _ = _latest(conn, kind)
    conn.execute("INSERT INTO dna_versions(kind,version,data,actor,note,created_at) VALUES (?,?,?,?,?,?);", (kind, v + 1, json.dumps(data), actor, note[:200], now))
    return v + 1


def set_pref(kind: str, key: str, value: Any, *, source: str = "explicit", confidence: float = 1.0, actor: str = "owner",
             note: str = "", db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> Dict[str, Any]:
    _kind(kind)
    if not _KEY.match(key or ""):
        raise DnaError("invalid key")
    if source not in ("explicit", "learned"):
        raise DnaError("source must be explicit|learned")
    if len(json.dumps(value)) > MAX_VALUE:
        raise DnaError("value too large")
    now = time.time() if now is None else now
    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        v, data, _ = _latest(conn, kind)
        old = data.get(key)
        if old and old["source"] == "explicit" and source == "learned":
            conn.execute("ROLLBACK;")
            return {"kind": kind, "version": v, "skipped": "learned_value_never_overrides_explicit"}
        if key not in data and len(data) >= MAX_KEYS:
            conn.execute("ROLLBACK;")
            raise DnaError("too many keys")
        data[key] = {"value": value, "source": source, "confidence": max(0.0, min(1.0, float(confidence))), "updated": now,
                     "corrections": (old["corrections"] + 1) if old and old["value"] != value else (old["corrections"] if old else 0)}
        nv = _write(conn, kind, data, actor, note or f"set {key}", now)
        conn.execute("COMMIT;")
    except Exception:
        try:
            conn.execute("ROLLBACK;")
        except Exception:
            pass
        raise
    finally:
        conn.close()
    return {"kind": kind, "version": nv}


def history(kind: str, db_path: str = DEFAULT_DB_PATH) -> List[Dict[str, Any]]:
    _kind(kind)
    conn = get_connection(db_path)
    try:
        return [{"version": r["version"], "actor": r["actor"], "note": r["note"], "created_at": r["created_at"], "keys": len(json.loads(r["data"]))}
                for r in conn.execute("SELECT * FROM dna_versions WHERE kind=? ORDER BY version DESC LIMIT 200;", (kind,)).fetchall()]
    finally:
        conn.close()


def _diff(a: Dict[str, Any], b: Dict[str, Any]) -> Dict[str, Any]:
    return {"added": sorted(set(b) - set(a)), "removed": sorted(set(a) - set(b)),
            "changed": {k: [a[k]["value"], b[k]["value"]] for k in a if k in b and a[k]["value"] != b[k]["value"]}}


def diff(kind: str, a: int, b: int, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    return {"kind": kind, "from": a, "to": b, **_diff(get(kind, db_path, a)["data"], get(kind, db_path, b)["data"])}


def restore(kind: str, version: int, actor: str = "owner", db_path: str = DEFAULT_DB_PATH, confirm: bool = False,
            now: Optional[float] = None) -> Dict[str, Any]:
    cur, tgt = get(kind, db_path), get(kind, db_path, version)
    preview = {"kind": kind, "current_version": cur["version"], "restore_version": version, **_diff(cur["data"], tgt["data"])}
    if not confirm:
        return {"status": "PREVIEW", **preview}
    now = time.time() if now is None else now
    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        nv = _write(conn, kind, tgt["data"], actor, f"restore of v{version}", now)
        conn.execute("COMMIT;")
    finally:
        conn.close()
    record_audit("dna_restore", actor, {"kind": kind, "from": cur["version"], "restored": version, "new": nv}, db_path)
    return {"status": "RESTORED", "new_version": nv, **preview}


def version_at(kind: str, ts: float, db_path: str = DEFAULT_DB_PATH) -> int:
    _kind(kind)
    conn = get_connection(db_path)
    try:
        r = conn.execute("SELECT MAX(version) m FROM dna_versions WHERE kind=? AND created_at<=?;", (kind, ts)).fetchone()
        return r["m"] or 0
    finally:
        conn.close()


def yesterday(kind: str, db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> Dict[str, Any]:
    """'Kal wali yaad te wapas ja' - PREVIEW of the state 24h ago; the caller must confirm with restore(..., confirm=True)."""
    now = time.time() if now is None else now
    v = version_at(kind, now - DAY, db_path)
    if v == 0:
        return {"status": "NOTHING_TO_RESTORE", "reason": "no version existed 24h ago"}
    return restore(kind, v, db_path=db_path, confirm=False)


def resolve(kind: str, explicit: Optional[Dict[str, Any]] = None, defaults: Optional[Dict[str, Any]] = None,
            db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    out: Dict[str, Any] = {k: {"value": v, "from": "default"} for k, v in (defaults or {}).items()}
    for k, e in get(kind, db_path)["data"].items():
        out[k] = {"value": e["value"], "from": f"dna:{e['source']}", "confidence": e["confidence"]}
    for k, v in (explicit or {}).items():
        out[k] = {"value": v, "from": "explicit_request"}
    return out


def stale(kind: str, db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None, max_age_days: int = 90, min_conf: float = 0.4) -> List[str]:
    now = time.time() if now is None else now
    return sorted(k for k, e in get(kind, db_path)["data"].items()
                  if e["source"] == "learned" and (now - e["updated"] > max_age_days * DAY or e["confidence"] < min_conf))


def learn(task: str, outcome: str, correction: str = "", preference: str = "", source: str = "result", confidence: float = 0.5,
          db_path: str = DEFAULT_DB_PATH) -> None:
    conn = get_connection(db_path)
    try:
        conn.execute("INSERT INTO dna_learn(task,outcome,correction,preference,source,confidence,created_at) VALUES (?,?,?,?,?,?,?);",
                     (task[:300], outcome[:300], correction[:300], preference[:300], source[:60], max(0.0, min(1.0, float(confidence))), time.time()))
    finally:
        conn.close()


def learn_log(db_path: str = DEFAULT_DB_PATH, limit: int = 50) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        return [dict(r) for r in conn.execute("SELECT * FROM dna_learn ORDER BY id DESC LIMIT ?;", (max(1, min(500, limit)),)).fetchall()]
    finally:
        conn.close()


# ----------------------------------------------------------------------------- evidence-gated learning (one odd result never changes DNA)
LEARN_MIN_COUNT, LEARN_MIN_SHARE = 3, 0.7


def observe(kind: str, key: str, value: Any, db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None,
            min_count: int = LEARN_MIN_COUNT, min_share: float = LEARN_MIN_SHARE) -> Dict[str, Any]:
    """Record one observation. DNA changes only when the same value was seen >= min_count times AND makes up >= min_share of all
    observations of that key (so a single unusual result, or a split signal, changes nothing). Learned values never override explicit ones."""
    _kind(kind)
    if not _KEY.match(key or ""):
        raise DnaError("invalid key")
    val = json.dumps(value, sort_keys=True)
    if len(val) > MAX_VALUE:
        raise DnaError("value too large")
    now = time.time() if now is None else now
    okey = f"{kind}.{key}"
    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        conn.execute("INSERT INTO dna_observations(key,value,count,first_at,last_at) VALUES (?,?,1,?,?) "
                     "ON CONFLICT(key,value) DO UPDATE SET count=count+1, last_at=excluded.last_at;", (okey, val, now, now))
        rows = conn.execute("SELECT value,count FROM dna_observations WHERE key=?;", (okey,)).fetchall()
        conn.execute("COMMIT;")
    finally:
        conn.close()
    total = sum(r["count"] for r in rows)
    top = max(rows, key=lambda r: r["count"])
    share = top["count"] / total
    if top["count"] < min_count or share < min_share:
        return {"status": "OBSERVING", "observations": total, "top_share": round(share, 2), "needed": f">={min_count} and >={int(min_share * 100)}%"}
    topv = json.loads(top["value"])
    cur = get(kind, db_path)["data"].get(key)
    if cur and cur["value"] == topv:
        return {"status": "ALREADY_LEARNED", "observations": total}
    conf = round(min(0.9, 0.4 + 0.1 * top["count"] * share), 2)
    r = set_pref(kind, key, topv, source="learned", confidence=conf, actor="learning", note=f"learned:{key}", db_path=db_path, now=now)
    if r.get("skipped"):
        return {"status": "SKIPPED_EXPLICIT_WINS", "observations": total}
    return {"status": "LEARNED", "version": r["version"], "confidence": conf, "evidence": {"count": top["count"], "of": total}}


def rollback_learned(kind: str, db_path: str = DEFAULT_DB_PATH, confirm: bool = False, actor: str = "owner") -> Dict[str, Any]:
    """Undo the latest automatic learning step: preview first, then a NEW version restored from the one before it."""
    _kind(kind)
    h = history(kind, db_path)  # newest first
    if len(h) >= 2 and str(h[0].get("note", "")).startswith("learned:"):
        return {**restore(kind, h[1]["version"], actor=actor, db_path=db_path, confirm=confirm), "undoes": h[0]["version"]}
    if any(str(v.get("note", "")).startswith("learned:") for v in h):
        return {"status": "LATER_CHANGES_EXIST", "note": "a newer non-learning change exists; use the Time Machine restore preview so it is not lost"}
    return {"status": "NOTHING_TO_ROLL_BACK"}
