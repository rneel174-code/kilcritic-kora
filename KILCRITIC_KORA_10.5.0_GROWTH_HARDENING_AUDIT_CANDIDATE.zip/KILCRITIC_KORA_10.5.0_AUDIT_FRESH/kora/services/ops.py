"""Operations: measured resources, data lifecycle, feature flags, notifications, export/delete, safe migration."""
import json
import os
import shutil
import sqlite3
import time
import zipfile
from typing import Any, Dict, List, Optional

from kora.core.db import DEFAULT_DB_PATH, get_connection, get_setting, init_db, record_audit, set_setting

DAY = 86400


# ----------------------------------------------------------------------------- measured resources (no fake scores)
def resources(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    import resource as _r
    out: Dict[str, Any] = {"measured_at": time.time()}
    ru = _r.getrusage(_r.RUSAGE_SELF)
    out["process_max_rss_mb"] = round(ru.ru_maxrss / 1024, 1)  # Linux reports KiB
    out["cpu_seconds"] = round(ru.ru_utime + ru.ru_stime, 2)
    try:
        from kora.services.android_compat import load_avg_1m
        out["load_avg_1m"] = load_avg_1m()
    except Exception:
        out["load_avg_1m"] = None
    d = os.path.dirname(os.path.abspath(db_path))
    du = shutil.disk_usage(d)
    out["disk_free_mb"], out["disk_total_mb"] = du.free // 2**20, du.total // 2**20
    out["db_size_mb"] = round(os.path.getsize(db_path) / 2**20, 2) if os.path.exists(db_path) else 0
    return out


# ----------------------------------------------------------------------------- data lifecycle (protected data is never touched)
RETENTION = {"checkpoints": 30, "budget_usage": 400, "proposals_done": 90, "dna_learn": 365, "shadow_files": 7}


def lifecycle(db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> Dict[str, int]:
    """Archive/delete only disposable data: old checkpoints, finished proposals, old usage rows, stale shadow clones."""
    now = time.time() if now is None else now
    n: Dict[str, int] = {}
    conn = get_connection(db_path)
    try:
        n["checkpoints"] = conn.execute("DELETE FROM checkpoints WHERE updated_at < ?;", (now - RETENTION["checkpoints"] * DAY,)).rowcount
        n["proposals_done"] = conn.execute("DELETE FROM proposals WHERE status IN ('EXECUTED','FAILED','REJECTED') AND created_at < ?;", (now - RETENTION["proposals_done"] * DAY,)).rowcount
        n["dna_learn"] = conn.execute("DELETE FROM dna_learn WHERE created_at < ?;", (now - RETENTION["dna_learn"] * DAY,)).rowcount
        cutoff = time.strftime("%Y-%m", time.gmtime(now - RETENTION["budget_usage"] * DAY))
        n["budget_usage"] = conn.execute("DELETE FROM budget_usage WHERE (period LIKE 'm:%' AND substr(period,3) < ?) OR (period LIKE 'd:%' AND substr(period,3,7) < ?);", (cutoff, cutoff)).rowcount
    finally:
        conn.close()
    sd = os.path.join(os.path.dirname(os.path.abspath(db_path)), "shadow")
    n["shadow_files"] = 0
    if os.path.isdir(sd):
        for f in os.listdir(sd):
            p = os.path.join(sd, f)
            if f.endswith(".db") and os.path.isfile(p) and now - os.path.getmtime(p) > RETENTION["shadow_files"] * DAY:
                os.remove(p)
                n["shadow_files"] += 1
    return n


# ----------------------------------------------------------------------------- adaptive environment profile
ENV_PROFILES = ("EARTH", "OCEAN", "SKY", "SPACE", "REGION")

def environment_get(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    profile = get_setting("environment_profile", "EARTH", db_path)
    if profile not in ENV_PROFILES:
        profile = "EARTH"
    return {"profile": profile, "available": list(ENV_PROFILES), "source": "owner_setting"}

def environment_set(profile: str, actor: str = "owner", db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    p = (profile or "").strip().upper()
    if p not in ENV_PROFILES:
        raise ValueError("profile must be EARTH|OCEAN|SKY|SPACE|REGION")
    set_setting("environment_profile", p, db_path)
    record_audit("environment_profile_set", actor, {"profile": p}, db_path)
    return environment_get(db_path)

# ----------------------------------------------------------------------------- feature flags (experimental = OFF by default)
FLAGS = {"experimental_voice": False, "experimental_trends": False, "shadow_publish_required": True,
         "voice_session_trust": False}  # True: voice sent from an authenticated owner session is treated as the owner (NOT biometric speaker ID)


def flag_get(name: str, db_path: str = DEFAULT_DB_PATH) -> bool:
    if name not in FLAGS:
        raise KeyError("unknown flag")
    v = get_setting("flag:" + name, None, db_path)
    return FLAGS[name] if v is None else v == "1"


def flag_set(name: str, value: bool, actor: str = "owner", db_path: str = DEFAULT_DB_PATH) -> None:
    if name not in FLAGS:
        raise KeyError("unknown flag")
    set_setting("flag:" + name, "1" if value else "0", db_path)
    record_audit("flag_set", actor, {"flag": name, "value": value}, db_path)


def flags(db_path: str = DEFAULT_DB_PATH) -> Dict[str, bool]:
    return {k: flag_get(k, db_path) for k in FLAGS}


# ----------------------------------------------------------------------------- notifications: grouped, non-spammy
LEVELS = ("CRITICAL", "IMPORTANT", "NORMAL", "BACKGROUND")


def notify(level: str, key: str, message: str, db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> Dict[str, Any]:
    """Same (level,key) within 1h is GROUPED into one entry with a count instead of a new notification."""
    if level not in LEVELS:
        raise ValueError("bad level")
    now = time.time() if now is None else now
    raw = get_setting("notifications", "[]", db_path)
    items: List[Dict[str, Any]] = json.loads(raw or "[]")
    for it in items:
        if it["level"] == level and it["key"] == key and now - it["last"] < 3600:
            it["count"] += 1
            it["last"] = now
            break
    else:
        items.append({"level": level, "key": key, "message": message[:200], "count": 1, "first": now, "last": now})
    items = sorted(items, key=lambda i: (LEVELS.index(i["level"]), -i["last"]))[:100]
    set_setting("notifications", json.dumps(items), db_path)
    return {"grouped": any(i["key"] == key and i["count"] > 1 for i in items)}


def notifications(db_path: str = DEFAULT_DB_PATH) -> List[Dict[str, Any]]:
    return json.loads(get_setting("notifications", "[]", db_path) or "[]")


# ----------------------------------------------------------------------------- export / controlled deletion
EXPORT_TABLES = ("social_posts", "rag_docs", "dna_versions", "dna_learn", "missions", "cron_jobs", "ledger", "proposals", "provenance", "trust", "settings")
SECRET_SETTING_PREFIXES = ("owner_totp", "kill_switch")


def export_zip(db_path: str, out_path: str) -> Dict[str, Any]:
    """One-click export: JSON per table inside a ZIP. Secrets (TOTP secret) and token hashes are never exported."""
    conn = get_connection(db_path)
    counts: Dict[str, int] = {}
    try:
        with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
            for t in EXPORT_TABLES:
                try:
                    rows = [dict(r) for r in conn.execute(f"SELECT * FROM {t};").fetchall()]
                except sqlite3.OperationalError:
                    continue
                if t == "settings":
                    rows = [r for r in rows if not r["key"].startswith(SECRET_SETTING_PREFIXES)]
                counts[t] = len(rows)
                z.writestr(f"{t}.json", json.dumps(rows, indent=1, default=str))
            z.writestr("MANIFEST.json", json.dumps({"exported_at": time.time(), "tables": counts, "excluded": ["secrets", "principal token hashes", "audit chain"]}, indent=1))
    finally:
        conn.close()
    record_audit("data_export", "owner", {"tables": counts}, db_path)
    return {"path": out_path, "tables": counts}


DELETE_TABLES = ("social_posts", "rag_chunks", "rag_docs", "dna_versions", "dna_learn", "missions", "ledger", "provenance", "checkpoints", "proposals")


def delete_user_data(db_path: str, confirm_phrase: str, actor: str = "owner") -> Dict[str, Any]:
    """'MERA DATA DELETE KAR': deletes user content tables in the LIVE database and writes a proof record to the audit chain.
    Does NOT touch existing backup files/snapshots (listed in the result: they must be deleted separately) and does not claim to."""
    if confirm_phrase != "MERA DATA DELETE KAR":
        return {"status": "CONFIRMATION_REQUIRED", "phrase": "MERA DATA DELETE KAR"}
    conn = get_connection(db_path)
    deleted: Dict[str, int] = {}
    try:
        conn.execute("BEGIN IMMEDIATE;")
        for t in DELETE_TABLES:
            deleted[t] = conn.execute(f"DELETE FROM {t};").rowcount
        conn.execute("COMMIT;")
        backups = [r["filename"] for r in conn.execute("SELECT filename FROM backups;").fetchall()]
    except Exception:
        conn.execute("ROLLBACK;")
        raise
    finally:
        conn.close()
    record_audit("user_data_deleted", actor, {"rows_deleted": deleted}, db_path)
    return {"status": "DELETED_FROM_LIVE_DB", "rows_deleted": deleted, "not_deleted": {"backups_still_containing_data": backups, "audit_log": "kept as deletion proof (no content)"},
            "note": "backups and copies outside the live database are NOT deleted by this action"}


# ----------------------------------------------------------------------------- safe migration
def migrate_safely(db_path: str, migrate=init_db) -> Dict[str, Any]:
    """VERSION -> BACKUP -> VALIDATE -> TRANSACTION -> MIGRATE -> VERIFY -> COMMIT; restore the backup copy on failure."""
    if not os.path.exists(db_path):
        migrate(db_path)
        return {"status": "CREATED"}
    backup = f"{db_path}.pre-migrate-{int(time.time())}"
    src = sqlite3.connect(db_path)
    dst = sqlite3.connect(backup)
    try:
        if src.execute("PRAGMA integrity_check;").fetchone()[0] != "ok":
            return {"status": "REFUSED", "reason": "integrity_check_failed_before_migration"}
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    try:
        migrate(db_path)
        c = sqlite3.connect(db_path)
        try:
            ok = c.execute("PRAGMA integrity_check;").fetchone()[0] == "ok"
        finally:
            c.close()
        if not ok:
            raise RuntimeError("post-migration integrity_check failed")
        return {"status": "MIGRATED", "backup": backup}
    except Exception as exc:  # noqa: BLE001
        for ext in ("-wal", "-shm"):
            if os.path.exists(db_path + ext):
                os.remove(db_path + ext)
        shutil.copyfile(backup, db_path)
        return {"status": "ROLLED_BACK", "error": str(exc)[:200], "backup": backup}


# ----------------------------------------------------------------------------- adaptive resource pressure (P0-P4)
PRESSURE_LOAD_PER_CPU = (0.9, 1.5)   # (elevated, critical) 1-minute load per CPU
PRESSURE_DISK_FREE_MB = (1024, 256)  # (elevated, critical) free disk


def pressure_level(db_path: str = DEFAULT_DB_PATH, snapshot: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Real measurements only. NORMAL / ELEVATED / CRITICAL; a metric that cannot be read is listed in `unknown`, never assumed fine."""
    r = snapshot or resources(db_path)
    reasons, unknown, level = [], [], 0
    load = r.get("load_avg_1m")
    if load is None:
        unknown.append("load_avg")
    else:
        per = load / max(1, os.cpu_count() or 1)
        if per >= PRESSURE_LOAD_PER_CPU[1]:
            level, reasons = 2, reasons + [f"cpu_load {per:.2f}/cpu"]
        elif per >= PRESSURE_LOAD_PER_CPU[0]:
            level, reasons = max(level, 1), reasons + [f"cpu_load {per:.2f}/cpu"]
    free = r.get("disk_free_mb")
    if free is not None:
        if free <= PRESSURE_DISK_FREE_MB[1]:
            level, reasons = 2, reasons + [f"disk_free {free}MB"]
        elif free <= PRESSURE_DISK_FREE_MB[0]:
            level, reasons = max(level, 1), reasons + [f"disk_free {free}MB"]
    return {"level": ("NORMAL", "ELEVATED", "CRITICAL")[level], "reasons": reasons, "unknown": unknown}


def apply_pressure(db_path: str = DEFAULT_DB_PATH, snapshot: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Pause the lowest tiers first: ELEVATED pauses P4 (background), CRITICAL pauses P4+P3. Jobs stay queued and resume
    automatically when pressure drops; P0-P2 (user-facing, safety) are never paused by this."""
    from kora.core.queue import DurableQueue, P3, P4  # noqa: F401
    q = DurableQueue(db_path)
    pl = pressure_level(db_path, snapshot)
    floor = {"NORMAL": 0, "ELEVATED": P3, "CRITICAL": P3 + 1}[pl["level"]]  # floor above P3 pauses tiers below P2
    if floor != q.priority_floor():
        q.set_priority_floor(floor)
        record_audit("pressure_floor", "system", {"level": pl["level"], "floor": floor, "reasons": pl["reasons"]}, db_path)
    return {**pl, "priority_floor": floor, "paused_tiers": {0: [], P3: ["P4"], P3 + 1: ["P4", "P3"]}[floor]}


# ----------------------------------------------------------------------------- honest health: GOOD / ATTENTION / BLOCKED / OFFLINE / UNKNOWN
def health(db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> Dict[str, Any]:
    """Each domain is actually checked; if a check cannot run the domain is UNKNOWN, never GOOD."""
    from kora.core import policy
    from kora.core.queue import DurableQueue
    now = time.time() if now is None else now
    dom: Dict[str, Dict[str, Any]] = {}

    def put(name: str, fn) -> None:
        try:
            state, detail = fn()
        except Exception as exc:  # noqa: BLE001
            state, detail = "UNKNOWN", f"check failed: {str(exc)[:100]}"
        dom[name] = {"state": state, "detail": detail}

    def system():
        pl = pressure_level(db_path)
        return ({"NORMAL": "GOOD", "ELEVATED": "ATTENTION", "CRITICAL": "BLOCKED"}[pl["level"]],
                ", ".join(pl["reasons"]) or ("measured; unknown: " + ",".join(pl["unknown"]) if pl["unknown"] else "measured"))

    def security():
        ch = verify_chain(db_path)
        if not ch["ok"]:
            return "BLOCKED", f"audit chain broken ({ch.get('reason')})"
        return ("ATTENTION", "safe mode is ON") if policy.is_safe_mode(db_path) else ("GOOD", f"audit chain intact ({ch['checked']} rows)")

    def tasks():
        q = DurableQueue(db_path)
        st = q.get_stats()
        froz = get_connection(db_path)
        try:
            n_frozen = froz.execute("SELECT COUNT(*) c FROM settings WHERE key LIKE 'frozen:%' AND value='1';").fetchone()["c"]
        finally:
            froz.close()
        if st["kill_switch"]:
            return "BLOCKED", "kill switch is ON"
        bad = st["DEAD_LETTER"] + n_frozen + len(q.blocked_by_dependency())
        return ("ATTENTION", f"{st['DEAD_LETTER']} dead-lettered, {n_frozen} frozen, blocked-by-dependency {len(q.blocked_by_dependency())}") if bad else ("GOOD", f"{st['QUEUED']} queued, {st['RUNNING']} running")

    def providers():
        from kora.services.ai_failover import provider_states
        ps = [p for p in provider_states() if p["provider"] != "local_deterministic_fallback"]
        if any(p["state"] == "HEALTHY" for p in ps):
            return "GOOD", "at least one provider has a recent real success"
        if any(p["state"] in ("FAILED", "RATE_LIMITED") for p in ps):
            return "ATTENTION", "configured providers are failing; local rule engine is the fallback"
        if any(p["state"] == "CONFIGURED" for p in ps):
            return "UNKNOWN", "keys configured but no real call has been made yet"
        return "OFFLINE", "no provider key configured; local rule engine only"

    def storage():
        r = resources(db_path)
        pl = pressure_level(db_path, r)
        free = r["disk_free_mb"]
        return ({"NORMAL": "GOOD", "ELEVATED": "ATTENTION", "CRITICAL": "BLOCKED"}[pl["level"]] if free <= PRESSURE_DISK_FREE_MB[0] else "GOOD", f"{free} MB free")

    def backup():
        from kora.services import atma
        pts = atma.list_restore_points(db_path, 1)
        if not pts:
            return "ATTENTION", "no backup exists yet"
        age_d = (now - pts[0]["created_at"]) / DAY
        if not pts[0]["integrity_verified"]:
            return "ATTENTION", "latest backup is not integrity-verified"
        return ("GOOD", f"latest verified backup {age_d:.1f} days old") if age_d <= 7 else ("ATTENTION", f"latest backup is {age_d:.0f} days old")

    def dna():
        from kora.services import dna as d
        stale = sum(len(d.stale(k, db_path, now)) for k in d.KINDS)
        return ("ATTENTION", f"{stale} stale/low-confidence learned entries") if stale else ("GOOD", "no stale learned entries")

    def accounts():
        c = get_connection(db_path)
        try:
            rows = c.execute("SELECT status, COUNT(*) n FROM accounts GROUP BY status;").fetchall()
        finally:
            c.close()
        cnt = {r["status"]: r["n"] for r in rows}
        if not cnt:
            return "UNKNOWN", "no accounts registered; connection state not checked"
        if cnt.get("NEEDS_RECONNECT"):
            return "ATTENTION", f"{cnt['NEEDS_RECONNECT']} account(s) need reconnecting"
        return ("GOOD", f"{cnt.get('ON', 0)} on") if cnt.get("ON") else ("ATTENTION", "all registered accounts are OFF")

    def missions():
        c = get_connection(db_path)
        try:
            rows = c.execute("SELECT status, updated_at FROM missions WHERE status='ACTIVE';").fetchall()
        finally:
            c.close()
        if not rows:
            return "UNKNOWN", "no active mission"
        stale = [r for r in rows if now - r["updated_at"] > 14 * DAY]
        return ("ATTENTION", f"{len(stale)} active mission(s) without progress for 14+ days") if stale else ("GOOD", f"{len(rows)} active, progressing")

    for n, f in (("SYSTEM", system), ("SECURITY", security), ("TASKS", tasks), ("PROVIDERS", providers), ("STORAGE", storage),
                 ("BACKUP", backup), ("DNA", dna), ("ACCOUNTS", accounts), ("MISSIONS", missions)):
        put(n, f)
    order = ["BLOCKED", "OFFLINE", "ATTENTION", "UNKNOWN", "GOOD"]
    overall = min((d["state"] for d in dom.values()), key=order.index)
    return {"overall": overall, "domains": dom, "checked_at": now,
            "note": "GOOD is only reported for domains that were actually measured; UNKNOWN means not checked"}


def verify_chain(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    from kora.core.db import verify_audit_chain
    return verify_audit_chain(db_path)


# ----------------------------------------------------------------------------- connectivity (honest: ONLINE / OFFLINE / UNKNOWN)
_net_cache: Dict[str, Any] = {"t": 0.0, "v": None}


def network_state(probe=None, cache_seconds: float = 20.0, now: Optional[float] = None) -> Dict[str, Any]:
    """TCP connect to the configured proxy (if any) or KORA_NET_PROBE (host:port, default 1.1.1.1:443). Result is cached briefly.
    OFFLINE only when the connection actually failed; a probe that could not run is UNKNOWN. Never used to fake fresh information."""
    import socket
    import urllib.parse as up
    t = time.time() if now is None else now
    if probe is None and _net_cache["v"] is not None and t - _net_cache["t"] < cache_seconds:
        return _net_cache["v"]
    target = os.environ.get("KORA_NET_PROBE", "")
    via = "probe"
    if not target:
        px = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy") or ""
        if px:
            u = up.urlparse(px if "://" in px else "http://" + px)
            target, via = f"{u.hostname}:{u.port or 3128}", "proxy"
        else:
            target, via = "1.1.1.1:443", "direct"
    try:
        host, port = target.rsplit(":", 1)
        ok = bool(probe()) if probe else bool(socket.create_connection((host, int(port)), timeout=1.5).close() or True)
        res = {"state": "ONLINE" if ok else "OFFLINE", "via": via}
    except OSError:
        res = {"state": "OFFLINE", "via": via}
    except Exception:  # noqa: BLE001
        res = {"state": "UNKNOWN", "via": via}
    if probe is None:
        _net_cache.update(t=t, v=res)
    return res


# ----------------------------------------------------------------------------- failure prediction (pre-flight; a fallback is a plan, never a result)
def predict_failure(kind: str, params: Optional[Dict[str, Any]] = None, db_path: str = DEFAULT_DB_PATH,
                    env: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    from kora.core import policy
    env = os.environ if env is None else env
    params = params or {}
    risks: List[Dict[str, str]] = []

    def add(reason: str, fallback: str, level: str = "MEDIUM") -> None:
        risks.append({"reason": reason, "planned_fallback": fallback, "level": level})
    if policy.is_safe_mode(db_path):
        add("safe_mode_on", "external actions will be refused; drafts only", "HIGH")
    pl = pressure_level(db_path)
    if pl["level"] != "NORMAL":
        add("resource_pressure:" + pl["level"], "background work is paused until pressure drops", "MEDIUM" if pl["level"] == "ELEVATED" else "HIGH")
    try:
        from kora.core.queue import DurableQueue
        st = DurableQueue(db_path).get_stats()
        if st["capacity"] and (st["QUEUED"] + st["RUNNING"]) >= 0.8 * st["capacity"]:
            add("queue_near_capacity", "new work waits; low tiers stay paused", "HIGH")
        if st["DEAD_LETTER"] >= 5:
            add("many_dead_letters", "review the dead-letter queue before adding similar work", "MEDIUM")
    except Exception:  # noqa: BLE001 - prediction must never crash the caller
        pass
    if kind in ("ai", "research", "publish", "evolution"):
        if network_state()["state"] == "OFFLINE":
            add("offline", "network steps are queued and resume after reconnect; no fresh data is invented", "MEDIUM")
    if kind in ("render", "media", "quality"):
        import shutil as _sh
        if not _sh.which("ffprobe"):
            add("ffprobe_missing", "quality cannot be verified; it will be reported UNVERIFIED", "MEDIUM")
        if resources(db_path)["disk_free_mb"] < 500:
            add("low_disk", "render skipped until space is freed", "HIGH")
    if kind in ("ai", "research"):
        from kora.services.ai_failover import provider_states
        if not any(p["state"] in ("HEALTHY", "CONFIGURED") for p in provider_states(env)):
            add("no_ai_provider", "local rule engine (not an LLM) will answer", "MEDIUM")
    if kind == "publish":
        from kora.services import social
        for plat in params.get("platforms", []):
            r = social.posting_preflight(params.get("owner", ""), plat, db_path, env)
            if not r["ready"]:
                add(f"{plat}:{r['reason']}", "platform skipped; other platforms continue", "HIGH")
    level = "HIGH" if any(x["level"] == "HIGH" for x in risks) else ("MEDIUM" if risks else "LOW")
    return {"kind": kind, "risk": level, "risks": risks, "proceed_recommended": level != "HIGH",
            "note": "prediction from real pre-checks; a planned fallback is not a claim that it worked"}


# ----------------------------------------------------------------------------- dry-run of risky changes
def dry_run(action: str, params: Optional[Dict[str, Any]] = None, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Read-only impact preview for risky operations. Changes nothing; the real action still needs its normal approval."""
    params = params or {}
    c = get_connection(db_path)
    try:
        if action == "delete_user_data":
            tables = ("jobs", "social_posts", "rag_docs", "dna_versions", "ledger", "checkpoints")
            counts = {t: c.execute(f"SELECT COUNT(*) n FROM {t};").fetchone()["n"] for t in tables}
            return {"action": action, "would_remove_rows": counts, "reversible": False, "changed": False,
                    "note": "export first; the real delete needs the confirm phrase"}
        if action == "lifecycle":
            cut = time.time() - RETENTION["checkpoints"] * DAY
            n = c.execute("SELECT COUNT(*) n FROM checkpoints WHERE updated_at < ?;", (cut,)).fetchone()["n"]
            return {"action": action, "would_remove_old_checkpoints": n, "reversible": False, "changed": False}
        if action == "restore_dna":
            from kora.services import dna
            return {"action": action, "changed": False, "diff": dna.restore(params["kind"], int(params["version"]), db_path=db_path, confirm=False)}
        if action == "priority_floor":
            n = c.execute("SELECT COUNT(*) n FROM jobs WHERE status='QUEUED' AND priority < ?;", (int(params.get("floor", 0)),)).fetchone()["n"]
            return {"action": action, "would_pause_queued_jobs": n, "reversible": True, "changed": False}
    finally:
        c.close()
    raise ValueError("unknown dry-run action")
