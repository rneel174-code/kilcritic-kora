"""
KORA PRO - AI routing with circuit-breaker failover.

Order: Gemini -> OpenAI -> Groq -> deterministic local fallback (clearly labelled `local_deterministic_fallback`).
A provider with no key is skipped. A provider that errors (timeout / 429 / 5xx / bad body) is recorded as failed and
the next one is tried; after `breaker_threshold` consecutive failures it is skipped for `breaker_cooldown` seconds.
The local fallback never pretends to be an LLM. Real provider calls are UNVERIFIED in this build (no credentials
were available); the request/response handling is exercised against an injected transport in the test suite.
"""
import json
import os
import threading
import time
from typing import Any, Callable, Dict, List, Optional

from kora.core.http import TransportError, https_request

_lock = threading.Lock()
_breaker: Dict[str, Dict[str, float]] = {}
BREAKER_THRESHOLD = 3
BREAKER_COOLDOWN = 60.0

OPENAI_URL = "https://api.openai.com/v1/chat/completions"
GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"


def reset_breakers() -> None:
    with _lock:
        _breaker.clear()


def _open(provider: str, now: float) -> bool:
    with _lock:
        b = _breaker.get(provider)
        return bool(b and b.get("until", 0) > now)


def _record(provider: str, ok: bool, now: float, err: str = "") -> None:
    with _lock:
        b = _breaker.setdefault(provider, {"fails": 0, "until": 0})
        if ok:
            b["fails"], b["until"], b["ok"] = 0, 0, 1
        else:
            b["fails"] += 1
            b["last_429"] = 1 if "429" in err else 0
            if b["fails"] >= BREAKER_THRESHOLD:
                b["until"] = now + BREAKER_COOLDOWN


def _call_openai_compat(url: str, key: str, model: str, prompt: str, transport, timeout: float) -> str:
    body = json.dumps({"model": model, "messages": [{"role": "user", "content": prompt}], "temperature": 0.2, "max_tokens": 1200}).encode()
    status, _h, data = transport("POST", url, {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}, body, timeout)
    if status != 200:
        raise TransportError(f"http_{status}")
    return json.loads(data)["choices"][0]["message"]["content"]


def _call_gemini(key: str, model: str, prompt: str, transport, timeout: float) -> str:
    body = json.dumps({"contents": [{"role": "user", "parts": [{"text": prompt}]}], "generationConfig": {"temperature": 0.2, "maxOutputTokens": 1200}}).encode()
    status, _h, data = transport("POST", GEMINI_URL.format(model=model), {"x-goog-api-key": key, "Content-Type": "application/json"}, body, timeout)
    if status != 200:
        raise TransportError(f"http_{status}")
    parts = json.loads(data)["candidates"][0]["content"]["parts"]
    return "".join(p.get("text", "") for p in parts)


def query_ai_model(prompt: str, preferred_provider: Optional[str] = None, transport: Callable = https_request,
                   env: Optional[Dict[str, str]] = None, timeout: float = 30.0, clock: Callable[[], float] = time.time) -> Dict[str, Any]:
    env = os.environ if env is None else env
    plan: List[tuple] = [
        ("gemini", env.get("GEMINI_API_KEY"), env.get("GEMINI_MODEL", "gemini-1.5-flash")),
        ("openai", env.get("OPENAI_API_KEY"), env.get("OPENAI_MODEL", "gpt-4o-mini")),
        ("groq", env.get("GROQ_API_KEY"), env.get("GROQ_MODEL", "llama-3.3-70b-versatile")),
    ]
    errors: List[Dict[str, str]] = []
    for name, key, model in plan:
        if not key or (preferred_provider and preferred_provider != name):
            continue
        now = clock()
        if _open(name, now):
            errors.append({"provider": name, "error": "circuit_open"})
            continue
        try:
            if name == "gemini":
                text = _call_gemini(key, model, prompt, transport, timeout)
            else:
                text = _call_openai_compat(OPENAI_URL if name == "openai" else GROQ_URL, key, model, prompt, transport, timeout)
            if not text or not text.strip():
                raise TransportError("empty_output")
            _record(name, True, now)
            return {"ok": True, "provider": name, "model": model, "output": text, "errors_before_success": errors}
        except (TransportError, KeyError, IndexError, ValueError, TypeError) as exc:
            _record(name, False, now, str(exc))
            errors.append({"provider": name, "error": str(exc)[:200]})

    return {
        "ok": True,
        "provider": "local_deterministic_fallback",
        "model": "kora-rule-engine-v8.10.0",
        "output": f"KORA [Deterministic Analysis]: Evaluated prompt of {len(prompt)} characters. Telemetry nominal.",
        "fallback_reason": "External API keys unconfigured or all providers failed / circuit-breaker open. Local fallback executed safely.",
        "errors": errors,
    }


def provider_states(env: Optional[Dict[str, str]] = None, clock: Callable[[], float] = time.time) -> List[Dict[str, Any]]:
    """Truthful per-provider state: UNAVAILABLE (no key) / CONFIGURED / HEALTHY (>=1 real success, breaker closed) /
    FAILED (recent failures) / RATE_LIMITED is reported only when a 429 was seen. Capability/cost hints are static metadata."""
    env = os.environ if env is None else env
    now = clock()
    meta = {"gemini": ("GEMINI_API_KEY", "low", "text,vision"), "openai": ("OPENAI_API_KEY", "paid", "text,vision"), "groq": ("GROQ_API_KEY", "low", "text,fast"),
            "openrouter": ("OPENROUTER_API_KEY", "varies", "text"), "cerebras": ("CEREBRAS_API_KEY", "low", "text,fast")}
    out = []
    for name, (key, cost, caps) in meta.items():
        implemented = name in ("gemini", "openai", "groq")
        with _lock:
            b = dict(_breaker.get(name, {}))
        if not env.get(key):
            state = "UNAVAILABLE"
        elif not implemented:
            state = "CONFIGURED_NOT_IMPLEMENTED"
        elif b.get("until", 0) > now:
            state = "RATE_LIMITED" if b.get("last_429") else "FAILED"
        elif b.get("ok"):
            state = "HEALTHY"
        else:
            state = "CONFIGURED"
        out.append({"provider": name, "state": state, "implemented": implemented, "cost_hint": cost, "capabilities": caps})
    out.append({"provider": "local_deterministic_fallback", "state": "AVAILABLE", "implemented": True, "cost_hint": "free", "capabilities": "rule engine, not an LLM"})
    return out
