"""Optional encrypted local vault for secrets/config exports.

Uses AES-GCM from the widely deployed `cryptography` package. If unavailable,
this module fails closed rather than falling back to plaintext.
"""
from __future__ import annotations
import base64, json, os
from hashlib import sha256
from typing import Any, Dict

class VaultError(RuntimeError):
    pass

def _crypto():
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        from cryptography.hazmat.primitives import hashes
        return AESGCM, PBKDF2HMAC, hashes
    except Exception as exc:
        raise VaultError("cryptography_dependency_required") from exc

def _key(password: str, salt: bytes):
    AESGCM, PBKDF2HMAC, hashes = _crypto()
    if not password:
        raise VaultError("empty_vault_password")
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=310000)
    return kdf.derive(password.encode())

def seal(data: Dict[str, Any], password: str) -> str:
    AESGCM, _, _ = _crypto()
    salt, nonce = os.urandom(16), os.urandom(12)
    ct = AESGCM(_key(password, salt)).encrypt(nonce, json.dumps(data, sort_keys=True).encode(), None)
    return json.dumps({"v": 1, "alg": "AES-256-GCM", "salt": base64.b64encode(salt).decode(), "nonce": base64.b64encode(nonce).decode(), "ciphertext": base64.b64encode(ct).decode()})

def open_sealed(blob: str, password: str) -> Dict[str, Any]:
    AESGCM, _, _ = _crypto()
    try:
        obj=json.loads(blob); salt=base64.b64decode(obj["salt"]); nonce=base64.b64decode(obj["nonce"]); ct=base64.b64decode(obj["ciphertext"])
        raw=AESGCM(_key(password,salt)).decrypt(nonce,ct,None)
        return json.loads(raw.decode())
    except Exception as exc:
        raise VaultError("vault_decrypt_failed") from exc

def fingerprint(blob: str) -> str:
    return sha256(blob.encode()).hexdigest()
