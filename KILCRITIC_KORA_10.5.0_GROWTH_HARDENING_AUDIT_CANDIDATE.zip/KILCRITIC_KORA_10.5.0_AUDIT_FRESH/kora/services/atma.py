"""ATMA core: persistent identity, verified restore points, Phoenix recovery, guardian heartbeat, Mission Lock.

Honest scope: this is a persistence/recovery layer, not consciousness. Phoenix restores ONLY from a backup whose file hash
matches the hash recorded when it was taken AND that passes integrity_check; it keeps safe mode ON afterwards until the
owner verifies and resumes. Cross-device encrypted sync / conflict resolution are NOT implemented (no crypto library).
"""
import hashlib
import json
import os
import shutil
import sqlite3
import time
from typing import Any, Dict, List, Optional

from kora.core import policy
from kora.core.contracts import new_id
from kora.core.db import DEFAULT_DB_PATH, get_connection, get_setting, record_audit, set_setting

HEARTBEAT = "atma_heartbeat"


def identity(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    aid = get_setting("atma_id", None, db_path)
    if not aid:
        aid = new_id("atma")
        set_setting("atma_id", aid, db_path)
        set_setting("atma_born", str(time.time()), db_path)
    return {"atma_id": aid, "born": float(get_setting("atma_born", "0", db_path) or 0), "note": "persistent configuration identity, not consciousness"}


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def list_restore_points(db_path: str = DEFAULT_DB_PATH, limit: int = 20) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        return [dict(r) for r in conn.execute("SELECT id,filename,sha256,size_bytes,integrity_verified,created_at FROM backups ORDER BY created_at DESC LIMIT ?;", (limit,)).fetchall()]
    finally:
        conn.close()


def verify_restore_point(backup_id: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    conn = get_connection(db_path)
    try:
        r = conn.execute("SELECT filepath,sha256 FROM backups WHERE id=?;", (backup_id,)).fetchone()
    finally:
        conn.close()
    if not r:
        return {"ok": False, "reason": "unknown_backup"}
    path = r["filepath"]
    if not os.path.isfile(path):
        return {"ok": False, "reason": "file_missing"}
    if sha256_file(path) != r["sha256"]:
        return {"ok": False, "reason": "hash_mismatch_corrupted_or_tampered"}
    try:
        c = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            if c.execute("PRAGMA integrity_check;").fetchone()[0] != "ok":
                return {"ok": False, "reason": "integrity_check_failed"}
            tables = {x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table';")}
        finally:
            c.close()
    except sqlite3.DatabaseError:
        return {"ok": False, "reason": "not_a_database"}
    if not {"jobs", "backups", "settings"} <= tables:
        return {"ok": False, "reason": "schema_incomplete"}
    return {"ok": True, "path": path, "sha256": r["sha256"]}


def phoenix_restore(backup_id: str, actor: str = "owner", db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Restore the live DB from a VERIFIED restore point. Leaves safe mode ON; a safety copy of the current state is kept."""
    v = verify_restore_point(backup_id, db_path)
    if not v["ok"]:
        record_audit("phoenix_refused", actor, {"backup": backup_id, "reason": v["reason"]}, db_path)
        return {"status": "REFUSED", "reason": v["reason"]}
    from kora.services import emergency
    emergency.set_safe_mode(True, actor, db_path)  # freeze writers first
    safety = f"{db_path}.pre-restore-{int(time.time())}"
    src_live = get_connection(db_path)
    try:
        dst = sqlite3.connect(safety)
        try:
            src_live.backup(dst)
        finally:
            dst.close()
    finally:
        src_live.close()
    src = sqlite3.connect(f"file:{v['path']}?mode=ro", uri=True)
    live = sqlite3.connect(db_path, timeout=10)
    try:
        src.backup(live)
    finally:
        live.close()
        src.close()
    from kora.core.db import init_db
    init_db(db_path)  # forward-migrate an older snapshot
    set_setting(policy.SAFE_MODE_KEY, "1", db_path)  # the snapshot may predate safe mode: keep it ON
    from kora.core.queue import DurableQueue
    DurableQueue(db_path).set_kill_switch(True)
    record_audit("phoenix_restore", actor, {"backup": backup_id, "safety_copy": os.path.basename(safety)}, db_path)
    return {"status": "RESTORED_SAFE_MODE_ON", "backup": backup_id, "safety_copy": safety,
            "next": "verify health, then POST /api/emergency/resume"}


# ----------------------------------------------------------------------------- guardian
def heartbeat(db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> float:
    t = time.time() if now is None else now
    set_setting(HEARTBEAT, str(t), db_path)
    return t


def guardian_status(db_path: str = DEFAULT_DB_PATH, stale_after: float = 1800.0, now: Optional[float] = None) -> Dict[str, Any]:
    now = time.time() if now is None else now
    last = float(get_setting(HEARTBEAT, "0", db_path) or 0)
    if not last:
        return {"state": "NO_HEARTBEAT_YET", "last": None}
    age = now - last
    return {"state": "ONLINE" if age <= stale_after else "STALE", "last": last, "age_seconds": round(age, 1),
            "offline_policy": "on STALE a verified local backup should be taken (cron 'backup'); alerts are not sent anywhere in this build"}


# ----------------------------------------------------------------------------- mission lock
def mission_set(goal: str, milestones: List[str], db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    goal = (goal or "").strip()
    if not goal or len(goal) > 500 or len(milestones) > 50:
        raise ValueError("goal 1-500 chars, <= 50 milestones")
    ms = [{"title": str(m)[:200], "done": False, "evidence": ""} for m in milestones]
    mid, now = new_id("mis"), time.time()
    conn = get_connection(db_path)
    try:
        conn.execute("INSERT INTO missions(id,goal,milestones,created_at,updated_at) VALUES (?,?,?,?,?);", (mid, goal, json.dumps(ms), now, now))
    finally:
        conn.close()
    return mission_get(mid, db_path)


def mission_progress(mid: str, index: int, evidence: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """A milestone only counts as done with non-empty evidence."""
    if not (evidence or "").strip():
        raise ValueError("evidence required to mark a milestone done")
    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        r = conn.execute("SELECT milestones FROM missions WHERE id=?;", (mid,)).fetchone()
        if not r:
            conn.execute("ROLLBACK;")
            raise KeyError("unknown mission")
        ms = json.loads(r["milestones"])
        if not isinstance(index, int) or not 0 <= index < len(ms):
            conn.execute("ROLLBACK;")
            raise ValueError("bad milestone index")
        ms[index].update(done=True, evidence=evidence[:500])
        conn.execute("UPDATE missions SET milestones=?, updated_at=?, status=? WHERE id=?;",
                     (json.dumps(ms), time.time(), "COMPLETE" if all(m["done"] for m in ms) else "ACTIVE", mid))
        conn.execute("COMMIT;")
    finally:
        conn.close()
    return mission_get(mid, db_path)


def mission_get(mid: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    conn = get_connection(db_path)
    try:
        r = conn.execute("SELECT * FROM missions WHERE id=?;", (mid,)).fetchone()
    finally:
        conn.close()
    if not r:
        raise KeyError("unknown mission")
    ms = json.loads(r["milestones"])
    done = sum(1 for m in ms if m["done"])
    return {"id": r["id"], "goal": r["goal"], "status": r["status"], "milestones": ms,
            "progress": {"done": done, "total": len(ms)}, "note": "a goal, not a guaranteed outcome; progress counts only evidenced milestones"}
