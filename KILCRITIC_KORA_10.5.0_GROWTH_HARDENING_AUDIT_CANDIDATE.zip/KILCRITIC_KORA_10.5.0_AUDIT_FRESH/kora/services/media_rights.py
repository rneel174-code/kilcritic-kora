"""Asset-level rights/provenance preflight.

This is a conservative evidence layer, not a legal-guarantee engine.
It records what is known and refuses to silently turn unknown rights into PASS.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional
import hashlib, os, time

STATUS = ("ORIGINAL", "USER_OWNED", "LICENSED", "PUBLIC_DOMAIN", "UNKNOWN", "RESTRICTED", "REVIEW")
DECISIONS = ("PASS", "AUTO_FIX", "REVIEW", "BLOCK")

@dataclass(frozen=True)
class RightsRecord:
    asset_id: str
    source: str
    rights_status: str
    owner_or_license: str = ""
    transformations: tuple = ()
    ai_generated: bool = False
    identity_risk: bool = False
    voice_imitation_risk: bool = False
    copyrighted_source_risk: bool = False
    created_at: float = 0.0
    sha256: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

def asset_sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def preflight(record: RightsRecord) -> Dict[str, Any]:
    reasons = []
    if record.rights_status not in STATUS:
        return {"decision": "REVIEW", "reasons": ["unknown_rights_status"], "record": record.to_dict()}
    if record.rights_status in ("RESTRICTED",):
        reasons.append("rights_restricted")
    if record.rights_status == "UNKNOWN":
        reasons.append("rights_unknown")
    if record.identity_risk:
        reasons.append("identity_risk")
    if record.voice_imitation_risk:
        reasons.append("voice_imitation_risk")
    if record.copyrighted_source_risk:
        reasons.append("copyrighted_source_risk")
    if any((record.identity_risk, record.voice_imitation_risk, record.copyrighted_source_risk)):
        decision = "BLOCK" if record.rights_status in ("UNKNOWN", "RESTRICTED") else "REVIEW"
    elif record.rights_status in ("ORIGINAL", "USER_OWNED", "LICENSED", "PUBLIC_DOMAIN"):
        decision = "PASS"
    else:
        decision = "REVIEW"
    return {"decision": decision, "reasons": reasons, "record": record.to_dict()}

def make_record(asset_id: str, source: str, rights_status: str, path: Optional[str] = None, **flags: Any) -> RightsRecord:
    digest = asset_sha256(path) if path and os.path.isfile(path) else ""
    return RightsRecord(asset_id=asset_id, source=source, rights_status=rights_status,
                        created_at=time.time(), sha256=digest, **flags)
