"""Single discovery surface for the additive final upgrade."""
from kora.services.hollywood_studio import CATEGORIES, STEPS
from kora.services.platform_readiness import PLATFORMS

def capability_manifest():
    return {
        "hollywood_studio": {"categories": list(CATEGORIES), "steps": list(STEPS)},
        "platforms": list(PLATFORMS),
        "rights_gate": True,
        "quality_gate": True,
        "one_asset_many_variants": True,
        "android_compat_probe": True,
        "truthful_publish_state": True,
    }
