"""Governed execution: proposals (approval ledger) + execute_governed + checkpoints.

* Anything HIGH/CRITICAL becomes a persisted PENDING proposal. A human approves it (API/HUD); the caller then re-invokes
  with `proposal_id` and the approval is consumed exactly once (PENDING->APPROVED->EXECUTING CAS).  Proposals are DATA:
  the API can approve/reject them but can never supply code to run - handlers are supplied by trusted in-process callers.
* Verification is real: the handler result must be a dict and must not report ok=False; otherwise FAILED and the
  optional `rollback` callable runs.
"""
import json
import re
import time
from typing import Any, Callable, Dict, List, Optional

from kora.core import policy
from kora.core.contracts import Risk, Verification, new_id
from kora.core.db import DEFAULT_DB_PATH, get_connection, record_audit

_TASK_ID = re.compile(r"^[A-Za-z0-9_.\-]{1,100}$")
MAX_CHECKPOINT_BYTES = 256 * 1024


# ----------------------------------------------------------------------------- proposals
def create_proposal(action: str, reason: str, risk: str, changes: Optional[List[Any]] = None, tests: Optional[List[str]] = None,
                    rollback: str = "", db_path: str = DEFAULT_DB_PATH) -> str:
    pid = new_id("prop")
    conn = get_connection(db_path)
    try:
        conn.execute("INSERT INTO proposals(id,action,reason,risk,changes,tests,rollback,created_at) VALUES (?,?,?,?,?,?,?,?);",
                     (pid, action, reason[:2000], risk, json.dumps(changes or [])[:20000], json.dumps(tests or [])[:5000], rollback[:2000], time.time()))
    finally:
        conn.close()
    record_audit("proposal_created", "system", {"id": pid, "action": action, "risk": risk}, db_path)
    return pid


def list_proposals(db_path: str = DEFAULT_DB_PATH, status: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        sql, args = "SELECT id,action,reason,risk,status,rollback,decided_by,created_at FROM proposals", []
        if status:
            sql += " WHERE status=?"
            args.append(status)
        return [dict(r) for r in conn.execute(sql + " ORDER BY created_at DESC LIMIT ?;", (*args, max(1, min(200, limit)))).fetchall()]
    finally:
        conn.close()


def decide(proposal_id: str, approve: bool, actor: str, db_path: str = DEFAULT_DB_PATH) -> bool:
    conn = get_connection(db_path)
    try:
        n = conn.execute("UPDATE proposals SET status=?, decided_by=?, decided_at=? WHERE id=? AND status='PENDING';",
                         ("APPROVED" if approve else "REJECTED", actor, time.time(), proposal_id)).rowcount
    finally:
        conn.close()
    if n:
        record_audit("proposal_approved" if approve else "proposal_rejected", actor, {"id": proposal_id}, db_path)
    return n == 1


def _consume(proposal_id: str, action: str, db_path: str) -> bool:
    conn = get_connection(db_path)
    try:
        return conn.execute("UPDATE proposals SET status='EXECUTING' WHERE id=? AND action=? AND status='APPROVED';", (proposal_id, action.upper())).rowcount == 1
    finally:
        conn.close()


def _finish(proposal_id: str, status: str, result: Any, db_path: str) -> None:
    conn = get_connection(db_path)
    try:
        conn.execute("UPDATE proposals SET status=?, result=? WHERE id=?;", (status, json.dumps(result, default=str)[:5000], proposal_id))
    finally:
        conn.close()


def verify(result: Any) -> Verification:
    if not isinstance(result, dict):
        return Verification("FAIL", notes=["handler result must be a dict"], rollback_required=True)
    if result.get("ok") is False:
        return Verification("FAIL", notes=[str(result.get("error", "handler reported failure"))[:200]], rollback_required=True)
    return Verification("PASS", evidence=[{"type": "handler_result", "keys": sorted(result)[:20]}])


def execute_governed(action: str, handler: Callable[[], Any], db_path: str = DEFAULT_DB_PATH, *, reason: str = "",
                     risk: Optional[Risk] = None, proposal_id: Optional[str] = None, rollback: Optional[Callable[[], Any]] = None,
                     changes: Optional[List[Any]] = None, tests: Optional[List[str]] = None) -> Dict[str, Any]:
    d = policy.evaluate(action, risk, db_path)
    if d["decision"] == "BLOCK":
        record_audit("governed_blocked", "system", {"action": action, "reason": d["reason"]}, db_path)
        return {"status": "BLOCKED", "reason": d["reason"]}
    if d["decision"] == "APPROVAL_REQUIRED":
        if not proposal_id or not _consume(proposal_id, action, db_path):
            pid = create_proposal(action.upper(), reason or f"Run {action}", d["risk"], changes, tests,
                                  "automatic rollback callable" if rollback else "none", db_path)
            return {"status": "PENDING_APPROVAL", "proposal_id": pid, "reason": d["reason"]}
    else:
        proposal_id = None
    try:
        result = handler()
        v = verify(result)
    except Exception as exc:  # noqa: BLE001
        result, v = None, Verification("FAIL", notes=[f"{exc.__class__.__name__}: {str(exc)[:200]}"], rollback_required=True)
    if v.status != "PASS":
        rolled = False
        if rollback:
            try:
                rollback()
                rolled = True
            except Exception:  # noqa: BLE001
                rolled = False
        if proposal_id:
            _finish(proposal_id, "FAILED", v.as_dict(), db_path)
        record_audit("governed_failed", "system", {"action": action, "rolled_back": rolled}, db_path)
        return {"status": "FAILED", "verification": v.as_dict(), "rolled_back": rolled}
    if proposal_id:
        _finish(proposal_id, "EXECUTED", result, db_path)
    return {"status": "VERIFIED", "result": result, "verification": v.as_dict()}


# ----------------------------------------------------------------------------- checkpoints
def checkpoint_save(task_id: str, state: Dict[str, Any], db_path: str = DEFAULT_DB_PATH) -> None:
    if not _TASK_ID.match(task_id or ""):
        raise ValueError("invalid task_id")  # no path traversal: ids are DB keys, never file names
    blob = json.dumps(state)
    if len(blob.encode()) > MAX_CHECKPOINT_BYTES:
        raise ValueError("checkpoint too large")
    conn = get_connection(db_path)
    try:
        conn.execute("INSERT INTO checkpoints(task_id,state,updated_at) VALUES (?,?,?) ON CONFLICT(task_id) DO UPDATE SET state=excluded.state, updated_at=excluded.updated_at;",
                     (task_id, blob, time.time()))
    finally:
        conn.close()


def checkpoint_load(task_id: str, db_path: str = DEFAULT_DB_PATH) -> Optional[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        r = conn.execute("SELECT state FROM checkpoints WHERE task_id=?;", (task_id,)).fetchone()
        return json.loads(r["state"]) if r else None
    finally:
        conn.close()


def checkpoint_delete(task_id: str, db_path: str = DEFAULT_DB_PATH) -> bool:
    conn = get_connection(db_path)
    try:
        return conn.execute("DELETE FROM checkpoints WHERE task_id=?;", (task_id,)).rowcount == 1
    finally:
        conn.close()
