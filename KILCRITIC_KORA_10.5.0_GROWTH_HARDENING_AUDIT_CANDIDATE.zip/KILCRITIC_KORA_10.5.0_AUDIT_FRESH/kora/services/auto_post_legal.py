"""Legal auto-post preparation: rights -> safety -> platform -> shadow preview -> (approval) -> queue.
Creates the post through the normal social flow (so approval, idempotency, safe mode and policy all still apply) and returns
the Shadow Publish report. It never publishes by itself; 'legal' never means guaranteed copyright immunity."""
from typing import Any, Dict, Optional

from kora.core.queue import DurableQueue
from kora.services import shadow, social, trust


def prepare(platform: str, content: str, audience: str, db_path: str, *, rights: str = "", source: str = "", media_path: Optional[str] = None,
            ai_generated: bool = False, title: Optional[str] = None, idempotency_key: Optional[str] = None,
            queue: Optional[DurableQueue] = None, media_root: Optional[str] = None, env=None) -> Dict[str, Any]:
    meta = {k: v for k, v in (("rights", rights), ("source", source), ("ai_generated", ai_generated)) if v}
    kw = {"media_root": media_root} if media_root else {}
    out = social.create_social_post(platform, content, audience, idempotency_key=idempotency_key, db_path=db_path, media_path=media_path, title=title,
                                    queue=queue, auto_approve=False, asset_meta=meta, env=env, **kw)
    pid = out["post_id"]
    trust.record_provenance("post", pid, source=source or "operator-supplied", tool="kora.auto_post_legal", rights=rights or "UNDECLARED",
                            transformations=";".join(out.get("preflight_fixes", [])), verification=f"preflight:{out.get('preflight')}", db_path=db_path)
    report = shadow.preview_post(pid, db_path, env=env)
    return {"post_id": pid, "status": out["status"], "shadow_publish": report, "next": "operator approval via /api/social/posts/{id}/approve, then the worker publishes"}
