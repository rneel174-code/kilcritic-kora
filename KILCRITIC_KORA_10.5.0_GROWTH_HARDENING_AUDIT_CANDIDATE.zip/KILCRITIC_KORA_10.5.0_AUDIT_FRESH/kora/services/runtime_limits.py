"""Hard runtime resource guards used by long-running jobs.

Limits are measured and enforced; they never pretend to create extra hardware.
"""
from __future__ import annotations
import os, shutil, time
from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class ResourceLimits:
    max_rss_mb: int = 1024
    min_free_disk_mb: int = 512
    max_wall_seconds: float = 3600.0

class ResourceLimitError(RuntimeError):
    pass

def rss_mb() -> Optional[float]:
    try:
        import resource
        raw = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        # Linux reports KiB; macOS reports bytes.
        return raw / 1024.0 if raw < 10_000_000 else raw / (1024.0 * 1024.0)
    except Exception:
        return None

def free_disk_mb(path: str = ".") -> float:
    return shutil.disk_usage(path).free / (1024.0 * 1024.0)

def enforce(limits: ResourceLimits = ResourceLimits(), disk_path: str = ".") -> dict:
    mem = current_rss_mb() if current_rss_mb() is not None else rss_mb()
    disk = free_disk_mb(disk_path)
    if mem is not None and mem > limits.max_rss_mb:
        raise ResourceLimitError(f"rss_limit_exceeded:{mem:.1f}MB>{limits.max_rss_mb}MB")
    if disk < limits.min_free_disk_mb:
        raise ResourceLimitError(f"disk_floor_exceeded:{disk:.1f}MB<{limits.min_free_disk_mb}MB")
    return {"rss_mb": mem, "free_disk_mb": disk, "limits": limits.__dict__.copy()}

def bounded_sleep_until(deadline: float, seconds: float) -> bool:
    """Sleep without ever crossing a caller-owned deadline. Returns False at deadline."""
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        return False
    time.sleep(min(max(0.0, seconds), remaining))
    return time.monotonic() < deadline


def current_rss_mb() -> Optional[float]:
    """CURRENT resident set (not peak). Linux /proc; None when unavailable (never faked)."""
    try:
        with open("/proc/self/statm") as fh:
            pages = int(fh.read().split()[1])
        return pages * (os.sysconf("SC_PAGE_SIZE") / (1024.0 * 1024.0))
    except Exception:
        return None

def env_limits(env=None) -> ResourceLimits:
    env = os.environ if env is None else env
    def _i(k, d):
        try:
            return max(1, int(env.get(k, d)))
        except (TypeError, ValueError):
            return d
    return ResourceLimits(max_rss_mb=_i("KORA_MAX_RSS_MB", 1536), min_free_disk_mb=_i("KORA_MIN_FREE_DISK_MB", 256))

def pressure(limits: Optional[ResourceLimits] = None, disk_path: str = ".") -> dict:
    """Non-raising snapshot: under_pressure True when RSS or disk floor breached (80% soft RSS)."""
    limits = limits or env_limits()
    mem = current_rss_mb()
    disk = free_disk_mb(disk_path)
    reasons = []
    if mem is not None and mem > limits.max_rss_mb * 0.8:
        reasons.append("rss_high")
    if disk < limits.min_free_disk_mb:
        reasons.append("disk_low")
    return {"under_pressure": bool(reasons), "reasons": reasons, "rss_mb": mem, "free_disk_mb": round(disk, 1)}
