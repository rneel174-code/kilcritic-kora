"""KILCRITIC Brain: ONE engine for text AND voice. Understands a goal, checks permissions, then routes to the real module.

Parity: voice and text go through the same `handle()` - same intents, same permission checks, same audit trail.
Voice differences are only SAFETY restrictions:
  * Voice OFF (default) => no voice command is processed at all (the server never receives audio either way).
  * Safe mode / emergency => voice is muted.
  * An unverified (unknown) voice is a GUEST: read-only status, nothing else. `voice_verified` is a CLIENT CLAIM and can
    never raise a principal above its own permissions.
  * Sensitive intents (restore, emergency, leaving safe mode) need TOTP step-up; by voice they are refused unless the owner
    is enrolled in TOTP and supplies the code (voice identity alone is never enough).
Replies meant to be spoken are redacted so secrets/tokens are never read aloud. Unrecognised goals get a clarification,
not a guess. Rule-based routing (no LLM) - it never pretends to understand.
"""
import re
import time
from typing import Any, Callable, Dict, Optional

from kora.core import identity, policy
from kora.core.db import DEFAULT_DB_PATH, get_setting, record_audit, set_setting
from kora.core.logger import redact_text
from kora.services import cost, dharma, dhanda, dna, emergency, sena

VOICE_KEY = "voice_enabled"
HELP = ["ho ja shuru", "status", "system doctor", "attack <topic>", "clone team researcher,editor", "mission lock: <goal>",
        "paise da hisab", "kal wali yaad te wapas ja", "compare dna", "safe mode", "emergency recovery", "voice off",
        "amazon wala resume kar", "pause <task>", "health"]


def voice_enabled(db_path: str = DEFAULT_DB_PATH) -> bool:
    return get_setting(VOICE_KEY, "0", db_path) == "1"


def set_voice(enabled: bool, actor: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    if enabled and policy.is_safe_mode(db_path):
        return {"voice": False, "reason": "safe_mode_mutes_voice"}
    set_setting(VOICE_KEY, "1" if enabled else "0", db_path)
    record_audit("voice_on" if enabled else "voice_off", actor, {}, db_path)
    return {"voice": enabled, "listening_must_stop_in_client": not enabled}


def safe_to_speak(text: str) -> str:
    t = redact_text(text)
    return re.sub(r"\b[A-Za-z0-9_\-]{32,}\b", "[hidden]", t)


# ---------------------------------------------------------------------------------------------- creator workflows (plan-only, truthful)
_WORKFLOW_MAP = {
    "social publishing": ("social", "Draft posts, approve them, schedule them: POST /api/social/posts, /approve, /api/autopilot/schedules. Publishing needs per-platform credentials."),
    "hollywood studio": ("studio", "Studio planning contracts only (rights, quality, platform gates). Video/movie generation is NOT_IMPLEMENTED in this build."),
    "editing": ("editing", "Editing planning only. Real local operation available: media conversion/quality check via ffmpeg (POST /api/media/convert, /api/quality/verify)."),
    "3d 4d 5d": ("animation", "Planning only. No 3D/4D/5D generation engine is implemented or configured."),
    "funny baby": ("fun", "Planning only. No generation provider is configured."),
    "media": ("media", "Media library actions: quality verify and platform conversion are real; creation of new media is NOT_IMPLEMENTED."),
    "convert quality": ("convert", "Real: POST /api/media/convert (ffmpeg, output verified with ffprobe) and POST /api/quality/verify."),
    "story movie": ("storymovie", "Planning only. Story->script->scenes->movie generation is NOT_IMPLEMENTED."),
    "voice text": ("voice", "Voice and text use this same command path; voice must be turned on first (POST /api/voice) and needs a browser/device STT."),
    "post autopilot": ("publish", "Real: preview (shadow publish), approval, scheduling and recovery. 30-day plan: POST /api/autopilot/calendar."),
    "research search": ("research", "Real: web research/RAG when allowed domains and network are available (offline => queued, nothing invented)."),
    "growth dhanda": ("growth", "Real: Dhanda ledger and score from recorded evidence. Trends/analytics need an external data source (NOT_CONFIGURED)."),
}
_PLATFORM_WORDS = {"youtube": "YOUTUBE", "facebook": "FACEBOOK", "instagram": "INSTAGRAM", "tiktok": "TIKTOK", "x": "X", "twitter": "X"}


def _open_workflow(ctx):
    from kora.services import capability_audit
    key = re.sub(r"[^a-z0-9 ]+", " ", ctx["arg"].lower())
    key = re.sub(r"\s+", " ", key.replace("\u2022", " ").replace("\u2192", " ")).strip()
    key = {"3d 4d 5d": "3d 4d 5d", "story movie": "story movie"}.get(key, key)
    hit = _WORKFLOW_MAP.get(key)
    if not hit:
        raise ValueError("unknown workflow; known: " + ", ".join(sorted(_WORKFLOW_MAP)))
    cat, note = hit
    caps = capability_audit.audit()["capabilities"]
    rel = {k: v["state"] for k, v in caps.items() if k.split(".")[0] in ("media", "studio", "social", "tool") or cat in k}
    return (f"{ctx['arg'].strip()}: {note} Plan only, nothing was created, exported or published.",
            {"status_override": "PLANNED", "state": "PLANNED_NOT_EXECUTED", "category": cat, "executed": False, "capabilities": rel})


def _create_plan(ctx):
    from kora.services import asset_compiler, capability_audit
    low = ctx["arg"].lower()
    kinds = [k for k in ("video", "photo", "picture", "image", "story", "wallpaper", "movie", "reel", "short", "clip", "film") if k in low]
    plats = sorted({v for k, v in _PLATFORM_WORDS.items() if re.search(rf"\b{k}\b", low)})
    caps = capability_audit.audit()["capabilities"]
    can_create = caps.get("media.create", {}).get("state") == "IMPLEMENTED_VERIFIED"
    variants = asset_compiler.compile_variants("(pending master asset)", plats or None)
    msg = ("Understood: " + ", ".join(kinds or ["content"]) + (" for " + ", ".join(plats) if plats else "") + ". "
           + ("" if can_create else "Media CREATION is NOT_IMPLEMENTED in this build, so nothing was created. ")
           + "Plan: understand -> rights -> plan -> create/edit -> quality -> platform variants -> preview -> approval -> publish -> verify. "
             "If you already have a master file, conversion and quality verification are real.")
    return msg, {"status_override": "PLANNED", "state": "PLANNED_NOT_EXECUTED", "executed": False, "kinds": kinds, "platforms": plats,
                 "variant_plan": variants, "media_creation": caps.get("media.create", {}).get("state", "NOT_IMPLEMENTED")}


# ---------------------------------------------------------------------------------------------- intents
def _status(ctx):
    from kora.core.queue import DurableQueue
    st = DurableQueue(ctx["db"]).get_stats()
    props = len(__import__("kora.services.governance", fromlist=["x"]).list_proposals(ctx["db"], "PENDING", 50))
    return (f"KORA online. Jobs queued {st.get('QUEUED', 0)}, running {st.get('RUNNING', 0)}, failed {st.get('DEAD_LETTER', 0)}. "
            f"{props} item(s) need your decision. Safe mode {'ON' if policy.is_safe_mode(ctx['db']) else 'off'}."), {"queue": st, "pending_decisions": props}


def _doctor(ctx):
    from kora.services.system_doctor import run_system_doctor_inspection
    r = run_system_doctor_inspection(ctx["db"])
    bad = [p.get("component") for p in r["probes"] if p.get("status") in ("CRITICAL", "DEGRADED")]
    return f"Health score {r['health_score']} (measured probes). Needs attention: {', '.join(bad) or 'nothing'}.", {"health_score": r["health_score"], "attention": bad}


def _attack(ctx):
    p = sena.attack_plan(ctx["arg"])
    return f"Plan ready: {len(p['angles'])} angles for '{p['topic']}' (plan only - nothing has been run).", p


def _team(ctx):
    roles = [r for r in re.split(r"[,\s]+", ctx["arg"]) if r]
    t = sena.clone_team(roles or ["researcher", "editor", "uploader", "analyst"])
    return "Team assigned least-privilege permissions. Uploader/publisher actions still need approval.", t


def _mission(ctx):
    m = __import__("kora.services.atma", fromlist=["x"]).mission_set(ctx["arg"], [])
    return f"Mission locked: {m['goal']}. Add milestones; progress only counts evidenced milestones.", m


def _money(ctx):
    s = dhanda.summary(ctx["db"])
    return ("Ledger (actual vs estimate are kept separate): " + (str(s) if s else "no entries yet.")), {"ledger": s}


def _yesterday(ctx):
    res = {k: dna.yesterday(k, ctx["db"], ctx["now"]) for k in dna.KINDS}
    changed = [k for k, v in res.items() if v.get("status") == "PREVIEW" and (v["added"] or v["removed"] or v["changed"])]
    return (f"Preview only. Differences vs yesterday in: {', '.join(changed) or 'nothing'}. Confirm via /api/dna/restore to apply."), res


def _compare(ctx):
    out = {}
    for k in dna.KINDS:
        h = dna.history(k, ctx["db"])
        if len(h) >= 2:
            out[k] = dna.diff(k, h[1]["version"], h[0]["version"], ctx["db"])
    return f"Compared the latest two versions of {len(out)} DNA file(s).", out


def _clean_query(arg: str) -> str:
    stop = {"wala", "wali", "wale", "da", "di", "de", "kar", "karo", "kr", "the", "task", "job", "ko", "nu", "dobara", "phir", "again", "please", "my"}
    return " ".join(w for w in re.split(r"\s+", arg.strip().lower()) if w and w not in stop)


def owner_key(principal: Dict[str, Any]) -> str:
    """Per-user scope key used for task ownership and context. A user can only ever see/resume tasks stamped with their own key."""
    return f"{principal.get('role', 'guest')}:{principal.get('id', '-')}"


def _find_tasks(ctx):
    from kora.core.queue import DurableQueue
    q = DurableQueue(ctx["db"])
    return q, q.resumable_for(ctx["owner"], _clean_query(ctx["arg"]))


def _resume(ctx):
    q, found = _find_tasks(ctx)
    if not found:
        return "I found no paused or failed task of yours matching that.", {"matches": 0}
    if len(found) > 1:
        names = "; ".join(f"{i + 1}) {t['label'] or t['handler_name']}" for i, t in enumerate(found[:3]))
        return f"{len(found)} tasks match. Which one: {names}?", {"matches": len(found), "candidates": [{"id": t["id"], "label": t["label"] or t["handler_name"]} for t in found[:3]], "needs_choice": True}
    t = found[0]
    res = q.resume_job(t["id"], ctx["owner"])
    return (f"Resumed '{t['label'] or t['handler_name']}'. Finished steps are not repeated." if res == "RESUMED" else "That task could not be resumed."), {"matches": 1, "result": res, "id": t["id"]}


def _pause(ctx):
    from kora.core.queue import DurableQueue
    q = DurableQueue(ctx["db"])
    rows = [r for r in q.get_active(200) if r["status"] == "QUEUED"]
    owned = [q.get_job(r["id"]) for r in rows]
    qs = _clean_query(ctx["arg"])
    owned = [j for j in owned if j and j["owner"] == ctx["owner"] and (not qs or qs in (j["label"] + " " + j["handler_name"]).lower())]
    if not owned:
        return "No waiting task of yours matches that (a task that is already running cannot be paused mid-step).", {"matches": 0}
    if len(owned) > 1:
        return f"{len(owned)} tasks match. Which one: " + "; ".join(f"{i + 1}) {j['label'] or j['handler_name']}" for i, j in enumerate(owned[:3])) + "?", {"matches": len(owned), "needs_choice": True}
    q.pause_job(owned[0]["id"], ctx["owner"])
    return f"Paused '{owned[0]['label'] or owned[0]['handler_name']}'. Say resume to continue.", {"matches": 1, "id": owned[0]["id"]}


def _health(ctx):
    from kora.services import ops
    h = ops.health(ctx["db"], ctx["now"])
    flagged = [f"{k} {v['state']}" for k, v in h["domains"].items() if v["state"] != "GOOD"]
    return f"Overall {h['overall']}. " + ("Not good: " + ", ".join(flagged) if flagged else "All domains checked and good."), h


def choose_option(options):
    """Pick the safest useful option and give a short human reason (a decision summary, not chain-of-thought).
    options: [{"name", "risk": LOW|MEDIUM|HIGH, "reversible": bool, "cost": number, "useful": bool}]"""
    rank = {"LOW": 0, "MEDIUM": 1, "HIGH": 2}
    ok = [o for o in options if o.get("useful", True)]
    if not ok:
        return {"chosen": None, "reason": "No option does what you asked, so nothing was chosen."}
    ok.sort(key=lambda o: (rank.get(str(o.get("risk", "HIGH")).upper(), 2), 0 if o.get("reversible", False) else 1, float(o.get("cost", 0))))
    best = ok[0]
    bits = [f"{str(best.get('risk', 'HIGH')).lower()} risk"]
    if best.get("reversible"):
        bits.append("can be undone")
    if "cost" in best:
        bits.append(f"cost {best['cost']}")
    return {"chosen": best["name"], "reason": "Chose the safest option that still works: " + ", ".join(bits) + ".", "alternatives": [o["name"] for o in ok[1:]]}


def _safe_on(ctx):
    r = emergency.set_safe_mode(True, ctx["actor"], ctx["db"])
    return "Safe mode ON: no new jobs, cron or publishing; voice muted.", r


def _emergency(ctx):
    r = emergency.emergency_recovery(ctx["actor"], ctx["db"])
    return f"Emergency recovery finished. Safe mode is ON; resume allowed: {r['resume_allowed']}.", r


def _voice_off(ctx):
    return "Voice is OFF. The client must stop the microphone.", set_voice(False, ctx["actor"], ctx["db"])


# name -> (regex, handler, permission needed by non-owner, sensitive, allowed for guest)
INTENTS = [
    ("voice_off", r"\bvoice\s*(off|band)\b|\bmic\s*off\b", _voice_off, None, False, True),
    ("safe_mode", r"\bsafe\s*mode\b", _safe_on, "CHANGE_SECURITY", False, False),
    ("emergency", r"\bemergency\s*recovery\b", _emergency, "CHANGE_SECURITY", True, False),
    ("mission", r"\bmission\s*lock\s*:?\s*(?P<arg>.+)", _mission, "WRITE_LOCAL_FILE", False, False),
    ("attack", r"^\s*attack\s+(?P<arg>.+)", _attack, "WEB_SEARCH", False, False),
    ("clone_team", r"\bclone\s*team\b\s*(?P<arg>.*)", _team, "WRITE_LOCAL_FILE", False, False),
    ("yesterday", r"\bkal\s*wali\s*yaad\b|\brestore\s*previous\s*style\b", _yesterday, "READ_LOCAL_FILE", False, False),
    ("compare_dna", r"\bcompare\s*dna\b", _compare, "READ_LOCAL_FILE", False, False),
    ("money", r"\bpaise\s*(da|ka)\s*hisab\b", _money, "READ_LOCAL_FILE", False, False),
    ("doctor", r"\bsystem\s*doctor\b", _doctor, "READ_LOCAL_FILE", False, False),
    ("resume", r"\bresume\b|\bdobara\s*chala\b|\bwapas\s*chalu\b", _resume, None, False, False),
    ("pause", r"\bpause\b|\bruk\s*ja\b|\brok\s*de\b", _pause, None, False, False),
    ("health", r"\bhealth\b|\bsab\s*theek\b", _health, "READ_LOCAL_FILE", False, False),
    ("open_workflow", r"^\s*open\s+(?P<arg>.+?)\s+workflow\s*$", _open_workflow, None, False, True),
    ("create_plan", r"\b(create|make|generate|edit|convert|resize|compress|export|render|banao|bana\s*de)\b.*\b(video|photo|picture|image|story|wallpaper|movie|reel|short|clip|film)\b", _create_plan, None, False, True),
    ("status", r"\bho\s*ja\s*shuru\b|^\s*(status|haal|kidda|kida)\b", _status, None, False, True),
]

RISKY_INTENTS = {"safe_mode", "emergency", "mission", "yesterday"}


def confidence_of(text: str, match: "re.Match") -> str:
    """HIGH/MEDIUM/LOW from how much of the message the matched phrase explains (+ any captured argument). Same function for voice and text."""
    words = max(1, len(text.split()))
    covered = max(1, len(text[match.start():match.end()].split()))
    share = covered / words
    return "HIGH" if share >= 0.5 else ("MEDIUM" if share >= 0.25 else "LOW")


def handle(text: str, *, principal: Dict[str, Any], source: str = "text", db_path: str = DEFAULT_DB_PATH, voice_verified: bool = False,
           totp_code: str = "", now: Optional[float] = None) -> Dict[str, Any]:
    now = time.time() if now is None else now
    text = (text or "").strip()
    if not text or len(text) > 500:
        return {"status": "INVALID", "message": "Say or type a goal (max 500 characters)."}
    role = principal.get("role", "guest")
    actor = f"{role}:{principal.get('id', '-')}:{source}"
    if source == "voice":
        if not voice_enabled(db_path):
            return {"status": "VOICE_OFF", "message": "Voice is off. Nothing was processed."}
        if policy.is_safe_mode(db_path):
            return {"status": "MUTED", "message": "Safe mode is on: voice is muted."}
        if not voice_verified:
            role = "guest"  # unknown voice never gets owner-level access
    elif source not in ("text", "touch"):  # touch = tapping a creator folder; it is the SAME command path/permissions as typed text
        return {"status": "INVALID", "message": "source must be text, touch or voice"}

    intent = None
    conf = "LOW"
    for name, rx, fn, perm, sensitive, guest_ok in INTENTS:
        m = re.search(rx, text, re.I)
        if m:
            intent, arg = (name, fn, perm, sensitive, guest_ok), (m.groupdict().get("arg") or "").strip()
            if name in ("resume", "pause") and not arg:  # target words = everything except the verb
                arg = (text[:m.start()] + " " + text[m.end():]).strip()
            conf = confidence_of(text, m)
            if name in ("mission", "attack", "clone_team") and arg:
                conf = "HIGH"  # explicit structured command with an argument
            if name == "create_plan":
                arg, conf = text, "HIGH"  # planning only: safe to answer, never executes anything
            break
    if not intent:
        record_audit("brain_command", actor, {"intent": None, "source": source, "text": redact_text(text)[:80]}, db_path)
        return {"status": "NEEDS_CLARIFICATION", "message": "I did not understand that goal. Try one of the examples.", "examples": HELP}
    name, fn, perm, sensitive, guest_ok = intent

    def done(res: Dict[str, Any]) -> Dict[str, Any]:
        res.setdefault("intent", name)
        res.setdefault("confidence", conf)
        res["source"] = source
        if source == "voice" and res.get("message"):
            res["speech"] = safe_to_speak(res["message"])
        record_audit("brain_command", actor, {"intent": name, "source": source, "status": res["status"], "text": redact_text(text)[:80]}, db_path)
        return res

    if conf == "LOW" or (conf == "MEDIUM" and (name in RISKY_INTENTS or sensitive or perm == "CHANGE_SECURITY")):
        # never guess: unsure => ask once; a risky action is never taken on a MEDIUM/LOW reading
        return done({"status": "NEEDS_CONFIRMATION", "message": f"Did you mean '{name.replace('_', ' ')}'? Say it plainly to confirm; nothing was done.", "candidate": name})
    if role == "guest" and not guest_ok:
        return done({"status": "DENIED", "message": "This voice/user is not authorised for that action."})
    if role in ("user", "device") and perm and not identity.has_permission(principal.get("id", ""), perm, db_path, now):
        return done({"status": "DENIED", "message": f"You have no active permission for this ({perm})."})
    if sensitive:
        enrolled = identity.totp_enrolled(db_path)
        if source == "voice" and not enrolled:
            return done({"status": "STEP_UP_REQUIRED", "message": "Sensitive action by voice needs 2FA; enrol TOTP first. Voice alone is never enough."})
        if enrolled:
            su = identity.step_up(totp_code, db_path, now)
            if su != "OK":
                return done({"status": "STEP_UP_REQUIRED", "message": "Give your one-time code to continue."})
    try:
        msg, data = fn({"db": db_path, "arg": arg, "now": now, "actor": actor, "owner": owner_key({"role": role, "id": principal.get("id", "-")})})
    except (ValueError, KeyError) as exc:
        return done({"status": "INVALID", "message": f"Could not do that: {str(exc)[:120]}"})
    return done({"status": (data.pop("status_override", "OK") if isinstance(data, dict) else "OK"), "message": msg, "data": data})
