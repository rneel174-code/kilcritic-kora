"""Single source of truth for capability state. Truthful vocabulary:
IMPLEMENTED_VERIFIED (real behaviour proven by a live probe), PLANNING_ONLY (plans/contracts, no real output),
NOT_IMPLEMENTED, READY_WITH_EXTERNAL_SETUP (code exists; credentials/approval needed), NOT_CONFIGURED, UNAVAILABLE.
Planning is never reported as implemented; code existing is never reported as ready."""
from __future__ import annotations
import importlib
import shutil
from typing import Any, Dict

CAPABILITIES = {
    "social.youtube": {"state": "READY_WITH_EXTERNAL_SETUP", "external": "OAuth/API project + audit may be required", "live_verified": False},
    "social.facebook": {"state": "READY_WITH_EXTERNAL_SETUP", "external": "Page token/permissions", "live_verified": False},
    "social.x": {"state": "READY_WITH_EXTERNAL_SETUP", "external": "OAuth2 user token", "live_verified": False},
    "social.instagram": {"state": "READY_WITH_EXTERNAL_SETUP", "external": "Professional account + Graph permissions + public HTTPS media", "live_verified": False},
    "social.tiktok": {"state": "READY_WITH_EXTERNAL_SETUP", "external": "video.publish approval + user authorization", "live_verified": False},
    "studio.pipeline": {"state": "PLANNING_ONLY", "external": "Plans/contracts and quality gates only; no editor output is produced", "live_verified": False},
    "media.create": {"state": "NOT_IMPLEMENTED", "external": "No video/photo/story generator exists; do not claim output", "live_verified": False},
    "media.convert": {"state": "PROBE", "external": "ffmpeg + ffprobe binaries", "live_verified": False},
    "media.quality_verify": {"state": "PROBE", "external": "ffprobe binary", "live_verified": False},
    "resource.guards": {"state": "IMPLEMENTED_VERIFIED", "external": "None", "live_verified": True},
    "encrypted.local.vault": {"state": "PROBE", "external": "cryptography package", "live_verified": False},
    "notification.outbox": {"state": "READY_WITH_EXTERNAL_SETUP", "external": "Delivery provider required for push/email/SMS/WhatsApp/Telegram", "live_verified": False},
    "self_evolution.governed": {"state": "IMPLEMENTED_VERIFIED", "external": "Owner approval for production mutation", "live_verified": True},
    "live.trends": {"state": "READY_WITH_EXTERNAL_SETUP", "external": "Search/provider credentials or public sources", "live_verified": False},
    "passkeys": {"state": "UNAVAILABLE", "external": "WebAuthn integration still required", "live_verified": False},
}


def _probe(key: str) -> Dict[str, Any]:
    if key == "media.convert":
        ok = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))
        try:
            from kora.services import media_pipeline
            ok = ok and hasattr(media_pipeline, "convert_variant")
        except Exception:
            ok = False
        return {"state": "IMPLEMENTED_VERIFIED" if ok else "UNAVAILABLE", "live_verified": ok}
    if key == "media.quality_verify":
        ok = bool(shutil.which("ffprobe"))
        return {"state": "IMPLEMENTED_VERIFIED" if ok else "UNAVAILABLE", "live_verified": ok}
    if key == "encrypted.local.vault":
        try:
            importlib.import_module("cryptography")
            return {"state": "IMPLEMENTED_VERIFIED", "live_verified": True}
        except Exception:
            return {"state": "UNAVAILABLE", "live_verified": False}
    return {}


def audit() -> Dict[str, Any]:
    caps = {}
    for k, v in CAPABILITIES.items():
        item = dict(v)
        if item["state"] == "PROBE":
            item.update(_probe(k))
        caps[k] = item
    counts: Dict[str, int] = {}
    for x in caps.values():
        counts[x["state"]] = counts.get(x["state"], 0) + 1
    return {"capabilities": caps, "counts": counts,
            "truth_rule": "Planning is not implementation; code is not readiness; no credential/approval is inferred from source."}
