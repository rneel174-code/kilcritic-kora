"""Region-aware defaults for Canada, United States and India.

Country profiles change localization/compliance defaults only; they never bypass
platform permissions, OAuth, tax rules, or local laws. The active profile is
selected by KORA_REGION (default IN) and can be overridden per job.
"""
from __future__ import annotations
import json
import os
from pathlib import Path
from typing import Any, Dict

ROOT = Path(__file__).resolve().parents[2]
PROFILE_FILE = ROOT / "config" / "regional_profiles.json"


def load_profiles() -> Dict[str, Any]:
    return json.loads(PROFILE_FILE.read_text(encoding="utf-8"))


def get_region(code: str | None = None) -> Dict[str, Any]:
    profiles = load_profiles()
    key = (code or os.getenv("KORA_REGION", "IN")).upper().strip()
    if key not in profiles["regions"]:
        raise ValueError(f"unsupported region: {key}; use CA, US or IN")
    return {"code": key, **profiles["regions"][key]}


def localized_defaults(code: str | None = None) -> Dict[str, Any]:
    r = get_region(code)
    return {
        "region": r["code"],
        "timezone": r["timezone"],
        "currency": r["currency"],
        "locale": r["locale"],
        "languages": r["languages"],
        "amazon": r["amazon"],
        "compliance": r["compliance"],
        "content": r["content"],
    }
