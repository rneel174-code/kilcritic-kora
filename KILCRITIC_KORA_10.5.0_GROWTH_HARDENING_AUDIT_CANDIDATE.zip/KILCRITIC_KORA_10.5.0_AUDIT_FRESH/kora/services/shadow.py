"""ATMA Shadow: an isolated, read-only/private place to preview and experiment. Never touches production.

* `preview_post` opens the production DB READ-ONLY and returns a Shadow Publish report (PASS / AUTO-FIXED / BLOCKED / HUMAN REVIEW).
* `clone_state` copies the DB into <db dir>/shadow/ for safe experiments; `diff_counts` shows how a shadow differs from
  production. Nothing in a shadow is ever copied back automatically.
* No surveillance: it only ever looks at KORA's own data. Performance is reported as UNAVAILABLE (no analytics source exists).
"""
import hashlib
import os
import re
import sqlite3
import time
from typing import Any, Dict, List

from kora.core.contracts import new_id
from kora.core.db import DEFAULT_DB_PATH
from kora.services import legal_guard
from kora.services.publishers import credential_requirements, missing_credentials


def _ro(db_path: str) -> sqlite3.Connection:
    c = sqlite3.connect(f"file:{os.path.abspath(db_path)}?mode=ro", uri=True, timeout=10)
    c.row_factory = sqlite3.Row
    return c


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip().lower())


def duplicate_of(content: str, db_path: str, exclude_id: str = "", days: int = 30) -> List[str]:
    key = hashlib.sha256(_norm(content).encode()).hexdigest()
    c = _ro(db_path)
    try:
        rows = c.execute("SELECT id,content FROM social_posts WHERE status!='REJECTED' AND created_at>?;", (time.time() - days * 86400,)).fetchall()
    finally:
        c.close()
    return [r["id"] for r in rows if r["id"] != exclude_id and hashlib.sha256(_norm(r["content"]).encode()).hexdigest() == key]


def preview_post(post_id: str, db_path: str = DEFAULT_DB_PATH, env=None) -> Dict[str, Any]:
    env = os.environ if env is None else env
    c = _ro(db_path)
    try:
        p = c.execute("SELECT * FROM social_posts WHERE id=?;", (post_id,)).fetchone()
        prov = [dict(r) for r in c.execute("SELECT source,tool,license,rights,verification FROM provenance WHERE subject_type='post' AND subject_id=?;", (post_id,)).fetchall()]
    finally:
        c.close()
    if not p:
        return {"status": "NOT_FOUND"}
    dups = duplicate_of(p["content"], db_path, exclude_id=post_id)
    rights = next((x["rights"] for x in prov if x["rights"]), "")
    pf = legal_guard.preflight({"platform": p["platform"], "content": p["content"], "audience": p["audience"], "media": bool(p["media_path"]),
                                "rights": rights, "duplicate_risk": bool(dups)})
    req = credential_requirements(p["platform"])
    miss = missing_credentials(p["platform"], env) if req["implemented"] else []
    issues = list(pf["issues"])
    if not req["implemented"]:
        issues.append("platform_adapter_not_implemented")
    if miss:
        issues.append("credentials_missing:" + ",".join(miss))
    status = {"PASS": "PASS", "AUTO_FIXED": "AUTO-FIXED", "HUMAN_REVIEW": "HUMAN REVIEW", "BLOCKED": "BLOCKED"}[pf["status"]]
    if status in ("PASS", "AUTO-FIXED") and (not req["implemented"] or miss):
        status = "HUMAN REVIEW"
    return {"status": status, "post_id": post_id, "platform": p["platform"], "issues": issues, "auto_fixes": pf["fixes"],
            "duplicate_of": dups, "provenance_records": len(prov), "rights": rights or "UNDECLARED",
            "estimated_performance": {"status": "UNAVAILABLE", "reason": "no analytics data source connected", "guarantee": False},
            "legal_guarantee": False, "read_only": True}


def clone_state(db_path: str = DEFAULT_DB_PATH) -> str:
    d = os.path.join(os.path.dirname(os.path.abspath(db_path)), "shadow")
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, new_id("shadow") + ".db")
    src = _ro(db_path)
    dst = sqlite3.connect(path)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    return path


def diff_counts(db_path: str, shadow_path: str) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    a, b = _ro(db_path), _ro(shadow_path)
    try:
        for t in ("jobs", "social_posts", "cron_jobs", "rag_docs", "proposals", "principals"):
            try:
                x, y = a.execute(f"SELECT COUNT(*) FROM {t};").fetchone()[0], b.execute(f"SELECT COUNT(*) FROM {t};").fetchone()[0]
            except sqlite3.OperationalError:
                continue
            if x != y:
                out[t] = {"production": x, "shadow": y}
    finally:
        a.close()
        b.close()
    return {"differs": bool(out), "tables": out, "applied_to_production": False}


def discard(path: str) -> bool:
    if os.path.basename(os.path.dirname(os.path.abspath(path))) != "shadow" or not path.endswith(".db"):
        raise ValueError("not a shadow file")
    try:
        os.remove(path)
        return True
    except FileNotFoundError:
        return False
