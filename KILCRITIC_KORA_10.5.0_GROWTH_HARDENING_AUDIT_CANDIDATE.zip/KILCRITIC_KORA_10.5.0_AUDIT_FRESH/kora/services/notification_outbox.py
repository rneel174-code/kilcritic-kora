"""Durable notification outbox: queues truthful events for a configured delivery worker."""
from __future__ import annotations
import json, time, uuid
from kora.core.db import get_connection, DEFAULT_DB_PATH

def init(db_path: str = DEFAULT_DB_PATH) -> None:
    c=get_connection(db_path)
    try:
        c.execute('''CREATE TABLE IF NOT EXISTS notification_outbox (id TEXT PRIMARY KEY, channel TEXT NOT NULL, payload TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'PENDING', attempts INTEGER NOT NULL DEFAULT 0, created_at REAL NOT NULL, sent_at REAL)''')
    finally: c.close()

def enqueue(channel: str, payload: dict, db_path: str = DEFAULT_DB_PATH) -> str:
    init(db_path); ident='notif-'+uuid.uuid4().hex[:12]
    c=get_connection(db_path)
    try: c.execute('INSERT INTO notification_outbox VALUES (?,?,?,?,?,?,?)',(ident,channel,json.dumps(payload), 'PENDING',0,time.time(),None))
    finally: c.close()
    return ident

def pending(limit: int = 50, db_path: str = DEFAULT_DB_PATH):
    init(db_path); c=get_connection(db_path)
    try: return [dict(x) for x in c.execute('SELECT * FROM notification_outbox WHERE status=\'PENDING\' ORDER BY created_at LIMIT ?', (max(1,min(500,limit)),)).fetchall()]
    finally: c.close()
