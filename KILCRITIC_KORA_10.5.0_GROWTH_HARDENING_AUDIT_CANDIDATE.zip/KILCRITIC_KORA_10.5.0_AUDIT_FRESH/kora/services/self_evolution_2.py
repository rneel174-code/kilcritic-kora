"""KORA Self-Evolution 2.0 intelligence layer.

Adds continuous audit, evidence-backed improvement ranking, dependency awareness,
regression memory, and resource-aware evolution planning on top of the governed
Self-Evolution 1.0 engine. It NEVER applies production changes by itself.
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from kora.core.db import DEFAULT_DB_PATH, get_connection, record_audit, set_setting
from kora.services import ops
from kora.services import self_evolution as se

STATE_KEY = "self_evolution_2_state"
WATCH_KEYS = (
    "BRAVE_SEARCH_API_KEY", "OPENAI_API_KEY", "GEMINI_API_KEY", "GROQ_API_KEY",
    "OPENROUTER_API_KEY", "YOUTUBE_API_KEY", "FACEBOOK_ACCESS_TOKEN",
    "INSTAGRAM_ACCESS_TOKEN", "TIKTOK_ACCESS_TOKEN", "X_API_KEY",
)


def _json_setting(db_path: str) -> Dict[str, Any]:
    from kora.core.db import get_setting
    raw = get_setting(STATE_KEY, "{}", db_path)
    try:
        return json.loads(raw or "{}")
    except Exception:
        return {}


def _save_state(state: Dict[str, Any], db_path: str) -> None:
    set_setting(STATE_KEY, json.dumps(state, sort_keys=True)[:50000], db_path)


def _hash_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def repository_fingerprint(root: Optional[str] = None) -> Dict[str, Any]:
    r = se.repo_root(root)
    files = se._files(r)
    rows = []
    for p in files:
        try:
            rows.append({"path": str(p.relative_to(r)), "sha256": _hash_file(p), "bytes": p.stat().st_size})
        except OSError:
            continue
    digest = hashlib.sha256("".join(x["path"] + ":" + x["sha256"] for x in rows).encode()).hexdigest()
    return {"root": str(r), "file_count": len(rows), "sha256": digest, "files": rows[:500]}


def dependency_status(env: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    env = os.environ if env is None else env
    configured = []
    missing = []
    for key in WATCH_KEYS:
        (configured if str(env.get(key, "")).strip() else missing).append(key)
    return {"configured": configured, "missing": missing,
            "note": "Missing credentials are not failures; they become actionable only when a task needs them."}


def regression_history(db_path: str = DEFAULT_DB_PATH, limit: int = 20) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        rows = conn.execute(
            "SELECT event_type,actor,details,created_at FROM audit_events "
            "WHERE event_type IN ('self_evolution_applied','self_evolution_rollback','governed_failed','self_evolution_2_audit') "
            "ORDER BY id DESC LIMIT ?;", (max(1, min(100, limit)),)
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def improvement_candidates(scan: Dict[str, Any], deps: Dict[str, Any], resources: Dict[str, Any],
                           history: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    candidates: List[Dict[str, Any]] = []
    for gap in scan.get("gaps", []):
        sev = gap.get("severity", "MEDIUM")
        score = {"CRITICAL": 100, "HIGH": 85, "MEDIUM": 60, "LOW": 35}.get(sev, 50)
        candidates.append({"id": gap.get("id", "UNKNOWN"), "priority": score, "severity": sev,
                           "reason": gap.get("reason", ""), "action": "prepare_governed_proposal"})
    if resources.get("process_max_rss_mb", 0) > 1024:
        candidates.append({"id": "RESOURCE_MEMORY_REVIEW", "priority": 70, "severity": "MEDIUM",
                           "reason": "Measured process RSS exceeded 1 GB during audit.", "action": "profile_before_change"})
    if any(x.get("event_type") == "self_evolution_rollback" for x in history):
        candidates.append({"id": "REGRESSION_REVIEW", "priority": 80, "severity": "HIGH",
                           "reason": "A previous self-evolution rollback exists; review its guard before the next evolution.",
                           "action": "regression_review"})
    if deps.get("missing"):
        candidates.append({"id": "DEPENDENCY_AWARENESS", "priority": 25, "severity": "LOW",
                           "reason": "Some optional provider credentials are not configured.",
                           "action": "ask_only_when_task_requires_it"})
    # Deduplicate by id and sort by score, not by arbitrary discovery order.
    best: Dict[str, Dict[str, Any]] = {}
    for c in candidates:
        if c["id"] not in best or c["priority"] > best[c["id"]]["priority"]:
            best[c["id"]] = c
    return sorted(best.values(), key=lambda x: (-x["priority"], x["id"]))[:20]


def audit(root: Optional[str] = None, db_path: str = DEFAULT_DB_PATH, env: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """Run a lightweight self-audit. It observes; it never modifies production code."""
    r = se.repo_root(root)
    scan = se.scan(str(r), db_path)
    deps = dependency_status(env)
    res = ops.resources(db_path)
    history = regression_history(db_path)
    fp = repository_fingerprint(str(r))
    candidates = improvement_candidates(scan, deps, res, history)
    state = {
        "last_audit": time.time(), "fingerprint": fp["sha256"],
        "candidate_ids": [x["id"] for x in candidates], "candidate_count": len(candidates),
    }
    _save_state(state, db_path)
    record_audit("self_evolution_2_audit", "system", {
        "fingerprint": fp["sha256"], "candidates": [x["id"] for x in candidates[:10]],
        "resource_rss_mb": res.get("process_max_rss_mb"),
    }, db_path)
    return {"status": "AUDITED", "scan": scan, "resources": res, "dependencies": deps,
            "repository": {k: fp[k] for k in ("file_count", "sha256")},
            "regression_history": history, "improvements": candidates, "auto_apply": False}


def evolution_plan(goal: str, root: Optional[str] = None, db_path: str = DEFAULT_DB_PATH,
                   env: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """Turn an owner/user goal into a bounded improvement plan; does not mutate code."""
    a = audit(root, db_path, env)
    goal = (goal or "").strip()[:500]
    priorities = a["improvements"]
    if goal:
        priorities = [{"id": "OWNER_GOAL", "priority": 95, "severity": "HIGH", "reason": goal,
                       "action": "use_existing_self_evolution_prepare"}] + priorities
    return {
        "status": "PLAN_READY", "goal": goal, "steps": [
            "inspect existing capability", "research authorized solution", "build evidence-backed proposal",
            "owner approval for production change", "isolated patch", "compile/tests", "canary",
            "apply", "verify", "rollback on failure", "record regression guard"
        ], "top_improvements": priorities[:10], "audit": a, "production_mutation": False,
    }
