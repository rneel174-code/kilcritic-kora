"""Dharma: Malak (owner preferences) + Auto Sudhaar (bounded self-repair).

Malak rules are a CLOSED whitelist of cosmetic/behavioural preferences with validators, versioned with history and
rollback, stored in the settings table. Anything about security, auth, legal, platform, permissions, resources or
truth is not a rule key at all - a preference can never switch those off or turn a falsehood into a fact.
"""
import json
import time
from typing import Any, Callable, Dict, Optional

from kora.core.contracts import Risk
from kora.core.db import DEFAULT_DB_PATH, get_setting, record_audit, set_setting

KEY = "malak_rules"
MAX_HISTORY = 200

RULES: Dict[str, Callable[[Any], bool]] = {
    "tone": lambda v: v in ("neutral", "friendly", "formal", "casual"),
    "language_mix": lambda v: isinstance(v, str) and 0 < len(v) <= 40,
    "emoji_level": lambda v: v in ("none", "low", "medium", "high"),
    "default_audience": lambda v: v in ("KIDS", "GENERAL", "ADULT"),
    "report_verbosity": lambda v: v in ("short", "normal", "detailed"),
    "auto_hashtags": lambda v: isinstance(v, bool),
}


class MalakViolation(ValueError):
    pass


def _load(db_path: str) -> Dict[str, Any]:
    raw = get_setting(KEY, None, db_path)
    if not raw:
        return {"version": 1, "rules": {}, "history": []}
    return json.loads(raw)


def _save(data: Dict[str, Any], db_path: str) -> None:
    data["history"] = data["history"][-MAX_HISTORY:]
    set_setting(KEY, json.dumps(data), db_path)


def get_rules(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    d = _load(db_path)
    return {"version": d["version"], "rules": dict(d["rules"]), "configurable": sorted(RULES)}


def get_rule(key: str, default: Any = None, db_path: str = DEFAULT_DB_PATH) -> Any:
    return _load(db_path)["rules"].get(key, default)


def set_rule(key: str, value: Any, actor: str = "owner", db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    if key not in RULES:
        raise MalakViolation(f"'{key}' is not a configurable preference (security, legal, platform, permission, resource and truth settings cannot be changed by preference)")
    if not RULES[key](value):
        raise MalakViolation(f"invalid value for '{key}'")
    d = _load(db_path)
    d["version"] += 1
    d["rules"][key] = value
    d["history"].append({"version": d["version"], "key": key, "value": value, "actor": actor, "at": time.time()})
    _save(d, db_path)
    record_audit("malak_set", actor, {"key": key, "version": d["version"]}, db_path)
    return get_rules(db_path)


def rollback(to_version: int, actor: str = "owner", db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Rebuild the rule set as it was at `to_version` (history replay); recorded as a NEW version, nothing is erased."""
    d = _load(db_path)
    if not isinstance(to_version, int) or to_version < 1 or to_version > d["version"]:
        raise MalakViolation("unknown version")
    rules: Dict[str, Any] = {}
    for h in d["history"]:
        if h["version"] <= to_version:
            rules[h["key"]] = h["value"]
    d["version"] += 1
    d["rules"] = rules
    d["history"].append({"version": d["version"], "key": "*", "value": f"rollback_to_{to_version}", "actor": actor, "at": time.time()})
    _save(d, db_path)
    record_audit("malak_rollback", actor, {"to": to_version, "version": d["version"]}, db_path)
    return get_rules(db_path)


def repair_flow(detect: Callable[[], Any], repair: Callable[[], Any], test: Callable[[], bool], verify: Callable[[], bool],
                rollback_fn: Callable[[], Any], risk: Risk = Risk.LOW) -> Dict[str, Any]:
    """DETECT -> REPAIR -> TEST -> VERIFY, rollback on failure OR exception. HIGH/CRITICAL never auto-repair."""
    if risk in (Risk.HIGH, Risk.CRITICAL):
        return {"status": "APPROVAL_REQUIRED"}
    try:
        issue = detect()
    except Exception as exc:  # noqa: BLE001
        return {"status": "DETECT_FAILED", "error": str(exc)[:200]}
    if not issue:
        return {"status": "NO_ISSUE"}
    try:
        repair()
        ok = bool(test()) and bool(verify())
        err = "" if ok else "verification_failed"
    except Exception as exc:  # noqa: BLE001
        ok, err = False, f"{exc.__class__.__name__}: {str(exc)[:200]}"
    if ok:
        return {"status": "REPAIRED"}
    try:
        rollback_fn()
        return {"status": "ROLLED_BACK", "error": err}
    except Exception as exc:  # noqa: BLE001
        return {"status": "ROLLBACK_FAILED", "error": err, "rollback_error": str(exc)[:200]}
