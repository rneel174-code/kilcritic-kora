"""
KORA 8.8.5 - Truthful Voice STT Pipeline with Bounded-Memory Stream Handling
Supported Provider Cascade: Groq -> OpenAI -> local Whisper -> fallback unavailable
Never fakes completion. Truthfully returns 'transcription_unavailable' if no provider is configured.
"""
import os
import shutil
import urllib.request
import urllib.error
import json
from typing import Dict, Any, Optional, Tuple

MAX_AUDIO_BYTES = 25 * 1024 * 1024  # 25 MB
ALLOWED_AUDIO_EXTENSIONS = {".mp3", ".wav", ".m4a", ".ogg", ".flac", ".webm"}

class AudioValidationError(Exception):
    pass

def validate_audio_file(filepath: str) -> Tuple[int, str]:
    """Validates audio file bounds, extension, and non-empty content without whole-file memory loading."""
    if not os.path.exists(filepath):
        raise AudioValidationError(f"Audio file does not exist: {filepath}")

    ext = os.path.splitext(filepath)[1].lower()
    if ext not in ALLOWED_AUDIO_EXTENSIONS:
        raise AudioValidationError(f"Invalid audio extension '{ext}'. Allowed: {ALLOWED_AUDIO_EXTENSIONS}")

    size = os.path.getsize(filepath)
    if size == 0:
        raise AudioValidationError("Audio upload is empty (0 bytes).")
    if size > MAX_AUDIO_BYTES:
        raise AudioValidationError(f"Audio file exceeds maximum size limit of {MAX_AUDIO_BYTES} bytes (actual: {size}).")

    # Inspect first 16 bytes for valid container signatures
    with open(filepath, "rb") as f:
        header = f.read(16)
        if ext == ".wav" and not (header.startswith(b"RIFF") or b"WAVE" in header):
            raise AudioValidationError("Corrupt or invalid WAV header signature.")
        elif ext == ".ogg" and not header.startswith(b"OggS"):
            raise AudioValidationError("Corrupt or invalid OGG header signature.")
        elif ext == ".flac" and not header.startswith(b"fLaC"):
            raise AudioValidationError("Corrupt or invalid FLAC header signature.")

    return size, ext

def _execute_multipart_stt(url: str, filepath: str, model_name: str, api_key: str) -> Optional[str]:
    """Generic multipart form-data dispatcher for OpenAI-compatible audio endpoints."""
    boundary = "----KoraBoundary7MA4YWxkTrZu0gW"
    filename = os.path.basename(filepath)

    with open(filepath, "rb") as f:
        file_bytes = f.read()

    body = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="model"\r\n\r\n'
        f"{model_name}\r\n"
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n'
        f"Content-Type: audio/mpeg\r\n\r\n"
    ).encode("utf-8") + file_bytes + f"\r\n--{boundary}--\r\n".encode("utf-8")

    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": f"multipart/form-data; boundary={boundary}"
        }
    )

    try:
        with urllib.request.urlopen(req, timeout=30.0) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            text = data.get("text", "").strip()
            # Strictly reject empty transcripts: must not return completed with empty string
            return text if text else None
    except Exception:
        return None

def transcribe_with_groq(filepath: str, api_key: str) -> Optional[str]:
    """Real Groq Whisper API client."""
    if not api_key:
        return None
    url = "https://api.groq.com/openai/v1/audio/transcriptions"
    return _execute_multipart_stt(url, filepath, "whisper-large-v3-turbo", api_key)

def transcribe_with_openai(filepath: str, api_key: str) -> Optional[str]:
    """Real OpenAI Whisper API client."""
    if not api_key:
        return None
    url = "https://api.openai.com/v1/audio/transcriptions"
    return _execute_multipart_stt(url, filepath, "whisper-1", api_key)

def transcribe_audio_pipeline(filepath: str, preferred_provider: Optional[str] = None) -> Dict[str, Any]:
    """
    Executes truthful transcription cascade.
    If no valid provider credentials or engine are available, truthfully returns
    status='transcription_unavailable' and ok=False.
    Never returns completed with an empty transcript.
    """
    size, ext = validate_audio_file(filepath)

    groq_key = os.environ.get("GROQ_API_KEY")
    openai_key = os.environ.get("OPENAI_API_KEY")

    # Provider 1: Groq (if configured)
    if (preferred_provider == "groq" or not preferred_provider) and groq_key:
        result = transcribe_with_groq(filepath, groq_key)
        if result:
            return {
                "ok": True,
                "status": "COMPLETED",
                "provider": "groq_whisper",
                "transcript": result,
                "bytes_processed": size
            }

    # Provider 2: OpenAI (if configured)
    if (preferred_provider == "openai" or not preferred_provider) and openai_key:
        result = transcribe_with_openai(filepath, openai_key)
        if result:
            return {
                "ok": True,
                "status": "COMPLETED",
                "provider": "openai_whisper",
                "transcript": result,
                "bytes_processed": size
            }

    # Provider 3: local Whisper (check if installed)
    try:
        import whisper  # type: ignore
        model = whisper.load_model("tiny")
        res = model.transcribe(filepath)
        text = res.get("text", "").strip()
        if text:
            return {
                "ok": True,
                "status": "COMPLETED",
                "provider": "local_whisper",
                "transcript": text,
                "bytes_processed": size
            }
    except ImportError:
        pass
    except Exception:
        pass

    # Truthful fallback: No provider exists or was configured
    return {
        "ok": False,
        "status": "transcription_unavailable",
        "provider": "none",
        "transcript": "",
        "message": "No functional STT provider credentials (GROQ_API_KEY, OPENAI_API_KEY) or local Whisper installed. Truthfully reported as transcription_unavailable."
    }
