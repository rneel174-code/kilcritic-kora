"""
KORA PRO - Web research (fetch + extract), SSRF-guarded.

* `fetch_page(url)`: https only, public addresses only (every DNS answer checked), no userinfo, port 443 only,
  redirects followed manually (max 3) and re-validated at every hop, body capped, text-like content types only.
* HTML -> plain text with the stdlib parser (script/style/nav stripped). Fetched text is UNTRUSTED DATA.
* `search_web(query)`: uses Brave Search API only if BRAVE_SEARCH_API_KEY is configured; otherwise reports
  CONFIGURATION_REQUIRED (it never fabricates search results). You can always research explicit URLs.
* Known residual risk: DNS rebinding between validation and connect (documented, not claimed solved).
"""
import json
import re
import urllib.error
import urllib.parse
import urllib.request
from html.parser import HTMLParser
from typing import Any, Callable, Dict, List, Optional, Tuple

from kora.core.http import TransportError, https_request
from kora.core.security import _default_resolver, validate_public_url

ALLOWED_TYPES = ("text/html", "text/plain", "application/xhtml+xml", "application/json", "text/markdown", "application/xml", "text/xml")
MAX_REDIRECTS = 3


class ResearchError(Exception):
    def __init__(self, code: str, detail: str = ""):
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code = code


class _TextExtractor(HTMLParser):
    SKIP = {"script", "style", "noscript", "svg", "head", "nav", "footer", "form", "iframe"}
    BLOCK = {"p", "div", "br", "li", "h1", "h2", "h3", "h4", "h5", "h6", "tr", "section", "article"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts: List[str] = []
        self.title = ""
        self._skip = 0
        self._in_title = False

    def handle_starttag(self, tag, attrs):
        if tag == "title":
            self._in_title = True
        if tag in self.SKIP:
            self._skip += 1
        elif tag in self.BLOCK:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False
        if tag in self.SKIP and self._skip:
            self._skip -= 1

    def handle_data(self, data):
        if self._in_title:
            self.title += data
        elif not self._skip:
            self.parts.append(data)


def html_to_text(html: str) -> Tuple[str, str]:
    p = _TextExtractor()
    try:
        p.feed(html)
        p.close()
    except Exception:
        pass
    text = re.sub(r"[ \t\r\f\v]+", " ", "".join(p.parts))
    text = re.sub(r"\n\s*\n+", "\n\n", text).strip()
    return p.title.strip()[:300], text


def default_fetcher(url: str, timeout: float, max_bytes: int) -> Tuple[int, Dict[str, str], bytes]:
    """One HTTP GET, no redirects (handled by caller). Uses the stdlib directly because the target is arbitrary
    public web, which is validated by `validate_public_url` rather than the API allowlist."""
    from kora.core.http import _NoRedirect  # single shared no-redirect handler
    opener = urllib.request.build_opener(_NoRedirect)
    req = urllib.request.Request(url, headers={"User-Agent": "KORA-Research/1.0", "Accept": "text/html,text/plain,application/json;q=0.8"})
    try:
        resp = opener.open(req, timeout=timeout)
    except urllib.error.HTTPError as e:
        resp = e
    except (urllib.error.URLError, OSError) as e:
        raise ResearchError("network_error", str(getattr(e, "reason", e))[:200])
    try:
        data = resp.read(max_bytes + 1)
        return getattr(resp, "status", None) or resp.code, {k.lower(): v for k, v in resp.headers.items()}, data
    finally:
        resp.close()


def fetch_page(url: str, max_bytes: int = 2 * 1024 * 1024, timeout: float = 10.0, allowed_domains=(),
               fetcher: Callable = default_fetcher, resolver: Callable = _default_resolver) -> Dict[str, Any]:
    current = url
    for _hop in range(MAX_REDIRECTS + 1):
        ok, why = validate_public_url(current, allowed_domains, resolver)
        if not ok:
            raise ResearchError("url_blocked", why)
        status, headers, body = fetcher(current, timeout, max_bytes)
        if status in (301, 302, 303, 307, 308):
            loc = headers.get("location", "")
            if not loc:
                raise ResearchError("bad_redirect")
            current = urllib.parse.urljoin(current, loc)
            continue
        if status != 200:
            raise ResearchError("http_status", str(status))
        if len(body) > max_bytes:
            raise ResearchError("response_too_large", f">{max_bytes}")
        ctype = headers.get("content-type", "").split(";")[0].strip().lower()
        if ctype and ctype not in ALLOWED_TYPES:
            raise ResearchError("content_type_not_allowed", ctype)
        m = re.search(r"charset=([\w\-]+)", headers.get("content-type", ""), re.I)
        try:
            raw = body.decode(m.group(1) if m else "utf-8", errors="replace")
        except LookupError:
            raw = body.decode("utf-8", errors="replace")
        if ctype in ("text/html", "application/xhtml+xml", ""):
            title, text = html_to_text(raw)
        else:
            title, text = "", raw.strip()
        if len(text) < 20:
            raise ResearchError("no_extractable_text")
        from kora.core.security import scan_injection
        inj = scan_injection(text)  # page text is untrusted data; instruction-like lines are removed, never obeyed
        return {"ok": True, "url": current, "title": title, "text": inj["text"], "bytes": len(body), "content_type": ctype,
                "injection_flagged": inj["flagged"], "injection_patterns": inj["patterns"]}
    raise ResearchError("too_many_redirects")


def search_web(query: str, env: Optional[Dict[str, str]] = None, transport: Callable = https_request, count: int = 5) -> Dict[str, Any]:
    import os
    env = os.environ if env is None else env
    key = (env.get("BRAVE_SEARCH_API_KEY") or "").strip()
    query = (query or "").strip()
    if not query:
        raise ResearchError("query_required")
    if not key:
        return {"ok": False, "status": "CONFIGURATION_REQUIRED", "error": "BRAVE_SEARCH_API_KEY is not set; pass explicit URLs to /api/research/fetch instead.", "results": []}
    url = "https://api.search.brave.com/res/v1/web/search?" + urllib.parse.urlencode({"q": query[:300], "count": max(1, min(10, count))})
    try:
        status, _h, data = transport("GET", url, {"Accept": "application/json", "X-Subscription-Token": key}, None, 15.0)
        if status != 200:
            return {"ok": False, "status": "PROVIDER_ERROR", "error": f"http_{status}", "results": []}
        items = (json.loads(data).get("web") or {}).get("results") or []
        return {"ok": True, "status": "OK", "results": [{"title": i.get("title", ""), "url": i.get("url", ""), "snippet": i.get("description", "")} for i in items[:count]]}
    except (TransportError, ValueError) as exc:
        return {"ok": False, "status": "PROVIDER_ERROR", "error": str(exc)[:200], "results": []}
