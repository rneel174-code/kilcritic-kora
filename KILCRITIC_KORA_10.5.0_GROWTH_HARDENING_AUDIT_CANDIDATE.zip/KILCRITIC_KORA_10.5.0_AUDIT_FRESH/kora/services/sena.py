"""SENA: bounded parallel workforce.

* Real threads, hard caps (jobs <= MAX_JOBS, workers <= MAX_WORKERS), per-job timeout, errors isolated per job,
  no nested spawning (a worker calling run_parallel is refused) -> no runaway agent creation.
* Optional checkpointing: with (task_id, db_path) finished results are saved, and a re-run with the same task_id skips
  jobs that already completed (crash/restart safe, no duplicate execution).  Results must be JSON-serialisable.
* `attack_plan` is a plan of angles (NOT results, NOT a cyber attack); `clone_team` assigns least-privilege permissions.
"""
import threading
import time
from typing import Any, Callable, Dict, List, Optional, Sequence

from kora.core.contracts import new_id
from kora.services import governance

MAX_JOBS = 20
MAX_WORKERS = 8
_ctx = threading.local()

ANGLES = ("research", "hook", "script", "thumbnail", "short", "long-form", "faq", "audience", "seo-metadata", "analytics-hypothesis")
ROLE_PERMISSIONS = {
    "researcher": ["WEB_SEARCH", "NETWORK_ACCESS", "READ_LOCAL_FILE"],
    "editor": ["READ_LOCAL_FILE", "WRITE_LOCAL_FILE"],
    "uploader": ["UPLOAD_EXTERNAL"],      # HIGH: every use still needs approval via the policy engine
    "analyst": ["READ_LOCAL_FILE"],
    "publisher": ["PUBLISH_SOCIAL"],      # HIGH: approval required
}


def attack_plan(topic: str) -> Dict[str, Any]:
    topic = (topic or "").strip()
    if not topic or len(topic) > 300:
        raise ValueError("topic must be 1-300 chars")
    return {"task_id": new_id("sena"), "topic": topic, "kind": "PLAN_ONLY",
            "angles": [{"angle": a, "brief": f"{a} for: {topic}"} for a in ANGLES]}


def clone_team(roles: Sequence[str]) -> Dict[str, Any]:
    roles = [str(r).strip().lower() for r in roles]
    if not roles or len(roles) > 10:
        raise ValueError("1-10 roles")
    bad = [r for r in roles if r not in ROLE_PERMISSIONS]
    if bad:
        raise ValueError(f"unknown roles: {bad}")
    return {"task_id": new_id("team"), "members": [{"role": r, "permissions": list(ROLE_PERMISSIONS[r])} for r in roles]}


def run_parallel(jobs: Sequence[Any], worker: Callable[[Any], Any], *, max_workers: int = 4, timeout: float = 60.0,
                 task_id: Optional[str] = None, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    if getattr(_ctx, "inside", False):
        raise RuntimeError("nested SENA runs are not allowed")
    jobs = list(jobs)
    if len(jobs) > MAX_JOBS:
        raise ValueError(f"too many jobs (max {MAX_JOBS})")
    workers = max(1, min(MAX_WORKERS, int(max_workers), len(jobs) or 1))
    done: Dict[str, Any] = {}
    if task_id and db_path:
        done = (governance.checkpoint_load(task_id, db_path) or {}).get("done", {})
    results: List[Optional[Dict[str, Any]]] = [None] * len(jobs)
    lock = threading.Lock()
    nxt = [0]
    deadline = time.monotonic() + timeout

    def save() -> None:
        if task_id and db_path:
            governance.checkpoint_save(task_id, {"done": done}, db_path)

    def run() -> None:
        _ctx.inside = True
        while True:
            with lock:
                i = nxt[0]
                if i >= len(jobs) or time.monotonic() >= deadline:
                    return
                nxt[0] += 1
            if str(i) in done:
                results[i] = {"index": i, "status": "OK", "result": done[str(i)], "resumed": True}
                continue
            try:
                out = worker(jobs[i])
                results[i] = {"index": i, "status": "OK", "result": out}
                if task_id and db_path:
                    with lock:
                        done[str(i)] = out
                        save()
            except Exception as exc:  # noqa: BLE001 - isolated: one failing agent never kills the others
                results[i] = {"index": i, "status": "ERROR", "error": f"{exc.__class__.__name__}: {str(exc)[:200]}"}

    threads = [threading.Thread(target=run, daemon=True, name=f"sena-{n}") for n in range(workers)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=max(0.0, deadline - time.monotonic()) + 0.05)
    with lock:  # snapshot: late threads cannot change what we return
        return [r or {"index": i, "status": "TIMEOUT" if i < nxt[0] else "NOT_RUN"} for i, r in enumerate(results)]
