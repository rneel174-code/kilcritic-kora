"""Dhanda: transparent cost/revenue ledger + honest opportunity scoring. Everything unverified is labelled ESTIMATE.

* Revenue only counts as ACTUAL with non-empty evidence (invoice id, payout reference...). Otherwise it is forced to
  ESTIMATED and never added to actual profit. No guaranteed income, no fabricated numbers.
"""
import time
from typing import Any, Dict, List

from kora.core.db import DEFAULT_DB_PATH, get_connection


REVENUE_STATUSES = ("ESTIMATE", "UNVERIFIED_ESTIMATE", "VERIFIED", "PAYOUT_RECEIVED")


def add_entry(kind: str, amount: float, note: str, currency: str = "USD", estimated: bool = False, evidence: str = "",
              db_path: str = DEFAULT_DB_PATH, *, source: str = "", fees: float = 0.0, payout_ref: str = "") -> Dict[str, Any]:
    """Revenue verifier. ESTIMATE = declared estimate; UNVERIFIED_ESTIMATE = claimed actual but no evidence (forced down);
    VERIFIED = evidence + source (platform/API receipt); PAYOUT_RECEIVED = also a payout reference. Costs are always actual."""
    if kind not in ("cost", "revenue") or not isinstance(amount, (int, float)) or not 0 < amount < 1e12 or not (note or "").strip():
        raise ValueError("kind cost|revenue, amount > 0 and a note are required")
    if not isinstance(fees, (int, float)) or fees < 0 or fees > amount:
        raise ValueError("fees must be >= 0 and not exceed the amount")
    ev, src, ref = (evidence or "").strip(), (source or "").strip(), (payout_ref or "").strip()
    if kind == "cost":
        status = "VERIFIED" if ev else "ESTIMATE" if estimated else "UNVERIFIED_ESTIMATE"
    elif estimated:
        status = "ESTIMATE"
    elif ev and src:
        status = "PAYOUT_RECEIVED" if ref else "VERIFIED"
    else:
        status = "UNVERIFIED_ESTIMATE"
    est = status in ("ESTIMATE", "UNVERIFIED_ESTIMATE")
    conn = get_connection(db_path)
    try:
        cur = conn.execute("INSERT INTO ledger(kind,amount,currency,estimated,note,evidence,created_at,status,fees,source) VALUES (?,?,?,?,?,?,?,?,?,?);",
                           (kind, float(amount), currency[:6].upper(), int(est), note[:300], (ev + (f" payout:{ref}" if ref else ""))[:300], time.time(), status, float(fees), src[:100]))
    finally:
        conn.close()
    return {"id": cur.lastrowid, "kind": kind, "status": status, "estimated": est,
            "warning": "claimed actual revenue without evidence+source is stored as UNVERIFIED_ESTIMATE" if (kind == "revenue" and not estimated and est) else ""}


def summary(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    conn = get_connection(db_path)
    try:
        rows = conn.execute("SELECT kind,estimated,currency,SUM(amount) s,SUM(fees) f FROM ledger GROUP BY kind,estimated,currency;").fetchall()
    finally:
        conn.close()
    out: Dict[str, Any] = {}
    for r in rows:
        cur = out.setdefault(r["currency"], {"actual_cost": 0.0, "actual_revenue": 0.0, "actual_fees": 0.0, "estimated_cost": 0.0, "estimated_revenue": 0.0})
        cur[("estimated_" if r["estimated"] else "actual_") + r["kind"]] = r["s"]
        if r["kind"] == "revenue" and not r["estimated"]:
            cur["actual_fees"] = r["f"] or 0.0
    for cur in out.values():
        cur["actual_net_profit"] = round(cur["actual_revenue"] - cur["actual_fees"] - cur["actual_cost"], 2)
        cur["note"] = "net profit uses VERIFIED/PAYOUT_RECEIVED revenue and verified costs only; estimates are shown separately"
    return out


FACTORS = ("opportunity", "demand", "competition", "effort", "cost", "risk", "monetization")


def score(opp: Dict[str, Any]) -> Dict[str, Any]:
    """Each factor 0..1 supplied by the caller (higher competition/effort/cost/risk = worse). Confidence is capped by evidence."""
    for k in FACTORS:
        v = opp.get(k)
        if not isinstance(v, (int, float)) or not 0 <= v <= 1:
            raise ValueError(f"{k} must be a number in 0..1")
    ev = [e for e in (opp.get("evidence") or []) if str(e).strip()]
    good = (opp["opportunity"] + opp["demand"] + opp["monetization"]) / 3
    bad = (opp["competition"] + opp["effort"] + opp["cost"] + opp["risk"]) / 4
    raw = round(max(0.0, good - 0.6 * bad), 3)
    conf = min(0.95, 0.2 + 0.15 * len(ev)) if ev else 0.1
    return {"label": "ESTIMATE", "score": raw, "confidence": round(conf, 2), "evidence_count": len(ev),
            "status": "SOURCE_BASED" if len(ev) >= 2 else "UNCERTAIN", "guaranteed_income": False}


def rank(opps: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    scored = [{"name": str(o.get("name", "?"))[:80], **score(o)} for o in opps[:100]]
    return sorted(scored, key=lambda x: (x["score"] * x["confidence"]), reverse=True)
