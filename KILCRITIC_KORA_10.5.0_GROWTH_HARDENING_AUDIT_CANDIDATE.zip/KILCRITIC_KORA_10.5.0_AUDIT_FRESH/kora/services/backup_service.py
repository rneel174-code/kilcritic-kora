"""
KORA 8.8.5 — Microservice: Database Backup Service
Real SQLite online backup API, PRAGMA integrity verification, fresh-connection schema readability, and actual file SHA-256 hashing.
"""
import os
import sqlite3
import hashlib
import time
import uuid
import shutil
from typing import Dict, Any, List, Optional

BACKUPS_DIR = os.path.abspath("data/backups")
os.makedirs(BACKUPS_DIR, exist_ok=True)
MIN_DISK_HEADROOM_BYTES = 50 * 1024 * 1024  # 50 MB

class BackupError(Exception):
    pass

class BackupService:
    def __init__(self, db_path: str = "data/kora.db", backups_dir: str = BACKUPS_DIR):
        self.db_path = os.path.abspath(db_path)
        self.backups_dir = os.path.abspath(backups_dir)
        os.makedirs(self.backups_dir, exist_ok=True)
        os.makedirs(os.path.dirname(self.db_path) or ".", exist_ok=True)
        self._ensure_source_db()

    def _ensure_source_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS system_snapshots (
                    id TEXT PRIMARY KEY,
                    snapshot_type TEXT NOT NULL,
                    filepath TEXT NOT NULL,
                    sha256 TEXT NOT NULL,
                    record_count INTEGER NOT NULL,
                    size_bytes INTEGER NOT NULL,
                    created_at REAL NOT NULL,
                    status TEXT NOT NULL
                );
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id TEXT PRIMARY KEY,
                    event TEXT NOT NULL,
                    created_at REAL NOT NULL
                );
            """)
            conn.commit()

    def check_headroom(self) -> int:
        stat = shutil.disk_usage(self.backups_dir)
        if stat.free < MIN_DISK_HEADROOM_BYTES:
            raise BackupError(f"Insufficient disk headroom: {stat.free} bytes free, required {MIN_DISK_HEADROOM_BYTES}")
        return stat.free

    def create_snapshot(self, snapshot_type: str = "FULL") -> Dict[str, Any]:
        """
        Creates an actual readable SQLite database backup snapshot:
        - Uses SQLite backup API (source_conn.backup(dest_conn))
        - Verifies PRAGMA integrity_check on the generated snapshot file
        - Opens the snapshot with a fresh SQLite connection to test schema readability
        - Calculates the SHA-256 digest of the actual backup file
        """
        self.check_headroom()
        snap_id = f"snap-{int(time.time()*1000)}-{uuid.uuid4().hex[:6]}"
        backup_filename = f"{snap_id}.db"
        backup_path = os.path.join(self.backups_dir, backup_filename)

        # 1. Real SQLite Online Backup via SQLite backup API
        source_conn = sqlite3.connect(self.db_path)
        dest_conn = sqlite3.connect(backup_path)
        try:
            source_conn.backup(dest_conn)
        finally:
            dest_conn.close()
            source_conn.close()

        # 2. Check non-zero file size on disk
        size_bytes = os.path.getsize(backup_path)
        if size_bytes == 0:
            if os.path.exists(backup_path):
                os.remove(backup_path)
            raise BackupError("Generated backup file is 0 bytes.")

        # 3. Calculate SHA-256 digest of the actual backup file
        hasher = hashlib.sha256()
        with open(backup_path, "rb") as f:
            while chunk := f.read(65536):
                hasher.update(chunk)
        sha256_hex = hasher.hexdigest()

        # 4. Open backup with a FRESH connection to verify PRAGMA integrity & schema readability
        fresh_conn = sqlite3.connect(backup_path)
        record_count = 0
        try:
            # PRAGMA integrity check
            cur = fresh_conn.execute("PRAGMA integrity_check;")
            res = cur.fetchone()[0]
            if res != "ok":
                raise BackupError(f"Backup file failed PRAGMA integrity_check: {res}")

            # Verify schema readability
            schema_cur = fresh_conn.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = [row[0] for row in schema_cur.fetchall()]
            if not tables:
                raise BackupError("Backup file has no readable tables in schema.")

            # Verify table queries succeed
            for table in tables:
                if not table.startswith("sqlite_"):
                    c = fresh_conn.execute(f"SELECT COUNT(*) FROM {table};")
                    record_count += c.fetchone()[0]
        finally:
            fresh_conn.close()

        # 5. Record snapshot metadata in source database ledger
        now = time.time()
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("BEGIN IMMEDIATE;")
            conn.execute("""
                INSERT INTO system_snapshots (id, snapshot_type, filepath, sha256, record_count, size_bytes, created_at, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'VERIFIED');
            """, (snap_id, snapshot_type, backup_path, sha256_hex, record_count, size_bytes, now))
            conn.commit()

        self.prune_snapshots(max_keep=5)

        return {
            "id": snap_id,
            "filename": backup_filename,
            "filepath": backup_path,
            "sha256": sha256_hex,
            "size_bytes": size_bytes,
            "record_count": record_count,
            "status": "VERIFIED"
        }

    def verify_snapshot_file(self, backup_path: str) -> Dict[str, Any]:
        """Opens snapshot with a fresh connection and verifies integrity and schema readability."""
        if not os.path.exists(backup_path):
            raise BackupError(f"Backup file does not exist: {backup_path}")

        hasher = hashlib.sha256()
        with open(backup_path, "rb") as f:
            while chunk := f.read(65536):
                hasher.update(chunk)
        sha256_hex = hasher.hexdigest()

        fresh_conn = sqlite3.connect(backup_path)
        try:
            cur = fresh_conn.execute("PRAGMA integrity_check;")
            res = cur.fetchone()[0]
            if res != "ok":
                raise BackupError(f"Integrity check failed: {res}")

            schema_cur = fresh_conn.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = [row[0] for row in schema_cur.fetchall()]
            return {
                "valid": True,
                "integrity": res,
                "tables": tables,
                "sha256": sha256_hex,
                "size_bytes": os.path.getsize(backup_path)
            }
        finally:
            fresh_conn.close()

    def restore_snapshot(self, backup_path: str, target_db_path: Optional[str] = None) -> Dict[str, Any]:
        """Restores database from an actual SQLite snapshot using SQLite backup API and verifies restore integrity."""
        target = os.path.abspath(target_db_path or self.db_path)
        verify_res = self.verify_snapshot_file(backup_path)

        # Restore via online backup API from snapshot to target
        snap_conn = sqlite3.connect(backup_path)
        dest_conn = sqlite3.connect(target)
        try:
            snap_conn.backup(dest_conn)
        finally:
            dest_conn.close()
            snap_conn.close()

        # Verify target restored database
        restored_conn = sqlite3.connect(target)
        try:
            cur = restored_conn.execute("PRAGMA integrity_check;")
            res = cur.fetchone()[0]
            if res != "ok":
                raise BackupError(f"Restored database failed integrity check: {res}")
            schema_cur = restored_conn.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = [row[0] for row in schema_cur.fetchall()]
            return {
                "success": True,
                "restored_path": target,
                "integrity": res,
                "tables": tables,
                "verified_source_sha256": verify_res["sha256"]
            }
        finally:
            restored_conn.close()

    def prune_snapshots(self, max_keep: int = 5) -> int:
        pruned = 0
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.execute("SELECT id, filepath FROM system_snapshots ORDER BY created_at DESC;")
            rows = cur.fetchall()
            if len(rows) > max_keep:
                for row in rows[max_keep:]:
                    if os.path.exists(row["filepath"]):
                        try:
                            os.remove(row["filepath"])
                        except OSError:
                            pass
                    conn.execute("DELETE FROM system_snapshots WHERE id = ?;", (row["id"],))
                    pruned += 1
            conn.commit()
        return pruned
