"""Portable resource probes for Linux, Android/Pydroid and restricted runtimes."""
from __future__ import annotations
import os
from typing import Optional

def load_avg_1m() -> Optional[float]:
    try:
        fn = getattr(os, "getloadavg", None)
        if fn:
            return float(fn()[0])
    except (OSError, AttributeError, IndexError, TypeError, ValueError):
        pass
    return None
