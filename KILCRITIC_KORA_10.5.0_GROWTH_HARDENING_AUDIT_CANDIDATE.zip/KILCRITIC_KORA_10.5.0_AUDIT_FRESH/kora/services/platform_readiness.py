"""Truthful social-platform capability/readiness matrix.

No entry here claims live credentials, approval, or successful publishing.
"""
from __future__ import annotations
from typing import Any, Dict

PLATFORMS = {
    "YOUTUBE": {"adapter": True, "official_api": True, "credential_env": ["YOUTUBE_ACCESS_TOKEN"], "status_without_credentials": "AUTH_REQUIRED"},
    "FACEBOOK": {"adapter": True, "official_api": True, "credential_env": ["FACEBOOK_PAGE_ID", "FACEBOOK_PAGE_ACCESS_TOKEN"], "status_without_credentials": "AUTH_REQUIRED"},
    "X": {"adapter": True, "official_api": True, "credential_env": ["X_OAUTH2_USER_TOKEN"], "status_without_credentials": "AUTH_REQUIRED"},
    "INSTAGRAM": {"adapter": True, "official_api": True, "credential_env": ["INSTAGRAM_ACCESS_TOKEN", "INSTAGRAM_USER_ID"], "status_without_credentials": "AUTH_REQUIRED", "media_requirements": ["public_https_media_url"]},
    "TIKTOK": {"adapter": True, "official_api": True, "credential_env": ["TIKTOK_ACCESS_TOKEN"], "status_without_credentials": "AUTH_REQUIRED", "requirements": ["video.publish approval", "user authorization"]},
}

def readiness(platform: str, env: Dict[str, str]) -> Dict[str, Any]:
    p = platform.strip().upper()
    if p not in PLATFORMS:
        return {"platform": p, "status": "UNSUPPORTED"}
    spec = PLATFORMS[p]
    missing = [k for k in spec["credential_env"] if not str(env.get(k, "")).strip()]
    if not spec["adapter"]:
        status = spec["status_without_credentials"]
    elif missing:
        status = "AUTH_REQUIRED"
    else:
        status = "READY_TO_PREFLIGHT"
    return {"platform": p, "status": status, "adapter": spec["adapter"], "official_api": spec["official_api"], "missing": missing, "requirements": spec.get("requirements", []) + spec.get("media_requirements", [])}

def matrix(env: Dict[str, str]) -> Dict[str, Dict[str, Any]]:
    return {p: readiness(p, env) for p in PLATFORMS}
