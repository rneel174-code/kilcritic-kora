"""FORTRESS (10.4): the hardening layer that sits ON TOP of the existing engines. It adds no queue, scheduler, state or identity system:
it reuses identity grants, the hash-chained audit log, supreme_guardian memory screening, runtime_assurance records, Self-Evolution 3's
promotion gate, the durable queue and the scheduler replay. Everything is additive; nothing here deletes anything.

  1 PermissionBoundary   immutable, hash-pinned list of actions no agent/delegation/evolution may ever perform
  2 Watchdog             independent scan (own cron job, read-mostly) that can HALT; only an explicit owner action resumes
  3 Delegation           scoped, expiring, use-limited, depth-limited agent delegation; never exceeds the parent; revocation cascades
  4 evolution_proof      maps the SE3 promotion gate onto diff -> tests -> security -> benchmark -> approval -> rollback
  5 dead-file audit      import-graph + reference proof; quarantine = COPY to an archive with owner approval, original untouched
  6 learning_firewall    + ObjectiveMonitor (drift)
  7 independence_report  provider fallback, offline capability, discover->build->test->verify truth
  8 complexity_gate      ACCEPT / SIMPLIFY / REFUSE
  9 recovery_proof       replay + audit chain + queue/schedule/malak recovery in one verifiable record
"""
from __future__ import annotations
import ast, difflib, hashlib, json, os, re, shutil, time, uuid
from types import MappingProxyType
from typing import Any, Dict, Iterable, List, Optional, Sequence

from kora.core.db import DEFAULT_DB_PATH, get_connection, record_audit, verify_audit_chain

# ------------------------------------------------------------------ 1. immutable permission boundary
_FORBIDDEN = frozenset({
    "CHANGE_SECURITY", "CHANGE_CREDENTIALS", "MODIFY_BOUNDARY", "DISABLE_AUDIT", "DELETE_AUDIT", "DISABLE_WATCHDOG",
    "SELF_GRANT_PERMISSION", "BYPASS_APPROVAL", "BYPASS_OTP", "BYPASS_CAPTCHA", "AUTO_PAY", "PUBLISH_WITHOUT_APPROVAL",
    "DELETE_FILES", "EXFILTRATE_SECRET", "DISABLE_SAFE_MODE", "CLEAR_HALT",
})
BOUNDARY = MappingProxyType({a: "NEVER" for a in sorted(_FORBIDDEN)})
# SHA-256 over the sorted forbidden actions + identity.NEVER_GRANTABLE. Changing either (by edit or at runtime) trips verify_boundary().
BOUNDARY_PIN = "6c521b822fd460e72abb8b86b32481c63a3c2490ab653e0d87a623e00915ce11"


def _compute_pin() -> str:
    from kora.core import identity
    body = json.dumps({"forbidden": sorted(_FORBIDDEN), "never_grantable": sorted(identity.NEVER_GRANTABLE)}, sort_keys=True)
    return hashlib.sha256(body.encode()).hexdigest()


def verify_boundary() -> Dict[str, Any]:
    cur = _compute_pin()
    return {"ok": cur == BOUNDARY_PIN, "pinned": BOUNDARY_PIN, "current": cur}


def boundary_check(action: str) -> Dict[str, Any]:
    a = str(action or "").upper().strip()
    if a in _FORBIDDEN:
        return {"allowed": False, "reason": "permission_boundary", "action": a}
    return {"allowed": True, "action": a}


# ------------------------------------------------------------------ state / tables
SECRET_RX = [re.compile(p, re.I) for p in (r"\bsk-[A-Za-z0-9_\-]{16,}", r"\bAIza[0-9A-Za-z_\-]{30,}", r"\bgh[pousr]_[A-Za-z0-9]{30,}",
                                          r"bearer\s+[A-Za-z0-9._\-]{20,}", r"\b\d{3}-?\d{2}-?\d{4}\b(?=.*ssn)", r"-----BEGIN [A-Z ]*PRIVATE KEY-----")]


def init(db_path: str = DEFAULT_DB_PATH) -> None:
    c = get_connection(db_path)
    try:
        c.execute("CREATE TABLE IF NOT EXISTS fortress_state (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at REAL NOT NULL)")
        c.execute("CREATE TABLE IF NOT EXISTS fortress_findings (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, severity TEXT NOT NULL, subject TEXT NOT NULL, evidence TEXT NOT NULL DEFAULT '{}', created_at REAL NOT NULL)")
        c.execute("""CREATE TABLE IF NOT EXISTS fortress_delegations (
            id TEXT PRIMARY KEY, parent TEXT NOT NULL, child TEXT NOT NULL, capability TEXT NOT NULL, parent_delegation TEXT, depth INTEGER NOT NULL DEFAULT 1,
            max_uses INTEGER NOT NULL, uses INTEGER NOT NULL DEFAULT 0, created_at REAL NOT NULL, expires_at REAL NOT NULL, revoked_at REAL)""")
    finally:
        c.close()


def _finding(db, kind, severity, subject, evidence=None):
    c = get_connection(db)
    try:
        c.execute("INSERT INTO fortress_findings(kind,severity,subject,evidence,created_at) VALUES (?,?,?,?,?)", (kind, severity, subject[:200], json.dumps(evidence or {}, default=str)[:4000], time.time()))
    finally:
        c.close()


def _set_state(db, key, value):
    c = get_connection(db)
    try:
        c.execute("INSERT INTO fortress_state(key,value,updated_at) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at", (key, value, time.time()))
    finally:
        c.close()


def _get_state(db, key, default=""):
    init(db); c = get_connection(db)
    try:
        r = c.execute("SELECT value FROM fortress_state WHERE key=?", (key,)).fetchone()
    finally:
        c.close()
    return r["value"] if r else default


def _is_owner(actor: str) -> bool:
    return str(actor or "").split("@")[0].split(":")[0] in ("owner", "operator-owner")


class HaltedError(RuntimeError):
    pass


def halted(db_path: str = DEFAULT_DB_PATH) -> bool:
    try:
        return _get_state(db_path, "halt") == "1"
    except Exception:
        return False


def assert_running(db_path: str = DEFAULT_DB_PATH) -> None:
    """Called by externally-effecting paths (dispatch/approve). Raises while the watchdog has HALTED the system."""
    if halted(db_path):
        raise HaltedError("fortress_halt: " + _get_state(db_path, "halt_reason", "security watchdog halted external effects"))


def resume_from_halt(actor: str, reason: str, db_path: str = DEFAULT_DB_PATH, owner_verified: bool = False) -> Dict[str, Any]:
    """The watchdog can halt; it can never un-halt itself. Only an explicit, verified owner action does."""
    if not owner_verified or not _is_owner(actor):
        return {"status": "REFUSED", "reason": "owner_verification_required"}
    if not verify_boundary()["ok"]:
        return {"status": "REFUSED", "reason": "boundary_integrity_failed"}
    _set_state(db_path, "halt", "0"); _set_state(db_path, "halt_reason", "")
    record_audit("fortress_resume", actor, {"reason": str(reason)[:300]}, db_path)
    return {"status": "RESUMED"}


# ------------------------------------------------------------------ 2. independent watchdog
def watchdog_scan(db_path: str = DEFAULT_DB_PATH, env: Optional[Dict[str, str]] = None, halt_on_critical: bool = True) -> Dict[str, Any]:
    """Runs on its own cron job; does not use worker objects. CRITICAL => HALT (sticky). WARN is reported only."""
    init(db_path); env = os.environ if env is None else env
    crit: List[Dict[str, Any]] = []; warn: List[Dict[str, Any]] = []
    b = verify_boundary()
    if not b["ok"]: crit.append({"check": "boundary_integrity", "evidence": b})
    chain = verify_audit_chain(db_path)
    if not chain.get("ok"): crit.append({"check": "audit_chain", "evidence": chain})
    c = get_connection(db_path)
    try:
        bad = c.execute("SELECT id FROM social_posts WHERE status='PUBLISHED' AND (approved_by IS NULL OR approved_by='') LIMIT 20").fetchall()
        if bad: crit.append({"check": "published_without_approval", "evidence": [r["id"] for r in bad]})
        now = time.time()
        stuck = c.execute("SELECT COUNT(*) n FROM jobs WHERE status='RUNNING' AND lease_expires_at IS NOT NULL AND lease_expires_at < ?", (now - 300,)).fetchone()["n"]
        if stuck: warn.append({"check": "stuck_leases", "evidence": stuck})
        dlq = c.execute("SELECT COUNT(*) n FROM jobs WHERE status='DEAD_LETTER'").fetchone()["n"]
        if dlq >= 20: warn.append({"check": "dlq_growth", "evidence": dlq})
        rows = c.execute("SELECT details FROM audit_events ORDER BY id DESC LIMIT 500").fetchall()
        leaks = [i for i, r in enumerate(rows) if any(p.search(r["details"] or "") for p in SECRET_RX)]
        if leaks: crit.append({"check": "secret_in_audit_log", "evidence": {"rows": len(leaks)}})
        exp = c.execute("SELECT id FROM fortress_delegations WHERE revoked_at IS NULL AND expires_at < ?", (now,)).fetchall()
        for r in exp: c.execute("UPDATE fortress_delegations SET revoked_at=? WHERE id=?", (now, r["id"]))
        if exp: warn.append({"check": "expired_delegations_revoked", "evidence": [r["id"] for r in exp]})
    finally:
        c.close()
    if str(env.get("KORA_SOCIAL_AUTO_APPROVE", "")).lower() in ("1", "true", "yes"):
        warn.append({"check": "auto_approve_enabled", "evidence": "KORA_SOCIAL_AUTO_APPROVE is on; non-PASS preflight is still refused by the gate"})
    try:
        from kora.services import scheduled_autopilot as sa
        rep = sa.replay_from_audit(db_path)
        if not rep["ok"]: crit.append({"check": "schedule_replay_mismatch", "evidence": rep["mismatches"]})
    except Exception as exc:  # table absent on very old DBs: report, do not crash the watchdog
        warn.append({"check": "schedule_replay_unavailable", "evidence": type(exc).__name__})
    for f in crit: _finding(db_path, f["check"], "CRITICAL", f["check"], f["evidence"])
    for f in warn: _finding(db_path, f["check"], "WARN", f["check"], f["evidence"])
    if crit and halt_on_critical and not halted(db_path):
        _set_state(db_path, "halt", "1"); _set_state(db_path, "halt_reason", ",".join(x["check"] for x in crit)[:300])
        record_audit("fortress_halt", "watchdog", {"checks": [x["check"] for x in crit]}, db_path)
    return {"status": "HALTED" if halted(db_path) else ("WARN" if warn else "OK"), "critical": crit, "warnings": warn, "halted": halted(db_path)}


# ------------------------------------------------------------------ 3. agent identity + delegation + capability expiry
MAX_DELEGATION_TTL = 24 * 3600
MAX_DELEGATION_DEPTH = 3
MAX_DELEGATION_USES = 1000


class DelegationError(Exception):
    pass


def issue_delegation(parent: str, child: str, capability: str, *, ttl_seconds: float, max_uses: int = 10, parent_delegation: Optional[str] = None,
                     db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> Dict[str, Any]:
    """parent = a principal id holding `capability` (identity grant) OR the child side of an existing delegation (sub-delegation)."""
    from kora.core import identity
    init(db_path); now = time.time() if now is None else now
    cap = str(capability or "").upper().strip()
    if not boundary_check(cap)["allowed"] or cap in identity.NEVER_GRANTABLE:
        raise DelegationError("capability_forbidden_by_boundary")
    if not child or child == parent:
        raise DelegationError("child_must_differ_from_parent")
    ttl = float(ttl_seconds)
    if not 1 <= ttl <= MAX_DELEGATION_TTL: raise DelegationError("ttl_out_of_range")
    uses = int(max_uses)
    if not 1 <= uses <= MAX_DELEGATION_USES: raise DelegationError("max_uses_out_of_range")
    depth, exp = 1, now + ttl
    c = get_connection(db_path)
    try:
        if parent_delegation:
            pd = c.execute("SELECT * FROM fortress_delegations WHERE id=?", (parent_delegation,)).fetchone()
            if not pd or pd["revoked_at"] or pd["expires_at"] <= now: raise DelegationError("parent_delegation_not_active")
            if pd["child"] != parent: raise DelegationError("not_the_delegate_of_parent_delegation")
            if pd["capability"] != cap: raise DelegationError("cannot_widen_capability")
            if pd["depth"] + 1 > MAX_DELEGATION_DEPTH: raise DelegationError("depth_limit")
            if uses > pd["max_uses"] - pd["uses"]: raise DelegationError("cannot_exceed_parent_uses")
            depth, exp = pd["depth"] + 1, min(exp, pd["expires_at"])
        elif not identity.has_permission(parent, cap, db_path, now):
            raise DelegationError("parent_lacks_capability")
        did = "dlg-" + uuid.uuid4().hex[:12]
        c.execute("INSERT INTO fortress_delegations(id,parent,child,capability,parent_delegation,depth,max_uses,uses,created_at,expires_at) VALUES (?,?,?,?,?,?,?,0,?,?)",
                  (did, parent, child, cap, parent_delegation, depth, uses, now, exp))
    finally:
        c.close()
    record_audit("delegation_issued", parent, {"id": did, "child": child, "capability": cap, "depth": depth, "expires_at": exp, "max_uses": uses}, db_path)
    return {"delegation_id": did, "capability": cap, "depth": depth, "expires_at": exp, "max_uses": uses}


def authorize_delegated(delegation_id: str, agent: str, capability: str, db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> Dict[str, Any]:
    """Atomically consume one use. Wrong agent / capability, expired, revoked, exhausted, or boundary action => denied (and audited)."""
    init(db_path); now = time.time() if now is None else now; cap = str(capability or "").upper().strip()
    def deny(why):
        record_audit("delegation_denied", str(agent)[:60], {"id": delegation_id, "capability": cap, "reason": why}, db_path)
        return {"allowed": False, "reason": why}
    if not boundary_check(cap)["allowed"]: return deny("permission_boundary")
    c = get_connection(db_path)
    try:
        d = c.execute("SELECT * FROM fortress_delegations WHERE id=?", (delegation_id,)).fetchone()
        if not d: return deny("unknown_delegation")
        if d["child"] != agent: return deny("wrong_agent")
        if d["capability"] != cap: return deny("capability_not_delegated")
        if d["revoked_at"]: return deny("revoked")
        if d["expires_at"] <= now: return deny("expired")
        n = c.execute("UPDATE fortress_delegations SET uses=uses+1 WHERE id=? AND uses<max_uses AND revoked_at IS NULL AND expires_at>?", (delegation_id, now)).rowcount
        if n != 1: return deny("uses_exhausted")
    finally:
        c.close()
    return {"allowed": True, "delegation_id": delegation_id, "remaining": d["max_uses"] - d["uses"] - 1}


def revoke_delegation(delegation_id: str, by: str = "owner", db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    init(db_path); c = get_connection(db_path); revoked = []
    try:
        todo = [delegation_id]
        while todo:
            cur = todo.pop()
            if c.execute("UPDATE fortress_delegations SET revoked_at=? WHERE id=? AND revoked_at IS NULL", (time.time(), cur)).rowcount: revoked.append(cur)
            todo += [r["id"] for r in c.execute("SELECT id FROM fortress_delegations WHERE parent_delegation=?", (cur,)).fetchall()]
    finally:
        c.close()
    record_audit("delegation_revoked", by, {"revoked": revoked}, db_path)
    return {"revoked": revoked}


# ------------------------------------------------------------------ 4. self-evolution proof (reuses the SE3 gate)
_STAGE_MAP = (("diff", ("provenance_verified", "no_duplicate_module", "existing_capability_check", "dependency_compatibility")),
              ("tests", ("baseline_captured", "canary_passed", "correctness_tests", "regression_tests")),
              ("security", ("security_permission_checks",)),
              ("benchmark", ("candidate_benchmark", "resource_budget")),
              ("approval", ("owner_approval",)),
              ("rollback", ("rollback_point_possible",)))


def evolution_proof(proposal_id: str, db_path: str = DEFAULT_DB_PATH, root: Optional[str] = None) -> Dict[str, Any]:
    from kora.services import self_evolution_3 as se3
    gate = se3.promotion_gate(proposal_id, db_path, root)
    by = {i.get("name"): i for i in gate.get("items", [])}
    stages = []
    for stage, names in _STAGE_MAP:
        items = [by.get(n) for n in names]
        missing = [n for n, i in zip(names, items) if i is None]
        bad = [n for n, i in zip(names, items) if i is not None and i.get("status") not in ("PASS", "NOT_APPLICABLE")]
        stages.append({"stage": stage, "status": "PASS" if not missing and not bad else ("UNVERIFIED" if missing and not bad else "FAIL"), "failing": bad, "missing": missing})
    ok = all(s["status"] == "PASS" for s in stages) and gate.get("can_promote", False)
    return {"proposal_id": proposal_id, "stages": stages, "can_promote": bool(ok), "gate_blocked_by": gate.get("blocked_by", []),
            "note": "promotion itself is still performed only by self_evolution_3.promote after owner approval; this reports the proof, it promotes nothing"}


# ------------------------------------------------------------------ 5. dead / duplicate file audit (never deletes)
PROTECTED_DIRS = ("kora/core/", "kora/supreme_runtime/", "kora_core/", "kora/bridge/")
_ENTRY = {"run.py", "server.ts"}


def _py_files(root: str) -> List[str]:
    out = []
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in ("__pycache__", ".git", "node_modules", "data", "_quarantine", "dist", ".pytest_cache")]
        out += [os.path.join(dp, f) for f in fn if f.endswith(".py")]
    return sorted(out)


def _modname(root, path):
    rel = os.path.relpath(path, root)[:-3].replace(os.sep, ".")
    return rel[:-9] if rel.endswith(".__init__") else rel


def import_graph(root: str) -> Dict[str, Any]:
    files = _py_files(root); mods = {_modname(root, f): f for f in files}; importers: Dict[str, set] = {m: set() for m in mods}
    for f in files:
        try: tree = ast.parse(open(f, encoding="utf-8").read())
        except (SyntaxError, UnicodeDecodeError): continue
        me = _modname(root, f)
        for n in ast.walk(tree):
            names = []
            if isinstance(n, ast.Import): names = [a.name for a in n.names]
            elif isinstance(n, ast.ImportFrom) and n.module:
                names = [n.module] + [f"{n.module}.{a.name}" for a in n.names]
                if n.level:
                    base = me.rsplit(".", n.level)[0] if "." in me else ""
                    names = [f"{base}.{n.module}" if base else n.module] + [f"{base}.{n.module}.{a.name}" for a in n.names]
            for nm in names:
                if nm in mods and nm != me: importers[nm].add(me)
    return {"modules": mods, "importers": importers}


def _string_refs(root: str, mod: str, own: str) -> List[str]:
    short = mod.rsplit(".", 1)[-1]; rx = re.compile(r"[\"'/.]" + re.escape(short) + r"[\"'.]")
    hits = []
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in ("__pycache__", ".git", "node_modules", "data", "_quarantine", "dist")]
        for f in fn:
            p = os.path.join(dp, f)
            if p == own or not f.endswith((".py", ".json", ".ts", ".js", ".html", ".toml", ".cfg", ".txt")): continue
            try:
                if os.path.getsize(p) < 2_000_000 and rx.search(open(p, encoding="utf-8", errors="ignore").read()): hits.append(os.path.relpath(p, root))
            except OSError: pass
    return sorted(set(hits))[:20]


def dependency_proof(root: str, rel_path: str) -> Dict[str, Any]:
    g = import_graph(root); path = os.path.join(root, rel_path); mod = _modname(root, path)
    imp = sorted(g["importers"].get(mod, set()))
    refs = _string_refs(root, mod, path) if mod in g["modules"] else []
    non_test = [i for i in imp if ".tests." not in "." + i + "." and not i.endswith("_tests")]
    cls = ("ENTRYPOINT" if rel_path in _ENTRY else "IMPORTED" if non_test else "TEST_ONLY" if imp else "REFERENCED_BY_STRING" if refs else "UNREFERENCED")
    return {"path": rel_path, "module": mod, "importers": imp, "string_refs": refs, "class": cls, "protected": rel_path.startswith(PROTECTED_DIRS),
            "safe_to_archive": cls == "UNREFERENCED" and not rel_path.startswith(PROTECTED_DIRS) and os.path.basename(rel_path) != "__init__.py"}


def dead_file_audit(root: str) -> Dict[str, Any]:
    g = import_graph(root); rows = []; hashes: Dict[str, List[str]] = {}
    for mod, f in g["modules"].items():
        rel = os.path.relpath(f, root)
        if os.path.basename(f) == "__init__.py" or rel in _ENTRY: continue
        imp = sorted(g["importers"].get(mod, set()))
        non_test = [i for i in imp if ".tests." not in "." + i + "." and not i.endswith("_tests")]
        if non_test: continue
        proof = dependency_proof(root, rel)
        rows.append(proof)
        hashes.setdefault(hashlib.sha256(open(f, "rb").read()).hexdigest(), []).append(rel)
    dups = [v for v in hashes.values() if len(v) > 1]
    return {"status": "AUDITED", "candidates": rows, "unreferenced": [r["path"] for r in rows if r["class"] == "UNREFERENCED"],
            "test_only": [r["path"] for r in rows if r["class"] == "TEST_ONLY"], "string_referenced": [r["path"] for r in rows if r["class"] == "REFERENCED_BY_STRING"],
            "duplicates": dups, "deleted": [], "note": "audit only; nothing is deleted. Archive requires proof + owner approval (quarantine_archive)."}


def quarantine_archive(root: str, rel_path: str, *, approved_by: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """COPY a proven-unreferenced file into <root>/_quarantine/<ts>/. The original is NOT removed (no auto-delete, ever)."""
    if not approved_by or not _is_owner(approved_by):
        return {"status": "REFUSED", "reason": "owner_approval_required"}
    if os.path.isabs(rel_path) or ".." in rel_path.replace("\\", "/").split("/"):
        return {"status": "REFUSED", "reason": "path_outside_root"}
    src = os.path.realpath(os.path.join(root, rel_path))
    if os.path.commonpath([os.path.realpath(root), src]) != os.path.realpath(root) or not os.path.isfile(src):
        return {"status": "REFUSED", "reason": "not_a_file_inside_root"}
    proof = dependency_proof(root, rel_path)
    if not proof["safe_to_archive"]:
        return {"status": "REFUSED", "reason": "dependency_proof_failed", "proof": proof}
    dst = os.path.join(root, "_quarantine", time.strftime("%Y%m%dT%H%M%S", time.gmtime()), rel_path)
    os.makedirs(os.path.dirname(dst), exist_ok=True); shutil.copy2(src, dst)
    init(db_path); c = get_connection(db_path)
    try:
        c.execute("INSERT INTO quarantine_ledger(kind,subject,reason,evidence,status,created_at) VALUES ('dead_file',?,?,?,?,?)",
                  (rel_path, "unreferenced (import graph + string refs)", json.dumps({"proof": proof, "archive": os.path.relpath(dst, root), "sha256": hashlib.sha256(open(src, "rb").read()).hexdigest()}), "ARCHIVED_COPY_ORIGINAL_KEPT", time.time()))
    finally:
        c.close()
    record_audit("dead_file_archived", approved_by, {"path": rel_path, "archive": os.path.relpath(dst, root)}, db_path)
    return {"status": "ARCHIVED_COPY_ORIGINAL_KEPT", "archive": os.path.relpath(dst, root), "original_kept": os.path.exists(src), "proof": proof}


# ------------------------------------------------------------------ 6. learning firewall + objective drift
PROTECTED_KINDS = frozenset({"permission", "security_policy", "credential", "boundary", "objective", "approval_rule", "audit_policy"})
_FLOOD_WINDOW, _FLOOD_MAX = 60.0, 20


def learning_firewall(text: str, *, source: str, kind: str = "preference", confidence: float = 0.5, db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> Dict[str, Any]:
    """Nothing is learned unless it passes. Protected kinds can never be learned (only the owner changes those, through governance)."""
    from kora.services import supreme_guardian as g
    init(db_path); now = time.time() if now is None else now; kind = str(kind or "preference").lower(); reasons: List[str] = []
    if kind in PROTECTED_KINDS: reasons.append("protected_kind_not_learnable")
    scr = g.inspect_memory(text, source, confidence, db_path); reasons += scr["reasons"]
    if re.search(r"\b(always|never)\b.{0,40}\b(approve|skip|bypass|ignore|disable)\b", text or "", re.I): reasons.append("policy_override_phrase")
    c = get_connection(db_path)
    try:
        n = c.execute("SELECT COUNT(*) n FROM fortress_findings WHERE kind='learn_attempt' AND subject=? AND created_at>?", (str(source)[:100], now - _FLOOD_WINDOW)).fetchone()["n"]
    finally:
        c.close()
    if n >= _FLOOD_MAX: reasons.append("flood_from_single_source")
    _finding(db_path, "learn_attempt", "INFO", str(source), {"kind": kind, "accepted": not reasons})
    if reasons:
        c = get_connection(db_path)
        try:
            c.execute("INSERT INTO quarantine_ledger(kind,subject,reason,evidence,status,created_at) VALUES ('learning',?,?,?,'QUARANTINED',?)",
                      (str(source)[:200], ",".join(sorted(set(reasons)))[:300], json.dumps({"kind": kind, "text_sha256": hashlib.sha256((text or "").encode()).hexdigest()}), now))
        finally:
            c.close()
        return {"status": "QUARANTINED", "learned": False, "reasons": sorted(set(reasons))}
    return {"status": "ACCEPT", "learned": True, "reasons": []}


_STOP = frozenset("a an the to of and or for in on with by at from is are be it this that as my our your i we you please".split())


def _toks(s: str) -> set:
    return {w for w in re.findall(r"[a-z0-9]+", (s or "").lower()) if w not in _STOP and len(w) > 2}


class ObjectiveMonitor:
    """The original objective is fixed at construction. check() flags a current goal/plan that no longer serves it, or that reaches for boundary actions."""
    def __init__(self, original_goal: str, min_overlap: float = 0.25):
        self.original = str(original_goal or "").strip(); self.min_overlap = min_overlap
        if not self.original: raise ValueError("original_goal_required")

    def check(self, current_goal: str, planned_actions: Sequence[str] = ()) -> Dict[str, Any]:
        a, b = _toks(self.original), _toks(current_goal)
        overlap = len(a & b) / max(1, len(a | b)); reasons = []
        if overlap < self.min_overlap: reasons.append("goal_no_longer_matches_original")
        bad = [x for x in planned_actions if not boundary_check(x)["allowed"]]
        if bad: reasons.append("boundary_action_planned:" + ",".join(bad))
        return {"drift": bool(reasons), "overlap": round(overlap, 3), "reasons": reasons, "action": "STOP_AND_ASK_OWNER" if reasons else "CONTINUE"}


# ------------------------------------------------------------------ 7. self-independence
OFFLINE_CAPABILITIES = (("durable_queue_and_scheduler", "sqlite, no network"), ("rule_engine_brain", "deterministic local"), ("audit_chain_and_replay", "local"),
                        ("malak_assist_checkpoints", "local (notification needs a channel)"), ("media_convert_quality", "needs ffmpeg/ffprobe binaries"))


def independence_report(env: Optional[Dict[str, str]] = None, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    from kora.services.ai_failover import provider_states
    env = os.environ if env is None else env
    prov = provider_states(env)
    usable = [p["provider"] for p in prov if p["state"] in ("HEALTHY", "CONFIGURED", "AVAILABLE")]
    local_only = [p for p in prov if p["provider"] == "local_deterministic_fallback"]
    offline = [{"capability": n, "note": note, "available": (bool(shutil.which("ffmpeg") and shutil.which("ffprobe")) if "ffmpeg" in note else True)} for n, note in OFFLINE_CAPABILITIES]
    return {"providers": prov, "fallback_chain": usable, "works_with_no_provider_keys": bool(local_only),
            "llm_independence": "PARTIAL: local fallback is a rule engine, not an LLM; real LLM answers need a configured provider",
            "offline_capabilities": offline, "needs_network": ["social publishing", "LLM providers", "Telegram/WhatsApp notification"]}


def capability_loop(db_path: str = DEFAULT_DB_PATH, env: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """discover -> (build) -> test -> verify. Discovery is real; build is NEVER automatic: a gap becomes an SE3 proposal that needs owner approval."""
    from kora.services import self_evolution_3 as se3
    snap = se3.discover_capabilities(db_path, env)
    gaps = snap.get("gaps") or []
    stages = [{"stage": "discover", "status": "DONE", "gaps": len(gaps)},
              {"stage": "build", "status": "NOT_AUTOMATED" if gaps else "NOT_NEEDED", "how": "se3.propose(...) -> owner approval -> canary"},
              {"stage": "test", "status": "REQUIRES_PROPOSAL" if gaps else "NOT_NEEDED"},
              {"stage": "verify", "status": "REQUIRES_PROPOSAL" if gaps else "NOT_NEEDED"}]
    return {"stages": stages, "gaps": gaps[:50], "auto_built": 0}


# ------------------------------------------------------------------ 8. complexity gate
_ENGINE_WORDS = {"queue": "kora/core/queue.py", "scheduler": "kora/core/scheduler.py", "audit": "kora/core/db.py (audit chain)", "identity": "kora/core/identity.py",
                 "approval": "kora/services/governance", "policy": "kora/core/policy.py", "state machine": "kora/services/scheduled_autopilot.py", "watchdog": "kora/services/fortress.py"}


def complexity_gate(proposal: Dict[str, Any], root: Optional[str] = None) -> Dict[str, Any]:
    from kora.supreme_runtime.runtime_assurance import ComplexityDebt
    name = str(proposal.get("name", "")).strip(); purpose = str(proposal.get("purpose", "")).lower(); actions = [str(x) for x in proposal.get("actions", [])]
    reasons, simplify = [], []
    if not name or not purpose: return {"verdict": "REFUSE", "reasons": ["name_and_purpose_required"]}
    bad = [a for a in actions if not boundary_check(a)["allowed"]]
    if bad: reasons.append("touches_permission_boundary:" + ",".join(bad))
    for word, owner in _ENGINE_WORDS.items():
        if re.search(r"\b(new|own|separate|second|another|custom)\b.{0,25}\b" + re.escape(word), purpose) or (word in name.lower() and proposal.get("new_engine")):
            reasons.append(f"duplicates_existing_engine:{word} -> reuse {owner}")
    if root:
        stems = [os.path.basename(f)[:-3] for f in _py_files(root)]
        close = [s for s in stems if difflib.SequenceMatcher(None, s, name.lower().replace(" ", "_")).ratio() >= 0.85 and s != name.lower()]
        if close: reasons.append("near_duplicate_module_name:" + ",".join(close[:3]))
    score = ComplexityDebt(float(proposal.get("capability_gain", 0)), float(proposal.get("complexity_added", 0)), float(proposal.get("maintenance_cost", 0)), float(proposal.get("failure_surface", 0))).score()
    if score <= 0: reasons.append(f"complexity_exceeds_gain(score={score})")
    elif score < 1: simplify.append(f"marginal_value(score={score})")
    if proposal.get("external_effects") and not proposal.get("rollback"): reasons.append("external_effects_without_rollback")
    if proposal.get("adds_dependency"): simplify.append("new_dependency: prefer stdlib or an existing module")
    verdict = "REFUSE" if reasons else ("SIMPLIFY" if simplify else "ACCEPT")
    return {"verdict": verdict, "score": score, "reasons": reasons, "simplify": simplify}


# ------------------------------------------------------------------ 9. crash recovery proof + deterministic replay
def recovery_proof(db_path: str = DEFAULT_DB_PATH, queue=None) -> Dict[str, Any]:
    from kora.services import scheduled_autopilot as sa, malak_assist
    from kora.core.queue import DurableQueue
    from kora.supreme_runtime.runtime_assurance import RecoveryProof
    q = queue or DurableQueue(db_path)
    released = q.recover_stale_leases()
    stale = sa.recover_stale_claims(db_path)
    mal = malak_assist.recover(db_path)
    r1, r2 = sa.replay_from_audit(db_path), sa.replay_from_audit(db_path)
    chain = verify_audit_chain(db_path)
    c = get_connection(db_path)
    try:
        dups = c.execute("SELECT idempotency_key, COUNT(*) n FROM jobs WHERE idempotency_key IS NOT NULL GROUP BY idempotency_key HAVING n>1").fetchall()
        double = c.execute("SELECT post_id, COUNT(*) n FROM autopilot_schedules WHERE status='PUBLISHED' AND frequency='ONCE' GROUP BY post_id HAVING n>1").fetchall()
    finally:
        c.close()
    deterministic = json.dumps(r1, sort_keys=True) == json.dumps(r2, sort_keys=True)
    checks = {"audit_chain_intact": bool(chain.get("ok")), "schedule_replay_matches": bool(r1["ok"]), "replay_deterministic": deterministic,
              "no_duplicate_idempotency_keys": not dups, "no_double_published_once_schedule": not double}
    proof = RecoveryProof(failed_step="process_restart", checkpoint=hashlib.sha256(json.dumps(r1, sort_keys=True).encode()).hexdigest()[:16],
                          side_effects=tuple(f"released_lease:{released}" for _ in range(1) if released) + tuple(f"requeued_claim:{x}" for x in stale),
                          blocked_repeats=tuple(r["idempotency_key"] for r in dups), rollback_verified=all(checks.values()))
    return {"valid": proof.valid() and all(checks.values()), "checks": checks, "released_leases": released, "recovered_claims": stale,
            "malak": {"waiting": len(mal["waiting"]), "interrupted_needs_review": mal["interrupted_needs_review"]}, "replay": r1, "checkpoint": proof.checkpoint}
