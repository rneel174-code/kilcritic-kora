"""
KORA PRO - Durable SQLite Queue
  * atomic claim (BEGIN IMMEDIATE + version fencing), priority DESC / created ASC ordering
  * leases with renewal; expired leases are recovered (re-queued with backoff, or dead-lettered when attempts are exhausted)
  * retry with exponential backoff + jitter, permanent-error short-circuit, dead-letter queue (list / requeue / purge)
  * idempotency keys, bounded capacity, payload size cap, durable (DB-backed) kill switch
  * completion / failure are only accepted from the worker that owns the running job (no stale-worker overwrite)

`max_retries` keeps its historical meaning: the maximum number of TOTAL attempts before dead-lettering.
"""
import json
import random
import time
import uuid
from typing import Any, Callable, Dict, List, Optional

from kora.core.db import DEFAULT_DB_PATH, get_connection

MAX_QUEUE_CAPACITY = 5000
MAX_PAYLOAD_BYTES = 1024 * 1024  # 1 MB
DEFAULT_LEASE_SECONDS = 30.0
DEFAULT_RETRY_BASE_SECONDS = 2.0
DEFAULT_RETRY_MAX_SECONDS = 900.0
KILL_KEY = "kill_switch"


# Priority tiers (existing integer `priority`, higher runs first). P4 is background and is paused first under pressure.
P0, P1, P2, P3, P4 = 100, 75, 50, 25, 0
TIERS = {"P0": P0, "P1": P1, "P2": P2, "P3": P3, "P4": P4}
FLOOR_KEY = "queue.min_priority"


def tier_name(priority: int) -> str:
    for n, v in TIERS.items():
        if priority >= v:
            return n
    return "P4"


class KillSwitchActiveException(Exception):
    pass


class QueueCapacityExceededException(Exception):
    pass


class PayloadOversizedException(Exception):
    pass


class IdempotencyConflictException(Exception):
    pass


class PermanentJobError(Exception):
    """Raise from a handler when retrying cannot help (bad input, unsupported platform...). Goes straight to the DLQ."""


class DurableQueue:
    def __init__(
        self,
        db_path: str = DEFAULT_DB_PATH,
        max_capacity: int = MAX_QUEUE_CAPACITY,
        retry_base: float = DEFAULT_RETRY_BASE_SECONDS,
        retry_max: float = DEFAULT_RETRY_MAX_SECONDS,
        rng: Optional[Callable[[], float]] = None,
        clock: Callable[[], float] = time.time,
    ):
        self.db_path = db_path
        self.max_capacity = max_capacity
        self.retry_base = retry_base
        self.retry_max = retry_max
        self._rng = rng or random.random
        self._clock = clock
        self._kill_switch = False

    # ------------------------------------------------------------------ kill switch (durable)
    def set_kill_switch(self, active: bool) -> None:
        from kora.core.db import set_setting
        self._kill_switch = bool(active)
        set_setting(KILL_KEY, "on" if active else "off", self.db_path)

    def is_kill_switch_active(self) -> bool:
        if self._kill_switch:
            return True
        from kora.core.db import get_setting
        return get_setting(KILL_KEY, "off", self.db_path) == "on"

    # ------------------------------------------------------------------ pressure floor (pause low tiers first)
    def priority_floor(self) -> int:
        from kora.core.db import get_setting
        try:
            return int(get_setting(FLOOR_KEY, "0", self.db_path))
        except ValueError:
            return 0

    def set_priority_floor(self, floor: int) -> None:
        """Jobs below `floor` stay QUEUED (not lost) until the floor is lowered. 0 = everything runs."""
        from kora.core.db import set_setting
        set_setting(FLOOR_KEY, str(max(0, min(P0, int(floor)))), self.db_path)

    # ------------------------------------------------------------------ per-user pause / resume / dependency view
    def pause_job(self, job_id: str, owner: Optional[str] = None) -> bool:
        return self._flag(job_id, 1, owner)

    def resume_job(self, job_id: str, owner: Optional[str] = None) -> str:
        """Resume a paused QUEUED job, or give a dead-lettered one a fresh budget. Completed work is never re-run.
        Returns RESUMED | NOT_FOUND | NOT_RESUMABLE."""
        j = self.get_job(job_id)
        if not j or (owner is not None and j["owner"] != owner):
            return "NOT_FOUND"
        if j["status"] == "DEAD_LETTER":
            return "RESUMED" if self.requeue_dead_letter(job_id) else "NOT_RESUMABLE"
        if j["status"] == "QUEUED" and j["paused"]:
            return "RESUMED" if self._flag(job_id, 0, owner) else "NOT_RESUMABLE"
        return "NOT_RESUMABLE"

    def _flag(self, job_id: str, val: int, owner: Optional[str]) -> bool:
        conn = get_connection(self.db_path)
        try:
            sql, args = "UPDATE jobs SET paused=?, updated_at=? WHERE id=? AND status='QUEUED'", [val, self._clock(), job_id]
            if owner is not None:
                sql += " AND owner=?"
                args.append(owner)
            return conn.execute(sql + ";", args).rowcount == 1
        finally:
            conn.close()

    def resumable_for(self, owner: str, query: str = "") -> List[Dict[str, Any]]:
        """Only THIS owner's paused / failed / dependency-blocked jobs. Never another user's."""
        conn = get_connection(self.db_path)
        try:
            rows = conn.execute(
                """SELECT id, handler_name, label, status, paused, depends_on, error, priority, updated_at FROM jobs
                   WHERE owner=? AND (paused=1 OR status='DEAD_LETTER') ORDER BY updated_at DESC LIMIT 50;""", (owner,)).fetchall()
        finally:
            conn.close()
        q = (query or "").strip().lower()
        out = [dict(r) for r in rows]
        return [r for r in out if not q or q in (r["label"] + " " + r["handler_name"]).lower()]

    def blocked_by_dependency(self) -> List[Dict[str, Any]]:
        """Queued jobs whose dependency is not COMPLETED (waiting, or stuck because the dependency failed)."""
        conn = get_connection(self.db_path)
        try:
            rows = conn.execute(
                """SELECT j.id, j.label, j.depends_on, d.status AS dep_status FROM jobs j JOIN jobs d ON d.id=j.depends_on
                   WHERE j.status='QUEUED' AND d.status!='COMPLETED' LIMIT 100;""").fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    # ------------------------------------------------------------------ helpers
    def _backoff(self, attempts: int) -> float:
        if self.retry_base <= 0:
            return 0.0
        delay = min(self.retry_max, self.retry_base * (2 ** max(0, attempts - 1)))
        return delay * (0.5 + 0.5 * self._rng())  # jitter in [50%,100%] so retries do not stampede

    # ------------------------------------------------------------------ enqueue
    def enqueue(
        self,
        handler_name: str,
        payload: Dict[str, Any],
        priority: int = 0,
        idempotency_key: Optional[str] = None,
        max_retries: int = 3,
        run_at: Optional[float] = None,
        owner: str = "",
        label: str = "",
        depends_on: str = "",
    ) -> Dict[str, Any]:
        if self.is_kill_switch_active():
            raise KillSwitchActiveException("Kill-switch is active. Queue rejects new submissions.")

        payload_str = json.dumps(payload)
        if len(payload_str.encode("utf-8")) > MAX_PAYLOAD_BYTES:
            raise PayloadOversizedException(f"Payload exceeds limit of {MAX_PAYLOAD_BYTES} bytes.")

        job_id = f"job-{uuid.uuid4()}"
        now = self._clock()
        conn = get_connection(self.db_path)
        try:
            conn.execute("BEGIN IMMEDIATE;")
            cur = conn.execute("SELECT COUNT(*) as cnt FROM jobs WHERE status IN ('QUEUED', 'RUNNING');")
            if cur.fetchone()["cnt"] >= self.max_capacity:
                raise QueueCapacityExceededException(f"Queue capacity of {self.max_capacity} exceeded.")

            if idempotency_key:
                existing = conn.execute("SELECT id, status FROM jobs WHERE idempotency_key = ?;", (idempotency_key,)).fetchone()
                if existing:
                    raise IdempotencyConflictException(
                        f"Duplicate job with idempotency key '{idempotency_key}' (Job ID: {existing['id']}) blocked."
                    )

            conn.execute(
                """INSERT INTO jobs (id, idempotency_key, priority, status, handler_name, payload,
                                     version, attempts, max_retries, created_at, updated_at, next_attempt_at, owner, label, depends_on)
                   VALUES (?, ?, ?, 'QUEUED', ?, ?, 1, 0, ?, ?, ?, ?, ?, ?, ?);""",
                (job_id, idempotency_key, priority, handler_name, payload_str, max(1, int(max_retries)), now, now, run_at or 0,
                 str(owner)[:80], str(label)[:120], str(depends_on)[:80]),
            )
            conn.execute("COMMIT;")
            return {"id": job_id, "idempotency_key": idempotency_key, "priority": priority,
                    "status": "QUEUED", "handler_name": handler_name, "created_at": now}
        except Exception:
            conn.execute("ROLLBACK;")
            raise
        finally:
            conn.close()

    def enqueue_once(self, handler_name: str, payload: Dict[str, Any], idempotency_key: str, **kw) -> Dict[str, Any]:
        """Like enqueue, but a duplicate key returns the existing job (`duplicate: True`) instead of raising."""
        try:
            out = self.enqueue(handler_name, payload, idempotency_key=idempotency_key, **kw)
            out["duplicate"] = False
            return out
        except IdempotencyConflictException:
            conn = get_connection(self.db_path)
            try:
                r = conn.execute("SELECT id, status, handler_name FROM jobs WHERE idempotency_key = ?;", (idempotency_key,)).fetchone()
            finally:
                conn.close()
            return {"id": r["id"], "status": r["status"], "handler_name": r["handler_name"], "duplicate": True}

    # ------------------------------------------------------------------ lease recovery
    def recover_stale_leases(self) -> int:
        """RUNNING jobs whose lease expired: re-queue with backoff, or dead-letter if attempts are exhausted."""
        now = self._clock()
        conn = get_connection(self.db_path)
        recovered = 0
        try:
            conn.execute("BEGIN IMMEDIATE;")
            stale = conn.execute(
                "SELECT id, attempts, max_retries FROM jobs WHERE status = 'RUNNING' AND lease_expires_at < ?;", (now,)
            ).fetchall()
            for j in stale:
                if j["attempts"] >= j["max_retries"]:
                    conn.execute(
                        """UPDATE jobs SET status='DEAD_LETTER', worker_id=NULL, lease_expires_at=NULL, updated_at=?,
                                  dead_lettered_at=?, error='lease_expired_max_attempts', last_error_kind='lease'
                           WHERE id=?;""", (now, now, j["id"]))
                else:
                    conn.execute(
                        """UPDATE jobs SET status='QUEUED', worker_id=NULL, lease_expires_at=NULL, updated_at=?,
                                  next_attempt_at=?, error='lease_expired', last_error_kind='lease'
                           WHERE id=?;""", (now, now + self._backoff(j["attempts"]), j["id"]))
                recovered += 1
            conn.execute("COMMIT;")
        except Exception:
            conn.execute("ROLLBACK;")
            raise
        finally:
            conn.close()
        return recovered

    # ------------------------------------------------------------------ claim
    def claim_next_job(self, worker_id: str, lease_duration: float = DEFAULT_LEASE_SECONDS) -> Optional[Dict[str, Any]]:
        """Atomically claim the highest-priority, oldest QUEUED job that is due (next_attempt_at <= now)."""
        if self.is_kill_switch_active():
            return None
        self.recover_stale_leases()

        now = self._clock()
        conn = get_connection(self.db_path)
        try:
            conn.execute("BEGIN IMMEDIATE;")
            candidate = conn.execute(
                """SELECT id, version, priority, handler_name, payload, attempts, max_retries
                   FROM jobs WHERE status = 'QUEUED' AND next_attempt_at <= ? AND paused = 0 AND (? = 0 OR priority >= ?)
                     AND (depends_on = '' OR EXISTS (SELECT 1 FROM jobs d WHERE d.id = jobs.depends_on AND d.status = 'COMPLETED'))
                   ORDER BY priority DESC, created_at ASC LIMIT 1;""", (now, (fl := self.priority_floor()), fl)
            ).fetchone()
            if not candidate:
                conn.execute("COMMIT;")
                return None

            new_version = candidate["version"] + 1
            lease_expires = now + lease_duration
            upd = conn.execute(
                """UPDATE jobs SET status='RUNNING', worker_id=?, lease_expires_at=?, version=?,
                          attempts = attempts + 1, updated_at=?
                   WHERE id=? AND version=? AND status='QUEUED';""",
                (worker_id, lease_expires, new_version, now, candidate["id"], candidate["version"]),
            )
            if upd.rowcount != 1:
                conn.execute("COMMIT;")
                return None
            conn.execute("COMMIT;")
            return {
                "id": candidate["id"], "handler_name": candidate["handler_name"],
                "payload": json.loads(candidate["payload"]), "priority": candidate["priority"],
                "version": new_version, "attempts": candidate["attempts"] + 1,
                "max_retries": candidate["max_retries"], "worker_id": worker_id,
                "lease_expires_at": lease_expires,
            }
        except Exception:
            conn.execute("ROLLBACK;")
            raise
        finally:
            conn.close()

    def renew_lease(self, job_id: str, worker_id: str, extension: float = DEFAULT_LEASE_SECONDS) -> bool:
        now = self._clock()
        conn = get_connection(self.db_path)
        try:
            conn.execute("BEGIN IMMEDIATE;")
            cur = conn.execute(
                "UPDATE jobs SET lease_expires_at=?, updated_at=? WHERE id=? AND worker_id=? AND status='RUNNING';",
                (now + extension, now, job_id, worker_id))
            conn.execute("COMMIT;")
            return cur.rowcount == 1
        except Exception:
            conn.execute("ROLLBACK;")
            raise
        finally:
            conn.close()

    # ------------------------------------------------------------------ completion / failure
    def complete_job(self, job_id: str, worker_id: str, result: Dict[str, Any], version: Optional[int] = None) -> bool:
        now = self._clock()
        conn = get_connection(self.db_path)
        try:
            conn.execute("BEGIN IMMEDIATE;")
            sql = """UPDATE jobs SET status='COMPLETED', result=?, error=NULL, lease_expires_at=NULL, updated_at=?
                     WHERE id=? AND worker_id=? AND status='RUNNING'"""
            args: List[Any] = [json.dumps(result, default=str), now, job_id, worker_id]
            if version is not None:
                sql += " AND version=?"
                args.append(version)
            cur = conn.execute(sql + ";", args)
            conn.execute("COMMIT;")
            return cur.rowcount == 1
        except Exception:
            conn.execute("ROLLBACK;")
            raise
        finally:
            conn.close()

    def fail_job(self, job_id: str, worker_id: str, error_message: str, permanent: bool = False, kind: str = "transient") -> str:
        """Record a failure. Returns QUEUED (will retry after backoff), DEAD_LETTER, NOT_FOUND or NOT_OWNER."""
        now = self._clock()
        conn = get_connection(self.db_path)
        try:
            conn.execute("BEGIN IMMEDIATE;")
            job = conn.execute("SELECT attempts, max_retries, status, worker_id FROM jobs WHERE id = ?;", (job_id,)).fetchone()
            if not job:
                conn.execute("COMMIT;")
                return "NOT_FOUND"
            if job["status"] != "RUNNING" or job["worker_id"] != worker_id:
                conn.execute("COMMIT;")
                return "NOT_OWNER"  # cancelled, lease-recovered, or owned by another worker: do not overwrite

            dead = permanent or job["attempts"] >= job["max_retries"]
            msg = str(error_message)[:1000]
            if dead:
                conn.execute(
                    """UPDATE jobs SET status='DEAD_LETTER', error=?, last_error_kind=?, worker_id=NULL, lease_expires_at=NULL,
                              updated_at=?, dead_lettered_at=? WHERE id=?;""",
                    (msg, "permanent" if permanent else kind, now, now, job_id))
                new_status = "DEAD_LETTER"
            else:
                conn.execute(
                    """UPDATE jobs SET status='QUEUED', error=?, last_error_kind=?, worker_id=NULL, lease_expires_at=NULL,
                              updated_at=?, next_attempt_at=? WHERE id=?;""",
                    (msg, kind, now, now + self._backoff(job["attempts"]), job_id))
                new_status = "QUEUED"
            conn.execute("COMMIT;")
            return new_status
        except Exception:
            conn.execute("ROLLBACK;")
            raise
        finally:
            conn.close()

    def cancel_job(self, job_id: str) -> bool:
        now = self._clock()
        conn = get_connection(self.db_path)
        try:
            conn.execute("BEGIN IMMEDIATE;")
            cur = conn.execute(
                "UPDATE jobs SET status='CANCELLED', worker_id=NULL, lease_expires_at=NULL, updated_at=? WHERE id=? AND status IN ('QUEUED','RUNNING');",
                (now, job_id))
            conn.execute("COMMIT;")
            return cur.rowcount == 1
        except Exception:
            conn.execute("ROLLBACK;")
            raise
        finally:
            conn.close()

    def is_cancelled(self, job_id: str) -> bool:
        conn = get_connection(self.db_path)
        try:
            r = conn.execute("SELECT status FROM jobs WHERE id=?;", (job_id,)).fetchone()
            return bool(r and r["status"] == "CANCELLED")
        finally:
            conn.close()

    # ------------------------------------------------------------------ dead-letter queue
    def list_dead_letters(self, limit: int = 50) -> List[Dict[str, Any]]:
        conn = get_connection(self.db_path)
        try:
            rows = conn.execute(
                """SELECT id, handler_name, attempts, max_retries, error, last_error_kind, dead_lettered_at, priority, created_at
                   FROM jobs WHERE status='DEAD_LETTER' ORDER BY dead_lettered_at DESC LIMIT ?;""",
                (max(1, min(500, int(limit))),)).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def requeue_dead_letter(self, job_id: str) -> bool:
        """Operator action: give a dead-lettered job a fresh attempt budget. Idempotency key is preserved."""
        if self.is_kill_switch_active():
            raise KillSwitchActiveException("Kill-switch is active.")
        now = self._clock()
        conn = get_connection(self.db_path)
        try:
            conn.execute("BEGIN IMMEDIATE;")
            cur = conn.execute(
                """UPDATE jobs SET status='QUEUED', attempts=0, next_attempt_at=0, dead_lettered_at=NULL, worker_id=NULL,
                          lease_expires_at=NULL, updated_at=?, version=version+1 WHERE id=? AND status='DEAD_LETTER';""",
                (now, job_id))
            conn.execute("COMMIT;")
            return cur.rowcount == 1
        except Exception:
            conn.execute("ROLLBACK;")
            raise
        finally:
            conn.close()

    def purge_dead_letters(self, older_than_seconds: float = 7 * 86400) -> int:
        cutoff = self._clock() - older_than_seconds
        conn = get_connection(self.db_path)
        try:
            cur = conn.execute("DELETE FROM jobs WHERE status='DEAD_LETTER' AND dead_lettered_at < ?;", (cutoff,))
            return cur.rowcount
        finally:
            conn.close()

    def cleanup(self, older_than_seconds: float = 3 * 86400) -> int:
        """Delete finished (COMPLETED / CANCELLED) jobs older than the cutoff. DLQ entries are kept."""
        cutoff = self._clock() - older_than_seconds
        conn = get_connection(self.db_path)
        try:
            cur = conn.execute("DELETE FROM jobs WHERE status IN ('COMPLETED','CANCELLED') AND updated_at < ?;", (cutoff,))
            return cur.rowcount
        finally:
            conn.close()

    # ------------------------------------------------------------------ introspection
    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        conn = get_connection(self.db_path)
        try:
            row = conn.execute("SELECT * FROM jobs WHERE id = ?;", (job_id,)).fetchone()
            if not row:
                return None
            res = dict(row)
            for k in ("payload", "result"):
                if res.get(k):
                    res[k] = json.loads(res[k])
            return res
        finally:
            conn.close()

    def get_active(self, limit: int = 50) -> List[Dict[str, Any]]:
        """RUNNING then QUEUED jobs only - what the minimal HUD shows."""
        conn = get_connection(self.db_path)
        try:
            rows = conn.execute(
                """SELECT id, handler_name, status, attempts, max_retries, priority, worker_id, next_attempt_at, error, updated_at
                   FROM jobs WHERE status IN ('RUNNING','QUEUED')
                   ORDER BY CASE status WHEN 'RUNNING' THEN 0 ELSE 1 END, priority DESC, created_at ASC LIMIT ?;""",
                (max(1, min(200, int(limit))),)).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def get_stats(self) -> Dict[str, Any]:
        conn = get_connection(self.db_path)
        try:
            counts = {r["status"]: r["cnt"] for r in conn.execute("SELECT status, COUNT(*) as cnt FROM jobs GROUP BY status;").fetchall()}
        finally:
            conn.close()
        return {
            "QUEUED": counts.get("QUEUED", 0), "RUNNING": counts.get("RUNNING", 0),
            "COMPLETED": counts.get("COMPLETED", 0), "FAILED": counts.get("FAILED", 0),
            "CANCELLED": counts.get("CANCELLED", 0), "DEAD_LETTER": counts.get("DEAD_LETTER", 0),
            "total": sum(counts.values()), "kill_switch": self.is_kill_switch_active(),
            "capacity": self.max_capacity,
        }
