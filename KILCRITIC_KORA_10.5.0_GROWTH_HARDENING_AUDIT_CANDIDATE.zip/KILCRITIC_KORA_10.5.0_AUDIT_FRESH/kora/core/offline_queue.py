"""Back-compat adapter: the offline queue API on top of the ONE durable queue (kora.core.queue.DurableQueue).

Earlier releases shipped a second, separate queue (own DB + table). That was a duplicate task system, so it now only
translates the old method names/shapes onto the main `jobs` table. Fencing token == job `version`.
"""
import os
from typing import Any, Dict, Optional

from kora.core.db import init_db
from kora.core.queue import DurableQueue, IdempotencyConflictException

DEFAULT_QUEUE_DB = os.path.abspath("data/offline_queue.db")


class QueueConflictError(Exception):
    pass


class DurableOfflineQueue:
    def __init__(self, db_path: str = DEFAULT_QUEUE_DB):
        self.db_path = os.path.abspath(db_path)
        os.makedirs(os.path.dirname(self.db_path) or ".", exist_ok=True)
        init_db(self.db_path)
        self._q = DurableQueue(self.db_path)

    def enqueue(self, action: str, payload: Dict[str, Any], priority: int = 10, idem_key: Optional[str] = None) -> Dict[str, Any]:
        try:
            j = self._q.enqueue(action, payload, priority=priority, idempotency_key=idem_key)
        except IdempotencyConflictException:
            return {"rejected": True, "error": f"Duplicate idempotency key '{idem_key}' rejected."}
        if j.get("duplicate") or j.get("deduplicated"):
            return {"id": j["id"], "rejected": True, "error": f"Duplicate idempotency key '{idem_key}' rejected."}
        return {"id": j["id"], "action": action, "priority": priority, "idempotency_key": idem_key, "state": "QUEUED", "rejected": False}

    def recover_stale_leases(self) -> int:
        return self._q.recover_stale_leases()

    def claim_next(self, worker_id: str, lease_seconds: float = 30.0) -> Optional[Dict[str, Any]]:
        c = self._q.claim_next_job(worker_id, lease_seconds)
        if not c:
            return None
        return {"id": c["id"], "action": c["handler_name"], "payload": c["payload"], "priority": c["priority"],
                "fencing_token": c["version"], "worker_id": worker_id, "lease_expires_at": c["lease_expires_at"]}

    def complete_job(self, job_id: str, worker_id: str, fencing_token: int, result: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        ok = self._q.complete_job(job_id, worker_id, result or {"status": "SUCCESS"}, version=fencing_token)
        if ok:
            return {"success": True, "job_id": job_id, "status": "COMPLETED"}
        return {"success": False, "error": "Rejected: unknown job, wrong worker, stale fencing token or not RUNNING."}

    def fail_job(self, job_id: str, worker_id: str, fencing_token: int, error_message: str) -> Dict[str, Any]:
        job = self._q.get_job(job_id)
        if not job or job.get("worker_id") != worker_id or job.get("version") != fencing_token:
            return {"success": False, "error": "Fencing or worker authorization failure"}
        st = self._q.fail_job(job_id, worker_id, error_message)
        return {"success": st in ("QUEUED", "DEAD_LETTER"), "job_id": job_id, "status": st}

    def count_by_state(self) -> Dict[str, int]:
        s = self._q.get_stats()
        return {"QUEUED": s["QUEUED"], "PROCESSING": s["RUNNING"], "COMPLETED": s["COMPLETED"], "FAILED": s["FAILED"] + s["DEAD_LETTER"]}
