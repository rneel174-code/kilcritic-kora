"""Thread-safe token-bucket rate limiter with a bounded key table (no unbounded memory growth)."""
from __future__ import annotations
import threading
import time
from collections import OrderedDict
from typing import Callable, Tuple


class RateLimiter:
    def __init__(self, max_keys: int = 10000, clock: Callable[[], float] = time.monotonic):
        self._b: "OrderedDict[str, Tuple[float, float]]" = OrderedDict()  # key -> (tokens, last)
        self._lock = threading.Lock()
        self._max = max_keys
        self._clock = clock

    def allow(self, key: str, per_minute: int, burst: int = 0) -> Tuple[bool, float]:
        """Return (allowed, retry_after_seconds)."""
        cap = float(max(1, burst or per_minute))
        rate = per_minute / 60.0
        now = self._clock()
        with self._lock:
            tokens, last = self._b.pop(key, (cap, now))
            tokens = min(cap, tokens + (now - last) * rate)
            if tokens >= 1.0:
                self._b[key] = (tokens - 1.0, now)
                ok, retry = True, 0.0
            else:
                self._b[key] = (tokens, now)
                ok, retry = False, (1.0 - tokens) / rate if rate > 0 else 60.0
            while len(self._b) > self._max:
                self._b.popitem(last=False)
        return ok, retry

    def size(self) -> int:
        with self._lock:
            return len(self._b)
