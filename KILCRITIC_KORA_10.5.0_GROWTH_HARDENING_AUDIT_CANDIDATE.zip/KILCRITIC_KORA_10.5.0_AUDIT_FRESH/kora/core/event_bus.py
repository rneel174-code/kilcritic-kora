"""
KORA 8.8.5 — Microservice: Process-Local Event Bus
ARCHITECTURE NOTICE:
This event bus is strictly PROCESS-LOCAL and IN-MEMORY.
Events are volatile and do NOT persist across system restarts.
Includes bounded memory queues (FIFO deque), isolated subscriber exception handling,
and real in-memory replay semantics.
"""
import time
import uuid
import fnmatch
from collections import deque
from typing import Dict, List, Callable, Any, Optional

DEFAULT_MAX_HISTORY = 500
DEFAULT_MAX_DLQ = 200

class ProcessLocalEventBus:
    """
    Process-Local In-Memory Event Bus.
    Truthfully labeled: in-memory, non-durable across process boundaries.
    """
    def __init__(self, max_history: int = DEFAULT_MAX_HISTORY, max_dlq: int = DEFAULT_MAX_DLQ):
        self._max_history = max_history
        self._max_dlq = max_dlq
        self._subscribers: Dict[str, Dict[str, Callable]] = {}  # topic_pattern -> {sub_id: callback}
        self._history: deque = deque(maxlen=max_history)
        self._dlq: deque = deque(maxlen=max_dlq)

    def subscribe(self, pattern: str, callback: Callable) -> str:
        """Registers a subscriber callback for a topic pattern. Returns unique sub_id."""
        sub_id = f"sub-{uuid.uuid4().hex[:8]}"
        if pattern not in self._subscribers:
            self._subscribers[pattern] = {}
        self._subscribers[pattern][sub_id] = callback
        return sub_id

    def unsubscribe(self, pattern: str, sub_id: str) -> bool:
        if pattern in self._subscribers and sub_id in self._subscribers[pattern]:
            del self._subscribers[pattern][sub_id]
            if not self._subscribers[pattern]:
                del self._subscribers[pattern]
            return True
        return False

    def match_topic(self, pattern: str, topic: str) -> bool:
        """Hierarchical topic matching supporting * and #."""
        if pattern in ("*", "#") or pattern == topic:
            return True
        pat = pattern.replace("#", "*")
        return fnmatch.fnmatch(topic, pat)

    def publish(self, topic: str, payload: Any, source: str = "system") -> Dict[str, Any]:
        """
        Dispatches event to matching subscribers.
        Ensures subscriber exceptions are isolated into the Dead Letter Queue (DLQ)
        without aborting other subscribers or corrupting event state.
        """
        now = time.time()
        evt_id = f"evt-{int(now * 1000)}-{uuid.uuid4().hex[:6]}"
        evt = {
            "id": evt_id,
            "topic": topic,
            "payload": payload,
            "source": source,
            "timestamp": now,
            "status": "ACKED",
            "dispatch_count": 0,
            "errors": []
        }

        matched_subscribers = []
        for pat, subs in self._subscribers.items():
            if self.match_topic(pat, topic):
                for sub_id, handler in list(subs.items()):
                    matched_subscribers.append((sub_id, handler))

        for sub_id, handler in matched_subscribers:
            try:
                handler(evt)
                evt["dispatch_count"] += 1
            except Exception as ex:
                err_msg = str(ex)
                evt["errors"].append({"sub_id": sub_id, "error": err_msg})
                # Bounded DLQ record
                self._dlq.append({
                    "id": f"dlq-{uuid.uuid4().hex[:6]}",
                    "event_id": evt["id"],
                    "topic": topic,
                    "sub_id": sub_id,
                    "error": err_msg,
                    "failed_at": time.time(),
                    "payload": payload
                })

        if evt["errors"]:
            evt["status"] = "PARTIAL_FAILURE" if evt["dispatch_count"] > 0 else "DLQ"

        # Bounded history record
        self._history.append(evt)
        return evt

    def replay_event(self, event_id: str) -> Dict[str, Any]:
        """
        Real replay semantics:
        Locates event in historical memory and re-dispatches it to all current subscribers.
        """
        target = None
        for item in self._history:
            if item["id"] == event_id:
                target = item
                break

        if not target:
            return {"success": False, "error": f"Event {event_id} not found in bounded history."}

        replay_payload = {
            **target,
            "id": f"replay-{uuid.uuid4().hex[:6]}-{target['id']}",
            "original_id": target["id"],
            "is_replay": True,
            "replayed_at": time.time()
        }

        # Dispatch to active subscribers
        dispatched = 0
        for pat, subs in self._subscribers.items():
            if self.match_topic(pat, target["topic"]):
                for sub_id, handler in subs.items():
                    try:
                        handler(replay_payload)
                        dispatched += 1
                    except Exception:
                        pass

        return {
            "success": True,
            "replayed_event_id": replay_payload["id"],
            "original_id": target["id"],
            "topic": target["topic"],
            "dispatched_count": dispatched,
            "status": "REPLAYED"
        }

    def get_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Returns the most recent events up to limit (within bounded memory)."""
        items = list(self._history)
        return items[-limit:]

    def get_dlq(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Returns the most recent DLQ entries up to limit (within bounded memory)."""
        items = list(self._dlq)
        return items[-limit:]

    def clear(self):
        """Clears memory buffers."""
        self._history.clear()
        self._dlq.clear()

# Alias for standard import
EventBus = ProcessLocalEventBus
