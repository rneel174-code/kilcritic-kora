"""Policy: ONE permission table (risk per permission), hard blocks, safe mode and revocation. Fails closed.

Decisions: BLOCK | APPROVAL_REQUIRED | ALLOW_WITH_GUARDS.  Owner preferences (dharma) can never change this table.
"""
import json
from typing import Any, Dict, Iterable, Optional

from kora.core.contracts import RISK_ORDER, Risk
from kora.core.db import DEFAULT_DB_PATH, get_setting

PERMISSIONS: Dict[str, Risk] = {
    "READ_LOCAL_FILE": Risk.LOW, "WEB_SEARCH": Risk.LOW,
    "WRITE_LOCAL_FILE": Risk.MEDIUM, "NETWORK_ACCESS": Risk.MEDIUM, "WEB_DOWNLOAD": Risk.MEDIUM,
    "ACCESS_MICROPHONE": Risk.MEDIUM, "ACCESS_CAMERA": Risk.MEDIUM, "ACCESS_LOCATION": Risk.MEDIUM,
    "MODIFY_CODE": Risk.HIGH, "INSTALL_PACKAGE": Risk.HIGH, "RUN_PROCESS": Risk.HIGH, "UPLOAD_EXTERNAL": Risk.HIGH,
    "PUBLISH_SOCIAL": Risk.HIGH, "SEND_MESSAGE": Risk.HIGH, "CREATE_APP": Risk.HIGH, "DEPLOY_APP": Risk.HIGH,
    "DELETE_DATA": Risk.HIGH,
    "CHANGE_SECURITY": Risk.CRITICAL, "CHANGE_CREDENTIALS": Risk.CRITICAL,
}

HARD_BLOCKS = frozenset({"BYPASS_AUTH", "BYPASS_DRM", "BYPASS_PAYWALL", "STEAL_CREDENTIALS", "UNAUTHORIZED_ACCESS",
                         "OFFENSIVE_ATTACK", "SILENT_PAYMENT", "SILENT_PUBLISH", "ARBITRARY_CODE_EXEC"})

SAFE_MODE_KEY = "safe_mode"
REVOKED_KEY = "revoked_permissions"


class PolicyDenied(Exception):
    def __init__(self, action: str, reason: str):
        super().__init__(f"{action}: {reason}")
        self.action, self.reason = action, reason


def is_safe_mode(db_path: str = DEFAULT_DB_PATH) -> bool:
    return get_setting(SAFE_MODE_KEY, "0", db_path) == "1"


def revoked(db_path: str = DEFAULT_DB_PATH) -> frozenset:
    try:
        return frozenset(json.loads(get_setting(REVOKED_KEY, "[]", db_path) or "[]"))
    except ValueError:
        return frozenset()


def evaluate(action: str, requested_risk: Optional[Risk] = None, db_path: Optional[str] = None) -> Dict[str, Any]:
    """Pure decision. `db_path` enables safe-mode / revocation checks."""
    a = (action or "").strip().upper()
    if a in HARD_BLOCKS:
        return {"decision": "BLOCK", "reason": "hard_policy", "risk": Risk.CRITICAL.value}
    if a not in PERMISSIONS:
        return {"decision": "BLOCK", "reason": "unknown_permission_fail_closed", "risk": Risk.CRITICAL.value}
    risk = PERMISSIONS[a]
    if requested_risk and RISK_ORDER[requested_risk] > RISK_ORDER[risk]:
        risk = requested_risk
    if db_path:
        if a in revoked(db_path):
            return {"decision": "BLOCK", "reason": "permission_revoked", "risk": risk.value}
        if is_safe_mode(db_path) and risk != Risk.LOW:
            return {"decision": "BLOCK", "reason": "safe_mode", "risk": risk.value}
    if risk in (Risk.HIGH, Risk.CRITICAL):
        return {"decision": "APPROVAL_REQUIRED", "reason": "high_impact", "risk": risk.value}
    return {"decision": "ALLOW_WITH_GUARDS", "reason": "low_medium", "risk": risk.value}


def require_enabled(action: str, db_path: str) -> None:
    """For flows that already contain a human approval step: deny only on BLOCK (safe mode / revoked / hard block)."""
    d = evaluate(action, None, db_path)
    if d["decision"] == "BLOCK":
        raise PolicyDenied(action, d["reason"])
