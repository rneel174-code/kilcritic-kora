"""
KORA PRO - Defensive Security, Sanitization & Access Controls
"""
import hmac
import re
import socket
import ipaddress
import urllib.parse
from typing import Any, Dict, List, Set, Optional, Tuple

SENSITIVE_KEY_PATTERNS = {
    "authorization",
    "token",
    "apikey",
    "api_key",
    "secret",
    "password",
    "cookie",
    "accesstoken",
    "access_token",
    "refreshtoken",
    "refresh_token",
    "session",
    "credentials",
    "bearer",
    "privkey",
    "private_key"
}

ALLOWED_OUTBOUND_HOSTS = {
    "api.openai.com",
    "api.groq.com",
    "generativelanguage.googleapis.com",
    "youtube.googleapis.com",
    "graph.facebook.com",
    "open.tiktokapis.com",
    "open-upload.tiktokapis.com",
    "api.twitter.com",
    "api.x.com",
    "www.googleapis.com",
    "api.search.brave.com",
}

class Reveal(dict):
    """A response that must deliver a one-time credential (new principal token, TOTP secret) to its owner.
    Only the named top-level keys escape redaction; everything else is still sanitized. Never use for logs/audit."""
    def __init__(self, data, reveal_keys=()):
        super().__init__(data)
        self.reveal_keys = frozenset(reveal_keys)


def sanitize_recursive(data: Any) -> Any:
    """
    Recursively redacts any field matching sensitive keys.
    Prevents leakage across logs, SSE streams, database events, and API responses.
    """
    if isinstance(data, dict):
        sanitized = {}
        reveal = getattr(data, "reveal_keys", frozenset())
        for k, v in data.items():
            if k in reveal:
                sanitized[k] = v
                continue
            key_clean = str(k).lower().replace("_", "").replace("-", "")
            if any(pattern in key_clean for pattern in SENSITIVE_KEY_PATTERNS):
                sanitized[k] = "[REDACTED]"
            else:
                sanitized[k] = sanitize_recursive(v)
        return sanitized
    elif isinstance(data, list):
        return [sanitize_recursive(item) for item in data]
    return data

def constant_time_compare(val_a: str, val_b: str) -> bool:
    """Protects against timing attacks on authentication tokens."""
    return hmac.compare_digest(str(val_a).encode("utf-8"), str(val_b).encode("utf-8"))

def validate_outbound_url_for_ssrf(url: str, allowlist: Set[str] = ALLOWED_OUTBOUND_HOSTS) -> bool:
    """
    Guards against SSRF and DNS rebinding attacks.
    Ensures URL uses HTTPS and resolves only to trusted domain names on the allowlist.
    Rejects localhost, loopback, and private IPv4/IPv6 ranges.
    """
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme.lower() != "https":
        return False

    host = parsed.hostname
    if not host:
        return False

    # Check for direct IP address
    try:
        ip = ipaddress.ip_address(host)
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            return False
    except ValueError:
        pass  # It is a hostname

    return host.lower() in allowlist

def check_remote_authorization(auth_header: Optional[str], client_ip: str, expected_token: Optional[str]) -> Tuple[bool, int]:
    """
    Determines access for remote vs local clients.
    Localhost requests without token are permitted for local dev.
    Remote requests without a valid bearer token are strictly rejected with 403 Forbidden.
    """
    is_local = client_ip in {"127.0.0.1", "::1", "localhost"}

    if not expected_token:
        # If no auth token is configured, allow local only
        return (True, 200) if is_local else (False, 403)

    if not auth_header:
        return (True, 200) if is_local else (False, 403)

    token = auth_header.replace("Bearer ", "").strip()
    if constant_time_compare(token, expected_token):
        return (True, 200)

    return (False, 403)


def _ip_is_public(ip_text: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_text.split("%")[0])
    except ValueError:
        return False
    if getattr(ip, "ipv4_mapped", None):
        ip = ip.ipv4_mapped
    return not (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved
                or ip.is_multicast or ip.is_unspecified or not ip.is_global)

def _default_resolver(host: str):
    return [ai[4][0] for ai in socket.getaddrinfo(host, None, proto=socket.IPPROTO_TCP)]

def validate_public_url(url: str, allowed_domains=(), resolver=_default_resolver) -> Tuple[bool, str]:
    """SSRF guard for *research* fetches (arbitrary public sites, not an API allowlist).

    https only; no userinfo; non-standard ports rejected; hostname must resolve ONLY to public IPs
    (every A/AAAA record is checked). If `allowed_domains` is set, the host must match one of them.
    Residual risk (documented): DNS can change between this check and the connection (rebinding).
    """
    try:
        parsed = urllib.parse.urlparse(url)
    except ValueError:
        return False, "invalid_url"
    if parsed.scheme.lower() != "https":
        return False, "https_required"
    if parsed.username or parsed.password:
        return False, "userinfo_blocked"
    host = (parsed.hostname or "").lower().rstrip(".")
    if not host:
        return False, "no_host"
    try:
        port = parsed.port
    except ValueError:
        return False, "invalid_port"
    if port not in (None, 443):
        return False, "port_not_allowed"
    if allowed_domains and not any(host == d or host.endswith("." + d) for d in allowed_domains):
        return False, "domain_not_allowed"
    try:
        ipaddress.ip_address(host)
        addrs = [host]
    except ValueError:
        if host == "localhost" or host.endswith((".localhost", ".local", ".internal")):
            return False, "internal_hostname"
        try:
            addrs = resolver(host)
        except OSError:
            return False, "dns_failure"
    if not addrs:
        return False, "dns_failure"
    if not all(_ip_is_public(a) for a in addrs):
        return False, "non_public_address"
    return True, "ok"


# ----------------------------------------------------------------------------- prompt-injection guard (external content is DATA)
_INJECTION = [
    ("override_instructions", re.compile(r"\b(ignore|disregard|forget|override)\b[^.\n]{0,40}\b(previous|prior|above|earlier|all|system|your)\b[^.\n]{0,30}\b(instruction|prompt|rule|polic)", re.I)),
    ("role_hijack", re.compile(r"\b(you are now|act as|pretend to be|from now on you)\b", re.I)),
    ("reveal_secrets", re.compile(r"\b(reveal|print|send|leak|show)\b[^.\n]{0,40}\b(system prompt|api[ _-]?key|token|password|secret|credential)", re.I)),
    ("tool_or_exfil_command", re.compile(r"\b(run|execute|call)\b[^.\n]{0,30}\b(command|shell|script|tool|function)\b|\bcurl\s+https?://|\bsudo\b|\brm\s+-rf\b", re.I)),
    ("disable_safety", re.compile(r"\b(disable|turn off|bypass|skip)\b[^.\n]{0,30}\b(safety|security|safe mode|approval|guard|filter|policy)", re.I)),
    ("fake_authority", re.compile(r"\b(system message|developer message|admin override|message from (the )?(owner|malak|anthropic))\b", re.I)),
]
INJECTION_MARK = "[removed: instruction-like text in external content]"


def scan_injection(text: str) -> Dict[str, Any]:
    """Heuristic detector. External content (web pages, files, OCR, transcripts) is data and never authority: flagged
    lines are replaced by a marker so downstream code never sees them as instructions. Heuristic = it can miss novel
    phrasing, so authority never depends on it (policy/permission checks run regardless)."""
    kinds: List[str] = []
    out: List[str] = []
    for line in (text or "").split("\n"):
        hit = [n for n, rx in _INJECTION if rx.search(line)]
        if hit:
            kinds.extend(hit)
            out.append(INJECTION_MARK)
        else:
            out.append(line)
    return {"flagged": bool(kinds), "patterns": sorted(set(kinds)), "removed_lines": sum(1 for l in out if l == INJECTION_MARK), "text": "\n".join(out)}
