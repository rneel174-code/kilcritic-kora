"""Anti-loop / runaway guard. Same error 3 times (configurable) for the same operation -> operation is FROZEN until a
human unfreezes it; logs are preserved (audit). Also bounds recursion depth and evolution proposals per day."""
import threading
import time
from typing import Dict, Optional

from kora.core.db import DEFAULT_DB_PATH, get_setting, record_audit, set_setting

FROZEN_PREFIX = "frozen:"
_lock = threading.Lock()
_counts: Dict[str, Dict[str, object]] = {}


class OperationFrozen(Exception):
    pass


def is_frozen(op: str, db_path: str = DEFAULT_DB_PATH) -> bool:
    return get_setting(FROZEN_PREFIX + op, "0", db_path) == "1"


def check(op: str, db_path: str = DEFAULT_DB_PATH) -> None:
    if is_frozen(op, db_path):
        raise OperationFrozen(f"operation '{op}' is frozen after repeated identical errors; owner review required")


def record_failure(op: str, error: str, db_path: str = DEFAULT_DB_PATH, threshold: int = 3, subject: Optional[str] = None) -> bool:
    """Returns True when this failure froze the operation. With `subject` (e.g. a job id) only DISTINCT subjects count, so one
    job retrying never freezes a whole operation by itself."""
    sig = f"{db_path}|{op}"
    err = (error or "")[:120]
    with _lock:
        c = _counts.get(sig)
        if not (c and c["err"] == err):
            c = _counts[sig] = {"err": err, "n": 0, "subjects": set()}
        if subject is None:
            c["n"] += 1  # type: ignore[operator]
        else:
            c["subjects"].add(subject)  # type: ignore[union-attr]
        n = c["n"] + len(c["subjects"])  # type: ignore[operator,arg-type]
    if n >= threshold:  # type: ignore[operator]
        set_setting(FROZEN_PREFIX + op, "1", db_path)
        record_audit("operation_frozen", "anti_loop", {"op": op, "error": err, "count": n}, db_path)
        return True
    return False


def record_success(op: str, db_path: str = DEFAULT_DB_PATH) -> None:
    with _lock:
        _counts.pop(f"{db_path}|{op}", None)


def unfreeze(op: str, actor: str = "owner", db_path: str = DEFAULT_DB_PATH) -> None:
    set_setting(FROZEN_PREFIX + op, "0", db_path)
    record_success(op, db_path)
    record_audit("operation_unfrozen", actor, {"op": op}, db_path)


class DepthGuard:
    """with DepthGuard(limit=3): ...  -> raises when nested deeper than limit in this thread."""
    _tl = threading.local()

    def __init__(self, limit: int = 3):
        self.limit = limit

    def __enter__(self):
        d = getattr(self._tl, "d", 0) + 1
        if d > self.limit:
            raise RecursionError(f"recursion limit {self.limit} exceeded")
        self._tl.d = d
        return self

    def __exit__(self, *a):
        self._tl.d -= 1
