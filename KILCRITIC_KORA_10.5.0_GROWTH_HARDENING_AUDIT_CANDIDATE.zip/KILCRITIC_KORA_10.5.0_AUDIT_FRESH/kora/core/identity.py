"""Server-side identity: owner (config token, never hard-coded), assigned users/devices with hashed tokens,
time-boxed/permanent permission grants with instant revoke, and TOTP (RFC 6238) step-up for sensitive actions.

* Only the SHA-256 of a principal token is stored; the token is shown once at creation.
* CHANGE_SECURITY / CHANGE_CREDENTIALS can never be granted to a non-owner.
* A voice (or any client-claimed identity) never counts as final authentication for sensitive actions - only TOTP does.
"""
import base64
import hashlib
import hmac
import secrets
import struct
import time
from typing import Any, Dict, List, Optional

from kora.core import policy
from kora.core.contracts import new_id
from kora.core.db import DEFAULT_DB_PATH, get_connection, get_setting, record_audit, set_setting

NEVER_GRANTABLE = frozenset({"CHANGE_SECURITY", "CHANGE_CREDENTIALS"})
MAX_TTL = 365 * 86400
TOTP_SECRET, TOTP_LAST = "owner_totp_secret", "owner_totp_last_counter"


class IdentityError(ValueError):
    pass


def _h(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def create_principal(name: str, role: str, created_by: str = "owner", db_path: str = DEFAULT_DB_PATH,
                     ttl_seconds: Optional[float] = None, now: Optional[float] = None) -> Dict[str, str]:
    name = (name or "").strip()
    if role not in ("user", "device") or not 1 <= len(name) <= 80:
        raise IdentityError("name 1-80 chars and role user|device required")
    token, pid = secrets.token_urlsafe(32), new_id("pr")
    conn = get_connection(db_path)
    try:
        t0 = time.time() if now is None else now
        conn.execute("INSERT INTO principals(id,name,role,token_hash,created_at,created_by,expires_at) VALUES (?,?,?,?,?,?,?);",
                     (pid, name, role, _h(token), t0, created_by, None if ttl_seconds is None else t0 + float(ttl_seconds)))
    finally:
        conn.close()
    record_audit("principal_created", created_by, {"id": pid, "role": role}, db_path)
    return {"id": pid, "name": name, "role": role, "token": token, "note": "token is shown once and stored only as a hash"}


def authenticate_token(token: str, db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> Optional[Dict[str, Any]]:
    if not token or len(token) > 300:
        return None
    conn = get_connection(db_path)
    try:
        r = conn.execute("SELECT id,name,role FROM principals WHERE token_hash=? AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > ?);", (_h(token), time.time() if now is None else now)).fetchone()
        return dict(r) if r else None
    finally:
        conn.close()


def list_principals(db_path: str = DEFAULT_DB_PATH) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        return [dict(r) for r in conn.execute("SELECT id,name,role,created_at,expires_at,revoked_at FROM principals ORDER BY created_at;").fetchall()]
    finally:
        conn.close()


def revoke_principal(pid: str, by: str = "owner", db_path: str = DEFAULT_DB_PATH) -> bool:
    now = time.time()
    conn = get_connection(db_path)
    try:
        n = conn.execute("UPDATE principals SET revoked_at=? WHERE id=? AND revoked_at IS NULL;", (now, pid)).rowcount
        conn.execute("UPDATE grants SET revoked_at=? WHERE principal_id=? AND revoked_at IS NULL;", (now, pid))
    finally:
        conn.close()
    if n:
        record_audit("principal_revoked", by, {"id": pid}, db_path)
    return n == 1


def grant(pid: str, permission: str, ttl_seconds: Optional[float] = None, by: str = "owner", db_path: str = DEFAULT_DB_PATH,
          now: Optional[float] = None) -> Dict[str, Any]:
    permission = (permission or "").upper()
    if permission not in policy.PERMISSIONS:
        raise IdentityError("unknown permission")
    if permission in NEVER_GRANTABLE:
        raise IdentityError(f"{permission} can never be granted to a non-owner")
    if ttl_seconds is not None and not 1 <= float(ttl_seconds) <= MAX_TTL:
        raise IdentityError("ttl_seconds must be 1..31536000 (omit for a permanent grant)")
    now = time.time() if now is None else now
    gid = new_id("gr")
    conn = get_connection(db_path)
    try:
        if not conn.execute("SELECT 1 FROM principals WHERE id=? AND revoked_at IS NULL;", (pid,)).fetchone():
            raise IdentityError("principal not found or revoked")
        conn.execute("INSERT INTO grants(id,principal_id,permission,expires_at,created_by,created_at) VALUES (?,?,?,?,?,?);",
                     (gid, pid, permission, None if ttl_seconds is None else now + float(ttl_seconds), by, now))
    finally:
        conn.close()
    record_audit("grant", by, {"id": gid, "principal": pid, "permission": permission, "ttl": ttl_seconds}, db_path)
    return {"grant_id": gid, "permission": permission, "expires_at": None if ttl_seconds is None else now + float(ttl_seconds)}


def revoke_grant(gid: str, by: str = "owner", db_path: str = DEFAULT_DB_PATH) -> bool:
    conn = get_connection(db_path)
    try:
        n = conn.execute("UPDATE grants SET revoked_at=? WHERE id=? AND revoked_at IS NULL;", (time.time(), gid)).rowcount
    finally:
        conn.close()
    if n:
        record_audit("grant_revoked", by, {"id": gid}, db_path)
    return n == 1


def has_permission(pid: str, permission: str, db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> bool:
    now = time.time() if now is None else now
    conn = get_connection(db_path)
    try:
        return conn.execute(
            """SELECT 1 FROM grants g JOIN principals p ON p.id=g.principal_id
               WHERE g.principal_id=? AND g.permission=? AND g.revoked_at IS NULL AND p.revoked_at IS NULL
                 AND (g.expires_at IS NULL OR g.expires_at > ?) LIMIT 1;""", (pid, permission, now)).fetchone() is not None
    finally:
        conn.close()


def list_grants(pid: str, db_path: str = DEFAULT_DB_PATH) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        return [dict(r) for r in conn.execute("SELECT id,permission,expires_at,created_by,created_at,revoked_at FROM grants WHERE principal_id=? ORDER BY created_at;", (pid,)).fetchall()]
    finally:
        conn.close()


# ----------------------------------------------------------------------------- TOTP (RFC 6238, SHA-1, 30s, 6 digits)
def _code(secret_b32: str, counter: int) -> str:
    key = base64.b32decode(secret_b32 + "=" * (-len(secret_b32) % 8), casefold=True)
    mac = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    off = mac[-1] & 0x0F
    return f"{(struct.unpack('>I', mac[off:off + 4])[0] & 0x7FFFFFFF) % 1000000:06d}"


def totp_enrolled(db_path: str = DEFAULT_DB_PATH) -> bool:
    return bool(get_setting(TOTP_SECRET, "", db_path))


def totp_enroll(db_path: str = DEFAULT_DB_PATH, current_code: str = "", now: Optional[float] = None) -> Dict[str, str]:
    """First enrolment is open to the (already authenticated) owner; re-enrolling requires a valid current code."""
    if totp_enrolled(db_path) and totp_verify(current_code, db_path, now) is not True:
        raise IdentityError("current TOTP code required to re-enrol")
    secret = base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")
    set_setting(TOTP_SECRET, secret, db_path)
    set_setting(TOTP_LAST, "0", db_path)
    record_audit("totp_enrolled", "owner", {}, db_path)
    return {"secret": secret, "uri": f"otpauth://totp/KORA:owner?secret={secret}&issuer=KORA", "note": "shown once; add it to an authenticator app"}


def totp_verify(code: str, db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> bool:
    secret = get_setting(TOTP_SECRET, "", db_path)
    code = str(code or "").strip()
    if not secret or len(code) != 6 or not code.isdigit():
        return False
    ctr = int((time.time() if now is None else now) // 30)
    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        row = conn.execute("SELECT value FROM settings WHERE key=?;", (TOTP_LAST,)).fetchone()
        last = int(row["value"]) if row else 0
        for c in (ctr - 1, ctr, ctr + 1):
            if c > last and hmac.compare_digest(_code(secret, c), code):
                conn.execute("INSERT INTO settings(key,value,updated_at) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at;",
                             (TOTP_LAST, str(c), time.time()))
                conn.execute("COMMIT;")
                return True  # a code can be used once (replay protection)
        conn.execute("ROLLBACK;")
        return False
    finally:
        conn.close()


def step_up(code: str, db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> str:
    """OK | INVALID | NOT_ENROLLED."""
    if not totp_enrolled(db_path):
        return "NOT_ENROLLED"
    return "OK" if totp_verify(code, db_path, now) else "INVALID"
