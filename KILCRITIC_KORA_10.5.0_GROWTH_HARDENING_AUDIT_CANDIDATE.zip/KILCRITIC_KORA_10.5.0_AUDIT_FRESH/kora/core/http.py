"""Guarded outbound HTTP for provider / publisher API calls.

* destination must pass the SSRF allowlist (https + known API host + no private IP literal)
* redirects are NOT followed (an allowlisted host cannot bounce us to an internal address)
* response body is size-capped; timeouts are mandatory
Returns (status, headers, body_bytes) for ANY HTTP status (4xx/5xx are data, not exceptions).
Network-level failures raise TransportError.
"""
from __future__ import annotations
import urllib.error
import urllib.request
from typing import Callable, Dict, Optional, Tuple

from kora.core.security import validate_outbound_url_for_ssrf

Transport = Callable[..., Tuple[int, Dict[str, str], bytes]]


class TransportError(Exception):
    pass


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):  # noqa: D401
        return None


_opener = urllib.request.build_opener(_NoRedirect)


def https_request(method: str, url: str, headers: Optional[Dict[str, str]] = None, body: Optional[bytes] = None,
                  timeout: float = 30.0, max_bytes: int = 4 * 1024 * 1024) -> Tuple[int, Dict[str, str], bytes]:
    if not validate_outbound_url_for_ssrf(url):
        raise TransportError("outbound_destination_blocked")
    req = urllib.request.Request(url, data=body, method=method.upper(), headers=headers or {})
    try:
        resp = _opener.open(req, timeout=timeout)
    except urllib.error.HTTPError as e:
        resp = e
    except (urllib.error.URLError, OSError) as e:
        raise TransportError(f"network_error: {getattr(e, 'reason', e)}")
    try:
        data = resp.read(max_bytes + 1)
        if len(data) > max_bytes:
            raise TransportError("response_too_large")
        return resp.status if hasattr(resp, "status") else resp.code, {k.lower(): v for k, v in resp.headers.items()}, data
    finally:
        resp.close()
