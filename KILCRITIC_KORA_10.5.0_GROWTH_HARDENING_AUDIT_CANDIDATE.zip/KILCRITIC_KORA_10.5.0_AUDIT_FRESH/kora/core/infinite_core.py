"""
KORA INFINITE CORE
Adaptive out-of-core execution layer.

Purpose:
- Handle workloads larger than available RAM by bounded streaming.
- Lazy-load optional/heavy modules.
- Choose conservative worker counts from measured resources.
- Provide backpressure-friendly chunk iteration.
- Never claim to create CPU/GPU/RAM that the device does not have.
"""

from __future__ import annotations

import importlib.util
import mmap
import os
from pathlib import Path
from typing import Iterator, Any

try:
    import psutil  # optional dependency
except Exception:
    psutil = None


class InfiniteReactor:
    """Measured, bounded resource profile for large local workloads."""

    def __init__(self, reserve_ram_gb: float = 0.5, max_workers: int | None = None, logical_capacity_gb: float = 10000.0):
        self.ram_gb = self._ram_gb()
        self.available_ram_gb = self._available_ram_gb()
        self.logical_capacity_gb = max(1.0, float(logical_capacity_gb))
        self.cpu_count = max(1, os.cpu_count() or 1)
        self.reserve_ram_gb = max(0.25, float(reserve_ram_gb))

        if self.ram_gb < 4:
            self.tier = "LITE"
            default_workers = 1
        elif self.ram_gb < 24:
            self.tier = "MID"
            default_workers = min(4, self.cpu_count)
        elif self.ram_gb < 100:
            self.tier = "KING"
            default_workers = min(12, self.cpu_count)
        else:
            self.tier = "INFINITE"
            default_workers = min(32, self.cpu_count)

        self.workers = max(1, min(default_workers, max_workers or default_workers))

    @staticmethod
    def _ram_gb() -> float:
        if psutil is not None:
            return psutil.virtual_memory().total / (1024 ** 3)
        return 0.0

    @staticmethod
    def _available_ram_gb() -> float:
        if psutil is not None:
            return psutil.virtual_memory().available / (1024 ** 3)
        return 0.0

    @property
    def evidence_mode(self) -> str:
        return "sequential" if self.tier == "LITE" else "bounded_parallel"

    def stream_big(
        self,
        path: str | os.PathLike,
        chunk_mb: int = 10,
        max_chunk_mb: int = 64,
        max_mmap_mb: int = 512,
    ) -> Iterator[bytes]:
        """
        Stream a large file in bounded chunks.

        mmap is used only when practical; slices are materialized one chunk
        at a time, so the caller never receives an unbounded in-memory file.
        """
        chunk_mb = max(1, min(int(chunk_mb), int(max_chunk_mb)))
        chunk_size = chunk_mb * 1024 * 1024
        p = Path(path)

        with p.open("rb") as f:
            # Very large mappings are unnecessary and can fail on constrained/32-bit
            # systems. Direct bounded reads are the default for large files.
            if p.stat().st_size > max(1, int(max_mmap_mb)) * 1024 * 1024:
                while True:
                    block = f.read(chunk_size)
                    if not block:
                        break
                    yield block
                return
            try:
                mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
            except (OSError, ValueError):
                while True:
                    block = f.read(chunk_size)
                    if not block:
                        break
                    yield block
                return

            try:
                for offset in range(0, len(mm), chunk_size):
                    yield mm[offset: offset + chunk_size]
            finally:
                mm.close()

    def call_atom(self, module_path: str | os.PathLike, func_name: str, *args, **kwargs) -> Any:
        """Lazy-load one isolated module only when the requested task needs it."""
        path = Path(module_path).resolve()
        spec = importlib.util.spec_from_file_location(
            f"kora_atom_{path.stem}", path
        )
        if spec is None or spec.loader is None:
            raise ImportError(f"Unable to load module: {path}")

        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        fn = getattr(mod, func_name)
        return fn(*args, **kwargs)

    def validate_large_workload(self, size_gb: float) -> dict:
        """Validate an out-of-core workload without claiming physical capacity."""
        size_gb = max(0.0, float(size_gb))
        return {
            "requested_gb": size_gb,
            "logical_capacity_gb": self.logical_capacity_gb,
            "supported_out_of_core": size_gb <= self.logical_capacity_gb,
            "requires_storage": size_gb > 0,
            "ram_independent": True,
            "physical_storage_verified": False,
            "note": "Logical streaming capacity only; actual storage/network/provider limits still apply.",
        }

    def profile(self) -> dict:
        return {
            "tier": self.tier,
            "ram_gb": round(self.ram_gb, 2),
            "available_ram_gb": round(self.available_ram_gb, 2),
            "logical_capacity_gb": self.logical_capacity_gb,
            "capacity_mode": "out_of_core_streaming",
            "cpu_count": self.cpu_count,
            "workers": self.workers,
            "evidence_mode": self.evidence_mode,
            "out_of_core": True,
            "bounded_memory": True,
            "fake_hardware_power": False,
        }


REACTOR = InfiniteReactor()
