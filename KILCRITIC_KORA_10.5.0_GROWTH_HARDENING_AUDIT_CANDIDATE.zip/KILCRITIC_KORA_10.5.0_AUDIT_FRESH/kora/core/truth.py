"""Satya (truth) rules. A preference is never a fact; claims without evidence are never VERIFIED."""
from typing import Any, Iterable, Optional

from kora.core.contracts import Truth


def classify(value: Any = None, evidence: Optional[Iterable[Any]] = None, *, user_preference: bool = False,
             goal: bool = False, tool_generated: bool = False, inferred: bool = False, verified: bool = False) -> Truth:
    ev = [e for e in (evidence or []) if e]
    if user_preference:
        return Truth.USER_PREFERENCE
    if goal:
        return Truth.GOAL
    if verified and ev:
        return Truth.VERIFIED
    if ev:
        return Truth.SOURCE_BASED
    if tool_generated:
        return Truth.TOOL_GENERATED
    if inferred:
        return Truth.INFERRED
    return Truth.UNAVAILABLE if value is None else Truth.UNCERTAIN


def can_assert_as_fact(state: Truth) -> bool:
    """Only VERIFIED / SOURCE_BASED claims may be presented as fact. Preferences and goals never can."""
    return state in (Truth.VERIFIED, Truth.SOURCE_BASED)
