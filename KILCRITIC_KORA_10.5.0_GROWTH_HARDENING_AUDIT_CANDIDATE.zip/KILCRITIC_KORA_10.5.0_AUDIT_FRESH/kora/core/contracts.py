"""Shared contracts (blueprint s.51/s.52): risk levels, truth states, Task/Proposal/Verification, and the error model."""
import time
import uuid
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class Risk(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


RISK_ORDER = {Risk.LOW: 0, Risk.MEDIUM: 1, Risk.HIGH: 2, Risk.CRITICAL: 3}


class Truth(str, Enum):
    VERIFIED = "VERIFIED"
    SOURCE_BASED = "SOURCE_BASED"
    USER_PREFERENCE = "USER_PREFERENCE"
    GOAL = "GOAL"
    TOOL_GENERATED = "TOOL_GENERATED"
    INFERRED = "INFERRED"
    UNCERTAIN = "UNCERTAIN"
    UNAVAILABLE = "UNAVAILABLE"


def new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:10]}"


@dataclass
class Task:
    goal: str
    risk: Risk = Risk.LOW
    permissions: List[str] = field(default_factory=list)
    budget: Dict[str, Any] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)
    task_id: str = field(default_factory=lambda: new_id("task"))
    created_at: float = field(default_factory=time.time)


@dataclass
class Verification:
    status: str  # PASS | FAIL | UNCERTAIN
    evidence: List[Dict[str, Any]] = field(default_factory=list)
    rollback_required: bool = False
    notes: List[str] = field(default_factory=list)

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


class KoraError(Exception):
    """Error model: simple user_message, technical detail kept for diagnostics only."""

    def __init__(self, module: str, category: str, user_message: str, *, severity: str = "MEDIUM", cause: str = "",
                 safe_action: str = "none", retryable: bool = False, rollback_available: bool = False, task_id: str = ""):
        super().__init__(user_message)
        self.error_id = new_id("err")
        self.module, self.category, self.severity = module, category, severity
        self.user_message, self.cause, self.safe_action = user_message, cause, safe_action
        self.retryable, self.rollback_available, self.task_id = retryable, rollback_available, task_id

    def public(self) -> Dict[str, Any]:
        return {"error_id": self.error_id, "module": self.module, "category": self.category, "severity": self.severity,
                "message": self.user_message, "safe_action": self.safe_action, "retryable": self.retryable,
                "rollback_available": self.rollback_available}


_RECOVERY = {
    "network": ("The internet or the provider could not be reached.", "Waiting a moment and retrying; queued work is kept.", True, "Check the connection; nothing else is needed."),
    "provider": ("An AI provider failed or is rate-limited.", "Switched to the next provider, or the local rule engine.", True, "Add or check a provider key in settings if this keeps happening."),
    "permission": ("This action is not permitted right now.", "Nothing was changed.", False, "Grant the permission or turn off safe mode if you really want it."),
    "budget": ("The daily/monthly spending cap was reached.", "The paid step was skipped.", False, "Raise the cap or wait for the next period."),
    "account": ("The social account is not connected.", "That platform was skipped; other work continued.", False, "Reconnect the account in its settings."),
    "storage": ("Disk space is low.", "Disposable files were cleaned where safe.", False, "Free some space or export and delete old data."),
    "loop": ("The same step kept failing, so it was frozen to protect the system.", "Stopped retrying.", False, "Review the error, then unfreeze it."),
}


def explain_error(category: str, detail: str = "", tried: str = "") -> Dict[str, Any]:
    """Five plain answers for a person: what happened, why, what was tried, can it auto-fix, what to do. Never claims a fix that did not happen."""
    what, did, auto, todo = _RECOVERY.get(category, ("Something went wrong.", "Nothing was changed.", False, "Check the activity log or ask for the System Doctor."))
    return {"what_happened": what, "why": (detail or "reason not recorded")[:200], "what_was_tried": tried or did,
            "auto_fixable": auto, "what_you_should_do": todo, "category": category if category in _RECOVERY else "unknown"}
