"""
KORA PRO - Cron workers.

* 5-field cron (minute hour day-of-month month day-of-week) in UTC: `*`, lists `1,5`, ranges `1-5`, steps `*/15`, `10-50/10`.
  Also `@every <N>s|m|h` for simple intervals.  Day-of-week: 0-6 (0 = Sunday; 7 accepted as Sunday).
* Schedules live in SQLite (`cron_jobs`), survive restarts, and only ENQUEUE work into the durable queue - the
  worker pool executes it (so retry / DLQ / timeout / kill-switch all apply).
* Multi-process safe: a due job is claimed by compare-and-swap on `next_run_at`, and the enqueue uses the idempotency
  key `cron:<id>:<slot>` - two schedulers can never fire the same slot twice.
* Missed runs while the process was down are COALESCED into a single run (no catch-up storm).
"""
import json
import re
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from kora.core.db import DEFAULT_DB_PATH, get_connection
from kora.core.queue import DurableQueue, KillSwitchActiveException, QueueCapacityExceededException


class CronError(ValueError):
    pass


_EVERY = re.compile(r"^@every\s+(\d+)\s*([smh])$", re.I)
_RANGES = [(0, 59), (0, 23), (1, 31), (1, 12), (0, 7)]


def _parse_field(tok: str, lo: int, hi: int) -> Set[int]:
    out: Set[int] = set()
    for part in tok.split(","):
        if not part:
            raise CronError("empty cron list item")
        step = 1
        if "/" in part:
            part, s = part.split("/", 1)
            if not s.isdigit() or int(s) < 1:
                raise CronError(f"bad step '{s}'")
            step = int(s)
        if part == "*":
            a, b = lo, hi
        elif "-" in part:
            x, y = part.split("-", 1)
            if not (x.isdigit() and y.isdigit()):
                raise CronError(f"bad range '{part}'")
            a, b = int(x), int(y)
        elif part.isdigit():
            a = int(part)
            b = hi if step > 1 else a
        else:
            raise CronError(f"bad cron token '{part}'")
        if a < lo or b > hi or a > b:
            raise CronError(f"value out of range {lo}-{hi}: '{part}'")
        out.update(range(a, b + 1, step))
    return out


def parse_cron(expr: str) -> Tuple[Set[int], Set[int], Set[int], Set[int], Set[int], bool, bool]:
    fields = expr.split()
    if len(fields) != 5:
        raise CronError("cron needs 5 fields: minute hour day-of-month month day-of-week")
    sets = [_parse_field(f, lo, hi) for f, (lo, hi) in zip(fields, _RANGES)]
    sets[4] = {0 if d == 7 else d for d in sets[4]}
    dom_star = fields[2].startswith("*")
    dow_star = fields[4].startswith("*")
    return sets[0], sets[1], sets[2], sets[3], sets[4], dom_star, dow_star


def validate_schedule(expr: str) -> None:
    expr = (expr or "").strip()
    if _EVERY.match(expr):
        n = int(_EVERY.match(expr).group(1))
        if n < 1:
            raise CronError("@every interval must be >= 1")
        return
    parse_cron(expr)


def next_run(expr: str, after: float) -> float:
    """First scheduled instant strictly after `after` (unix seconds, UTC)."""
    expr = expr.strip()
    m = _EVERY.match(expr)
    if m:
        n = int(m.group(1)) * {"s": 1, "m": 60, "h": 3600}[m.group(2).lower()]
        return after + n
    minute, hour, dom, month, dow, dom_star, dow_star = parse_cron(expr)
    dt = datetime.fromtimestamp(after, tz=timezone.utc).replace(second=0, microsecond=0) + timedelta(minutes=1)
    limit = dt + timedelta(days=366 * 5)
    while dt < limit:
        if dt.month not in month:
            dt = (dt.replace(day=1, hour=0, minute=0) + timedelta(days=32)).replace(day=1)
            continue
        wd = (dt.weekday() + 1) % 7  # python Mon=0 -> cron Sun=0
        if dom_star and dow_star:
            day_ok = True
        elif dom_star:
            day_ok = wd in dow
        elif dow_star:
            day_ok = dt.day in dom
        else:
            day_ok = dt.day in dom or wd in dow  # classic cron: either matches when both restricted
        if not day_ok:
            dt = dt.replace(hour=0, minute=0) + timedelta(days=1)
            continue
        if dt.hour not in hour:
            dt = dt.replace(minute=0) + timedelta(hours=1)
            continue
        if dt.minute not in minute:
            dt += timedelta(minutes=1)
            continue
        return dt.timestamp()
    raise CronError("schedule never fires within 5 years")


def add_cron_job(name: str, schedule: str, handler_name: str, payload: Optional[Dict[str, Any]] = None,
                 enabled: bool = True, db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> Dict[str, Any]:
    name = (name or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_.\-]{1,64}", name):
        raise CronError("name must be 1-64 chars of [A-Za-z0-9_.-]")
    validate_schedule(schedule)
    now = time.time() if now is None else now
    jid = f"cron-{uuid.uuid4().hex[:10]}"
    conn = get_connection(db_path)
    try:
        conn.execute(
            "INSERT INTO cron_jobs(id,name,schedule,handler_name,payload,enabled,next_run_at,created_at) VALUES (?,?,?,?,?,?,?,?);",
            (jid, name, schedule.strip(), handler_name, json.dumps(payload or {}), 1 if enabled else 0, next_run(schedule, now), now))
    except Exception as exc:
        if "UNIQUE" in str(exc):
            raise CronError(f"cron job '{name}' already exists")
        raise
    finally:
        conn.close()
    return {"id": jid, "name": name, "schedule": schedule.strip(), "handler_name": handler_name, "enabled": enabled}


def ensure_cron_job(name: str, schedule: str, handler_name: str, payload=None, db_path: str = DEFAULT_DB_PATH) -> bool:
    """Idempotent registration for built-in jobs. Returns True if created."""
    try:
        add_cron_job(name, schedule, handler_name, payload, db_path=db_path)
        return True
    except CronError as exc:
        if "already exists" in str(exc):
            return False
        raise


def list_cron_jobs(db_path: str = DEFAULT_DB_PATH) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        return [dict(r) for r in conn.execute(
            "SELECT id,name,schedule,handler_name,enabled,next_run_at,last_run_at,last_job_id,run_count FROM cron_jobs ORDER BY name;").fetchall()]
    finally:
        conn.close()


def set_cron_enabled(job_id: str, enabled: bool, db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None) -> bool:
    now = time.time() if now is None else now
    conn = get_connection(db_path)
    try:
        r = conn.execute("SELECT schedule FROM cron_jobs WHERE id=?;", (job_id,)).fetchone()
        if not r:
            return False
        conn.execute("UPDATE cron_jobs SET enabled=?, next_run_at=? WHERE id=?;", (1 if enabled else 0, next_run(r["schedule"], now), job_id))
        return True
    finally:
        conn.close()


def delete_cron_job(job_id: str, db_path: str = DEFAULT_DB_PATH) -> bool:
    conn = get_connection(db_path)
    try:
        return conn.execute("DELETE FROM cron_jobs WHERE id=?;", (job_id,)).rowcount == 1
    finally:
        conn.close()


def tick(db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None, queue: Optional[DurableQueue] = None) -> List[Dict[str, Any]]:
    """Fire every due cron job once. Returns a list of {name, job_id, duplicate, slot}."""
    now = time.time() if now is None else now
    q = queue or DurableQueue(db_path)
    fired: List[Dict[str, Any]] = []
    if q.is_kill_switch_active():
        return fired
    conn = get_connection(db_path)
    try:
        due = conn.execute("SELECT * FROM cron_jobs WHERE enabled=1 AND next_run_at <= ? ORDER BY next_run_at;", (now,)).fetchall()
    finally:
        conn.close()
    for j in due:
        slot = j["next_run_at"]
        nxt = next_run(j["schedule"], now)  # coalesce: jump past all missed slots
        conn = get_connection(db_path)
        try:
            claimed = conn.execute("UPDATE cron_jobs SET next_run_at=? WHERE id=? AND next_run_at=? AND enabled=1;", (nxt, j["id"], slot)).rowcount == 1
        finally:
            conn.close()
        if not claimed:
            continue  # another scheduler took this slot
        try:
            res = q.enqueue_once(j["handler_name"], json.loads(j["payload"] or "{}"), f"cron:{j['id']}:{int(slot)}", priority=-10)
        except (KillSwitchActiveException, QueueCapacityExceededException) as exc:
            # slot is skipped (backpressure); next slot still fires. Visible via audit/log by caller.
            fired.append({"name": j["name"], "job_id": None, "skipped": exc.__class__.__name__, "slot": slot})
            continue
        conn = get_connection(db_path)
        try:
            conn.execute("UPDATE cron_jobs SET last_run_at=?, last_job_id=?, run_count=run_count+1 WHERE id=?;", (now, res["id"], j["id"]))
        finally:
            conn.close()
        fired.append({"name": j["name"], "job_id": res["id"], "duplicate": res.get("duplicate", False), "slot": slot})
    return fired


class CronRunner:
    def __init__(self, db_path: str = DEFAULT_DB_PATH, tick_seconds: float = 5.0):
        self.db_path = db_path
        self.tick_seconds = tick_seconds
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.last_tick: Optional[float] = None
        self.fired_total = 0

    def _loop(self) -> None:
        import logging
        log = logging.getLogger("kora.cron")
        while not self._stop.is_set():
            try:
                self.fired_total += len([f for f in tick(self.db_path) if f.get("job_id")])
                self.last_tick = time.time()
            except Exception:
                log.exception("cron tick failed")
            self._stop.wait(self.tick_seconds)

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="kora-cron", daemon=True)
        self._thread.start()

    def stop(self, timeout: float = 5.0) -> bool:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout)
        return not (self._thread and self._thread.is_alive())

    def status(self) -> Dict[str, Any]:
        return {"running": bool(self._thread and self._thread.is_alive()), "last_tick": self.last_tick, "fired_total": self.fired_total}
