"""Structured JSON logging with automatic secret redaction.

Every record is one JSON line. Dict-valued `extra` fields pass through `sanitize_recursive`, and message
text is scrubbed for bearer tokens / key=value secrets, so credentials cannot reach log files.
"""
from __future__ import annotations
import json
import logging
import logging.handlers
import re
import sys
import time
from typing import Any, Optional

from kora.core.security import sanitize_recursive

_SECRET_TEXT = re.compile(
    r"(?i)(authorization[=:]\s*(?:bearer\s+|basic\s+)?|bearer\s+|(?:api[_-]?key|token|secret|password|access_token)[=:]\s*)([A-Za-z0-9._\-~+/]{6,})"
)


def redact_text(text: str) -> str:
    return _SECRET_TEXT.sub(lambda m: m.group(1) + "[REDACTED]", str(text))


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        out = {
            "ts": round(record.created, 3),
            "level": record.levelname,
            "logger": record.name,
            "msg": redact_text(record.getMessage()),
        }
        fields = getattr(record, "fields", None)
        if isinstance(fields, dict):
            out.update(sanitize_recursive(fields))
        if record.exc_info:
            out["exc"] = redact_text(self.formatException(record.exc_info))[:2000]
        return json.dumps(out, ensure_ascii=False, default=str)


_configured = False


def configure_logging(level: str = "INFO", log_file: str = "", stream=None, force: bool = False) -> None:
    global _configured
    if _configured and not force:
        return
    root = logging.getLogger("kora")
    for h in list(root.handlers):
        root.removeHandler(h)
    root.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    handlers = [logging.StreamHandler(stream or sys.stderr)]
    if log_file:
        handlers.append(logging.handlers.RotatingFileHandler(log_file, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"))
    fmt = JsonFormatter()
    for h in handlers:
        h.setFormatter(fmt)
        root.addHandler(h)
    root.propagate = False
    _configured = True


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name if name.startswith("kora") else f"kora.{name}")


def log_event(logger: logging.Logger, level: int, msg: str, **fields: Any) -> None:
    logger.log(level, msg, extra={"fields": fields})
