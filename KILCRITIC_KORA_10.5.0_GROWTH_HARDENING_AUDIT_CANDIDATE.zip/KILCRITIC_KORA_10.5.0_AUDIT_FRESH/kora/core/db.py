"""
KORA PRO - Authoritative SQLite Database Manager (schema v2: retry/DLQ, cron, RAG, social publish)
Authoritative Source of Truth with WAL, Foreign Keys, Busy Timeout & Immediate Transactions.
"""
import os
import sqlite3
import json
import time
from typing import Optional, Dict, Any, List

DEFAULT_DB_PATH = os.path.abspath(os.environ.get("KORA_DB_PATH", "data/kora_authoritative.db"))

def get_connection(db_path: str = DEFAULT_DB_PATH) -> sqlite3.Connection:
    os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
    conn = sqlite3.connect(db_path, timeout=10.0, isolation_level=None)
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA busy_timeout = 5000;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    conn.row_factory = sqlite3.Row
    return conn

SOCIAL_STATUSES = ("PENDING_APPROVAL", "APPROVED", "APPROVED_AWAITING_CREDENTIALS", "PUBLISHING", "PUBLISHED", "FAILED", "REJECTED")
SOCIAL_POSTS_DDL = """
CREATE TABLE IF NOT EXISTS social_posts (
    id TEXT PRIMARY KEY,
    platform TEXT NOT NULL CHECK(platform IN ('YOUTUBE', 'FACEBOOK', 'INSTAGRAM', 'TIKTOK', 'X')),
    content TEXT NOT NULL,
    audience TEXT NOT NULL CHECK(audience IN ('KIDS', 'GENERAL', 'ADULT')),
    status TEXT NOT NULL CHECK(status IN ('PENDING_APPROVAL', 'APPROVED', 'APPROVED_AWAITING_CREDENTIALS', 'PUBLISHING', 'PUBLISHED', 'FAILED', 'REJECTED')),
    external_id TEXT,
    idempotency_key TEXT UNIQUE,
    created_at REAL NOT NULL,
    published_at REAL,
    media_path TEXT,
    title TEXT,
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    job_id TEXT,
    approved_by TEXT,
    approved_at REAL,
    media_url TEXT,
    media_type TEXT,
    ai_generated INTEGER NOT NULL DEFAULT 0
);"""

def _add_column(conn: sqlite3.Connection, table: str, column: str, ddl: str) -> None:
    cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table});").fetchall()}
    if column not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl};")


def _migrate_autopilot_v7(conn: sqlite3.Connection) -> None:
    """SQLite cannot widen a CHECK constraint: rebuild autopilot_schedules with the truthful states, keeping every row.
    The previous table is kept (renamed, never dropped) as autopilot_schedules_v6 for audit/rollback."""
    row = conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='autopilot_schedules';").fetchone()
    if not row or "WAITING_CREDENTIALS" in (row[0] or ""):
        return
    conn.execute("DROP INDEX IF EXISTS idx_autopilot_due;")
    conn.execute("ALTER TABLE autopilot_schedules RENAME TO autopilot_schedules_v6;")
    conn.execute("""CREATE TABLE autopilot_schedules (
        id TEXT PRIMARY KEY, post_id TEXT NOT NULL, scheduled_for_utc REAL NOT NULL, timezone TEXT NOT NULL,
        frequency TEXT NOT NULL CHECK(frequency IN ('ONCE','DAILY','WEEKLY')),
        status TEXT NOT NULL CHECK(status IN ('SCHEDULED','WAITING_APPROVAL','WAITING_CREDENTIALS','QUEUED','PUBLISHING','PUBLISHED','FAILED','PAUSED','CANCELLED')),
        created_at REAL NOT NULL, updated_at REAL NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT,
        claimed_at REAL, retry_policy TEXT, content_id TEXT, approval_state TEXT, external_id TEXT, next_retry_at REAL,
        FOREIGN KEY(post_id) REFERENCES social_posts(id) ON DELETE CASCADE);""")
    conn.execute("""INSERT INTO autopilot_schedules (id,post_id,scheduled_for_utc,timezone,frequency,status,created_at,updated_at,attempts,last_error)
                    SELECT id,post_id,scheduled_for_utc,timezone,frequency,status,created_at,updated_at,attempts,last_error FROM autopilot_schedules_v6;""")

def _migrate_social_posts(conn: sqlite3.Connection) -> None:
    """v1 -> v2: widen the status CHECK and add publish-lifecycle columns, preserving every row."""
    row = conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='social_posts';").fetchone()
    if not row or "PUBLISHING" in (row[0] or ""):
        return
    conn.execute("ALTER TABLE social_posts RENAME TO social_posts_v1;")
    conn.execute(SOCIAL_POSTS_DDL)
    conn.execute("""INSERT INTO social_posts (id, platform, content, audience, status, external_id, idempotency_key, created_at, published_at)
                    SELECT id, platform, content, audience, status, external_id, idempotency_key, created_at, published_at FROM social_posts_v1;""")
    conn.execute("DROP TABLE social_posts_v1;")

def get_setting(key: str, default: Optional[str] = None, db_path: str = DEFAULT_DB_PATH) -> Optional[str]:
    conn = get_connection(db_path)
    try:
        r = conn.execute("SELECT value FROM settings WHERE key = ?;", (key,)).fetchone()
        return r["value"] if r else default
    except sqlite3.OperationalError:
        return default
    finally:
        conn.close()

def set_setting(key: str, value: str, db_path: str = DEFAULT_DB_PATH) -> None:
    conn = get_connection(db_path)
    try:
        conn.execute("INSERT INTO settings(key, value, updated_at) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at;",
                     (key, str(value), time.time()))
    finally:
        conn.close()

def record_audit(event_type: str, actor: str, details: Dict[str, Any], db_path: str = DEFAULT_DB_PATH) -> None:
    """Append-only audit event, hash-chained (each row hashes the previous row's hash) so edits/deletions are detectable."""
    import hashlib
    from kora.core.security import sanitize_recursive
    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        prev = conn.execute("SELECT hash FROM audit_events ORDER BY id DESC LIMIT 1;").fetchone()
        prev_hash = (prev["hash"] if prev and prev["hash"] else "") if prev else ""
        det, ts = json.dumps(sanitize_recursive(details), default=str)[:4000], time.time()
        h = hashlib.sha256(f"{prev_hash}|{event_type}|{actor}|{det}|{ts!r}".encode()).hexdigest()
        conn.execute("INSERT INTO audit_events(event_type, actor, details, created_at, prev_hash, hash) VALUES (?,?,?,?,?,?);",
                     (event_type, actor, det, ts, prev_hash, h))
        conn.execute("COMMIT;")
    except Exception:
        try:
            conn.execute("ROLLBACK;")
        except Exception:
            pass
        raise
    finally:
        conn.close()


def verify_audit_chain(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Recompute the chain over hashed rows. Rows written before chaining existed (hash NULL) are skipped, not trusted."""
    import hashlib
    conn = get_connection(db_path)
    try:
        rows = conn.execute("SELECT id,event_type,actor,details,created_at,prev_hash,hash FROM audit_events WHERE hash IS NOT NULL ORDER BY id;").fetchall()
        prev, checked = None, 0
        for r in rows:
            if prev is not None:
                if r["prev_hash"] != prev:
                    return {"ok": False, "broken_at": r["id"], "reason": "chain_link_mismatch_or_row_deleted", "checked": checked}
            exp = hashlib.sha256(f"{r['prev_hash']}|{r['event_type']}|{r['actor']}|{r['details']}|{r['created_at']!r}".encode()).hexdigest()
            if exp != r["hash"]:
                return {"ok": False, "broken_at": r["id"], "reason": "row_modified", "checked": checked}
            prev, checked = r["hash"], checked + 1
        return {"ok": True, "checked": checked}
    finally:
        conn.close()

def init_db(db_path: str = DEFAULT_DB_PATH) -> None:
    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        
        # 1. Jobs Queue table with atomic fencing, leases, and priority ordering
        conn.execute("""
        CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY,
            idempotency_key TEXT UNIQUE,
            priority INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL CHECK(status IN ('QUEUED', 'RUNNING', 'COMPLETED', 'FAILED', 'CANCELLED', 'DEAD_LETTER')),
            handler_name TEXT NOT NULL,
            payload TEXT NOT NULL,
            result TEXT,
            error TEXT,
            worker_id TEXT,
            lease_expires_at REAL,
            version INTEGER NOT NULL DEFAULT 1,
            attempts INTEGER NOT NULL DEFAULT 0,
            max_retries INTEGER NOT NULL DEFAULT 3,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL
        );
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_claim ON jobs(status, priority DESC, created_at ASC);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_lease ON jobs(status, lease_expires_at);")

        # 2. Media Assets table with strict Audience Isolation
        conn.execute("""
        CREATE TABLE IF NOT EXISTS media_assets (
            id TEXT PRIMARY KEY,
            filename TEXT NOT NULL,
            sha256 TEXT NOT NULL,
            audience TEXT NOT NULL CHECK(audience IN ('KIDS', 'GENERAL', 'ADULT')),
            file_size INTEGER NOT NULL,
            mime_type TEXT NOT NULL,
            storage_path TEXT NOT NULL,
            perceptual_hash TEXT,
            is_duplicate INTEGER NOT NULL DEFAULT 0,
            duplicate_of_id TEXT,
            created_at REAL NOT NULL,
            UNIQUE(sha256, audience),
            FOREIGN KEY(duplicate_of_id) REFERENCES media_assets(id) ON DELETE SET NULL
        );
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_media_sha_aud ON media_assets(sha256, audience);")

        # 3. Backups Ledger
        conn.execute("""
        CREATE TABLE IF NOT EXISTS backups (
            id TEXT PRIMARY KEY,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL,
            sha256 TEXT NOT NULL,
            size_bytes INTEGER NOT NULL,
            integrity_verified INTEGER NOT NULL DEFAULT 0,
            created_at REAL NOT NULL
        );
        """)

        # 4. Transcripts table
        conn.execute("""
        CREATE TABLE IF NOT EXISTS transcripts (
            id TEXT PRIMARY KEY,
            filename TEXT NOT NULL,
            provider TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('COMPLETED', 'TRANSCRIPTION_UNAVAILABLE', 'FAILED')),
            transcript TEXT NOT NULL,
            confidence REAL NOT NULL DEFAULT 0.0,
            duration REAL NOT NULL DEFAULT 0.0,
            speaker_tags TEXT,
            created_at REAL NOT NULL
        );
        """)

        # 5. Social Posts table with Approval enforcement (v2: publish lifecycle)
        _migrate_social_posts(conn)
        conn.execute(SOCIAL_POSTS_DDL)
        _add_column(conn, "social_posts", "media_url", "TEXT")
        _add_column(conn, "social_posts", "media_type", "TEXT")
        _add_column(conn, "social_posts", "ai_generated", "INTEGER NOT NULL DEFAULT 0")

        # 6. Structured Audit Events Log
        conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            actor TEXT NOT NULL,
            details TEXT NOT NULL,
            created_at REAL NOT NULL
        );
        """)

        # 7. System Health Probes History
        conn.execute("""
        CREATE TABLE IF NOT EXISTS system_probes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            component TEXT NOT NULL,
            status TEXT NOT NULL,
            message TEXT NOT NULL,
            metrics TEXT,
            created_at REAL NOT NULL
        );
        """)

        # 8. Schema Metadata
        conn.execute("""
        CREATE TABLE IF NOT EXISTS schema_migrations (
            version INTEGER PRIMARY KEY,
            applied_at REAL NOT NULL
        );
        """)
        conn.execute("INSERT OR IGNORE INTO schema_migrations (version, applied_at) VALUES (1, ?);", (time.time(),))

        # ---- schema v2 (additive) ----
        _add_column(conn, "jobs", "next_attempt_at", "REAL NOT NULL DEFAULT 0")
        _add_column(conn, "jobs", "dead_lettered_at", "REAL")
        _add_column(conn, "jobs", "last_error_kind", "TEXT")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_ready ON jobs(status, next_attempt_at, priority DESC, created_at ASC);")
        conn.execute("""CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at REAL NOT NULL);""")
        conn.execute("""
        CREATE TABLE IF NOT EXISTS cron_jobs (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL UNIQUE,
            schedule TEXT NOT NULL,
            handler_name TEXT NOT NULL,
            payload TEXT NOT NULL DEFAULT '{}',
            enabled INTEGER NOT NULL DEFAULT 1,
            next_run_at REAL NOT NULL,
            last_run_at REAL,
            last_job_id TEXT,
            run_count INTEGER NOT NULL DEFAULT 0,
            created_at REAL NOT NULL
        );""")
        conn.execute("""
        CREATE TABLE IF NOT EXISTS rag_docs (
            id TEXT PRIMARY KEY,
            source TEXT NOT NULL,
            title TEXT NOT NULL DEFAULT '',
            content_sha256 TEXT NOT NULL UNIQUE,
            chunk_count INTEGER NOT NULL DEFAULT 0,
            created_at REAL NOT NULL
        );""")
        conn.execute("""
        CREATE TABLE IF NOT EXISTS rag_chunks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            doc_id TEXT NOT NULL,
            idx INTEGER NOT NULL,
            text TEXT NOT NULL,
            vec TEXT NOT NULL,
            FOREIGN KEY(doc_id) REFERENCES rag_docs(id) ON DELETE CASCADE
        );""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_rag_chunks_doc ON rag_chunks(doc_id);")
        conn.execute("INSERT OR IGNORE INTO schema_migrations (version, applied_at) VALUES (2, ?);", (time.time(),))


        # ---- schema v3 (additive): governance ----
        _add_column(conn, "social_posts", "preflight", "TEXT")
        conn.execute("""
        CREATE TABLE IF NOT EXISTS proposals (
            id TEXT PRIMARY KEY,
            action TEXT NOT NULL,
            reason TEXT NOT NULL,
            risk TEXT NOT NULL,
            changes TEXT NOT NULL DEFAULT '[]',
            tests TEXT NOT NULL DEFAULT '[]',
            rollback TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','APPROVED','REJECTED','EXECUTING','EXECUTED','FAILED')),
            decided_by TEXT, decided_at REAL, result TEXT,
            created_at REAL NOT NULL
        );""")
        conn.execute("""CREATE TABLE IF NOT EXISTS checkpoints (task_id TEXT PRIMARY KEY, state TEXT NOT NULL, updated_at REAL NOT NULL);""")
        conn.execute("""CREATE TABLE IF NOT EXISTS budget_usage (
            period TEXT NOT NULL, resource TEXT NOT NULL, used REAL NOT NULL DEFAULT 0, reserved REAL NOT NULL DEFAULT 0,
            PRIMARY KEY(period, resource));""")
        conn.execute("INSERT OR IGNORE INTO schema_migrations (version, applied_at) VALUES (3, ?);", (time.time(),))


        _add_column(conn, "audit_events", "prev_hash", "TEXT")
        _add_column(conn, "audit_events", "hash", "TEXT")
        # ---- schema v4 (additive): identity, DNA/time machine, trust/provenance, ledger, missions ----
        conn.execute("""CREATE TABLE IF NOT EXISTS principals (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('user','device')),
            token_hash TEXT NOT NULL UNIQUE, created_at REAL NOT NULL, created_by TEXT, revoked_at REAL, expires_at REAL);""")
        conn.execute("""CREATE TABLE IF NOT EXISTS grants (
            id TEXT PRIMARY KEY, principal_id TEXT NOT NULL, permission TEXT NOT NULL, expires_at REAL,
            created_by TEXT, created_at REAL NOT NULL, revoked_at REAL,
            FOREIGN KEY(principal_id) REFERENCES principals(id) ON DELETE CASCADE);""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_grants_p ON grants(principal_id, permission);")
        conn.execute("""CREATE TABLE IF NOT EXISTS dna_versions (
            kind TEXT NOT NULL, version INTEGER NOT NULL, data TEXT NOT NULL, actor TEXT NOT NULL, note TEXT NOT NULL DEFAULT '',
            created_at REAL NOT NULL, PRIMARY KEY(kind, version));""")
        conn.execute("""CREATE TABLE IF NOT EXISTS dna_learn (
            id INTEGER PRIMARY KEY AUTOINCREMENT, task TEXT, outcome TEXT, correction TEXT, preference TEXT, source TEXT,
            confidence REAL, created_at REAL NOT NULL);""")
        conn.execute("""CREATE TABLE IF NOT EXISTS trust (
            subject_type TEXT NOT NULL, subject_id TEXT NOT NULL,
            level TEXT NOT NULL CHECK(level IN ('TRUSTED','VERIFIED','UNKNOWN','SUSPICIOUS','BLOCKED')),
            sha256 TEXT, evidence TEXT, updated_at REAL NOT NULL, PRIMARY KEY(subject_type, subject_id));""")
        conn.execute("""CREATE TABLE IF NOT EXISTS provenance (
            id INTEGER PRIMARY KEY AUTOINCREMENT, subject_type TEXT NOT NULL, subject_id TEXT NOT NULL, source TEXT, tool TEXT,
            license TEXT, rights TEXT, transformations TEXT, verification TEXT, version TEXT, created_at REAL NOT NULL);""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_prov_subject ON provenance(subject_type, subject_id);")
        conn.execute("""CREATE TABLE IF NOT EXISTS autopilot_schedules (
            id TEXT PRIMARY KEY, post_id TEXT NOT NULL, scheduled_for_utc REAL NOT NULL, timezone TEXT NOT NULL,
            frequency TEXT NOT NULL CHECK(frequency IN ('ONCE','DAILY','WEEKLY')),
            status TEXT NOT NULL CHECK(status IN ('SCHEDULED','WAITING_APPROVAL','WAITING_CREDENTIALS','QUEUED','PUBLISHING','PUBLISHED','FAILED','PAUSED','CANCELLED')),
            created_at REAL NOT NULL, updated_at REAL NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT,
            claimed_at REAL, retry_policy TEXT, content_id TEXT, approval_state TEXT, external_id TEXT, next_retry_at REAL,
            FOREIGN KEY(post_id) REFERENCES social_posts(id) ON DELETE CASCADE
        );""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_autopilot_due ON autopilot_schedules(status, scheduled_for_utc);")

        conn.execute("""CREATE TABLE IF NOT EXISTS ledger (
            id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL CHECK(kind IN ('cost','revenue')), amount REAL NOT NULL CHECK(amount > 0),
            currency TEXT NOT NULL, estimated INTEGER NOT NULL, note TEXT NOT NULL, evidence TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'ESTIMATE', fees REAL NOT NULL DEFAULT 0, source TEXT NOT NULL DEFAULT '');""")
        conn.execute("""CREATE TABLE IF NOT EXISTS missions (
            id TEXT PRIMARY KEY, goal TEXT NOT NULL, milestones TEXT NOT NULL DEFAULT '[]', status TEXT NOT NULL DEFAULT 'ACTIVE',
            created_at REAL NOT NULL, updated_at REAL NOT NULL);""")
        conn.execute("INSERT OR IGNORE INTO schema_migrations (version, applied_at) VALUES (4, ?);", (time.time(),))

        # ---- schema v5 (additive): per-user task context/dependencies on the ONE queue, account registry, DNA observations ----
        _add_column(conn, "jobs", "owner", "TEXT NOT NULL DEFAULT ''")
        _add_column(conn, "jobs", "label", "TEXT NOT NULL DEFAULT ''")
        _add_column(conn, "jobs", "depends_on", "TEXT NOT NULL DEFAULT ''")
        _add_column(conn, "jobs", "paused", "INTEGER NOT NULL DEFAULT 0")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_owner ON jobs(owner, status);")
        conn.execute("""CREATE TABLE IF NOT EXISTS accounts (
            owner TEXT NOT NULL, platform TEXT NOT NULL, handle TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'OFF' CHECK(status IN ('ON','OFF','NEEDS_RECONNECT')),
            updated_at REAL NOT NULL, PRIMARY KEY(owner, platform));""")
        conn.execute("""CREATE TABLE IF NOT EXISTS dna_observations (
            key TEXT NOT NULL, value TEXT NOT NULL, count INTEGER NOT NULL DEFAULT 1, first_at REAL NOT NULL, last_at REAL NOT NULL,
            PRIMARY KEY(key, value));""")
        conn.execute("INSERT OR IGNORE INTO schema_migrations (version, applied_at) VALUES (5, ?);", (time.time(),))

        # ---- schema v6 (additive): Self-Evolution 3.0 tamper-evident ledger (evolution memory) + regression guards; public media URL for Graph/TikTok pulls ----
        conn.execute("""CREATE TABLE IF NOT EXISTS evo_ledger (
            id INTEGER PRIMARY KEY AUTOINCREMENT, proposal_id TEXT NOT NULL DEFAULT '', stage TEXT NOT NULL, payload TEXT NOT NULL,
            schema_v INTEGER NOT NULL DEFAULT 2, prev_hash TEXT NOT NULL DEFAULT '', hash TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL);""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_evo_ledger_p ON evo_ledger(proposal_id, stage);")
        conn.execute("""CREATE TABLE IF NOT EXISTS evo_guards (
            id INTEGER PRIMARY KEY AUTOINCREMENT, pattern TEXT NOT NULL UNIQUE, files TEXT NOT NULL DEFAULT '[]', reason TEXT NOT NULL,
            test_ref TEXT NOT NULL DEFAULT '', hits INTEGER NOT NULL DEFAULT 0, created_at REAL NOT NULL);""")
        _add_column(conn, "social_posts", "media_url", "TEXT")
        conn.execute("INSERT OR IGNORE INTO schema_migrations (version, applied_at) VALUES (6, ?);", (time.time(),))

        # ---- schema v7 (additive): truthful scheduler states + recovery columns, post owner (account gate), watchdog/quarantine ledgers ----
        _add_column(conn, "social_posts", "owner", "TEXT")
        # external read-back verification (additive): NOT_VERIFIED | VERIFIED | NOT_FOUND | PENDING | UNVERIFIED
        _add_column(conn, "social_posts", "verification_state", "TEXT NOT NULL DEFAULT 'NOT_VERIFIED'")
        _add_column(conn, "social_posts", "verified_at", "REAL")
        _add_column(conn, "social_posts", "verification_detail", "TEXT")
        _migrate_autopilot_v7(conn)
        for col, ddl in (("claimed_at", "REAL"), ("retry_policy", "TEXT"), ("content_id", "TEXT"), ("approval_state", "TEXT"),
                         ("external_id", "TEXT"), ("next_retry_at", "REAL")):
            _add_column(conn, "autopilot_schedules", col, ddl)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_autopilot_due ON autopilot_schedules(status, scheduled_for_utc);")
        conn.execute("""CREATE TABLE IF NOT EXISTS quarantine_ledger (
            id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, subject TEXT NOT NULL, reason TEXT NOT NULL, evidence TEXT NOT NULL DEFAULT '{}',
            status TEXT NOT NULL DEFAULT 'QUARANTINED', created_at REAL NOT NULL, released_at REAL, released_by TEXT);""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_quarantine_kind ON quarantine_ledger(kind, status);")
        conn.execute("INSERT OR IGNORE INTO schema_migrations (version, applied_at) VALUES (7, ?);", (time.time(),))


        # ---- schema v5 (additive): Supreme Guardian / self-sufficiency layer ----
        conn.execute("CREATE TABLE IF NOT EXISTS guardian_incidents (id TEXT PRIMARY KEY, kind TEXT NOT NULL, subject TEXT NOT NULL, status TEXT NOT NULL, evidence TEXT NOT NULL, proposed_fix TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL, resolved_at REAL, resolution TEXT NOT NULL DEFAULT '');")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_guardian_incidents_status ON guardian_incidents(status);")
        conn.execute("CREATE TABLE IF NOT EXISTS guardian_predictions (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, prediction TEXT NOT NULL, confidence REAL NOT NULL, evidence TEXT NOT NULL, created_at REAL NOT NULL);")
        conn.execute("CREATE TABLE IF NOT EXISTS guardian_meta_tools (name TEXT PRIMARY KEY, steps TEXT NOT NULL, status TEXT NOT NULL, benchmark TEXT NOT NULL DEFAULT '{}', created_at REAL NOT NULL, updated_at REAL NOT NULL);")
        conn.execute("CREATE TABLE IF NOT EXISTS guardian_recycle (path TEXT PRIMARY KEY, status TEXT NOT NULL, evidence TEXT NOT NULL, replacement TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL);")
        conn.execute("CREATE TABLE IF NOT EXISTS guardian_vault (name TEXT PRIMARY KEY, token TEXT NOT NULL, created_at REAL NOT NULL, expires_at REAL, revoked_at REAL, version INTEGER NOT NULL DEFAULT 1);")
        conn.execute("INSERT OR IGNORE INTO schema_migrations (version, applied_at) VALUES (5, ?);", (time.time(),))

        conn.execute("COMMIT;")
    except Exception as e:
        conn.execute("ROLLBACK;")
        raise e
    finally:
        conn.close()

if __name__ == "__main__":
    init_db()
    print("Database initialized successfully at", DEFAULT_DB_PATH)
