"""Request authentication for the KORA bridge.

Rules (fail closed):
* Client address is the TCP peer. X-Forwarded-For is honoured ONLY when KORA_TRUST_PROXY=true.
* No token configured  -> only loopback clients are allowed.
* Token configured     -> remote clients need `Authorization: Bearer <token>` (or X-Kora-Token).
                          Loopback clients may omit it unless KORA_REQUIRE_AUTH_LOCAL=true.
* A wrong token is always rejected, even from loopback.
* Repeated failures from one client are throttled (bounded table).
"""
from __future__ import annotations
import threading
import time
from collections import OrderedDict
from typing import Mapping, Optional, Tuple

from kora.core.security import constant_time_compare

LOOPBACK = {"127.0.0.1", "::1", "localhost"}


def client_ip(peer: str, headers: Mapping[str, str], trust_proxy: bool) -> str:
    if trust_proxy:
        fwd = headers.get("x-forwarded-for", "")
        if fwd:
            return fwd.split(",")[0].strip() or peer
    return peer


def extract_token(headers: Mapping[str, str]) -> str:
    auth = headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    return headers.get("x-kora-token", "").strip()


class Authenticator:
    def __init__(self, token: str, require_local: bool = False, trust_proxy: bool = False,
                 max_fail: int = 8, window: float = 60.0, clock=time.monotonic):
        self.token = token
        self.require_local = require_local
        self.trust_proxy = trust_proxy
        self.max_fail = max_fail
        self.window = window
        self._clock = clock
        self._fails: "OrderedDict[str, list]" = OrderedDict()
        self._lock = threading.Lock()

    def _throttled(self, ip: str) -> bool:
        now = self._clock()
        with self._lock:
            recent = [t for t in self._fails.get(ip, []) if now - t < self.window]
            self._fails[ip] = recent
            self._fails.move_to_end(ip)
            while len(self._fails) > 5000:
                self._fails.popitem(last=False)
            return len(recent) >= self.max_fail

    def _record_fail(self, ip: str) -> None:
        with self._lock:
            self._fails.setdefault(ip, []).append(self._clock())

    def check(self, peer: str, headers: Mapping[str, str]) -> Tuple[bool, int, str]:
        """Return (allowed, http_status, reason). `headers` keys must be lower-case."""
        ip = client_ip(peer, headers, self.trust_proxy)
        local = ip in LOOPBACK
        supplied = extract_token(headers)
        if self._throttled(ip):
            return False, 429, "too_many_auth_failures"
        if supplied:
            if self.token and constant_time_compare(supplied, self.token):
                return True, 200, "token_ok"
            self._record_fail(ip)
            return False, 403, "invalid_token"
        if local and not (self.require_local and self.token):
            return True, 200, "local_ok"
        if not self.token:
            return False, 403, "remote_denied_no_token_configured"
        self._record_fail(ip)
        return False, 403, "token_required"
