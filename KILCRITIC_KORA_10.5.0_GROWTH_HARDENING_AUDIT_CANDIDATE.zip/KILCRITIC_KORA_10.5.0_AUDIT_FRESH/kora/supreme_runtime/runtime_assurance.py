from __future__ import annotations

"""Next-generation KORA runtime assurance primitives.

Design rule: this layer governs and proves execution; it does not replace
existing scheduling, queues, permissions, security, memory, or repair engines.
All persistence is caller-owned so the layer can remain lightweight and
portable on mobile/desktop deployments.
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
import hashlib
import json
import time
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _hash(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode()).hexdigest()


@dataclass(frozen=True)
class AgentContract:
    """Bounded task contract inherited by delegated work."""
    contract_id: str
    goal: str
    allowed_actions: Tuple[str, ...] = ()
    forbidden_actions: Tuple[str, ...] = ()
    max_steps: int = 50
    max_seconds: int = 900
    max_cost: float = 0.0
    success_criteria: Tuple[str, ...] = ()
    exit_conditions: Tuple[str, ...] = ()
    parent_contract_id: Optional[str] = None

    def child(self, contract_id: str, goal: str, allowed_actions: Sequence[str]) -> "AgentContract":
        """Create a strictly no-more-authority child contract."""
        allowed = tuple(a for a in allowed_actions if a in self.allowed_actions)
        return AgentContract(
            contract_id=contract_id, goal=goal, allowed_actions=allowed,
            forbidden_actions=self.forbidden_actions,
            max_steps=max(1, min(self.max_steps, self.max_steps // 2 or 1)),
            max_seconds=max(1, min(self.max_seconds, self.max_seconds // 2 or 1)),
            max_cost=max(0.0, min(self.max_cost, self.max_cost)),
            success_criteria=self.success_criteria,
            exit_conditions=self.exit_conditions,
            parent_contract_id=self.contract_id,
        )

    def permits(self, action: str, step: int, elapsed_seconds: float, cost: float) -> bool:
        return (action in self.allowed_actions and action not in self.forbidden_actions
                and step < self.max_steps and elapsed_seconds <= self.max_seconds
                and cost <= self.max_cost)


@dataclass(frozen=True)
class AutonomyBudget:
    level: str = "ASK"
    risk: str = "MEDIUM"
    max_external_effects: int = 0
    reversible_only: bool = True

    def permits_external(self) -> bool:
        return self.level in {"AUTO", "BOUNDED"} and self.max_external_effects > 0


class HorizonReducer:
    """Break a long plan into bounded, verifiable horizons."""
    def reduce(self, steps: Sequence[str], horizon: int = 5) -> List[List[str]]:
        horizon = max(1, min(int(horizon), 25))
        return [list(steps[i:i + horizon]) for i in range(0, len(steps), horizon)]


class TrajectoryGuard:
    """Check mission-level invariants, not only individual actions."""
    def __init__(self, forbidden_sequences: Optional[Sequence[Sequence[str]]] = None):
        self.forbidden_sequences = [tuple(x) for x in (forbidden_sequences or []) if x]

    def check(self, trajectory: Sequence[str], invariants: Sequence[str] = ()) -> Dict[str, Any]:
        seq = tuple(trajectory)
        violations: List[str] = []
        for forbidden in self.forbidden_sequences:
            if len(forbidden) <= len(seq):
                for i in range(len(seq) - len(forbidden) + 1):
                    if seq[i:i + len(forbidden)] == forbidden:
                        violations.append("forbidden_sequence:" + "->".join(forbidden))
        return {"safe": not violations, "violations": violations,
                "invariants_checked": list(invariants), "trajectory_hash": _hash(list(seq))}


class RuntimeWatchdog:
    """Independent-style decision boundary; caller wires it beside the worker."""
    def __init__(self, max_steps: int = 1000, max_errors: int = 5):
        self.max_steps = max(1, max_steps)
        self.max_errors = max(1, max_errors)

    def inspect(self, *, step: int, errors: int, action: str,
                resource_pressure: str = "LOW", anomaly: bool = False) -> Dict[str, Any]:
        reasons = []
        if step >= self.max_steps: reasons.append("step_budget_exhausted")
        if errors >= self.max_errors: reasons.append("error_budget_exhausted")
        if resource_pressure.upper() == "CRITICAL": reasons.append("critical_resource_pressure")
        if anomaly: reasons.append("runtime_anomaly")
        return {"decision": "STOP" if reasons else "CONTINUE", "reasons": reasons,
                "action": action, "observed_at": _now()}


@dataclass
class ExecutionProof:
    """Tamper-evident proof record, not a blockchain or cryptographic signature."""
    contract_id: str
    events: List[Dict[str, Any]] = field(default_factory=list)
    previous_hash: str = "GENESIS"

    def append(self, event: Mapping[str, Any]) -> str:
        record = {"event": dict(event), "previous_hash": self.previous_hash,
                  "recorded_at": _now()}
        digest = _hash(record)
        record["hash"] = digest
        self.events.append(record)
        self.previous_hash = digest
        return digest

    def verify(self) -> bool:
        previous = "GENESIS"
        for record in self.events:
            if record.get("previous_hash") != previous:
                return False
            body = {"event": record.get("event", {}),
                    "previous_hash": record.get("previous_hash"),
                    "recorded_at": record.get("recorded_at")}
            if _hash(body) != record.get("hash"):
                return False
            previous = record["hash"]
        return previous == self.previous_hash


@dataclass
class StateMemoryTree:
    """Execution-state branches with explicit trusted/stale status."""
    root_id: str
    nodes: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    def add(self, node_id: str, parent_id: Optional[str], state: Mapping[str, Any], trusted: bool = True) -> None:
        if parent_id is not None and parent_id not in self.nodes and parent_id != self.root_id:
            raise ValueError("unknown parent state")
        self.nodes[node_id] = {"parent_id": parent_id, "state": dict(state),
                               "trusted": bool(trusted), "updated_at": _now()}

    def mark_stale(self, node_id: str) -> None:
        if node_id in self.nodes:
            self.nodes[node_id]["trusted"] = False
            self.nodes[node_id]["stale_at"] = _now()

    def trusted_path(self, node_id: str) -> List[Dict[str, Any]]:
        out = []
        current = node_id
        while current in self.nodes:
            node = self.nodes[current]
            if not node.get("trusted"):
                return []
            out.append({"id": current, **node})
            current = node.get("parent_id")
        return list(reversed(out))


@dataclass(frozen=True)
class DelegationRecord:
    delegation_id: str
    parent_agent: str
    child_agent: str
    contract_id: str
    capability: str
    created_at: str = field(default_factory=_now)
    expires_at: Optional[str] = None
    revoked: bool = False


@dataclass(frozen=True)
class SupplyChainRecord:
    component: str
    version: str
    source: str
    content_hash: str
    allowed: bool = False
    verified_at: str = field(default_factory=_now)


@dataclass
class EvidenceRecord:
    subject: str
    source: str
    status: str = "UNVERIFIED"
    captured_at: str = field(default_factory=_now)
    max_age_seconds: Optional[int] = None
    evidence_hash: str = ""

    def __post_init__(self) -> None:
        if not self.evidence_hash:
            self.evidence_hash = _hash(asdict(self) | {"evidence_hash": ""})

    def freshness(self, now: Optional[float] = None) -> str:
        if self.max_age_seconds is None:
            return "CURRENT"
        try:
            captured = datetime.fromisoformat(self.captured_at).timestamp()
        except ValueError:
            return "UNKNOWN"
        age = (now or time.time()) - captured
        return "STALE" if age > self.max_age_seconds else "CURRENT"


@dataclass(frozen=True)
class ComplexityDebt:
    capability_gain: float
    complexity_added: float
    maintenance_cost: float
    failure_surface: float

    def score(self) -> float:
        return self.capability_gain - (self.complexity_added + self.maintenance_cost + self.failure_surface)


@dataclass(frozen=True)
class ObjectiveDrift:
    original_goal: str
    current_goal: str

    def detected(self) -> bool:
        return self.original_goal.strip() != self.current_goal.strip()


@dataclass(frozen=True)
class BlastRadius:
    files: Tuple[str, ...] = ()
    modules: Tuple[str, ...] = ()
    external_systems: Tuple[str, ...] = ()
    credentials: Tuple[str, ...] = ()
    queues: Tuple[str, ...] = ()

    def score(self) -> int:
        return sum(bool(x) for x in (self.files, self.modules, self.external_systems, self.credentials, self.queues))


@dataclass(frozen=True)
class RecoveryProof:
    failed_step: str
    checkpoint: str
    side_effects: Tuple[str, ...] = ()
    blocked_repeats: Tuple[str, ...] = ()
    rollback_verified: bool = False

    def valid(self) -> bool:
        return bool(self.failed_step and self.checkpoint and self.rollback_verified)


class SupremeRuntime:
    """Facade that composes the primitives without owning execution resources."""
    def __init__(self) -> None:
        self.horizon = HorizonReducer()
        self.trajectory = TrajectoryGuard()
        self.watchdog = RuntimeWatchdog()

    def preflight(self, contract: AgentContract, steps: Sequence[str], *, goal: Optional[str] = None) -> Dict[str, Any]:
        drift = ObjectiveDrift(contract.goal, goal or contract.goal)
        horizons = self.horizon.reduce(steps)
        trajectory = self.trajectory.check(steps)
        return {
            "contract_id": contract.contract_id,
            "goal": contract.goal,
            "objective_drift": drift.detected(),
            "horizon_count": len(horizons),
            "horizons": horizons,
            "trajectory": trajectory,
            "ready": not drift.detected() and trajectory["safe"],
        }

    @staticmethod
    def attest(proof: ExecutionProof) -> Dict[str, Any]:
        return {"proof_valid": proof.verify(), "event_count": len(proof.events),
                "head": proof.previous_hash}
