"""KORA Supreme Runtime Assurance layer.

A single coordination boundary for next-generation runtime guarantees:
contracts, horizon reduction, trajectory assurance, execution proofs,
state-tree memory, identity/delegation, supply-chain trust, watchdogs,
drift/blast-radius checks, evidence freshness, recovery proof and
architecture-complexity accounting.

It intentionally does not create a second scheduler, queue, permission
engine, security engine, or database. It produces machine-checkable plans,
verdicts and evidence that existing engines can consume.
"""
from .runtime_assurance import (
    AgentContract, AutonomyBudget, HorizonReducer, TrajectoryGuard,
    RuntimeWatchdog, ExecutionProof, StateMemoryTree, DelegationRecord,
    SupplyChainRecord, EvidenceRecord, ComplexityDebt, ObjectiveDrift,
    BlastRadius, RecoveryProof, SupremeRuntime,
)

__all__ = [
    "AgentContract", "AutonomyBudget", "HorizonReducer", "TrajectoryGuard",
    "RuntimeWatchdog", "ExecutionProof", "StateMemoryTree", "DelegationRecord",
    "SupplyChainRecord", "EvidenceRecord", "ComplexityDebt", "ObjectiveDrift",
    "BlastRadius", "RecoveryProof", "SupremeRuntime",
]
