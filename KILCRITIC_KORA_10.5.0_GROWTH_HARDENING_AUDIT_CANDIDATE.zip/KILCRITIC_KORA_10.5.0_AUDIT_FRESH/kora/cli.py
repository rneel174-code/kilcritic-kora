"""
KORA 8.8.5 - Unified Command-Line Interface (CLI)
Provides operations for testing, backups, doctor sweeps, queue workers, and audits.
"""
import sys
import json
import argparse
from kora.core.db import init_db, DEFAULT_DB_PATH
from kora.core.queue import DurableQueue
from kora_core.worker import SafeWorker
from kora.services.backup import create_verified_backup, verify_and_test_restore
from kora.services.system_doctor import run_system_doctor_inspection, execute_safe_self_healing
import kora.tests.run_all as tests_runner

def main():
    parser = argparse.ArgumentParser(description="KORA PRO Command Center CLI")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Command: test
    subparsers.add_parser("test", help="Execute complete 22-test behavioral suite")

    # Command: init
    subparsers.add_parser("init", help="Initialize authoritative SQLite database")

    # Command: backup
    subparsers.add_parser("backup", help="Create verified snapshot with SHA-256 and integrity check")

    # Command: doctor
    subparsers.add_parser("doctor", help="Run real System Doctor telemetry inspection")

    # Command: heal
    subparsers.add_parser("heal", help="Execute safe self-healing (temp cleanup + lease recovery)")

    # Command: worker
    worker_parser = subparsers.add_parser("worker", help="Run queue worker for N iterations")
    worker_parser.add_argument("--count", type=int, default=1, help="Number of jobs to process")

    # Command: stats
    subparsers.add_parser("stats", help="Show durable queue telemetry stats")
    subparsers.add_parser("serve", help="Run HTTP bridge + worker pool + cron")
    subparsers.add_parser("dlq", help="List dead-letter queue")
    rq = subparsers.add_parser("dlq-requeue", help="Requeue one dead-lettered job")
    rq.add_argument("job_id")

    args = parser.parse_args()
    if args.command not in (None, "test"):
        init_db()  # idempotent; guarantees the schema exists for every command

    if args.command == "test":
        tests_runner.main()
    elif args.command == "init":
        init_db()
        print("Database initialized.")
    elif args.command == "backup":
        res = create_verified_backup()
        print(json.dumps(res, indent=2))
    elif args.command == "doctor":
        res = run_system_doctor_inspection(DEFAULT_DB_PATH)
        print(json.dumps(res, indent=2))
    elif args.command == "heal":
        res = execute_safe_self_healing(DEFAULT_DB_PATH)
        print(json.dumps(res, indent=2))
    elif args.command == "worker":
        q = DurableQueue()
        w = SafeWorker(q)
        for _ in range(args.count):
            res = w.process_one()
            print("Processed job:", res)
    elif args.command == "stats":
        q = DurableQueue()
        print(json.dumps(q.get_stats(), indent=2))
    elif args.command == "serve":
        from kora.bridge.server import serve
        serve()
    elif args.command == "dlq":
        print(json.dumps(DurableQueue().list_dead_letters(), indent=2))
    elif args.command == "dlq-requeue":
        print(json.dumps({"requeued": DurableQueue().requeue_dead_letter(args.job_id)}))
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
