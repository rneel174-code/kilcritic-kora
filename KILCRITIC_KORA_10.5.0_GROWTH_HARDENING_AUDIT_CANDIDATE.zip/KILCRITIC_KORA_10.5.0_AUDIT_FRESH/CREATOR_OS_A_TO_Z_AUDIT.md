# KILCRITIC Creator OS A→Z audit — 2026-10-05

## Locked UX
- Full-screen KORA face as central interaction point.
- Transparent/glass folder controls around the face.
- Same interaction model inside each folder: touch, voice, text.
- Creator-first dashboard; technical tools remain in Advanced.
- Region profiles: India, America, Canada.
- Human-authorized account connection model; no credential/account fabrication.

## Important external limits
- Social publishing requires official APIs, OAuth/permissions, and platform approval where required.
- Amazon Associate registration must be completed by the human owner; locale tags are separate.
- Copyright/rights status is verified where evidence exists; no blanket copyright guarantee.
- Search can discover world data/media, but downloading/reusing protected material remains subject to rights and site/platform rules.

## Additional architecture opportunities locked for future implementation
- Universal Importer + provenance chain
- Task checkpoint/resume
- Account connection center
- Approval inbox
- One-master-to-platform variants
- Evidence freshness monitor
- Objective-drift detector
- Blast-radius and recovery proof
- Self-benchmark arena
- Complexity debt / simplification pass
