# KORA Creator Desktop Live Test

This release changes only the HTTP presentation routing:
- `/` serves the creator-first desktop HUD.
- `/advanced` and `/legacy-hud` serve the preserved technical HUD.
- Creator desktop supports draggable icons, persistent positions, Hide/Show, Add to Front, and face-centered workspaces.
- Voice/Text/Touch controls are primary UI controls.
- Existing Python APIs/backend remain in the archive.
- No account connection, publishing, viral result, or completion is fabricated by the UI.

Reference concept: WebOS-style movable desktop/file organization, implemented independently for this project.
