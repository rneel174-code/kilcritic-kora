# IMPLEMENTATION CHECKLIST

Phase 1 Resume: inspect repo; find last checkpoint; backup; inventory modules/routes/workers/state; identify social adapters and existing approval/auth/queue/scheduler.

Phase 2 Integrate: map 5.0 to existing modules; reuse; add only missing capabilities; preserve working features.

Phase 3 Social: YouTube/Facebook/Instagram/TikTok adapters; OAuth; draft/schedule/publish/verify; analytics; earnings truth labels.

Phase 4 Evolution: refusal intelligence; provenance; adversarial guard; resource meter; migration; benchmark; canary; rollback.

Phase 5 Release: compile; unit; integration; security; permissions; queue/race/idempotency; media; social preflight; offline/resume; regression; mobile/desktop; final ZIP scan.
