# OFFICIAL PLATFORM SETUP

YouTube / Facebook / Instagram / TikTok must use their official developer/OAuth/authorized flows.

Never put tokens, cookies or private keys in this ZIP. Store secrets in the real application's secure secret mechanism.

Owner setup:
1. Create/authorize the platform app where required.
2. Grant minimum scopes.
3. Complete official OAuth.
4. Confirm account/page/channel permissions.
5. Run a non-destructive verification.
6. Test draft/private/unlisted mode where supported before public publishing.

If an API does not expose a metric/action, label it UNAVAILABLE instead of guessing.
