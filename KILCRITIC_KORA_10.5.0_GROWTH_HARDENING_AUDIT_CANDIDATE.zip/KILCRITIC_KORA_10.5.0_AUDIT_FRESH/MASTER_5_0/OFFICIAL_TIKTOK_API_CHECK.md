# OFFICIAL API CHECK — TIKTOK CONTENT POSTING

Checked against TikTok for Developers documentation during final packaging.

Current official flow supports Content Posting API / Direct Post:
- query creator information
- initialize post
- upload media when FILE_UPLOAD is used
- fetch post status
- explicit user authorization and video.publish scope
- unaudited clients have private-view restrictions
- rate limits and audit/approval requirements apply

Relevant official documentation:
https://developers.tiktok.com/docs/en/content-posting-api-get-started
https://developers.tiktok.com/docs/en/content-posting-api-reference-direct-post
https://developers.tiktok.com/docs/en/content-posting-api-reference-get-video-status

This research is NOT a claim that the source adapter is already implemented.
The actual source audit still marks TikTok publishing NOT_IMPLEMENTED.
