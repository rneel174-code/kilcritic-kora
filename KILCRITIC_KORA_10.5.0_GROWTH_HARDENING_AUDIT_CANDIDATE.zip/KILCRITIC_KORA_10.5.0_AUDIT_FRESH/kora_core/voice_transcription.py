import sys
from kora.services import voice_transcription as _m
sys.modules[__name__] = _m
