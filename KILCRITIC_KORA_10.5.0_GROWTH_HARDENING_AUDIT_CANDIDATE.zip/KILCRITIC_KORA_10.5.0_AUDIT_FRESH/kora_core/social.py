import sys
from kora.services import social as _m
sys.modules[__name__] = _m
