import sys
from kora.services import ai_failover as _m
sys.modules[__name__] = _m
