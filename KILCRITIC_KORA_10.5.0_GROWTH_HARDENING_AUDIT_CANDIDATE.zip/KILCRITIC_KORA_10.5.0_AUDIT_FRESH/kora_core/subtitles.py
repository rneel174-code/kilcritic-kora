import sys
from kora.services import subtitles as _m
sys.modules[__name__] = _m
