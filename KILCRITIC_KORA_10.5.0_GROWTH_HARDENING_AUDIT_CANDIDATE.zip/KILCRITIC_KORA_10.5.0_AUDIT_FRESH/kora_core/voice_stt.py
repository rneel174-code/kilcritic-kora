import sys
from kora.services import voice_stt as _m
sys.modules[__name__] = _m
