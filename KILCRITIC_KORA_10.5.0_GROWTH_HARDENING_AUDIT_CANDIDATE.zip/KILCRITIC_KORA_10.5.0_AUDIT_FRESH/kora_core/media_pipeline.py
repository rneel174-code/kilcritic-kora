import sys
from kora.services import media_pipeline as _m
sys.modules[__name__] = _m
