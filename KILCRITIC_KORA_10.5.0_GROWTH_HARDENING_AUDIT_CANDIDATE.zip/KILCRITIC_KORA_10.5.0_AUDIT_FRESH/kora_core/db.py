import sys
from kora.core import db as _m
sys.modules[__name__] = _m
