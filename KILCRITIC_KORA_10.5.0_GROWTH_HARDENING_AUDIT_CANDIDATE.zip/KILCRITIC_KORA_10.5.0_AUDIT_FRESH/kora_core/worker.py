import sys
from kora.core import worker as _m
sys.modules[__name__] = _m
