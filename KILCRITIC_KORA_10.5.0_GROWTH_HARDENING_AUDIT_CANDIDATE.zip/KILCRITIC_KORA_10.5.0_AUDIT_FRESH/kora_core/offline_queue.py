import sys
from kora.core import offline_queue as _m
sys.modules[__name__] = _m
