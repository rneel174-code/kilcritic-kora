import sys
from kora.core import event_bus as _m
sys.modules[__name__] = _m
