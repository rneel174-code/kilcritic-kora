import sys
from kora.services import media_dedup as _m
sys.modules[__name__] = _m
