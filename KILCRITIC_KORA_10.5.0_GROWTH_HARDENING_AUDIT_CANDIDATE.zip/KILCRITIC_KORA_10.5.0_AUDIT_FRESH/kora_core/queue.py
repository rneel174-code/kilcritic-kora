import sys
from kora.core import queue as _m
sys.modules[__name__] = _m
