import sys
from kora.services import system_doctor as _m
sys.modules[__name__] = _m
