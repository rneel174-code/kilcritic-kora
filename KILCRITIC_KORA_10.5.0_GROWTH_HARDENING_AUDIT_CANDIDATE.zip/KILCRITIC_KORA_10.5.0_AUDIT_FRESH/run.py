"""KORA PRO launcher: HTTP bridge + worker pool + cron. Configure via .env (see .env.example)."""
from kora.bridge.server import serve

if __name__ == "__main__":
    serve()
