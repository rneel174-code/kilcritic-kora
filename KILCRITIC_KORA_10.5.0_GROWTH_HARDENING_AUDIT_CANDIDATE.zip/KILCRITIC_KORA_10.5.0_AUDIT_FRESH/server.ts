import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { spawn } from 'child_process';
import crypto from 'crypto';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const AUTH_SECRET = process.env.KORA_AUTH_TOKEN || '';

// Body parsing with limits to prevent memory exhaustion
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));

// --- Auth (UNVERIFIED: TypeScript could not be built in the hardening sandbox) ---
// No default secret. X-Forwarded-For is trusted only when KORA_TRUST_PROXY=1.
const TRUST_PROXY = ['1', 'true', 'yes'].includes((process.env.KORA_TRUST_PROXY || '').toLowerCase());
const REQUIRE_AUTH_LOCAL = ['1', 'true', 'yes'].includes((process.env.KORA_REQUIRE_AUTH_LOCAL || '').toLowerCase());

function clientIp(req: Request): string {
  if (TRUST_PROXY) {
    const fwd = ((req.headers['x-forwarded-for'] as string) || '').split(',')[0].trim();
    if (fwd) return fwd;
  }
  return req.socket.remoteAddress || '';
}

function tokenEquals(a: string, b: string): boolean {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  return ab.length === bb.length && crypto.timingSafeEqual(ab, bb);
}

function authorized(req: Request): boolean {
  const ip = clientIp(req);
  const isLoopback = ip === '127.0.0.1' || ip === '::1' || ip === '::ffff:127.0.0.1';
  if (isLoopback && !REQUIRE_AUTH_LOCAL) return true;
  if (!AUTH_SECRET) return false; // remote access impossible without a configured token
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '').trim();
  return token !== '' && tokenEquals(token, AUTH_SECRET);
}

// All mutating routes require authorization; GET /api/health stays public.
app.use('/api', (req, res, next) => {
  if (req.method === 'GET' && req.path === '/health') return next();
  if (req.method !== 'GET' && !authorized(req)) {
    res.status(403).json({ error: 'Forbidden' });
    return;
  }
  next();
});

// Security Headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

// Sensitive Key Sanitizer
const SENSITIVE_KEYS = new Set([
  'authorization',
  'token',
  'apikey',
  'api_key',
  'secret',
  'password',
  'cookie',
  'accesstoken',
  'access_token',
  'refreshtoken',
  'refresh_token',
  'session',
  'credentials',
]);

function sanitizeRecursive(data: any): any {
  if (Array.isArray(data)) {
    return data.map(sanitizeRecursive);
  } else if (data !== null && typeof data === 'object') {
    const sanitized: Record<string, any> = {};
    for (const [k, v] of Object.entries(data)) {
      const cleanKey = k.toLowerCase().replace(/[_-]/g, '');
      if (SENSITIVE_KEYS.has(cleanKey)) {
        sanitized[k] = '[REDACTED]';
      } else {
        sanitized[k] = sanitizeRecursive(v);
      }
    }
    return sanitized;
  }
  return data;
}

// SSE Subscriber Pool with Bounded Queues
interface SseClient {
  id: string;
  res: Response;
  queueDepth: number;
}
const sseClients: Map<string, SseClient> = new Map();
const MAX_SSE_BUFFER = 100;

export function broadcastSse(eventType: string, data: any) {
  const sanitized = sanitizeRecursive(data);
  const payloadStr = JSON.stringify(sanitized);

  for (const [id, client] of sseClients.entries()) {
    if (client.queueDepth >= MAX_SSE_BUFFER) {
      // Overflow detected -> emit resync_required
      client.res.write(`event: resync_required\ndata: {"message": "Subscriber buffer overflow. Authoritative DB resync required."}\n\n`);
      client.queueDepth = 0;
      continue;
    }

    client.queueDepth++;
    client.res.write(`event: ${eventType}\ndata: ${payloadStr}\n\n`);
    setTimeout(() => {
      if (client.queueDepth > 0) client.queueDepth--;
    }, 1000);
  }
}

// Periodic SSE Keepalive Heartbeat
setInterval(() => {
  for (const client of sseClients.values()) {
    client.res.write(`: keepalive\n\n`);
  }
}, 15000);

// Helper to run python CLI and parse JSON
function runPythonCommand(args: string[]): Promise<any> {
  return new Promise((resolve, reject) => {
    const proc = spawn('python3', ['-m', 'kora.cli', ...args], {
      cwd: path.resolve(__dirname, '.'),
      env: { ...process.env, PYTHONPATH: '.' },
    });

    let stdout = '';
    let stderr = '';

    proc.stdout.on('data', (d) => (stdout += d.toString()));
    proc.stderr.on('data', (d) => (stderr += d.toString()));

    proc.on('close', (code) => {
      if (code !== 0) {
        return reject(new Error(stderr.trim() || `Process exited with code ${code}`));
      }
      try {
        const parsed = JSON.parse(stdout.trim());
        resolve(parsed);
      } catch {
        resolve({ raw: stdout.trim() });
      }
    });

    proc.on('error', reject);
  });
}

// ==========================================
// API ROUTES
// ==========================================

// 1. Health Probe
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    version: '8.8.5-KORA-GODFATHER-CTO-HARDENED',
    timestamp: Date.now(),
    uptime: process.uptime(),
  });
});

// 2. SSE Stream with Remote 403 & Bounded Queue
app.get('/api/stream', (req: Request, res: Response) => {
  if (!authorized(req)) {
    res.status(403).json({ error: 'Forbidden: valid bearer token required' });
    return;
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const clientId = `sub-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  sseClients.set(clientId, { id: clientId, res, queueDepth: 0 });

  // Initial connection event
  res.write(`event: connected\ndata: {"clientId": "${clientId}", "kernel": "8.8.5-HARDENED"}\n\n`);

  req.on('close', () => {
    sseClients.delete(clientId);
  });
});

// 3. Queue Stats
app.get('/api/queue/stats', async (req, res) => {
  try {
    const stats = await runPythonCommand(['stats']);
    res.json(stats);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 4. System Doctor Probes
app.get('/api/doctor/probes', async (req, res) => {
  try {
    const probes = await runPythonCommand(['doctor']);
    res.json(probes);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 5. System Doctor Safe Self-Healing
app.post('/api/doctor/heal', async (req, res) => {
  try {
    const healRes = await runPythonCommand(['heal']);
    broadcastSse('doctor_healed', healRes);
    res.json(healRes);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 6. Create Verified Backup
app.post('/api/backup/create', async (req, res) => {
  try {
    const backupRes = await runPythonCommand(['backup']);
    broadcastSse('backup_created', backupRes);
    res.json(backupRes);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 7. Run 22 Behavioral Tests
app.get('/api/tests/run', (req, res) => {
  const proc = spawn('python3', ['-m', 'kora.tests.run_all'], {
    cwd: path.resolve(__dirname, '.'),
    env: { ...process.env, PYTHONPATH: '.' },
  });

  let output = '';
  proc.stdout.on('data', (d) => (output += d.toString()));
  proc.stderr.on('data', (d) => (output += d.toString()));

  proc.on('close', (code) => {
    const passCount = (output.match(/\[PASS\]/g) || []).length;
    const failCount = (output.match(/\[FAIL\]/g) || []).length;
    res.json({
      success: code === 0,
      exitCode: code,
      passed: passCount,
      failed: failCount,
      total: passCount + failCount,
      output: output.split('\n').filter((l) => l.trim().length > 0),
    });
  });
});

// ==========================================
// VITE SETUP (Development vs Production)
// ==========================================
async function startServer() {
  // Ensure DB initialized
  try {
    await runPythonCommand(['init']);
  } catch (e) {
    console.warn('Initial DB check:', e);
  }

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  const HOST = process.env.KORA_BIND_HOST || '127.0.0.1';
  app.listen(PORT, HOST, () => {
    console.log(`[KORA PRO] Server running on http://${HOST}:${PORT}`);
  });
}

startServer();
