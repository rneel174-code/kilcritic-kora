# KORA / KILCRITIC 5.0 GODFATHER — FULL SYSTEM

This ZIP is an additive build from the real KORA 10.2.2 Self-Evolution source base.

## What changed
- Godfather Meta-Orchestrator planning layer.
- Existing-capability-first routing.
- Adaptive sequential/bounded-parallel execution planning.
- Measured resource awareness through Infinite Core.
- Evidence hashing for proposal records.
- Evidence-based Evolution Judge: REFUSE / HOLD / PROPOSE.
- Duplicate-control: existing capabilities are reused instead of recreated.
- Read-only Godfather health/plan bridge surfaces.

## What was preserved
Durable queue, scheduler, worker pool, idempotency, anti-loop/circuit protections,
permissions/authentication, trust, legal/platform guard, social approval flow,
cost governor, checkpoints, offline queue, provider failover, self-evolution,
backup/recovery, voice controls, DNA, ATMA/DHARMA and existing HUD.

## Verified
- Existing behavioral suite: 75/75 PASS.
- GF01 meta-architecture tests: PASS.
- Python compile check: PASS.
- Bridge Godfather health/plan smoke check: PASS.

## Important
This is a real software optimization layer, not literal unlimited hardware.
External publishing/account/payment/credential changes remain permission and approval gated.
Instagram/TikTok are not falsely marked as implemented when official provider setup is missing.
