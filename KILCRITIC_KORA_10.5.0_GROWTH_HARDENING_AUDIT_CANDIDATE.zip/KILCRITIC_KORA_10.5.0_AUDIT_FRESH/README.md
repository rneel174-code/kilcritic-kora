# KILCRITIC SUPREME 10.2.1 (KORA governed self-evolution release)

Refactor of KORA 8.8.5 into a layered, stdlib-only Python core.

```
kora/
  core/      db, durable queue, worker pool, cron scheduler, auth, rate-limit, logger, security (SSRF), http
  services/  social publish, web research, RAG, AI failover, backup, media, doctor, job handlers
  bridge/    WSGI API (auth, rate-limit, CSRF/Host/Origin checks) + server
  config/    typed settings from env / .env
  hud/       minimal UI: shows only active work (running / queued / needs approval / failed)
  tests/     69 tests (T01-T22 original, T23-T43 PRO, T44-T53 governance, T54-T69 supreme)
kora_core/   back-compat shims (old import paths still work)
```

## Run
```
cp .env.example .env        # set KORA_AUTH_TOKEN for any non-loopback access
python3 run.py              # API + HUD on http://127.0.0.1:8080 (default), worker pool + cron included
python3 -m kora.tests.run_all
python3 -m kora.cli stats | dlq | dlq-requeue <id>
```
Python 3 standard library only. No secrets are shipped; every credential comes from the environment.

## Governance layer (8.10.0, from the KILCRITIC blueprint)
Policy table + hard blocks + safe mode, approval proposals (HUD "Needs your decision"), Malak preferences (closed whitelist, versioned),
legal/platform preflight on social posts, persistent cost caps, checkpoints, SENA bounded parallel runner, emergency recovery.
See `docs/BLUEPRINT_PLAN.md` for what is DONE vs planned. Endpoints: `/api/governance/proposals`, `/api/malak`, `/api/cost`,
`/api/legal/preflight`, `/api/safe-mode`, `/api/emergency[/resume]`, `/api/sena/{attack,team}`.

## SUPREME 10.2 additions
Identity/roles + TOTP step-up, One Brain (`/api/brain`) for text and voice, DNA Time Machine, ATMA/Phoenix, Shadow Publish, trust/skill gate,
deep research, ledger/revenue verifier, anti-loop, export/delete, safe migration. Requirement-by-requirement status: `docs/BLUEPRINT_PLAN.md`;
changelog/limitations/migration/recovery: `docs/CHANGELOG_AND_NOTES.md`; audit table: `AUDIT_REPORT.md`.

## Behaviour notes
- Queue: atomic claim, leases + heartbeat, exponential backoff with jitter, permanent-error short-circuit, dead-letter queue (list / requeue / purge), idempotency keys, capacity limit, durable kill switch.
- Social "auto publish": a worker publishes **after human approval**. `KORA_SOCIAL_AUTO_APPROVE=true` skips approval (off by default, audited).
- Research: https-only, SSRF-guarded fetch; Brave search needs `BRAVE_SEARCH_API_KEY`.
- RAG: local hashed bag-of-words vectors in SQLite (not a neural embedding). Without an LLM key answers are extractive and labelled `extractive_no_llm`.
- Cron: 5-field (UTC) or `@every 30s|5m|2h`; jobs enqueue into the queue so retry/DLQ apply.

## Status (see AUDIT_REPORT.md)
Verified by the bundled tests: queue/worker/DLQ/cron/auth/rate-limit/logger/settings/research SSRF/RAG/bridge/real HTTP server.
UNVERIFIED (no live credentials/network in build sandbox): X, Facebook, YouTube publishing; Gemini/OpenAI/Groq; Brave search; `server.ts` and the legacy React `src/` (could not be built).
NOT_IMPLEMENTED: Instagram, TikTok publishing.


## 10.2.1 — Self-Evolution + Holographic HUD
- Self-Evolution Engine: DETECT -> RESEARCH -> PROPOSE -> MALAK APPROVAL -> ISOLATED PATCH -> TEST -> APPLY -> VERIFY -> ROLLBACK.
- Owner-approved code changes use the existing governance/TOTP approval path; owner secrets are never stored in proposals.
- AI/provider output is treated as an untrusted patch artifact. Patch paths are validated and affected files are snapshotted before mutation.
- After owner approval of a MODIFY_CODE proposal, KORA automatically applies the approved patch only after dry-run, compile and full behavioural test verification.
- Failed verification rolls back the affected files and records the failure.
- Environment profiles: EARTH/OCEAN/SKY/SPACE/REGION. These are software workload behaviours, not physical power.
- Native HUD redesigned for desktop/mobile fullscreen with current task, approvals, self-evolution, health/resources, discovery, environment and voice controls.

## Creator-first HUD lock
The normal dashboard intentionally hides system health, discovery, events, resources, environment, backup, doctor, tests, queues and other technical controls. The creator surface is a single transparent-glass MEDIA + SOCIAL + STUDIO folder with the KORA face in the center and creator functions around it. Touch, voice and text are the primary interaction modes. Technical tools remain available only under Advanced.
