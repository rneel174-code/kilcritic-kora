# KORA / KILCRITIC Creator OS 10.3.0: Full real test audit (no code changed)

Target: `KILCRITIC_SUPREME_10.3_FINAL_MERGED.zip` extracted clean, server on 127.0.0.1:8000, fresh DB, SIGKILL + restart tested.
Evidence: live HTTP, headless Chromium (390x844, 844x390, 320x640, 1366x800), in-process tests with fake transports (no public post, no real credentials).

## Totals
| PASS | FAIL | PARTIAL | NOT CONFIGURED | NOT IMPLEMENTED | FAKE / PLACEHOLDER |
|---|---|---|---|---|---|
| 19 | 22 | 6 | 7 | 11 | 11 |

## Phase results
| Phase | Result | Evidence |
|---|---|---|
| 1 Startup/routing | PASS | `/` 200 creator_index (Creator OS), `/creator.css` 200, `/creator.js` 200, `/kora_avatar.jpg` 200 (940 KB), `/advanced` 200 legacy HUD. `/favicon.ico`, `/manifest.json`, `/sw.js` = 404 (files exist in `public/` but are not served) |
| 2 Mobile UI | FAIL | No horizontal scroll on any size (PASS). But: hero master button covered by `#desktopIcons` on every viewport; landscape 844x390: master folder cannot be opened at all (icon hides under dock); dock `Hidden` button off-screen at 390 and 320; 320px: schedule buttons covered, command input clipped; workspace portrait: avatar head cropped |
| 3 Master folder | FAIL | Workspace opens only via the draggable icon (single click). All 12 categories send `POST /api/brain {source:"touch"}` -> `{"ok":false,"status":"INVALID","message":"source must be text or voice"}` (12/12). UI keeps placeholder text "KORA is preparing the correct workflow", so the user is misled |
| 4 Create content (A-G) | NOT IMPLEMENTED | No endpoint for video/photo/story/wallpaper/story->movie/convert/export (all 404). Only planning: `/api/studio/plan`, `/api/assets/variants` (state `PLANNED_NOT_EXPORTED`), `/api/workflow/plan` (`PLANNED_NOT_EXECUTED`) - none called by the UI. Real and working: `/api/quality/verify` (ffprobe: fake 4K caught -> FAIL, honest 720p -> PASS) |
| 5 Voice/text/touch | FAIL | touch -> INVALID; text "Create a short video and prepare it for YouTube and Facebook." -> NEEDS_CLARIFICATION; voice -> VOICE_OFF (no toggle in Creator UI; browser STT UNAVAILABLE in headless). The 3 routes do not reach one workflow |
| 6 Scheduled auto-post | PARTIAL | 5 live schedules +2..+10 min created and fired on time. Statuses seen: SCHEDULED -> WAITING_APPROVAL. Lifecycle DRAFT/READY/DUE/PUBLISHING/VERIFIED does not exist in the schedule model; no retry-policy, approval-state or content-ID fields |
| 7 Restart recovery | PASS | SIGKILL with 9 schedules; after restart 9 present, 9 unique ids, next-run times identical, worker resumed, overdue schedule picked up within seconds. Gap: crash between claim and dispatch (see S3) |
| 8 Duplicate protection | PASS | 2 schedules on 1 post + 4 racing `process_due` threads -> 1 job, 1 external call, post PUBLISHED once; later ticks no-op |
| 9 Failure/retry | PARTIAL | network, 500, 401, malformed, over-length: never a fake PUBLISHED; retryable errors retried 4x then DLQ; 401 and over-length fail permanently with 0/1 call; secrets redacted in errors; no duplicates. Fails: schedule row stays QUEUED after FAILED/DLQ (S2); malformed 2xx JSON -> uncaught `JSONDecodeError` -> "publishing_interrupted" |
| 10 Real platforms | NOT CONFIGURED | No credentials; nothing published |
| 11 Rights/safety/approval | FAIL | Default gate holds (all posts PENDING_APPROVAL). But `legal/preflight` returns PASS for rights=UNKNOWN, "pirated movie", copied-from-web, adult flag, celebrity voice clone. With `KORA_SOCIAL_AUTO_APPROVE=true` such a post was auto-approved and published (fake transport). `media_rights.py` (which would return UNKNOWN) is not wired |
| 12 30-day autopilot | PARTIAL | tz math incl. DST PASS, queue order PASS, pause/resume/cancel API PASS, past/bad tz/unknown post rejected PASS. Edit: NOT_IMPLEMENTED. WAITING_APPROVAL never re-evaluated. DAILY re-posts the same post only |
| 13 Truthful status | PARTIAL | UI strings are honest (no PUBLISHED/EXPORTED claims). FAKE SUCCESS RISK: `capability_audit` marks `studio.pipeline` IMPLEMENTED although studio is planning-only; docs claim a UI region selector that is absent in the Creator HUD |
| 14 API map | see below | |

## Platform table (Phase 10)
| Platform | IMPLEMENTED | CONFIGURED | AUTHORIZED | READY | PUBLISH TESTED | EXTERNAL ID VERIFIED |
|---|---|---|---|---|---|---|
| YouTube | adapter yes | no | no | NOT READY | fake transport only | no |
| Facebook | adapter yes | no | no | NOT READY | fake transport only | no |
| X | adapter yes | no | no | NOT READY | fake transport only | id from API response only, no read-back |
| Instagram | adapter yes, but unreachable via API (S6) | no | no | NOT READY | fake transport only | no |
| TikTok | adapter yes | no | no | NOT READY | fake transport only | no |

## UI -> backend map (Phase 14)
| UI action | Call | Backend | Result |
|---|---|---|---|
| Category tap (12) | POST /api/brain source=touch | api.brain -> brain.handle | INVALID (dead) |
| GO (text) | POST /api/brain source=text | brain.handle | NEEDS_CLARIFICATION for creation goals |
| Voice | POST /api/brain source=voice | brain.handle | VOICE_OFF by default |
| Schedule Auto-Post | POST /api/autopilot/schedules | scheduled_autopilot.create_schedule | real, persisted |
| My Schedule | GET /api/autopilot/schedules | list_schedules | real |
| Dock Touch | none (sets text "TOUCH READY") | - | placeholder |
| Search | none (opens workspace) | - | placeholder |
| Add / Hide / Drag / Drawer | localStorage only | - | local, works |
| Advanced | /advanced | static | works |
| Pause/Resume/Cancel schedule | no UI (API only) | autopilot_pause/resume/cancel | API works, no button |
| Post create / approve | no UI in Creator HUD | social_create / social_approve | API works, no button |

## Findings with file / function / line (priority)
| ID | Pri | Finding | Location |
|---|---|---|---|
| R1 | P0 | Rights gate bypassed: rights only checked when `media` truthy; adult only for KIDS; text-only UNKNOWN passes; auto-approve then publishes | `kora/services/legal_guard.py::preflight` (l.15-40); `kora/services/social.py::create_social_post` l.196-200; `kora/services/media_rights.py` unused |
| U1 | P1 | `source:'touch'` rejected by backend; UI shows placeholder | `kora/hud/creator.js` l.26 `runCategory`; `kora/services/brain.py` l.223 |
| S1 | P1 | WAITING_APPROVAL never re-evaluated after approval/credentials | `kora/services/scheduled_autopilot.py::process_due` l.135-142 |
| S2 | P1 | Schedule never reconciled to PUBLISHED/FAILED/VERIFIED; stays QUEUED forever (even after DLQ) | same file l.143-152 |
| S3 | P1 | Crash after claim (l.120) before dispatch leaves row QUEUED with no job; no recovery | same file l.116-124 |
| S4 | P2 | APPROVED_AWAITING_CREDENTIALS mislabeled WAITING_APPROVAL/`approval_required` (seen live) | same file l.131-142 |
| S5 | P2 | pause/cancel/resume unconditional: can CANCEL a QUEUED/published item, RESUME a cancelled one | same file l.79-98 |
| S6 | P1 | Instagram unreachable: API ignores `public_media_url`/`media_type`/`ai_generated` (media_url stays NULL) | `kora/bridge/api.py::social_create` l.472-479 |
| S7 | P2 | `owner` not passed -> account OFF / not connected not enforced on API path or scheduler | `api.py::social_create` l.472; `social.py::create_social_post` |
| S8 | P2 | No schedule edit/reschedule, no retry policy / approval / content-ID fields, no 30-day bulk calendar | `scheduled_autopilot.py` l.52 table; `api.py` l.133-137 |
| S9 | P3 | DAILY/WEEKLY repost the same `post_id`; next-run from old timestamp (catch-up burst) | `scheduled_autopilot.py::_next_recurring` l.101-103 |
| P1 | P2 | Instagram/TikTok/YouTube preflight PASS with no media | `legal_guard.py::preflight` |
| P2 | P3 | Malformed 2xx JSON uncaught in adapters | `publishers.py` l.61, 79, 116 |
| P3 | P3 | External ID is only the API response id; no read-back verification | `social.py::run_publish` l.330-338 |
| UI2 | P2 | `#desktopIcons{inset:10px;z-index:35}` covers hero master button (z 25) | `kora/hud/creator.css` l.1 |
| UI3 | P2 | Landscape: master icon hidden under dock; no way to open workspace | `creator.css` (.dock z 60) / `creator.js::render` |
| UI4 | P3 | Dock overflows 390/320 (`Text`/`Hidden` clipped, only scroll); 320 schedule buttons covered; workspace avatar head cropped | `creator.css`, `creator_index.html` |
| UI5 | P3 | Dock Touch + Search are placeholders | `creator.js` l.37 |
| UI6 | P4 | favicon/manifest/sw.js 404 | static route table `api.py` l.56-60 |
| T1 | P2 | `studio.pipeline: IMPLEMENTED` is false (planning only) | `kora/services/capability_audit.py` l.13 |
| T2 | P3 | Docs claim region selector in Creator UI; absent | `CHANGELOG.md`, `creator_index.html` |
| D1 | P2 | Dead modules (imported only by tests): capability_audit, media_rights, notification_outbox, secure_vault, runtime_limits, regionalization | `kora/services/*` |
| D2 | P2 | React `MediaSocialStudioHub.tsx` makes zero API calls and `server.ts` has none of the creator routes: UI-only mock, separate from the working Python HUD | `src/components/MediaSocialStudioHub.tsx`, `server.ts` |

## Security
PASS: path traversal 404, foreign Origin 403, spoofed Host 403, oversize body 413, invalid JSON 400, X-Frame/nosniff/CSP/no-store present, errors redacted. Issues: R1 (auto-approve), S7. `HEAD /` returns 404 (cosmetic).

## Recommended fix order
1. P0 R1: rights/safety gate for text-only content; auto-approve must refuse UNKNOWN/unauthorized/adult.
2. P1: U1 (touch source), S1, S2, S3, S6.
3. P2: S4, S5, S7, S8, UI2, UI3, T1, D1, P1.
4. P3/P4: rest.
