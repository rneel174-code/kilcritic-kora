# LOCK-11 — MALAK-ASSIST

Human-in-the-loop bridge for tasks requiring OTP, CAPTCHA, payment authorization, OAuth/account connection, or explicit approval.

Flow:
TASK -> WAITING_FOR_MALAK -> checkpoint -> Telegram/WhatsApp notification -> authenticated one-time code -> RESUMABLE -> continue -> verify -> audit.

No CAPTCHA/OTP/MFA/payment/platform restriction is bypassed. If no messaging credentials are configured, status is NOT_CONFIGURED and the task remains safely paused.

Optional environment configuration:
- KORA_MALAK_TELEGRAM_BOT_TOKEN
- KORA_MALAK_TELEGRAM_CHAT_ID
- KORA_WHATSAPP_CLOUD_TOKEN
- KORA_WHATSAPP_PHONE_NUMBER_ID
- KORA_MALAK_WHATSAPP_TO

These are never written to normal memory or audit logs.

Endpoints:
- POST /api/malak-assist/pause
- GET /api/malak-assist
- GET /api/malak-assist/{task_id}
- POST /api/malak-assist/{task_id}/resume
