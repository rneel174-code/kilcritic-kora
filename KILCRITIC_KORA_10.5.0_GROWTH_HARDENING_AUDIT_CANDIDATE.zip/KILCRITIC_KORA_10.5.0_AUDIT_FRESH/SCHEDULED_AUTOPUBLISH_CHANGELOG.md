# Scheduled Auto-Publish + Creator OS Upgrade — 2026-10-05

## Added
- Durable `autopilot_schedules` SQLite table.
- One-time, daily and weekly schedules.
- IANA timezone-aware scheduling.
- 15-second dispatcher through the existing CronRunner.
- Existing DurableQueue + `social_publish` path reused; no duplicate publisher/worker.
- Idempotent schedule claim and existing post idempotency retained.
- Pause / resume / cancel API.
- Creator UI schedule controls under **POST + AUTOPILOT**.
- Truthful states: SCHEDULED, WAITING_APPROVAL, QUEUED, PUBLISHED, FAILED, PAUSED, CANCELLED.
- Existing rights/legal/platform preflight, credential checks, retry/DLQ and external verification remain in the publish path.
- Recurring schedules advance after a claimed run.

## Safety lock
Automatic approval is NOT silently enabled. `KORA_SOCIAL_AUTO_APPROVE=true` is required before a scheduled pending-approval post can be approved automatically. Otherwise the schedule becomes `WAITING_APPROVAL`.

## Existing Creator OS preserved
- Full-screen KORA creator desktop.
- `MEDIA + SOCIAL + STUDIO` master folder.
- Transparent orbit/folder controls.
- Touch / Voice / Text.
- Front desktop Show/Hide/Add/Move controls; Hide never deletes.
- Creation → rights/safety → quality → platform variants → preview → schedule/publish → verify → learn architecture.
- Advanced technical controls remain separate.
