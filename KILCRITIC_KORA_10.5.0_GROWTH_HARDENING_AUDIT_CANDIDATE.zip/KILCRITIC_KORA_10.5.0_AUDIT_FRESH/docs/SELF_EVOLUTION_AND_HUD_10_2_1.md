# KILCRITIC SUPREME 10.2.1 — Self-Evolution + HUD Lock

## Self-Evolution
DETECT → RESEARCH → PROPOSE → MALAK APPROVAL → ISOLATED PATCH → DRY-RUN/CANARY → COMPILE → FULL TESTS → APPLY/VERIFY → ROLLBACK IF NEEDED → AUDIT.

Owner authentication reuses the existing KORA owner auth + TOTP step-up path. Secrets are never stored in proposals. AI output is treated as an untrusted patch artifact and cannot directly execute code.

A missing API/provider/hardware dependency must be reported truthfully. KORA should prefer free/open-source/local/authorized alternatives, tell Malak when a dependency is required, and resume after it is configured.

## Environment Profiles
EARTH = stable/offline-first; OCEAN = resilient flow; SKY = lightweight parallel work; SPACE = isolated simulation; REGION = localization.
These are software behavior profiles only and do not create physical power.

## HUD
The native `/kora/hud` is now the primary full-screen desktop/mobile experience: KORA avatar, live state, current task, owner decisions, self-evolution, measured resources, provider/discovery status, environment profile, voice, backup, doctor and advanced drawer.

## Verification
72/72 bundled behavioral tests passed after integration. Native HUD JavaScript syntax check passed. Frontend React/TypeScript build remains separately dependent on the project's Node dependencies and was not claimed as tested without `node_modules`.
