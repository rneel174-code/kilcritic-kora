# Scheduled Auto-Publish Engine

KILCRITIC Creator OS now includes durable scheduled posting on top of the existing queue/worker/social publisher stack.

## What it supports
- Post 1, 2, 3, 4, 5… each with its own date/time.
- Explicit IANA timezone (for example `Asia/Kolkata`).
- One-time, daily and weekly schedules.
- Durable SQLite state survives process restarts.
- 15-second dispatcher using the existing CronRunner.
- Idempotent social dispatch through the existing `social_publish` queue job.
- Existing legal/platform preflight, credential checks, publisher capability checks, retry/DLQ and external-ID verification remain authoritative.
- Pause, resume and cancel.
- Missed/blocked schedule becomes visible as `WAITING_APPROVAL` or `FAILED`; it is never falsely marked published.
- Recurring schedules advance only after a claimed run.

## Auto-publish rule
A scheduled item may automatically dispatch an already `APPROVED` post. If a post is still `PENDING_APPROVAL`, the scheduler only auto-approves it when the explicit `KORA_SOCIAL_AUTO_APPROVE=true` setting is enabled. Otherwise it changes to `WAITING_APPROVAL`.

## Important platform truth
The scheduler does not create missing platform integrations. A platform must have an official/authorized publisher and valid credentials. If a publisher is not implemented or credentials are missing, no fake `PUBLISHED` state is emitted.

## Unified creator flow
Create/edit/convert → rights/safety → quality → platform variant → preview → schedule → required approval/authorization → queue → publish → verify → save/learn.

The File Manager is not a mandatory step between creation and scheduling.
