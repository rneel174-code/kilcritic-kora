# 7-day MVP (PLAN, not results)
Day1 enrol 10 shops (`/api/growth/pilot/shops`). Day2 baseline sales per shop (7 days of BEFORE records needed). Day3 create campaign + attribution link/QR per shop. Day4-5 festival/offer posters (original assets, human review). Day6 publish only via approved/authorized path. Day7+ record AFTER sales; `/api/growth/pilot/<id>` decides CONDITION_MET / NOT_MET / UNVERIFIED.
Rs500 rule: only when incremental sales >= 5000 AND before/after are POS/UPI/API-sourced with references. Malak collects; nothing charges automatically. Photos alone = UNVERIFIED.
