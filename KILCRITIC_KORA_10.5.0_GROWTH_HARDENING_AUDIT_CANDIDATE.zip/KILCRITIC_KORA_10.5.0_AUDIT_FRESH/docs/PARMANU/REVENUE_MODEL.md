# Revenue model - SCENARIO LABELS ONLY
Revenue classes: service per shop, subscription, lead-gen, B2B deployment. All figures are unvalidated hypotheses. States: DISCOVERED > ESTIMATED > PROPOSED > IN_PROGRESS > INVOICED > PAID_VERIFIED (dhanda VERIFIED/PAYOUT_RECEIVED) > REFUNDED/FAILED/UNKNOWN. Estimate is never earned.
