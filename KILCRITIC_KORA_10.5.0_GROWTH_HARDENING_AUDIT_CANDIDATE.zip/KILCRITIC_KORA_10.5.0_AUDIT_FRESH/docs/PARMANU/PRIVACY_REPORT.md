# Privacy
Encrypted export uses AES-256-GCM (cryptography AESGCM; fails closed if unavailable; Fernet is not called AES-GCM). Secrets are redacted before storage (Malak checkpoints, growth text fields, social errors). "No data collected" is NOT claimed: the system stores campaign/shop numbers the owner enters. Anonymised pack/consent UI: NOT_IMPLEMENTED.
