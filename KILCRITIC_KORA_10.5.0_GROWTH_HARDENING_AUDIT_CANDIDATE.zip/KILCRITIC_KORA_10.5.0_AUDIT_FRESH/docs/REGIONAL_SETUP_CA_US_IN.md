# Regional Setup — Canada / America / India

KILCRITIC uses explicit region profiles. Default is **India (IN)**. Profiles affect localization, currency, marketplace, timezone default, language defaults and compliance preflight hints.

## Profiles
- IN: Asia/Kolkata, INR, en-IN/hi-IN/pa-IN, amazon.in
- US: America/New_York default, USD, en-US/es-US, amazon.com
- CA: America/Toronto default, CAD, en-CA/fr-CA, amazon.ca

The region is not a legal or platform-policy bypass. Platform permissions, rights, OAuth, account approvals and local requirements still apply.

## Amazon
Amazon Associates is locale-specific. The system must never silently reuse an India/US/Canada Associate tag as another locale. Human registration/authorization is required. Affiliate disclosure remains mandatory. Amazon states that tags work only in the locale where the Associate registers and that multiple locales require separate registration.

## Compliance hints
- Canada: CASL/PIPEDA/provincial privacy considerations; commercial electronic messages require applicable consent, identification and unsubscribe mechanisms.
- US: FTC endorsement/affiliate disclosure requirements; disclosure should be clear and conspicuous.
- India: DPDP Act/Rules privacy controls, consent and data minimization as applicable.

These are operational guardrails, not legal advice or a guarantee of compliance.
