# KILCRITIC / KORA — FINAL SUPREME UPGRADE LOCK

## Base verified
- Base source: `KILCRITIC_SUPREME_10.2.2_SELF_EVOLUTION_2_FINAL(1).zip`
- Base SHA-256: `214aabd25718f9143f758d0ede377e179b342382e29c6d66f8df6b3f30fd4d26`
- Base archive entries: 161
- Existing architecture is reused; no parallel queue/scheduler/security/permission/repair/orchestrator is introduced.

## Added/strengthened
1. Media Rights + asset provenance record and conservative rights preflight.
2. Hollywood Studio category/flow contract: movie-cinematic, funny, funny-baby, cartoon/animation, reels/shorts, story/short-film, photo-to-cinematic, VFX/motion, audio/voice/SFX, subtitles, color/HDR, original AI.
3. Measured Studio quality gate (resolution, duration, black frames, audio clipping, subtitle sync, artifact risk).
4. Truthful platform readiness matrix. Existing X/Facebook/YouTube adapters remain implemented; Instagram/TikTok remain explicitly NOT_IMPLEMENTED until their official integrations are actually built and approved/configured.
5. One-master-asset → platform variant compiler (planning layer; no fake export/post success).
6. Android/Pydroid-safe `getloadavg` probe; `/api/ops` must not crash merely because `os.getloadavg` is unavailable.
7. Regression tests for all added gates.

## Locked media rule
- No pirated/cracked software, stolen API, license bypass or paywall/DRM bypass.
- External professional products are capability/workflow references or official connectors only.
- Original/owned/licensed/public-domain media can pass rights preflight.
- Unknown/restricted/risky media cannot silently become PASS.
- Exact unauthorized movie/character/identity/voice copying is not an automatic creation target.
- Copyright-safe is a risk-control objective, not a legal guarantee.

## Publishing truth
A platform icon never means publishing is ready. The UI must distinguish AUTH_REQUIRED, READY_TO_PREFLIGHT, NOT_IMPLEMENTED, BLOCKED, VERIFYING and VERIFIED/FAILED states. No fake published/success state.

## TikTok official capability note
Official TikTok Content Posting API supports direct posting of video and photos, but requires an approved/authorized app scope and has audit/visibility requirements. This package therefore records capability/readiness but does not pretend that the existing source has a working TikTok adapter.

## Provenance direction
C2PA/Content Credentials is treated as an optional standards-based provenance integration target. It does not itself prove that media is truthful or copyright-free; it records verifiable provenance assertions.

## Release discipline
This is an additive upgrade to the verified source tree. Nothing from the source archive is intentionally deleted. Production deployment still requires the repository's existing approval, test, canary, rollback and external credential/API setup gates.
