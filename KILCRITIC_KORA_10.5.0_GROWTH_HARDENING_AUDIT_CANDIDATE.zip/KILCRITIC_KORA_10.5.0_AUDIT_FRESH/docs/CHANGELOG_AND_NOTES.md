# KILCRITIC SUPREME 10.2 (on KORA 8.10.0) — changelog, limitations, migration, recovery

## Changelog (short)
- New: roles/users/devices with hashed tokens, temporary grants, expiry, revoke; TOTP step-up for sensitive actions; audit hash-chain.
- New: One Brain for text+voice (`/api/brain`), voice on/off + safe-mode mute; HUD with face, voice, text, search, drawer.
- New: DNA vault + Time Machine, ATMA (identity, guardian, mission lock, Phoenix restore), Shadow Publish, trust levels + skill-hash gate, deep research + Science Lab report, provider states, revenue verifier ledger, anti-loop freeze, feature flags, grouped notifications, data export/deletion, safe migration, voice/face consent gate, legal auto-post prep.
- Fixed: log/response redaction swallowed one-time credentials (now explicit `Reveal`); duplicate posts are held for review; `Authorization: Bearer` log leak (earlier).
- Kept: every 8.10.0 feature and all 53 earlier tests (unchanged). Tests now 69, all PASS.

## Limitations (real)
See `docs/BLUEPRINT_PLAN.md`. Biggest: no Hollywood studio/media creation/content switcher/trend engine/Mirror/app builder/document assistant; no encrypted multi-device sync or object storage; Instagram/TikTok not implemented; live X/Facebook/YouTube/AI providers/Brave search/browser voice are UNVERIFIED; `server.ts` and legacy React `src/` were not built; voice speaker identity is not verified; TOTP only (no passkeys); owner token comes from `KORA_AUTH_TOKEN`/loopback; TOTP secret is stored in the DB (protect the DB file); legal checks are heuristic.

## Migration notes
Schema auto-upgrades v2 -> v3 -> v4 additively (new tables/columns only; nothing dropped). To be extra safe run `kora.services.ops.migrate_safely(db_path)` once before first start: it backs up the DB, validates, migrates, verifies, and restores the backup on failure. Old import paths (`kora_core.*`) and all earlier endpoints still work.

## Recovery notes
- Frozen/compromised: `POST /api/emergency` (safe mode ON, kill switch, risky permissions revoked), then `POST /api/emergency/resume` only after probes are clean.
- Restore: `GET /api/atma` lists restore points; `POST /api/atma/restore {backup_id}` restores only a backup whose SHA-256 and integrity check pass; a pre-restore copy is kept next to the DB; safe mode stays ON until you resume.
- Lost TOTP device: stop the server and clear the `owner_totp_secret` row from the `settings` table with a SQLite client, then re-enrol.
- Tamper check: `GET /api/audit/verify`.
