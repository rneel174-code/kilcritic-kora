# Self-Evolution 3.0 Good Father — integration plan & status

Principle: upgrade the existing V2 engine; no duplicate architecture. Spec files: `docs/SELF_EVOLUTION_3_SPEC/`.

| # | 3.0 upgrade | Where (reused / new) | Test |
|---|---|---|---|
| 1 | Continuous capability discovery | `se3.discover_capabilities` (reads real tools, libs, skills, providers) | T98 |
| 2 | Self-benchmark lab | `se3.benchmark` (time/CPU/RSS/failures, isolated) | T100 |
| 3 | Evolution score | `se3.score` -> reuses `godfather.evolution_decision` | T101 |
| 4 | Regression intelligence | `se3.add_guard/check_guards/risk_pattern_confidence` (`evo_guards`) | T102 |
| 5 | Dependency intelligence | `se3.dependency_intel` (freshness/license/advisory = UNVERIFIED offline) | T99 |
| 6 | Performance evolution | `se3.performance_profile` (measured data only) | T106 |
| 7 | Failure prediction | `se3.predict` over `ops.predict_failure` | T107 |
| 8 | Evolution memory | `se3.record/memory/verify_ledger` (hash-chained `evo_ledger`) | T96 |
| 9 | Capability gap radar | `se3.detect_gaps` (recorded signals only) | T105 |
| 10 | Self-test generator | `se3.generate_test` (7 templates) | T110 |
| 11 | Rollback intelligence | `se3.rollback_points/verified_rollback` (reuses SE1 rollback) | T113-T114 |
| 12 | Upgrade dependency graph | `se3.impact_graph/classify` (levels 0-6) | T103 |
| 13 | Owner preference learning | `se3.learn_decision/preference_weight` | T101 |
| 14 | Resource-aware evolution | `se3.run_cycle` + `ops.pressure_level`, checkpoints, daily cap, depth guard | T108 |
| 15 | Offline evolution queue | durable jobs `evolution_resume`, `evolution_net_check` | T109 |
| 16 | Evidence-based promotion | `se3.promotion_gate/promote`; legacy `/approve` `/apply` route through it | T111-T112, T115, T118 |

Good Father mode: Protect (freeze, adversarial scan, guards) -> Guide (gaps, FIND-first, score) -> Teach (memory, reasons, tests) -> Improve (isolated draft + canary) -> Verify (promotion gate, post-deploy health) -> Recover (verified rollback, chaos check).
High/Critical changes need: owner approval (TOTP step-up for apply/rollback/unfreeze), isolated patch, tests, canary, verification, rollback. The owner mechanism is not hard-coded. Cycles never patch code.
