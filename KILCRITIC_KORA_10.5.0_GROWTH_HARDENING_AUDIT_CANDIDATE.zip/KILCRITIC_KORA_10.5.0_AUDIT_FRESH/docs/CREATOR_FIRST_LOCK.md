# KILCRITIC Creator-First Master Lock

## Main dashboard
The default dashboard is creator-first and uses one transparent-glass **MEDIA + SOCIAL + STUDIO** folder as the front door.

Visible creator destinations include:
- YouTube, Facebook, TikTok, Instagram, X
- Amazon
- Hollywood Studio / Editing
- Cartoon / Animation
- Funny Baby / Funny Videos
- Videos / Photos / Stories / Wallpapers
- Voice + Text
- POST / 30-Day Autopilot
- Research + Search
- Growth / Comments
- Amazon Dhanda

Technical controls remain behind **Advanced** and are not deleted.

## Universal creator flow
DISCOVER → RIGHTS/ACCESS → UNDERSTAND → PLAN → CREATE/EDIT → QUALITY → PLATFORM VARIANT → PREVIEW → HUMAN APPROVAL → PUBLISH → VERIFY → ANALYTICS → LEARN.

The same studio task can be controlled by voice, touch or text. The system must never claim an external action succeeded without verification.

## World search / media
Research can discover public/authorized web information and media. Imported media must carry provenance/rights state. The system may transform authorized content, but must not silently copy protected videos, photos, stories, voices, identities or distinctive works.

## Amazon Dhanda
Amazon is an authorized commerce/affiliate integration, not a fake account generator.

Required flow:
1. Human creates/approves the Amazon Associates/Influencer account using Amazon's official process.
2. System connects only through authorized credentials/API/session mechanisms.
3. Detect products/offers using permitted Amazon data and refresh price/availability with required timestamps.
4. Score demand, sale signals, commission opportunity, competition and risk.
5. Show opportunities on the dashboard.
6. Generate original product content/creative variants.
7. Add required affiliate disclosures.
8. Prepare platform-specific posts.
9. Human approval or configured permitted autopilot gate before external publishing.
10. Verify published IDs/URLs and track clicks/conversions where the authorized platform provides them.
11. Reply to relevant comments only when platform rules and authorization allow it; no spam, bulk unsolicited replies, fake engagement or trend manipulation.

The system must not create a person's identity, fake account, bypass CAPTCHA/liveness/verification, invent sales, scrape private data, or mass-copy other creators' content.

## Social safety lock
Cross-platform publishing is adapter/capability based. Each platform must enforce its own API, rate limits, spam, authenticity, disclosure, copyright and privacy rules. Duplicate or near-duplicate spam is blocked or routed for human review.

## Truth lock
UNAVAILABLE, AUTH_REQUIRED, NOT_IMPLEMENTED, BLOCKED, HUMAN_REVIEW and VERIFIED are distinct states. No UI may convert an unverified external action into a success badge.
