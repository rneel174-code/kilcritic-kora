# KILCRITIC / KORA 10.4.0: Fix + Harden + LOCK-11 report (2026-10-07)

Additive only. Nothing was deleted or cut: every 10.3.0 module/API/UI/DB table/queue/scheduler is preserved (tests T1–T121 kept; seven tests that asserted the unsafe behaviour were corrected, see section E).
Evidence: `python -m kora.tests.run_all` = **151/151 PASS** (T1–T121 + 30 new T122–T151), Supreme Guardian suite registered (T150), compile OK, live HTTP smoke 23/23, SIGKILL+restart proven, headless-Chromium mobile checks 24/24 (390x844, 320x640, 844x390).

## A. The 9 fixes from the real-test audit
| # | Fix | Result | Proof |
|---|---|---|---|
| 1 | Rights/safety gate: UNKNOWN / undeclared / pirated / copied / adult / voice-clone never PASS; scheduler/auto-approve cannot force them | PASS | T130, T131, smoke |
| 2 | Touch -> valid PLANNED workflow (no INVALID); UI shows the real status/message | PASS | T137, Chromium |
| 3 | Approval/credentials re-checked every tick; truthful states SCHEDULED / WAITING_APPROVAL / WAITING_CREDENTIALS / QUEUED / PUBLISHING / PUBLISHED / FAILED / PAUSED / CANCELLED | PASS | T131, T132 |
| 4 | Crash-after-claim recovery, reconcile to real post state, deterministic audit replay, no duplicate jobs/posts under a 6-thread race | PASS | T134, recovery proof |
| 5 | Instagram: `public_media_url` / `media_type` / `ai_generated` / owner reach the post; media required at approval; account OFF/needs-reconnect not usable; SSRF-safe media URL | PASS (fake transport) | T136 |
| 6 | Pause/Resume/Cancel/Edit/Retry state guards (409 on illegal, 404 unknown); 30-item calendar all-or-nothing | PASS | T133, smoke |
| 7 | Mobile UI: master folder reachable at 390/320/landscape, dock fits, command input in viewport, no horizontal scroll | PASS | Chromium script |
| 8 | Capability audit vocabulary: IMPLEMENTED_VERIFIED / PLANNING_ONLY / NOT_IMPLEMENTED / READY_WITH_EXTERNAL_SETUP / UNAVAILABLE; live probes | PASS | T128, `/api/capabilities` |
| 9 | Media creation is NOT_IMPLEMENTED (no generator exists); `media.convert` is real ffmpeg and reports EXPORTED_VERIFIED only when ffprobe measures the requested size | PASS | T129 |
Also fixed: malformed 2xx JSON from a platform no longer crashes (FAILED / `malformed_response`); `/manifest.json` and `/sw.js` served; `/api/platforms/readiness`; `/api/autopilot/schedules/<id>/edit|retry`, `/api/autopilot/calendar`, `/api/media/convert`.

## B. LOCK-11 MALAK-ASSIST (verified + hardened)
Flow: TASK -> detect human dependency -> WAITING_FOR_MALAK -> durable checkpoint -> notify -> authenticated task-bound reply -> resume the exact checkpoint once -> execute -> verify -> audit.
| Requirement | Status | Proof |
|---|---|---|
| OTP / CAPTCHA / PAYMENT / APPROVAL / OAUTH / HUMAN_INPUT pause; never bypassed; never auto-pay; OTP value never stored | PASS | T122 |
| Wrong / expired / duplicate / cross-task replies rejected; lockout after 5 wrong codes | PASS | T123 |
| Unauthorized sender and task-unbound reply rejected | PASS | T124 |
| Checkpoint survives restart; consumed exactly once (6-thread race); crash mid-run reported not re-run | PASS | T125, SIGKILL smoke |
| Notification failure never fakes SENT; bot token never leaks | PASS | T126 |
| Secrets/OTP/card/bearer redacted from checkpoint, notes, outcome, audit | PASS | T127 |
| One-time code is sent ONLY to the Malak channel; the API no longer returns it to the requester | PASS (security fix) | smoke |
| Telegram adapter (Bot API) | IMPLEMENTED, **NOT_CONFIGURED** (needs `KORA_MALAK_TELEGRAM_BOT_TOKEN`, `KORA_MALAK_TELEGRAM_CHAT_ID`) | T126 |
| WhatsApp adapter (Cloud API) | IMPLEMENTED, **NOT_CONFIGURED** (needs `KORA_WHATSAPP_CLOUD_TOKEN`, `KORA_WHATSAPP_PHONE_NUMBER_ID`, `KORA_MALAK_WHATSAPP_TO`) | T126 |
| Live delivery to a real phone | **UNVERIFIED** (no credentials here) | n/a |
| Inbound webhook (Telegram/WhatsApp -> `/api/malak-assist/inbound`) | IMPLEMENTED as an authenticated relay endpoint; a public webhook receiver is **NOT_CONFIGURED** | T124 |

## C. The 10 hardening items (new `kora/services/fortress.py`, reuses existing engines)
| # | Item | Status | Proof |
|---|---|---|---|
| 1 | Deep red-team tests: prompt injection, memory poisoning, SSRF, path/command injection, privilege escalation, tool abuse, secret leakage, supply chain, race/retry/queue abuse | PASS | T147–T149 |
| 2 | Independent Security Watchdog (own cron job `fortress-watchdog`, 60 s) + immutable hash-pinned permission boundary; CRITICAL => sticky HALT of dispatch; only a verified owner (step-up) can resume | PASS | T138–T140 |
| 3 | Agent identity/delegation: scoped, expiring (<=24 h), use-limited, depth<=3, never wider than parent, cascade revoke, race-safe | PASS | T141 |
| 4 | Self-evolution proof diff -> tests -> security -> benchmark -> approval -> rollback (maps the existing SE3 gate; promotes nothing itself) | PASS | T142 |
| 5 | Dead/duplicate file audit with import-graph + string-reference proof; quarantine = COPY to `_quarantine/`, original kept, owner approval, protected dirs refused | PASS | T143 |
| 6 | Truthful capability status | PASS | T128 |
| 7 | Crash recovery + deterministic replay + recovery proof (a diverged state is NOT certified) | PASS | T146 |
| 8 | Learning firewall (injection/secret/policy-override/protected kinds/flood) + objective-drift monitor | PASS | T144 |
| 9 | Self-independence: provider fallback chain, offline capability list, discover -> build -> test -> verify (build is never automatic) | PARTIAL by design | T145 |
| 10 | Complexity gate ACCEPT / SIMPLIFY / REFUSE (duplicate engines, boundary actions, negative value, near-duplicate names) | PASS | T145 |
New owner-only routes: `/api/fortress/{status,watchdog,resume,delegations,dead-files,complexity,recovery-proof,independence,evolution-proof/<id>}`.

## D. Real bugs found by the red team and fixed
1. Platform error bodies that echo the access token were stored in `social_posts.last_error` and the job error. Now scrubbed (`_scrub_secrets`).
2. SSRF filter let decimal/hex/short IP hosts (`2130706433`, `0x7f.0.0.1`, `127.1`) through. Now rejected; hosts must be dotted DNS names.
3. `/api/malak-assist/pause` handed the one-time resume code back to the requester (self-approval). Removed.
4. `/api/malak-assist/<id>/resume` returned `ok:true` on REJECTED. Now `ok` only on RESUMABLE.

## E. Obsolete tests corrected (no shim, no unsafe behaviour restored)
T19, T36, T37, T48, T49, T53, T59 previously accepted undeclared/unknown rights as PASS. They now assert the current contract explicitly:
undeclared or UNKNOWN rights => `HUMAN_REVIEW` (stays PENDING_APPROVAL; automation/auto-approve refused; nothing reaches the platform); copyright-risk content (`pirated`, UNKNOWN + copied) => `BLOCKED` (create refused). Only declared, original/licensed rights reach PASS. T151 additionally guards zero conflict markers, no secrets in shipped files, and the rights contract.

## F. Remaining gaps (honest)
- Real publishing to YouTube / Facebook / X / Instagram / TikTok: **UNVERIFIED** (no credentials; fake-transport tests only). External id is not read back from the platform.
- Media creation (video/photo/story generation, story->movie): **NOT_IMPLEMENTED**. Only conversion + quality verification are real.
- `server.ts` and the React `src/` were never built here (no npm): **UNVERIFIED**; the Python HUD is the working UI.
- Telegram/WhatsApp: adapters exist, **NOT_CONFIGURED**; no live message was sent.
- Passkeys/WebAuthn: **UNAVAILABLE**.
- LLM independence is PARTIAL: with no provider keys KORA answers from a local rule engine, not an LLM.
- Dead-file audit lists 2 unreferenced test files and test-only modules; nothing was archived or deleted (owner decision).
- Watchdog is independent as a separate cron job/code path, not a separate OS process.
