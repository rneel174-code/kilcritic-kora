/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Settings2, X } from 'lucide-react';

import { eventBus } from './services/eventBus';
import { backupService } from './services/backupService';
import { voiceTranscription } from './services/voiceTranscription';
import { mediaDedup } from './services/mediaDedup';
import { systemDoctor } from './services/systemDoctor';
import { offlineQueue, NetworkMode } from './services/offlineQueue';
import { testSuiteRunner } from './services/testSuite';
import { orchestrator } from './services/orchestrator';

import { Header } from './components/Header';
import { TopologyView } from './components/TopologyView';
import { EventBusTab } from './components/EventBusTab';
import { BackupTab } from './components/BackupTab';
import { VoiceTranscriptionTab } from './components/VoiceTranscriptionTab';
import { MediaDedupTab } from './components/MediaDedupTab';
import { SystemDoctorTab } from './components/SystemDoctorTab';
import { OfflineQueueTab } from './components/OfflineQueueTab';
import { TestSuiteTab } from './components/TestSuiteTab';
import { KoraFaceHud } from './components/KoraFaceHud';
import { ServiceName } from './services/types';
import { MediaSocialStudioHub } from './components/MediaSocialStudioHub';

export default function App() {
  // Active Tab - default to Fullscreen KORA Face HUD
  const [activeTab, setActiveTab] = useState<string>('creator_hub');
  const [isHudMinimized, setIsHudMinimized] = useState(false);
  const [advancedOpen, setAdvancedOpen] = useState(false);

  // Service States
  const [events, setEvents] = useState(eventBus.getEvents());
  const [dlq, setDlq] = useState(eventBus.getDLQ());
  const [busMetrics, setBusMetrics] = useState(eventBus.getMetrics());

  const [snapshots, setSnapshots] = useState(backupService.getSnapshots());
  const [transcripts, setTranscripts] = useState(voiceTranscription.getTranscripts());
  const [vadThreshold, setVadThresholdState] = useState(voiceTranscription.getVadThreshold());

  const [mediaItems, setMediaItems] = useState(mediaDedup.getMediaItems());
  const [dedupStats, setDedupStats] = useState(mediaDedup.getStats());

  const [doctorProbes, setDoctorProbes] = useState(systemDoctor.getProbes());
  const [healthScore, setHealthScore] = useState(systemDoctor.getHealthScore());
  const [servicesHealth, setServicesHealth] = useState(systemDoctor.getServicesHealth());
  const [isAutoHealing, setIsAutoHealing] = useState(systemDoctor.isAutoHealing());

  const [queue, setQueue] = useState(offlineQueue.getQueue());
  const [networkMode, setNetworkModeState] = useState<NetworkMode>(offlineQueue.getNetworkMode());

  const [tests, setTests] = useState(testSuiteRunner.getTests());
  const [isTesting, setIsTesting] = useState(testSuiteRunner.isTestRunning());
  const testSummary = testSuiteRunner.getSummary();

  // Initialize Orchestrator on Mount
  useEffect(() => {
    orchestrator.init();

    // Subscribe to microservice changes
    const unsubBus = eventBus.subscribeChange(() => {
      setEvents(eventBus.getEvents());
      setDlq(eventBus.getDLQ());
      setBusMetrics(eventBus.getMetrics());
    });

    const unsubBackup = backupService.subscribe(() => {
      setSnapshots(backupService.getSnapshots());
    });

    const unsubVoice = voiceTranscription.subscribe(() => {
      setTranscripts(voiceTranscription.getTranscripts());
      setVadThresholdState(voiceTranscription.getVadThreshold());
    });

    const unsubDedup = mediaDedup.subscribe(() => {
      setMediaItems(mediaDedup.getMediaItems());
      setDedupStats(mediaDedup.getStats());
    });

    const unsubDoctor = systemDoctor.subscribe(() => {
      setDoctorProbes(systemDoctor.getProbes());
      setHealthScore(systemDoctor.getHealthScore());
      setServicesHealth(systemDoctor.getServicesHealth());
      setIsAutoHealing(systemDoctor.isAutoHealing());
    });

    const unsubQueue = offlineQueue.subscribe(() => {
      setQueue(offlineQueue.getQueue());
      setNetworkModeState(offlineQueue.getNetworkMode());
    });

    const unsubTests = testSuiteRunner.subscribe(() => {
      setTests(testSuiteRunner.getTests());
      setIsTesting(testSuiteRunner.isTestRunning());
    });

    return () => {
      unsubBus();
      unsubBackup();
      unsubVoice();
      unsubDedup();
      unsubDoctor();
      unsubQueue();
      unsubTests();
    };
  }, []);

  // Top action handlers
  const handleRunDiagnostics = () => {
    systemDoctor.runDiagnostics();
  };

  const handleTriggerBackup = async () => {
    await backupService.createSnapshot('INCREMENTAL');
  };

  const handleRunTests = async () => {
    setActiveTab('test_suite');
    await testSuiteRunner.runAllTests();
  };

  const handleSetNetworkMode = (mode: NetworkMode) => {
    offlineQueue.setNetworkMode(mode);
  };

  const advancedTabs = [
    { id: 'hud', label: 'KORA Face HUD' },
    { id: 'topology', label: 'System Overview' },
    { id: 'event_bus', label: 'Events / Event Bus' },
    { id: 'backup_service', label: 'Backup' },
    { id: 'voice_transcription', label: 'Voice / STT' },
    { id: 'media_dedup', label: 'Media Dedup' },
    { id: 'system_doctor', label: 'System Health / Doctor' },
    { id: 'offline_queue', label: 'Offline Queue' },
    { id: 'test_suite', label: 'Tests / Verification' },
  ];

  return (
    <div className="min-h-screen bg-[#070a10] text-zinc-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Tactical Header */}
      {advancedOpen ? (
        <Header
          healthScore={healthScore}
          networkMode={networkMode}
          onSetNetworkMode={handleSetNetworkMode}
          testPassedCount={testSummary.passed}
          testTotalCount={testSummary.total}
          isTesting={isTesting}
          onRunTests={handleRunTests}
          onRunDiagnostics={handleRunDiagnostics}
          onTriggerBackup={handleTriggerBackup}
          activeTab={activeTab}
          onAdvanced={() => setAdvancedOpen(true)}
        />
      ) : null}

      {/* Main Container */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">
        {/* Creator-first dashboard: advanced/system tools stay hidden until explicitly opened. */}
        {activeTab === 'creator_hub' && !advancedOpen && (
          <MediaSocialStudioHub onAdvanced={() => setAdvancedOpen(true)} />
        )}

        <main>
        {/* Advanced content is only rendered after the user explicitly opens Advanced. */}
        {advancedOpen && activeTab !== 'creator_hub' && (
          <div className="mb-5 flex items-center justify-between rounded-2xl border border-zinc-800 bg-zinc-950/80 px-4 py-3">
            <div>
              <div className="text-sm font-bold text-zinc-200">Advanced / System Tools</div>
              <div className="text-[11px] text-zinc-500">Technical controls are hidden from the creator dashboard.</div>
            </div>
            <button onClick={() => { setAdvancedOpen(false); setActiveTab('creator_hub'); }} className="rounded-xl border border-zinc-700 px-3 py-2 text-xs text-zinc-400 hover:text-white">Back to Creator Dashboard</button>
          </div>
        )}

        {activeTab === 'creator_hub' && !advancedOpen && null}

          {advancedOpen && activeTab === 'hud' && (
            <KoraFaceHud
              healthScore={healthScore}
              networkMode={networkMode}
              servicesHealth={servicesHealth}
              onNavigateTab={setActiveTab}
              onRunDiagnostics={handleRunDiagnostics}
              onTriggerBackup={handleTriggerBackup}
              onRunTests={handleRunTests}
              onVoiceSimulate={() => voiceTranscription.recordSampleVoiceTransmission()}
              isKillSwitchActive={offlineQueue.getNetworkMode() === 'OFFLINE'}
              isMinimized={false}
              onToggleMinimize={() => setActiveTab('topology')}
            />
          )}

          {advancedOpen && activeTab === 'topology' && (
            <TopologyView
              servicesHealth={servicesHealth}
              onNavigateTab={setActiveTab}
              onInjectChaos={(t) => systemDoctor.injectChaos(t)}
              onRunDiagnostics={handleRunDiagnostics}
              onForceHeal={() => systemDoctor.forceHealAll()}
              onTriggerBackup={handleTriggerBackup}
              onRunTests={handleRunTests}
              recentEventsCount={events.length}
            />
          )}

          {activeTab === 'event_bus' && (
            <EventBusTab
              events={events}
              dlq={dlq}
              metrics={busMetrics}
              onPublishEvent={(topic, payload, source) => eventBus.publish(topic, payload, source)}
              onReplayEvent={(id) => eventBus.replayEvent(id)}
              onFlushDLQ={() => eventBus.flushDLQ()}
            />
          )}

          {activeTab === 'backup_service' && (
            <BackupTab
              snapshots={snapshots}
              onCreateSnapshot={(type) => backupService.createSnapshot(type).then(() => {})}
              onVerifyIntegrity={(id) => backupService.verifySnapshotIntegrity(id)}
              onRestore={(id) => backupService.restoreFromSnapshot(id)}
              onExportJSON={() => {
                const blob = new Blob([backupService.exportSnapshotsAsJSON()], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `kilcritic-backup-manifest-${Date.now()}.json`;
                a.click();
              }}
              onPruneExpired={() => backupService.enforceRetentionPolicy()}
            />
          )}

          {activeTab === 'voice_transcription' && (
            <VoiceTranscriptionTab
              transcripts={transcripts}
              vadThreshold={vadThreshold}
              onSetVadThreshold={(val) => voiceTranscription.setVadThreshold(val)}
              onSimulateTransmission={() => voiceTranscription.recordSampleVoiceTransmission()}
              onProcessCustomText={(text, speaker) => voiceTranscription.processAudioBuffer(text, speaker)}
            />
          )}

          {activeTab === 'media_dedup' && (
            <MediaDedupTab
              mediaItems={mediaItems}
              stats={dedupStats}
              onPurgeDuplicates={() => mediaDedup.purgeDuplicates()}
              onRegisterMedia={(name, size, type, customHash) =>
                mediaDedup.registerMedia(name, size, type, customHash)
              }
            />
          )}

          {activeTab === 'system_doctor' && (
            <SystemDoctorTab
              probes={doctorProbes}
              healthScore={healthScore}
              servicesHealth={servicesHealth}
              isAutoHealing={isAutoHealing}
              onToggleAutoHealing={() => systemDoctor.toggleAutoHealing()}
              onRunDiagnostics={handleRunDiagnostics}
              onForceHeal={() => systemDoctor.forceHealAll()}
              onInjectChaos={(t) => systemDoctor.injectChaos(t)}
            />
          )}

          {activeTab === 'offline_queue' && (
            <OfflineQueueTab
              queue={queue}
              networkMode={networkMode}
              onSetNetworkMode={handleSetNetworkMode}
              onEnqueue={(target, action, payload, idemKey, prio) =>
                offlineQueue.enqueue(target, action, payload, idemKey, prio)
              }
              onFlushQueue={() => offlineQueue.flushAll()}
              onClearSynced={() => offlineQueue.clearSynced()}
            />
          )}

          {activeTab === 'test_suite' && (
            <TestSuiteTab
              tests={tests}
              isRunning={isTesting}
              onRunAllTests={() => testSuiteRunner.runAllTests()}
            />
          )}
        {advancedOpen && (
          <section className="mt-6 rounded-3xl border border-zinc-800 bg-[#090d16] p-4 md:p-6">
            <div className="flex items-center justify-between gap-3 mb-4">
              <div className="flex items-center gap-2 text-zinc-200 font-bold"><Settings2 className="w-4 h-4 text-emerald-300" /> Advanced</div>
              <button onClick={() => { setAdvancedOpen(false); setActiveTab('creator_hub'); }} className="p-2 rounded-lg text-zinc-500 hover:text-white hover:bg-zinc-800" aria-label="Close Advanced"><X className="w-4 h-4" /></button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2 mb-5">
              {advancedTabs.map(tab => (
                <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`rounded-xl border px-3 py-2 text-left text-xs transition-all ${activeTab === tab.id ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300' : 'border-zinc-800 bg-zinc-900/50 text-zinc-400 hover:text-zinc-200 hover:border-zinc-700'}`}>
                  {tab.label}
                </button>
              ))}
            </div>
          </section>
        )}
        </main>
      </div>

      {/* Cyber-CTO Footer Status Bar */}
      <footer className="mt-auto border-t border-zinc-800 bg-[#090d16] px-4 py-2.5 text-xs font-mono text-zinc-400">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5 text-emerald-400 font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              KILCRITIC SUPREME 10.2.2
            </span>
            <span className="text-zinc-600">|</span>
            <span>Creator Dashboard • Advanced hidden by default</span>
            <span className="text-zinc-600">|</span>
            <span>75/75 Core Tests Passing</span>
          </div>

          <div className="flex items-center gap-4 text-zinc-500 text-[11px]">
            <span>Bus Events: {events.length}</span>
            <span>Snapshots: {snapshots.length}</span>
            <span>Queue: {queue.length}</span>
            <span>Network: <strong className="text-zinc-300">{networkMode}</strong></span>
          </div>
        </div>
      </footer>
    </div>
  );
}
