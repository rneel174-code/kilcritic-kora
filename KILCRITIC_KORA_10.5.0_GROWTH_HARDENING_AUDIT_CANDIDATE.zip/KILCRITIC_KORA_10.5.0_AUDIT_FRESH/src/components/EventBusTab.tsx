import React, { useState } from 'react';
import {
  Layers,
  Send,
  RotateCcw,
  Trash2,
  Search,
  Filter,
  AlertOctagon,
  CheckCircle,
  Clock,
  Code,
} from 'lucide-react';
import { BusEvent, ServiceName } from '../services/types';
import { eventBus } from '../services/eventBus';

interface EventBusTabProps {
  events: BusEvent[];
  dlq: BusEvent[];
  metrics: {
    totalPublished: number;
    totalAcked: number;
    totalDlq: number;
    totalReplayed: number;
    activeSubscriptions: number;
  };
  onPublishEvent: (topic: string, payload: any, source: ServiceName | 'user_ui') => void;
  onReplayEvent: (id: string) => void;
  onFlushDLQ: () => void;
}

export const EventBusTab: React.FC<EventBusTabProps> = ({
  events,
  dlq,
  metrics,
  onPublishEvent,
  onReplayEvent,
  onFlushDLQ,
}) => {
  const [filterTopic, setFilterTopic] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [newTopic, setNewTopic] = useState('voice.vad.stream');
  const [newSource, setNewSource] = useState<ServiceName | 'user_ui'>('user_ui');
  const [newPayload, setNewPayload] = useState('{\n  "priority": "HIGH",\n  "telemetry": "nominal"\n}');
  const [payloadError, setPayloadError] = useState<string | null>(null);

  const filteredEvents = events.filter((e) => {
    const matchesTopic = filterTopic ? e.topic.toLowerCase().includes(filterTopic.toLowerCase()) : true;
    const matchesStatus = filterStatus === 'ALL' ? true : e.status === filterStatus;
    return matchesTopic && matchesStatus;
  });

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const parsed = JSON.parse(newPayload);
      setPayloadError(null);
      onPublishEvent(newTopic, parsed, newSource);
    } catch (err: any) {
      setPayloadError('Invalid JSON payload');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <div className="p-3 rounded-lg bg-zinc-900 border border-zinc-800">
          <span className="text-[10px] font-mono text-zinc-500 uppercase block">Published</span>
          <span className="text-xl font-bold font-mono text-zinc-100">{metrics.totalPublished}</span>
        </div>
        <div className="p-3 rounded-lg bg-zinc-900 border border-zinc-800">
          <span className="text-[10px] font-mono text-zinc-500 uppercase block">Delivered / Acked</span>
          <span className="text-xl font-bold font-mono text-emerald-400">{metrics.totalAcked}</span>
        </div>
        <div className="p-3 rounded-lg bg-zinc-900 border border-zinc-800">
          <span className="text-[10px] font-mono text-zinc-500 uppercase block">Dead-Letter Queue</span>
          <span className={`text-xl font-bold font-mono ${dlq.length > 0 ? 'text-rose-400' : 'text-zinc-400'}`}>
            {dlq.length}
          </span>
        </div>
        <div className="p-3 rounded-lg bg-zinc-900 border border-zinc-800">
          <span className="text-[10px] font-mono text-zinc-500 uppercase block">Replayed</span>
          <span className="text-xl font-bold font-mono text-indigo-400">{metrics.totalReplayed}</span>
        </div>
        <div className="p-3 rounded-lg bg-zinc-900 border border-zinc-800">
          <span className="text-[10px] font-mono text-zinc-500 uppercase block">Active Listeners</span>
          <span className="text-xl font-bold font-mono text-cyan-400">{metrics.activeSubscriptions}</span>
        </div>
      </div>

      {/* DLQ Alert Banner if items exist */}
      {dlq.length > 0 && (
        <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-500/40 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <AlertOctagon className="w-5 h-5 text-rose-400 shrink-0" />
            <div>
              <h4 className="font-mono font-bold text-rose-200 text-sm">
                Dead Letter Queue (DLQ): {dlq.length} Faulted Events
              </h4>
              <p className="text-xs text-rose-300">
                Failed consumer executions have been isolated to avoid cascaded pipeline crashes.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onReplayEvent(dlq[0]?.id)}
              className="px-3 py-1.5 rounded bg-rose-900/60 hover:bg-rose-800/80 border border-rose-500/50 text-rose-200 text-xs font-mono font-semibold flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Replay Oldest</span>
            </button>
            <button
              onClick={onFlushDLQ}
              className="px-3 py-1.5 rounded bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 text-xs font-mono font-semibold flex items-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5 text-zinc-400" />
              <span>Flush DLQ</span>
            </button>
          </div>
        </div>
      )}

      {/* Two Column Layout: Event Dispatcher & Live Log */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Event Publisher Form */}
        <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-4">
          <div className="flex items-center gap-2">
            <Send className="w-4 h-4 text-cyan-400" />
            <h3 className="font-mono font-bold text-sm text-zinc-200 uppercase">
              Publish Event to Bus
            </h3>
          </div>

          <form onSubmit={handlePublish} className="space-y-3">
            <div>
              <label className="text-[11px] font-mono text-zinc-400 block mb-1">
                Topic (supports dot notation, e.g. voice.stream)
              </label>
              <input
                type="text"
                value={newTopic}
                onChange={(e) => setNewTopic(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-200 font-mono text-xs focus:outline-none focus:border-cyan-500"
                required
              />
            </div>

            <div>
              <label className="text-[11px] font-mono text-zinc-400 block mb-1">Source Service</label>
              <select
                value={newSource}
                onChange={(e) => setNewSource(e.target.value as any)}
                className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-200 font-mono text-xs focus:outline-none focus:border-cyan-500"
              >
                <option value="user_ui">user_ui</option>
                <option value="event_bus">event_bus</option>
                <option value="backup_service">backup_service</option>
                <option value="voice_transcription">voice_transcription</option>
                <option value="media_dedup">media_dedup</option>
                <option value="system_doctor">system_doctor</option>
                <option value="offline_queue">offline_queue</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-mono text-zinc-400 block mb-1">Payload (JSON)</label>
              <textarea
                value={newPayload}
                onChange={(e) => setNewPayload(e.target.value)}
                rows={5}
                className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-200 font-mono text-xs focus:outline-none focus:border-cyan-500"
              />
              {payloadError && (
                <span className="text-[10px] text-rose-400 font-mono block mt-1">{payloadError}</span>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-2 px-4 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-zinc-900 font-mono font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md"
            >
              <Send className="w-3.5 h-3.5" />
              <span>DISPATCH EVENT</span>
            </button>
          </form>

          {/* Quick Preset Topics */}
          <div className="pt-2 border-t border-zinc-800 space-y-2">
            <span className="text-[10px] font-mono text-zinc-500 uppercase block">Quick Presets:</span>
            <div className="flex flex-wrap gap-1.5">
              {[
                'voice.vad.triggered',
                'media.scan.requested',
                'system.heartbeat.pulse',
                'backup.delta.created',
                'queue.flush.manual',
              ].map((topic) => (
                <button
                  key={topic}
                  type="button"
                  onClick={() => setNewTopic(topic)}
                  className="px-2 py-0.5 rounded bg-zinc-950 hover:bg-zinc-800 text-[10px] font-mono text-zinc-400 border border-zinc-800 transition-colors"
                >
                  {topic}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Live Event Stream Table */}
        <div className="lg:col-span-2 p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              <h3 className="font-mono font-bold text-sm text-zinc-200 uppercase">
                Event Bus Stream ({filteredEvents.length} items)
              </h3>
            </div>

            {/* Filter controls */}
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3 h-3 text-zinc-500 absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  placeholder="Filter topic..."
                  value={filterTopic}
                  onChange={(e) => setFilterTopic(e.target.value)}
                  className="pl-7 pr-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-200 font-mono text-xs focus:outline-none focus:border-cyan-500 w-36"
                />
              </div>

              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-2 py-1.5 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-300 font-mono text-xs focus:outline-none focus:border-cyan-500"
              >
                <option value="ALL">All Status</option>
                <option value="ACKED">ACKED</option>
                <option value="PUBLISHED">PUBLISHED</option>
                <option value="DLQ">DLQ</option>
                <option value="REPLAYED">REPLAYED</option>
              </select>
            </div>
          </div>

          {/* Event Stream List */}
          <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1">
            {filteredEvents.length === 0 ? (
              <div className="p-8 text-center text-zinc-500 text-xs font-mono">
                No events match current filter.
              </div>
            ) : (
              filteredEvents.map((evt) => (
                <div
                  key={evt.id}
                  className="p-3 rounded-lg bg-zinc-950/70 border border-zinc-800/80 hover:border-zinc-700 text-xs font-mono space-y-1.5 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-cyan-400">{evt.topic}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400">
                        {evt.source}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          evt.status === 'ACKED'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : evt.status === 'DLQ'
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                            : evt.status === 'REPLAYED'
                            ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
                            : 'bg-zinc-800 text-zinc-300'
                        }`}
                      >
                        {evt.status}
                      </span>

                      <button
                        onClick={() => onReplayEvent(evt.id)}
                        title="Replay Event"
                        className="p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-cyan-300 transition-colors"
                      >
                        <RotateCcw className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  {/* Payload excerpt */}
                  <div className="p-1.5 rounded bg-zinc-900/80 text-[11px] text-zinc-300 font-mono overflow-x-auto">
                    <code>{JSON.stringify(evt.payload)}</code>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-zinc-500 pt-1">
                    <span>ID: {evt.id} | Corr: {evt.correlationId}</span>
                    <span>{new Date(evt.timestamp).toLocaleTimeString()}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
