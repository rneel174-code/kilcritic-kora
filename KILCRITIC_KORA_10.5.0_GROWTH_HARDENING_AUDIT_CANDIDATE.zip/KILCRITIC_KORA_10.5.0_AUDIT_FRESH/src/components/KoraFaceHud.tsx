import React, { useState, useEffect, useRef } from 'react';
import {
  Calendar,
  Bell,
  Mail,
  Home,
  Activity,
  FileText,
  Newspaper,
  CloudSun,
  HardDrive,
  HeartPulse,
  Subtitles,
  Mic,
  MicOff,
  Maximize2,
  Minimize2,
  X,
  Send,
  Zap,
  Cpu,
  Layers,
  Sparkles,
  Search,
  Wifi,
  Battery,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
  Bot,
  Brain,
  Film,
  Camera,
  Radio,
  CopySlash,
  Stethoscope,
  Network,
  Award,
  Share2,
  Compass,
  TrendingUp,
  Lock,
  ChevronRight,
  Plus,
  Flame,
  Clock,
  Sliders,
  Database,
  Eye,
  Key,
} from 'lucide-react';
import { ServiceHealth, ServiceName } from '../services/types';
import { NetworkMode } from '../services/offlineQueue';

export type KoraHudState =
  | 'IDLE'
  | 'LISTENING'
  | 'THINKING'
  | 'SPEAKING'
  | 'WORKING'
  | 'SUCCESS'
  | 'WARNING'
  | 'ERROR'
  | 'OFFLINE';

export interface HudModuleItem {
  id: string;
  name: string;
  category: 'CORE' | 'CREATOR' | 'AUTOPILOT' | 'DISCOVERY' | 'SOCIAL' | 'SYSTEM';
  status: 'ONLINE' | 'STANDBY' | 'HARDENED' | 'NOT CONFIGURED';
  icon: React.ReactNode;
  desc: string;
  tabTarget?: string;
  actionText?: string;
  action?: () => void;
}

interface KoraFaceHudProps {
  healthScore: number;
  networkMode: NetworkMode;
  servicesHealth: Record<ServiceName, ServiceHealth>;
  onNavigateTab: (tabId: string) => void;
  onRunDiagnostics: () => void;
  onTriggerBackup: () => void;
  onRunTests: () => void;
  onVoiceSimulate: () => Promise<any>;
  isKillSwitchActive?: boolean;
  isMinimized?: boolean;
  onToggleMinimize?: () => void;
}

export const KoraFaceHud: React.FC<KoraFaceHudProps> = ({
  healthScore,
  networkMode,
  servicesHealth,
  onNavigateTab,
  onRunDiagnostics,
  onTriggerBackup,
  onRunTests,
  onVoiceSimulate,
  isKillSwitchActive = false,
  isMinimized = false,
  onToggleMinimize,
}) => {
  const [hudState, setHudState] = useState<KoraHudState>('IDLE');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [localMinimized, setLocalMinimized] = useState(false);

  const effectiveMinimized = onToggleMinimize ? isMinimized : localMinimized;
  const triggerMinimize = onToggleMinimize || (() => setLocalMinimized(!localMinimized));

  const [activeCategory, setActiveCategory] = useState<
    'ALL' | 'CORE' | 'CREATOR' | 'AUTOPILOT' | 'DISCOVERY' | 'SOCIAL' | 'SYSTEM'
  >('ALL');

  const [activeModalItem, setActiveModalItem] = useState<HudModuleItem | null>(null);
  const [inputText, setInputText] = useState('');
  const [currentTime, setCurrentTime] = useState('');
  const [searchFilter, setSearchFilter] = useState('');
  const [systemLogs, setSystemLogs] = useState<string[]>([
    'KORA 8.8.5 GODFATHER kernel loaded',
    'Holographic HUD matrix online',
    'All 6 microservices healthy',
  ]);
  const [notesList, setNotesList] = useState<string[]>([
    'Godfather CTO Hardened: 22 tests passing',
    'Strict audience isolation active: KIDS vs GENERAL vs ADULT',
    'SQLite WAL authoritative master synced',
  ]);
  const [newNote, setNewNote] = useState('');

  const containerRef = useRef<HTMLDivElement>(null);

  // Clock updater
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Sync state with health/network
  useEffect(() => {
    if (networkMode === 'OFFLINE') {
      setHudState('OFFLINE');
    } else if (isKillSwitchActive || healthScore < 70) {
      setHudState('WARNING');
    } else if (hudState === 'OFFLINE' && networkMode === 'ONLINE') {
      setHudState('IDLE');
    }
  }, [networkMode, isKillSwitchActive, healthScore]);

  // Fullscreen management
  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch {
      setIsFullscreen(!isFullscreen);
    }
  };

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  const addLog = (msg: string) => {
    setSystemLogs((prev) => [
      `[${new Date().toLocaleTimeString()}] ${msg}`,
      ...prev.slice(0, 5),
    ]);
  };

  const handleVoiceClick = async () => {
    setHudState('LISTENING');
    addLog('Voice input active: listening to 48kHz audio buffer...');
    setTimeout(async () => {
      setHudState('THINKING');
      addLog('Processing VAD spectrum and truthful STT cascade...');
      try {
        const res = await onVoiceSimulate();
        setHudState('SPEAKING');
        addLog(`Transcribed: "${res.text}" [Speaker: ${res.speaker}]`);
        setTimeout(() => setHudState('IDLE'), 2500);
      } catch (e: any) {
        setHudState('ERROR');
        addLog(`Voice Error: ${e?.message || 'Provider unavailable'}`);
        setTimeout(() => setHudState('IDLE'), 2000);
      }
    }, 1200);
  };

  const handleInputSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    const q = inputText.trim();
    setInputText('');
    setHudState('THINKING');
    addLog(`User Command: "${q}"`);

    setTimeout(() => {
      setHudState('WORKING');
      if (q.toLowerCase().includes('backup')) {
        onTriggerBackup();
        addLog('Executed automatic backup snapshot.');
      } else if (q.toLowerCase().includes('heal') || q.toLowerCase().includes('doctor')) {
        onRunDiagnostics();
        addLog('Executed System Doctor diagnostic sweep.');
      } else if (q.toLowerCase().includes('test')) {
        onRunTests();
        addLog('Triggered 22-test behavioral suite.');
      } else {
        addLog(`Synthesized autonomous response for: "${q}"`);
      }
      setHudState('SUCCESS');
      setTimeout(() => setHudState('IDLE'), 2000);
    }, 900);
  };

  const handleAddNote = () => {
    if (!newNote.trim()) return;
    setNotesList((prev) => [newNote.trim(), ...prev]);
    setNewNote('');
    addLog('New note saved into context memory.');
  };

  // 8 Primary Holographic Floating Cards from Image Reference (IMG-20261003-WA5142.jpg)
  const PRIMARY_HUD_CARDS = [
    {
      id: 'schedule',
      title: 'Schedule',
      sub: 'Today • 3 meetings',
      desc: 'Next: Event Bus Sync @ 16:30 | Council Alignment @ 18:00',
      icon: <Calendar className="w-8 h-8 text-cyan-400" />,
      tag: 'CALENDAR',
      action: () => onNavigateTab('topology'),
    },
    {
      id: 'reminders',
      title: 'Reminders',
      sub: '2 pending • Team check-in',
      desc: 'Pending: 1 Social post awaiting human approval | SQLite WAL prune',
      icon: <Bell className="w-8 h-8 text-cyan-400" />,
      tag: 'TASKS',
      action: () => onNavigateTab('offline_queue'),
    },
    {
      id: 'mail',
      title: 'Mail',
      sub: '12 new • Priority inbox',
      desc: 'Event bus notifications & verified worker completion alerts',
      icon: <Mail className="w-8 h-8 text-cyan-400" />,
      tag: 'COMMS',
      action: () => onNavigateTab('event_bus'),
    },
    {
      id: 'smart_home',
      title: 'Smart Home',
      sub: '5 devices • All online',
      desc: '6 microservices mesh: Event Bus, Backup, Voice, Dedup, Doctor, Queue',
      icon: <Home className="w-8 h-8 text-cyan-400" />,
      tag: 'MESH',
      action: () => onNavigateTab('topology'),
    },
    {
      id: 'fitness',
      title: 'Fitness',
      sub: `${healthScore}% score • System Nominal`,
      desc: `Storage headroom healthy | 22/22 behavioral tests passing`,
      icon: <Activity className="w-8 h-8 text-cyan-400" />,
      tag: 'HEALTH',
      action: () => onNavigateTab('system_doctor'),
    },
    {
      id: 'notes',
      title: 'Notes',
      sub: `${notesList.length} notes • Pinned`,
      desc: 'Context memory scratchpad & executive guidelines',
      icon: <FileText className="w-8 h-8 text-cyan-400" />,
      tag: 'MEMORY',
      action: () =>
        setActiveModalItem({
          id: 'notes_modal',
          name: 'KORA Context Notes',
          category: 'CORE',
          status: 'ONLINE',
          icon: <FileText className="w-5 h-5 text-cyan-400" />,
          desc: 'Persistent context notes stored across sessions.',
        }),
    },
    {
      id: 'news',
      title: 'News',
      sub: '7 updates • Tech & AI',
      desc: 'Algorithmic trends, competitor radar & hashtag discovery',
      icon: <Newspaper className="w-8 h-8 text-cyan-400" />,
      tag: 'DISCOVERY',
      action: () =>
        setActiveModalItem({
          id: 'news_modal',
          name: 'AI & Tech Trends Radar',
          category: 'DISCOVERY',
          status: 'ONLINE',
          icon: <Newspaper className="w-5 h-5 text-cyan-400" />,
          desc: 'Continuous platform velocity scanner across technical topics.',
        }),
    },
    {
      id: 'weather',
      title: 'Weather',
      sub: '22°C • Clear • Now',
      desc: 'All external platform adapters verified (YouTube, TikTok, X)',
      icon: <CloudSun className="w-8 h-8 text-cyan-400" />,
      tag: 'RADAR',
      action: () =>
        setActiveModalItem({
          id: 'platform_radar',
          name: 'Platform Atmosphere & Radar',
          category: 'SYSTEM',
          status: 'ONLINE',
          icon: <CloudSun className="w-5 h-5 text-cyan-400" />,
          desc: 'External API network climate & adapter connectivity overview.',
        }),
    },
  ];

  // Complete 59 Modules Across All 6 Categories
  const ALL_MODULES: Record<string, HudModuleItem[]> = {
    CORE: [
      { id: 'c1', name: 'KORA / Ask KORA', category: 'CORE', status: 'ONLINE', icon: <Bot className="w-4 h-4 text-cyan-400" />, desc: 'Primary cognitive interactive assistant interface' },
      { id: 'c2', name: 'Brain', category: 'CORE', status: 'ONLINE', icon: <Brain className="w-4 h-4 text-indigo-400" />, desc: 'Vector state store, context memory & neural bindings' },
      { id: 'c3', name: 'Memory', category: 'CORE', status: 'ONLINE', icon: <Database className="w-4 h-4 text-teal-400" />, desc: 'Deterministic SQLite persistent context storage' },
      { id: 'c4', name: 'Command Center', category: 'CORE', status: 'ONLINE', icon: <Cpu className="w-4 h-4 text-emerald-400" />, tabTarget: 'topology', desc: 'Central operational microservice mesh topology' },
      { id: 'c5', name: 'CEO / Executive', category: 'CORE', status: 'ONLINE', icon: <Zap className="w-4 h-4 text-amber-400" />, desc: 'High-level strategy governance & approval routing' },
      { id: 'c6', name: 'Director', category: 'CORE', status: 'ONLINE', icon: <Film className="w-4 h-4 text-purple-400" />, desc: 'Task breakdown & orchestration dispatch worker' },
      { id: 'c7', name: 'Agent OS', category: 'CORE', status: 'ONLINE', icon: <Layers className="w-4 h-4 text-cyan-400" />, tabTarget: 'event_bus', desc: 'Event bus routing & dead-letter queue manager' },
      { id: 'c8', name: 'Council', category: 'CORE', status: 'HARDENED', icon: <ShieldCheck className="w-4 h-4 text-rose-400" />, desc: 'Multi-agent consensus & safety alignment matrix' },
    ],
    CREATOR: [
      { id: 'cr1', name: 'Creator Studio', category: 'CREATOR', status: 'ONLINE', icon: <Camera className="w-4 h-4 text-pink-400" />, desc: 'Multi-modal generation and rendering workspace' },
      { id: 'cr2', name: 'Video', category: 'CREATOR', status: 'ONLINE', icon: <Film className="w-4 h-4 text-red-400" />, desc: 'Frame processing, transcoding and segment pipeline' },
      { id: 'cr3', name: 'Audio', category: 'CREATOR', status: 'ONLINE', icon: <Radio className="w-4 h-4 text-indigo-400" />, desc: '48kHz audio processing and acoustic normalization' },
      { id: 'cr4', name: 'Voice', category: 'CREATOR', status: 'ONLINE', icon: <Mic className="w-4 h-4 text-emerald-400" />, tabTarget: 'voice_transcription', desc: 'Voice ingest and real-time VAD noise gate' },
      { id: 'cr5', name: 'STT', category: 'CREATOR', status: 'ONLINE', icon: <FileText className="w-4 h-4 text-cyan-400" />, tabTarget: 'voice_transcription', desc: 'Truthful multi-provider speech transcription' },
      { id: 'cr6', name: 'TTS', category: 'CREATOR', status: 'ONLINE', icon: <Radio className="w-4 h-4 text-teal-400" />, desc: 'Neural speech synthesis with rate and pitch control' },
      { id: 'cr7', name: 'Media Hub', category: 'CREATOR', status: 'ONLINE', icon: <CopySlash className="w-4 h-4 text-amber-400" />, tabTarget: 'media_dedup', desc: 'Perceptual hashing (pHash) & storage reclaim' },
      { id: 'cr8', name: 'Images', category: 'CREATOR', status: 'ONLINE', icon: <Camera className="w-4 h-4 text-purple-400" />, desc: 'Visual asset store and thumbnail generator' },
      { id: 'cr9', name: 'Wallpapers', category: 'CREATOR', status: 'ONLINE', icon: <Sparkles className="w-4 h-4 text-yellow-400" />, desc: 'High-definition cybernetic holographic artwork' },
      { id: 'cr10', name: 'Stories', category: 'CREATOR', status: 'ONLINE', icon: <Film className="w-4 h-4 text-blue-400" />, desc: '9:16 vertical short-form story storyboarder' },
      { id: 'cr11', name: 'Captions / Subtitles', category: 'CREATOR', status: 'HARDENED', icon: <Subtitles className="w-4 h-4 text-cyan-400" />, desc: 'ffprobe duration-bounded subtitle burner' },
      { id: 'cr12', name: 'FFmpeg Editor', category: 'CREATOR', status: 'HARDENED', icon: <Film className="w-4 h-4 text-emerald-400" />, desc: 'Hardened argument-array media processor' },
      { id: 'cr13', name: 'Quality', category: 'CREATOR', status: 'HARDENED', icon: <Sparkles className="w-4 h-4 text-rose-400" />, desc: 'Source, processing, and export quality controls' },
    ],
    AUTOPILOT: [
      { id: 'ap1', name: 'Autopilot', category: 'AUTOPILOT', status: 'ONLINE', icon: <Zap className="w-4 h-4 text-emerald-400" />, desc: 'Autonomous scheduling and recurring task engine' },
      { id: 'ap2', name: '30-Day Planner', category: 'AUTOPILOT', status: 'ONLINE', icon: <Calendar className="w-4 h-4 text-blue-400" />, desc: 'Content calendar, milestone tracker & sync map' },
      { id: 'ap3', name: 'Scheduler', category: 'AUTOPILOT', status: 'ONLINE', icon: <Clock className="w-4 h-4 text-teal-400" />, desc: 'Deterministic cron and one-shot timer dispatch' },
      { id: 'ap4', name: 'Durable Queue', category: 'AUTOPILOT', status: 'HARDENED', icon: <Database className="w-4 h-4 text-cyan-400" />, tabTarget: 'offline_queue', desc: 'Atomic leasing, priority 100 before 10, fencing' },
      { id: 'ap5', name: 'Worker', category: 'AUTOPILOT', status: 'HARDENED', icon: <Network className="w-4 h-4 text-teal-400" />, desc: 'Concurrent worker pool with safe handler registry' },
      { id: 'ap6', name: 'Offline Queue', category: 'AUTOPILOT', status: 'ONLINE', icon: <Network className="w-4 h-4 text-amber-400" />, tabTarget: 'offline_queue', desc: 'Local buffering, idempotency token validator' },
      { id: 'ap7', name: 'Recovery', category: 'AUTOPILOT', status: 'HARDENED', icon: <RotateCcw className="w-4 h-4 text-purple-400" />, desc: 'Stale lease reclaim and crash-recovery engine' },
      { id: 'ap8', name: 'System Doctor', category: 'AUTOPILOT', status: 'ONLINE', icon: <Stethoscope className="w-4 h-4 text-rose-400" />, tabTarget: 'system_doctor', desc: 'Continuous probes & safe artifact self-healing' },
    ],
    DISCOVERY: [
      { id: 'dc1', name: 'Trends', category: 'DISCOVERY', status: 'ONLINE', icon: <TrendingUp className="w-4 h-4 text-purple-400" />, desc: 'Real-time search and platform velocity scanner' },
      { id: 'dc2', name: 'Smart Discovery', category: 'DISCOVERY', status: 'ONLINE', icon: <Compass className="w-4 h-4 text-cyan-400" />, desc: 'Algorithmic opportunity identification engine' },
      { id: 'dc3', name: 'Competition', category: 'DISCOVERY', status: 'ONLINE', icon: <Eye className="w-4 h-4 text-amber-400" />, desc: 'Cross-channel competitor benchmark radar' },
      { id: 'dc4', name: 'Hashtags', category: 'DISCOVERY', status: 'ONLINE', icon: <Share2 className="w-4 h-4 text-emerald-400" />, desc: 'Audience-isolated hashtag generator' },
      { id: 'dc5', name: 'Metadata', category: 'DISCOVERY', status: 'ONLINE', icon: <FileText className="w-4 h-4 text-blue-400" />, desc: 'SEO title, description & OpenGraph generator' },
      { id: 'dc6', name: 'Growth', category: 'DISCOVERY', status: 'ONLINE', icon: <TrendingUp className="w-4 h-4 text-pink-400" />, desc: 'Channel velocity and viewer retention tracker' },
      { id: 'dc7', name: 'Analytics', category: 'DISCOVERY', status: 'ONLINE', icon: <Activity className="w-4 h-4 text-yellow-400" />, desc: 'Truthful performance metrics and retention charts' },
      { id: 'dc8', name: 'Learning', category: 'DISCOVERY', status: 'ONLINE', icon: <Brain className="w-4 h-4 text-teal-400" />, desc: 'Self-tuning model parameter adjustment store' },
      { id: 'dc9', name: 'Brahma / Self-Improvement', category: 'DISCOVERY', status: 'HARDENED', icon: <Sparkles className="w-4 h-4 text-indigo-400" />, desc: 'Safe proposal generation without arbitrary RCE' },
    ],
    SOCIAL: [
      { id: 'sc1', name: 'YouTube', category: 'SOCIAL', status: 'NOT CONFIGURED', icon: <Film className="w-4 h-4 text-red-500" />, desc: 'Official API integration with mandatory approval gate' },
      { id: 'sc2', name: 'Facebook', category: 'SOCIAL', status: 'NOT CONFIGURED', icon: <Share2 className="w-4 h-4 text-blue-500" />, desc: 'Meta Graph API adapter with verified token check' },
      { id: 'sc3', name: 'Instagram', category: 'SOCIAL', status: 'NOT CONFIGURED', icon: <Camera className="w-4 h-4 text-pink-500" />, desc: 'Reels and carousel publishing verification pipeline' },
      { id: 'sc4', name: 'TikTok', category: 'SOCIAL', status: 'NOT CONFIGURED', icon: <Radio className="w-4 h-4 text-cyan-400" />, desc: 'Official Open API publisher with idempotency' },
      { id: 'sc5', name: 'X / Twitter', category: 'SOCIAL', status: 'NOT CONFIGURED', icon: <Share2 className="w-4 h-4 text-zinc-300" />, desc: 'X API v2 dispatch requiring operator signature' },
      { id: 'sc6', name: 'Comments', category: 'SOCIAL', status: 'ONLINE', icon: <Mail className="w-4 h-4 text-amber-400" />, desc: 'Unified community comment ingestion inbox' },
      { id: 'sc7', name: 'Publishing', category: 'SOCIAL', status: 'HARDENED', icon: <Send className="w-4 h-4 text-emerald-400" />, desc: 'Orchestrated multi-network publisher' },
      { id: 'sc8', name: 'Approvals', category: 'SOCIAL', status: 'HARDENED', icon: <Lock className="w-4 h-4 text-rose-400" />, desc: 'Strict human-in-the-loop publish approval barrier' },
    ],
    SYSTEM: [
      { id: 'sy1', name: 'Live System Overview', category: 'SYSTEM', status: 'ONLINE', icon: <Cpu className="w-4 h-4 text-cyan-400" />, tabTarget: 'topology', desc: 'Full-duplex telemetry and health score gauge' },
      { id: 'sy2', name: 'Test All Systems', category: 'SYSTEM', status: 'ONLINE', icon: <Award className="w-4 h-4 text-emerald-400" />, tabTarget: 'test_suite', desc: 'CTO 22-test behavioral assertion verification' },
      { id: 'sy3', name: 'AI Providers', category: 'SYSTEM', status: 'HARDENED', icon: <Bot className="w-4 h-4 text-indigo-400" />, desc: 'Truthful status: Gemini, OpenAI, Groq, local fallback' },
      { id: 'sy4', name: 'Failover', category: 'SYSTEM', status: 'HARDENED', icon: <RotateCcw className="w-4 h-4 text-amber-400" />, desc: 'Graceful fallback to labeled deterministic engine' },
      { id: 'sy5', name: 'Security', category: 'SYSTEM', status: 'HARDENED', icon: <ShieldCheck className="w-4 h-4 text-rose-400" />, desc: 'SSRF allowlist, recursive secret redaction, 403 gate' },
      { id: 'sy6', name: 'Integrity', category: 'SYSTEM', status: 'HARDENED', icon: <Key className="w-4 h-4 text-teal-400" />, desc: 'Cryptographic SHA-256 and PRAGMA integrity' },
      { id: 'sy7', name: 'Backup', category: 'SYSTEM', status: 'ONLINE', icon: <HardDrive className="w-4 h-4 text-emerald-400" />, tabTarget: 'backup_service', desc: 'SHA-256 integrity snapshots with restore readability' },
      { id: 'sy8', name: 'Restore', category: 'SYSTEM', status: 'HARDENED', icon: <RotateCcw className="w-4 h-4 text-cyan-400" />, desc: 'Clean database restoration with schema validation' },
      { id: 'sy9', name: 'Kill Switch', category: 'SYSTEM', status: 'HARDENED', icon: <Flame className="w-4 h-4 text-rose-500" />, desc: 'Emergency circuit breaker halting all worker dispatch' },
      { id: 'sy10', name: 'Emergency', category: 'SYSTEM', status: 'HARDENED', icon: <AlertTriangle className="w-4 h-4 text-red-500" />, desc: 'Quarantine mode and safe scrap purger' },
      { id: 'sy11', name: 'Audit', category: 'SYSTEM', status: 'ONLINE', icon: <FileText className="w-4 h-4 text-amber-400" />, desc: 'Full event log and transaction ledger' },
      { id: 'sy12', name: 'Setup', category: 'SYSTEM', status: 'ONLINE', icon: <Sliders className="w-4 h-4 text-zinc-400" />, desc: 'Operator environment variables & runtime flags' },
      { id: 'sy13', name: 'Performance', category: 'SYSTEM', status: 'ONLINE', icon: <Activity className="w-4 h-4 text-emerald-400" />, desc: 'Queue latency, claim throughput, and memory stats' },
    ],
  };

  const getFilteredCategoryModules = () => {
    if (activeCategory === 'ALL') return [];
    const list = ALL_MODULES[activeCategory] || [];
    if (!searchFilter.trim()) return list;
    return list.filter(
      (m) =>
        m.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
        m.desc.toLowerCase().includes(searchFilter.toLowerCase())
    );
  };

  // ==========================================
  // MINIMIZED FLOATING AVATAR WIDGET (PiP Mode)
  // ==========================================
  if (effectiveMinimized) {
    return (
      <aside
        aria-label="KORA Holographic Capsule"
        className="fixed bottom-6 right-6 z-50 flex items-center gap-3 p-2.5 rounded-full bg-zinc-950/90 border border-cyan-500/50 shadow-[0_0_30px_rgba(6,182,212,0.4)] backdrop-blur-md transition-all duration-300 hover:scale-105"
      >
        <button
          onClick={triggerMinimize}
          className="relative w-12 h-12 rounded-full overflow-hidden border-2 border-cyan-400 shadow-inner group"
          title="Click to Maximize KORA Holographic HUD"
          aria-label="Maximize KORA Holographic HUD"
        >
          <img
            src="/kora_avatar.jpg"
            alt="KORA Avatar"
            className="w-full h-full object-cover object-top"
          />
          <span className="absolute inset-0 bg-cyan-500/20 group-hover:bg-transparent transition-colors" />
          <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-400 border border-zinc-950 animate-ping" />
        </button>

        <div className="flex flex-col pr-2 font-mono">
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-black text-cyan-300 tracking-wider">KORA 8.8.5</span>
            <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-500/30 font-bold">
              {healthScore}%
            </span>
          </div>
          <span className="text-[10px] text-zinc-400">{hudState} • Tap to expand</span>
        </div>

        <button
          onClick={triggerMinimize}
          className="p-1.5 rounded-full bg-zinc-900 hover:bg-zinc-800 text-cyan-400 transition-colors"
          title="Expand Fullscreen HUD"
          aria-label="Expand Fullscreen HUD"
        >
          <Maximize2 className="w-4 h-4" />
        </button>
      </aside>
    );
  }

  // ==========================================
  // FULLSCREEN HOLOGRAPHIC JARVIS HUD
  // ==========================================
  return (
    <div
      ref={containerRef}
      className={`relative w-full overflow-x-hidden flex flex-col font-sans transition-all duration-300 select-none ${
        isFullscreen
          ? 'fixed inset-0 z-50 overflow-y-auto bg-[#030712] min-h-screen'
          : 'rounded-3xl border border-cyan-500/40 bg-[#030712] min-h-[820px] shadow-[0_0_50px_rgba(6,182,212,0.25)] mb-6'
      }`}
      style={{
        paddingTop: isFullscreen ? 'max(1rem, env(safe-area-inset-top))' : '1rem',
        paddingBottom: isFullscreen ? 'max(1rem, env(safe-area-inset-bottom))' : '1.5rem',
      }}
    >
      {/* 1. PHOTOREALISTIC HOLOGRAPHIC AI FEMALE AVATAR BACKGROUND */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <img
          src="/kora_avatar.jpg"
          alt="KORA Holographic Avatar"
          className="w-full h-full object-cover object-top opacity-35 filter brightness-110 contrast-125"
        />
        {/* Futuristic Cyber Overlay Gradients & Grid Scanlines */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#030712]/80 via-transparent to-[#030712] opacity-90" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-cyan-900/30 via-transparent to-transparent" />
        <div className="absolute inset-0 bg-[linear-gradient(to_bottom,transparent_50%,rgba(6,182,212,0.03)_51%)] bg-[length:100%_4px]" />
      </div>

      <div className="relative z-10 flex flex-col flex-1 px-4 md:px-8 max-w-5xl mx-auto w-full">
        {/* 2. TOP STATUS BAR (Matching image: KORA HUD ● LIVE KILCRITIC 8.8.5, time, wifi, battery) */}
        <div className="w-full p-3.5 rounded-2xl bg-zinc-950/70 border border-cyan-500/40 backdrop-blur-md shadow-[0_0_20px_rgba(6,182,212,0.15)] flex items-center justify-between gap-3 text-zinc-100 font-mono">
          <div className="flex items-center gap-2">
            <span className="text-base md:text-lg font-black tracking-wider text-cyan-400">
              KORA HUD
            </span>
            <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/40">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              LIVE
            </span>
            <span className="text-xs text-zinc-400 hidden sm:inline">KILCRITIC 8.8.5</span>
          </div>

          {/* Time, Connectivity, and Window Controls */}
          <div className="flex items-center gap-3 text-xs text-zinc-300">
            <span className="font-bold text-zinc-200">{currentTime || '14:22'}</span>
            <Wifi className="w-3.5 h-3.5 text-cyan-400" />
            <div className="flex items-center gap-1">
              <Battery className="w-4 h-4 text-emerald-400" />
              <span className="text-[10px]">61%</span>
            </div>

            {/* Minimize Button */}
            <button
              onClick={triggerMinimize}
              className="p-1.5 rounded-lg bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 transition-colors"
              title="Minimize to small floating capsule"
              aria-label="Minimize HUD"
            >
              <Minimize2 className="w-3.5 h-3.5" />
            </button>

            {/* Fullscreen Toggle */}
            <button
              onClick={toggleFullscreen}
              className="p-1.5 rounded-lg bg-zinc-900/80 hover:bg-zinc-800 border border-cyan-500/40 text-cyan-400 transition-colors"
              title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
              aria-label="Toggle Fullscreen"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 3. CATEGORY SELECTOR CHIPS (Access All 6 Categories & 59 Modules) */}
        <div className="flex items-center justify-between gap-2 py-3 overflow-x-auto scrollbar-none">
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
            {(['ALL', 'CORE', 'CREATOR', 'AUTOPILOT', 'DISCOVERY', 'SOCIAL', 'SYSTEM'] as const).map(
              (cat) => (
                <button
                  key={cat}
                  onClick={() => {
                    setActiveCategory(cat);
                    setSearchFilter('');
                  }}
                  className={`px-3 py-1 rounded-full text-xs font-mono font-bold transition-all whitespace-nowrap backdrop-blur-sm ${
                    activeCategory === cat
                      ? 'bg-cyan-500 text-zinc-950 shadow-[0_0_15px_rgba(6,182,212,0.6)] font-black'
                      : 'bg-zinc-950/60 text-zinc-400 border border-zinc-800/80 hover:border-cyan-500/40 hover:text-cyan-300'
                  }`}
                >
                  {cat}
                </button>
              )
            )}
          </div>

          {activeCategory !== 'ALL' && (
            <div className="relative w-40 shrink-0">
              <Search className="w-3 h-3 text-zinc-500 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Search..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="w-full pl-7 pr-2 py-1 rounded-lg bg-zinc-950 border border-zinc-800 text-zinc-200 text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>
          )}
        </div>

        {/* 4. CONTENT CARDS (ALL = 8 Reference Cards | Category = Submodules) */}
        {activeCategory === 'ALL' ? (
          <div className="grid grid-cols-2 md:grid-cols-2 gap-3.5 my-2 flex-1">
            {PRIMARY_HUD_CARDS.map((card) => (
              <div
                key={card.id}
                onClick={card.action}
                className="group relative p-4 rounded-2xl bg-zinc-950/40 hover:bg-zinc-900/50 border border-cyan-500/30 hover:border-cyan-400 transition-all duration-300 backdrop-blur-md cursor-pointer flex flex-col items-center justify-center text-center shadow-[0_0_20px_rgba(6,182,212,0.1)] hover:shadow-[0_0_30px_rgba(6,182,212,0.35)] hover:-translate-y-0.5"
              >
                <div className="mb-2.5 p-3 rounded-2xl bg-cyan-950/50 border border-cyan-500/40 group-hover:scale-110 transition-transform shadow-[0_0_15px_rgba(6,182,212,0.3)]">
                  {card.icon}
                </div>
                <h3 className="font-extrabold text-sm md:text-base text-zinc-100 group-hover:text-cyan-300 transition-colors tracking-wide">
                  {card.title}
                </h3>
                <p className="text-xs text-cyan-400/90 font-mono mt-0.5">{card.sub}</p>
                <span className="absolute top-2.5 right-2.5 text-[8px] font-mono font-bold px-1.5 py-0.5 rounded bg-zinc-900/80 text-zinc-400 border border-zinc-800">
                  {card.tag}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 my-2 flex-1 max-h-[460px] overflow-y-auto pr-1">
            {getFilteredCategoryModules().map((mod) => (
              <div
                key={mod.id}
                onClick={() => {
                  if (mod.tabTarget) {
                    onNavigateTab(mod.tabTarget);
                  } else {
                    setActiveModalItem(mod);
                  }
                }}
                className="p-3.5 rounded-2xl bg-zinc-950/70 hover:bg-zinc-900/70 border border-zinc-800/80 hover:border-cyan-400/60 transition-all cursor-pointer backdrop-blur-md flex items-start gap-3 group"
              >
                <div className="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 shrink-0 group-hover:scale-105 transition-transform">
                  {mod.icon}
                </div>
                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-xs text-zinc-200 truncate group-hover:text-cyan-300 transition-colors">
                      {mod.name}
                    </h4>
                    <span
                      className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded ${
                        mod.status === 'ONLINE'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                          : mod.status === 'HARDENED'
                          ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/30'
                          : 'bg-zinc-900 text-zinc-400 border border-zinc-800'
                      }`}
                    >
                      {mod.status}
                    </span>
                  </div>
                  <p className="text-[10px] text-zinc-400 line-clamp-2 leading-relaxed">
                    {mod.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 5. "How can I help you today?" INTERACTIVE PROMPT BAR */}
        <form onSubmit={handleInputSubmit} className="relative mt-2 mb-3 w-full">
          <div className="relative flex items-center">
            <input
              type="text"
              placeholder="How can I help you today?"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="w-full py-3.5 pl-5 pr-28 rounded-2xl bg-zinc-950/70 border border-cyan-500/50 text-zinc-100 placeholder-zinc-400 text-sm md:text-base font-sans backdrop-blur-md shadow-[0_0_25px_rgba(6,182,212,0.2)] focus:outline-none focus:border-cyan-400 focus:shadow-[0_0_35px_rgba(6,182,212,0.4)] transition-all"
            />
            <div className="absolute right-2 flex items-center gap-1.5">
              <button
                type="button"
                onClick={handleVoiceClick}
                className="p-2 rounded-xl bg-cyan-950/70 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-300 transition-colors"
                title="Activate Voice Input"
                aria-label="Voice input"
              >
                <Mic className="w-4 h-4" />
              </button>
              <button
                type="submit"
                className="p-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-zinc-950 font-bold transition-all shadow-md"
                title="Execute instruction"
                aria-label="Send command"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </form>

        {/* 6. BOTTOM ACTION DOCK (Backup, Doctor Heal, Subtitles, Voice - Matching image) */}
        <div className="w-full p-2.5 rounded-2xl bg-zinc-950/80 border border-cyan-500/40 backdrop-blur-md shadow-[0_0_25px_rgba(6,182,212,0.15)] flex items-center justify-around gap-2 text-zinc-300 font-mono">
          {/* Backup */}
          <button
            onClick={() => {
              onTriggerBackup();
              addLog('Backup button tapped: Creating verified SQLite snapshot...');
            }}
            className="flex-1 py-2 px-1 rounded-xl hover:bg-cyan-950/40 flex flex-col items-center justify-center gap-1 transition-all group"
          >
            <HardDrive className="w-5 h-5 text-cyan-400 group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-bold text-zinc-200 group-hover:text-cyan-300">
              Backup
            </span>
          </button>

          {/* Doctor Heal */}
          <button
            onClick={() => {
              onRunDiagnostics();
              addLog('Doctor Heal tapped: Running real diagnostic sweep & healing...');
            }}
            className="flex-1 py-2 px-1 rounded-xl hover:bg-cyan-950/40 flex flex-col items-center justify-center gap-1 transition-all group"
          >
            <HeartPulse className="w-5 h-5 text-rose-400 group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-bold text-zinc-200 group-hover:text-rose-300">
              Doctor Heal
            </span>
          </button>

          {/* Subtitles */}
          <button
            onClick={() => {
              setActiveModalItem({
                id: 'subtitles_dock',
                name: 'FFprobe Subtitle Burner',
                category: 'CREATOR',
                status: 'HARDENED',
                icon: <Subtitles className="w-5 h-5 text-amber-400" />,
                desc: 'ffprobe duration-bounded subtitle burner. Strictly validates 0 <= start < end <= duration. Font size bounded (10-72).',
              });
              addLog('Subtitles tapped: Opening ffprobe subtitle burner matrix.');
            }}
            className="flex-1 py-2 px-1 rounded-xl hover:bg-cyan-950/40 flex flex-col items-center justify-center gap-1 transition-all group"
          >
            <Subtitles className="w-5 h-5 text-amber-400 group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-bold text-zinc-200 group-hover:text-amber-300">
              Subtitles
            </span>
          </button>

          {/* Voice */}
          <button
            onClick={handleVoiceClick}
            className="flex-1 py-2 px-1 rounded-xl hover:bg-cyan-950/40 flex flex-col items-center justify-center gap-1 transition-all group"
          >
            <Mic className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-bold text-zinc-200 group-hover:text-emerald-300">
              Voice
            </span>
          </button>
        </div>

        {/* Live telemetry console output at the bottom */}
        {systemLogs.length > 0 && (
          <div className="mt-2 p-2 rounded-xl bg-zinc-950/80 border border-zinc-800 text-[10px] font-mono text-cyan-400/90 truncate flex items-center justify-between">
            <span className="truncate">{systemLogs[0]}</span>
            <span className="text-zinc-500 ml-2 shrink-0">{hudState}</span>
          </div>
        )}
      </div>

      {/* ==========================================
          INTERACTIVE POPUP / DETAIL MODAL
         ========================================== */}
      {activeModalItem && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-2xl bg-zinc-950 border border-cyan-500/40 p-5 space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-zinc-900 border border-zinc-800">
                  {activeModalItem.icon}
                </div>
                <div>
                  <h3 className="font-bold text-sm text-zinc-100 uppercase tracking-wide">
                    {activeModalItem.name}
                  </h3>
                  <span className="text-[10px] text-zinc-500 font-mono">
                    CATEGORY: {activeModalItem.category}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setActiveModalItem(null)}
                className="p-1 rounded-lg hover:bg-zinc-900 text-zinc-400 hover:text-zinc-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Truthful Status Card */}
            <div className="space-y-3 text-xs font-mono">
              <div className="p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-zinc-500">OPERATIONAL STATUS:</span>
                  <span
                    className={`font-bold ${
                      activeModalItem.status === 'ONLINE'
                        ? 'text-emerald-400'
                        : activeModalItem.status === 'HARDENED'
                        ? 'text-cyan-400'
                        : 'text-amber-400'
                    }`}
                  >
                    {activeModalItem.status}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-zinc-500">AUTHORITY:</span>
                  <span className="text-zinc-300">SQLite WAL Master</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-zinc-500">HUMAN APPROVAL GATE:</span>
                  <span className="text-emerald-400 font-bold">MANDATORY</span>
                </div>
              </div>

              <p className="text-zinc-400 text-xs font-sans leading-relaxed">
                {activeModalItem.desc}
              </p>

              {/* Special Notes Section */}
              {activeModalItem.id === 'notes_modal' && (
                <div className="space-y-2 pt-2 border-t border-zinc-800">
                  <div className="space-y-1 max-h-36 overflow-y-auto">
                    {notesList.map((n, i) => (
                      <div key={i} className="p-2 rounded bg-zinc-900 text-zinc-300 text-[11px]">
                        {n}
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="text"
                      placeholder="Add note..."
                      value={newNote}
                      onChange={(e) => setNewNote(e.target.value)}
                      className="flex-1 py-1 px-2.5 rounded bg-zinc-900 border border-zinc-700 text-xs text-zinc-200"
                    />
                    <button
                      onClick={handleAddNote}
                      className="py-1 px-3 rounded bg-cyan-600 hover:bg-cyan-500 text-zinc-950 font-bold text-xs"
                    >
                      Add
                    </button>
                  </div>
                </div>
              )}

              <div className="flex items-center gap-2 pt-3 border-t border-zinc-800">
                {activeModalItem.tabTarget ? (
                  <button
                    onClick={() => {
                      onNavigateTab(activeModalItem.tabTarget!);
                      setActiveModalItem(null);
                    }}
                    className="flex-1 py-2 px-3 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-zinc-950 font-bold text-xs transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span>OPEN MODULE TAB</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      addLog(`Executed verification on ${activeModalItem.name}`);
                      setActiveModalItem(null);
                    }}
                    className="flex-1 py-2 px-3 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-zinc-950 font-bold text-xs transition-colors"
                  >
                    RUN VERIFICATION PROBE
                  </button>
                )}
                <button
                  onClick={() => setActiveModalItem(null)}
                  className="py-2 px-4 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 text-xs transition-colors"
                >
                  DISMISS
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
