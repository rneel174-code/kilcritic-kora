import React, { useMemo, useState } from 'react';
import {
  FolderOpen, Youtube, Instagram, Facebook, Music2, Twitter, Film, Scissors, Baby,
  Video, Image as ImageIcon, BookOpen, Layers3, Send, CalendarClock, MessageCircle,
  TrendingUp, Search, Sparkles, ArrowLeft, Camera, Palette, Mic, Globe2, ShoppingBag,
  Bot, WandSparkles, Megaphone, X, PlayCircle, Type, MousePointer2
} from 'lucide-react';

interface HubProps { onAdvanced: () => void; }
type Mode = 'touch' | 'voice' | 'text';
type Item = { id:string; label:string; icon:React.ReactNode; desc:string; group:string };

const ITEMS: Item[] = [
  {id:'youtube',label:'YouTube',icon:<Youtube/>,desc:'Video + Shorts',group:'social'},
  {id:'facebook',label:'Facebook',icon:<Facebook/>,desc:'Video + Photos',group:'social'},
  {id:'instagram',label:'Instagram',icon:<Instagram/>,desc:'Reels + Stories',group:'social'},
  {id:'tiktok',label:'TikTok',icon:<Music2/>,desc:'Short Video',group:'social'},
  {id:'x',label:'X',icon:<Twitter/>,desc:'Posts + Media',group:'social'},
  {id:'amazon',label:'Amazon',icon:<ShoppingBag/>,desc:'Offers + Affiliate',group:'business'},
  {id:'hollywood',label:'Hollywood Studio',icon:<Film/>,desc:'Cinematic Studio',group:'studio'},
  {id:'editing',label:'Editing',icon:<Scissors/>,desc:'Video + Photo Edit',group:'studio'},
  {id:'cartoon',label:'Cartoon',icon:<Palette/>,desc:'Animation',group:'studio'},
  {id:'funny_baby',label:'Funny Baby',icon:<Baby/>,desc:'Child-safe original',group:'studio'},
  {id:'funny_video',label:'Funny Videos',icon:<PlayCircle/>,desc:'Original comedy',group:'studio'},
  {id:'videos',label:'Videos',icon:<Video/>,desc:'Create + Edit',group:'studio'},
  {id:'photos',label:'Photos',icon:<Camera/>,desc:'Create + Edit',group:'studio'},
  {id:'stories',label:'Stories',icon:<BookOpen/>,desc:'Story creation',group:'studio'},
  {id:'wallpapers',label:'Wallpapers',icon:<Layers3/>,desc:'Phone + Desktop',group:'studio'},
  {id:'voice_text',label:'Voice + Text',icon:<Mic/>,desc:'Control + Script',group:'studio'},
  {id:'post',label:'POST',icon:<Send/>,desc:'Approve + Publish',group:'publish'},
  {id:'autopilot30',label:'30-Day Autopilot',icon:<CalendarClock/>,desc:'Plan + Schedule',group:'publish'},
  {id:'comments',label:'Comments',icon:<MessageCircle/>,desc:'Reply + Moderate',group:'growth'},
  {id:'growth',label:'Growth',icon:<TrendingUp/>,desc:'Analytics + Learn',group:'growth'},
  {id:'research',label:'Research',icon:<Search/>,desc:'World Search + Evidence',group:'research'},
  {id:'search',label:'Searching',icon:<Globe2/>,desc:'Web + Media Search',group:'research'},
  {id:'dhanda',label:'Amazon Dhanda',icon:<Sparkles/>,desc:'Opportunity Radar',group:'business'},
  {id:'autopilot',label:'Autopilot Mode',icon:<Bot/>,desc:'Approved automation',group:'publish'},
];

const FACE = '/src/assets/images/kora_hologram_avatar_1790983636132.jpg';

export const MediaSocialStudioHub: React.FC<HubProps> = ({onAdvanced}) => {
  const [open,setOpen] = useState(false);
  const [selected,setSelected] = useState<Item|null>(null);
  const [mode,setMode] = useState<Mode>('touch');
  const [region,setRegion] = useState<'IN'|'US'|'CA'>('IN');
  const [connected,setConnected] = useState<Record<string,boolean>>({});

  const orbitItems = useMemo(() => ITEMS, []);
  const openItem = (item:Item) => setSelected(item);

  if (selected) return (
    <section className="relative min-h-[calc(100vh-2rem)] overflow-hidden rounded-[2.5rem] border border-white/15 bg-white/[0.035] backdrop-blur-3xl p-4 md:p-8">
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,rgba(34,211,238,.10),transparent_48%)]"/>
      <div className="relative flex items-center justify-between gap-3 mb-4">
        <button onClick={()=>setSelected(null)} className="rounded-2xl border border-white/10 bg-white/[0.05] px-4 py-2 text-xs font-bold text-zinc-300 hover:text-white"><ArrowLeft className="inline w-4 h-4 mr-2"/>Back</button>
        <button onClick={()=>setSelected(null)} aria-label="Close" className="rounded-xl border border-white/10 p-2 text-zinc-400"><X className="w-4 h-4"/></button>
      </div>
      <div className="relative min-h-[calc(100vh-9rem)] flex items-center justify-center">
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-[min(70vw,760px)] h-[min(70vw,760px)] rounded-full border border-cyan-300/10"/>
        </div>
        <div className="relative w-full max-w-6xl min-h-[620px] flex items-center justify-center">
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-20 text-center">
            <div className="mx-auto w-40 h-40 md:w-56 md:h-56 rounded-full border border-cyan-300/40 bg-white/[0.07] backdrop-blur-2xl overflow-hidden shadow-[0_0_100px_rgba(34,211,238,.2)]">
              <img src={FACE} alt="KORA face" className="w-full h-full object-cover"/>
            </div>
            <div className="mt-4 text-2xl md:text-3xl font-black">{selected.label}</div>
            <div className="text-xs text-zinc-500 mt-1">{selected.desc}</div>
            <div className="mt-4 flex justify-center gap-2">
              {(['touch','voice','text'] as Mode[]).map(m=><button key={m} onClick={()=>setMode(m)} className={`rounded-xl border px-3 py-2 text-xs font-bold capitalize ${mode===m?'border-cyan-300/60 bg-cyan-300/15 text-cyan-200':'border-white/10 bg-white/[.03] text-zinc-500'}`}>{m}</button>)}
            </div>
          </div>
          <div className="absolute inset-0">
            {orbitItems.slice(0,16).map((item,i)=>{
              const a=(i/16)*Math.PI*2-Math.PI/2;
              const x=50+Math.cos(a)*43, y=50+Math.sin(a)*43;
              return <button key={item.id} onClick={()=>openItem(item)} style={{left:`${x}%`,top:`${y}%`}} className="absolute -translate-x-1/2 -translate-y-1/2 w-24 md:w-32 rounded-2xl border border-white/15 bg-white/[.055] backdrop-blur-xl p-2 text-center shadow-xl hover:border-cyan-300/50 hover:bg-cyan-300/10 transition-all">
                <div className="mx-auto w-8 h-8 rounded-xl bg-white/[.06] flex items-center justify-center text-cyan-200">{React.cloneElement(item.icon as React.ReactElement,{className:'w-4 h-4'})}</div>
                <div className="mt-1 text-[9px] md:text-[10px] font-bold text-zinc-200 leading-tight">{item.label}</div>
              </button>
            })}
          </div>
        </div>
      </div>
    </section>
  );

  return (
    <section className="relative min-h-[calc(100vh-2rem)] overflow-hidden rounded-[3rem] border border-white/15 bg-white/[0.025] backdrop-blur-3xl">
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,rgba(34,211,238,.09),transparent_45%)]"/>
      <div className="relative min-h-[calc(100vh-2rem)] flex items-center justify-center p-4 md:p-8">
        <div className="relative w-full max-w-6xl aspect-square md:aspect-[1.35/1]">
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
            <button onClick={()=>setOpen(true)} aria-label="Open Media Social Studio folder" className="relative w-44 h-36 md:w-64 md:h-52 rounded-[2rem] border border-cyan-200/30 bg-white/[.07] backdrop-blur-2xl shadow-[0_0_100px_rgba(34,211,238,.18)] hover:border-cyan-200/70 transition-all">
              <FolderOpen className="absolute left-1/2 top-5 -translate-x-1/2 w-16 h-16 md:w-20 md:h-20 text-cyan-200/80" strokeWidth={1.2}/>
              <img src={FACE} alt="KORA face" className="absolute left-1/2 top-7 -translate-x-1/2 w-11 h-11 md:w-14 md:h-14 rounded-full object-cover border border-white/30"/>
              <div className="absolute inset-x-2 bottom-4 text-center"><div className="text-xs md:text-sm font-black tracking-wider">MEDIA + SOCIAL + STUDIO</div><div className="text-[9px] text-cyan-200/70 mt-1">OPEN CREATOR FOLDER</div></div>
            </button>
          </div>
          {orbitItems.map((item,i)=>{
            const a=(i/orbitItems.length)*Math.PI*2-Math.PI/2;
            const x=50+Math.cos(a)*43, y=50+Math.sin(a)*43;
            return <button key={item.id} onClick={()=>openItem(item)} style={{left:`${x}%`,top:`${y}%`}} className="absolute -translate-x-1/2 -translate-y-1/2 w-[82px] md:w-[112px] rounded-2xl border border-white/15 bg-white/[.045] backdrop-blur-xl p-2 text-center shadow-lg hover:border-cyan-300/50 hover:bg-cyan-300/10 transition-all">
              <div className="mx-auto w-8 h-8 rounded-xl bg-white/[.05] flex items-center justify-center text-cyan-200">{React.cloneElement(item.icon as React.ReactElement,{className:'w-4 h-4'})}</div>
              <div className="mt-1 text-[8px] md:text-[10px] font-bold text-zinc-200 leading-tight">{item.label}</div>
            </button>
          })}
        </div>
      </div>
      <div className="absolute bottom-3 left-0 right-0 flex flex-wrap justify-center gap-2 px-3">
        <div className="rounded-full border border-white/10 bg-black/20 backdrop-blur-xl px-3 py-1.5 text-[10px] text-zinc-400"><MousePointer2 className="inline w-3 h-3 mr-1"/>Touch</div>
        <div className="rounded-full border border-white/10 bg-black/20 backdrop-blur-xl px-3 py-1.5 text-[10px] text-zinc-400"><Mic className="inline w-3 h-3 mr-1"/>Voice</div>
        <div className="rounded-full border border-white/10 bg-black/20 backdrop-blur-xl px-3 py-1.5 text-[10px] text-zinc-400"><Type className="inline w-3 h-3 mr-1"/>Text</div>
        <div className="rounded-full border border-white/10 bg-black/20 backdrop-blur-xl px-3 py-1.5 text-[10px] text-cyan-200">Region: {region}</div>
        <button onClick={()=>setRegion(region==='IN'?'US':region==='US'?'CA':'IN')} className="rounded-full border border-white/10 bg-black/20 backdrop-blur-xl px-3 py-1.5 text-[10px] text-zinc-400">Change region</button>
        <button onClick={onAdvanced} className="rounded-full border border-white/10 bg-black/20 backdrop-blur-xl px-3 py-1.5 text-[10px] text-zinc-500 hover:text-white">Advanced</button>
      </div>
    </section>
  );
};
