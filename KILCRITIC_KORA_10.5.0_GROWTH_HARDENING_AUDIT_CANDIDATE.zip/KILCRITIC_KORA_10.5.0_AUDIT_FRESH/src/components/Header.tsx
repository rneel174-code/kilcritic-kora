import React from 'react';
import {
  Cpu,
  Settings2,
} from 'lucide-react';
import { NetworkMode } from '../services/offlineQueue';

interface HeaderProps {
  healthScore: number;
  networkMode: NetworkMode;
  onSetNetworkMode: (mode: NetworkMode) => void;
  testPassedCount: number;
  testTotalCount: number;
  isTesting: boolean;
  onRunTests: () => void;
  onRunDiagnostics: () => void;
  onTriggerBackup: () => void;
  activeTab: string;
  onAdvanced: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  healthScore,
  networkMode,
  onSetNetworkMode,
  testPassedCount,
  testTotalCount,
  isTesting,
  onRunTests,
  onRunDiagnostics,
  onTriggerBackup,
  onAdvanced,
}) => {
  const allTestsPassed = testPassedCount === testTotalCount && testTotalCount > 0;

  return (
    <header className="border-b border-zinc-800 bg-[#090d16]/95 backdrop-blur sticky top-0 z-50 px-4 py-3 text-zinc-100 shadow-xl">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-400">
            <Cpu className="w-5 h-5 animate-pulse" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping" />
          </div>
          <div className="min-w-0">
            <h1 className="text-base md:text-lg font-black tracking-widest text-zinc-100 uppercase font-mono truncate">
              KILCRITIC <span className="text-emerald-400">SUPREME</span>
            </h1>
            <div className="text-[10px] md:text-xs text-zinc-500 font-mono">MEDIA + SOCIAL + STUDIO • CREATOR DASHBOARD</div>
          </div>
        </div>
        <button onClick={onAdvanced} className="shrink-0 flex items-center gap-2 px-3 py-2 rounded-xl border border-zinc-700 bg-zinc-900/70 text-xs font-semibold text-zinc-400 hover:text-zinc-100 hover:border-zinc-600 transition-all">
          <Settings2 className="w-4 h-4" />
          <span>Advanced</span>
        </button>
      </div>
    </header>
  );
};
