import React, { useState } from 'react';
import {
  Network,
  Wifi,
  WifiOff,
  CloudLightning,
  RefreshCw,
  Send,
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Trash2,
  Key,
} from 'lucide-react';
import { QueueItem, ServiceName } from '../services/types';
import { NetworkMode } from '../services/offlineQueue';

interface OfflineQueueTabProps {
  queue: QueueItem[];
  networkMode: NetworkMode;
  onSetNetworkMode: (mode: NetworkMode) => void;
  onEnqueue: (
    targetService: ServiceName,
    action: string,
    payload: any,
    idempotencyKey?: string,
    priority?: QueueItem['priority']
  ) => { item?: QueueItem; rejected: boolean; reason?: string };
  onFlushQueue: () => Promise<{ synced: number; failed: number }>;
  onClearSynced: () => void;
}

export const OfflineQueueTab: React.FC<OfflineQueueTabProps> = ({
  queue,
  networkMode,
  onSetNetworkMode,
  onEnqueue,
  onFlushQueue,
  onClearSynced,
}) => {
  const [targetService, setTargetService] = useState<ServiceName>('voice_transcription');
  const [actionName, setActionName] = useState('SYNC_OFFLINE_AUDIO_RECORD');
  const [idempotencyKey, setIdempotencyKey] = useState(`idem-${Date.now().toString().slice(-6)}`);
  const [priority, setPriority] = useState<QueueItem['priority']>('NORMAL');
  const [enqueueFeedback, setEnqueueFeedback] = useState<{ success: boolean; msg: string } | null>(null);
  const [isFlushing, setIsFlushing] = useState(false);

  const handleEnqueue = (e: React.FormEvent) => {
    e.preventDefault();
    const res = onEnqueue(
      targetService,
      actionName,
      { source: 'offline_queue_tab', timestamp: Date.now() },
      idempotencyKey,
      priority
    );

    if (res.rejected) {
      setEnqueueFeedback({
        success: false,
        msg: res.reason || 'Idempotency violation rejected duplicate token.',
      });
    } else {
      setEnqueueFeedback({
        success: true,
        msg: `Successfully enqueued mutation '${res.item?.id}' into resilient queue.`,
      });
      // generate a new key for convenience
      setIdempotencyKey(`idem-${(Date.now() + 10).toString().slice(-6)}`);
    }

    setTimeout(() => setEnqueueFeedback(null), 5000);
  };

  const handleFlush = async () => {
    setIsFlushing(true);
    const res = await onFlushQueue();
    setIsFlushing(false);
    setEnqueueFeedback({
      success: true,
      msg: `Batch flush executed: ${res.synced} items synced, ${res.failed} failures.`,
    });
    setTimeout(() => setEnqueueFeedback(null), 4000);
  };

  const pendingCount = queue.filter((q) => q.state === 'QUEUED' || q.state === 'PROCESSING').length;
  const syncedCount = queue.filter((q) => q.state === 'SYNCED').length;
  const failedCount = queue.filter((q) => q.state === 'FAILED').length;

  return (
    <div className="space-y-6">
      {/* Top Banner: Network Mode & Connectivity Switch */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-zinc-900 via-zinc-900 to-teal-950/20 border border-teal-500/30 space-y-4 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-lg bg-teal-950/60 border border-teal-500/40 text-teal-400">
              <Network className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-mono font-bold text-base text-zinc-100 uppercase tracking-wider">
                  Offline-First Resilient Queue & Idempotency Barrier
                </h3>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-teal-500/20 text-teal-300 border border-teal-500/40">
                  GUARANTEED EXACTLY-ONCE
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Mutations are buffered locally in persistent memory during network disconnects and flushed with exponential backoff upon reconnect.
              </p>
            </div>
          </div>

          {/* Network Switch Controls */}
          <div className="flex items-center gap-2 p-1 rounded-lg bg-zinc-950 border border-zinc-800 text-xs font-mono">
            <button
              onClick={() => onSetNetworkMode('ONLINE')}
              className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 transition-all font-bold ${
                networkMode === 'ONLINE'
                  ? 'bg-emerald-600 text-zinc-950 shadow-md'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Wifi className="w-3.5 h-3.5" />
              <span>ONLINE</span>
            </button>
            <button
              onClick={() => onSetNetworkMode('FLAKY')}
              className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 transition-all font-bold ${
                networkMode === 'FLAKY'
                  ? 'bg-amber-600 text-zinc-950 shadow-md'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <CloudLightning className="w-3.5 h-3.5" />
              <span>FLAKY 3G</span>
            </button>
            <button
              onClick={() => onSetNetworkMode('OFFLINE')}
              className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 transition-all font-bold ${
                networkMode === 'OFFLINE'
                  ? 'bg-rose-600 text-zinc-100 shadow-md'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <WifiOff className="w-3.5 h-3.5" />
              <span>OFFLINE</span>
            </button>
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2">
          <div className="p-3 rounded-lg bg-zinc-950/80 border border-zinc-800">
            <span className="text-[10px] font-mono text-zinc-500 uppercase block">Queue Buffer State</span>
            <span
              className={`text-2xl font-mono font-bold ${
                networkMode === 'ONLINE'
                  ? 'text-emerald-400'
                  : networkMode === 'FLAKY'
                  ? 'text-amber-400'
                  : 'text-rose-400'
              }`}
            >
              {networkMode}
            </span>
          </div>

          <div className="p-3 rounded-lg bg-zinc-950/80 border border-zinc-800">
            <span className="text-[10px] font-mono text-zinc-500 uppercase block">Pending In Queue</span>
            <span className={`text-2xl font-mono font-bold ${pendingCount > 0 ? 'text-amber-400' : 'text-zinc-300'}`}>
              {pendingCount} items
            </span>
          </div>

          <div className="p-3 rounded-lg bg-zinc-950/80 border border-zinc-800">
            <span className="text-[10px] font-mono text-zinc-500 uppercase block">Successfully Synced</span>
            <span className="text-2xl font-mono font-bold text-emerald-400">{syncedCount} items</span>
          </div>

          <div className="p-3 rounded-lg bg-zinc-950/80 border border-zinc-800">
            <span className="text-[10px] font-mono text-zinc-500 uppercase block">Transient Errors</span>
            <span className={`text-2xl font-mono font-bold ${failedCount > 0 ? 'text-rose-400' : 'text-zinc-400'}`}>
              {failedCount} items
            </span>
          </div>
        </div>
      </div>

      {/* Feedback Banner */}
      {enqueueFeedback && (
        <div
          className={`p-3.5 rounded-lg border text-xs font-mono flex items-center gap-2 ${
            enqueueFeedback.success
              ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
              : 'bg-rose-950/60 border-rose-500/40 text-rose-300'
          }`}
        >
          {enqueueFeedback.success ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
          )}
          <span>{enqueueFeedback.msg}</span>
        </div>
      )}

      {/* Two Column Grid: Enqueue Form & Live Queue Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Dispatch Mutation with Idempotency Key */}
        <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-4">
          <div className="flex items-center gap-2">
            <Send className="w-4 h-4 text-teal-400" />
            <h4 className="font-mono font-bold text-sm text-zinc-200 uppercase">
              Enqueue Mutation Task
            </h4>
          </div>

          <form onSubmit={handleEnqueue} className="space-y-3">
            <div>
              <label className="text-[11px] font-mono text-zinc-400 block mb-1">Target Service</label>
              <select
                value={targetService}
                onChange={(e) => setTargetService(e.target.value as any)}
                className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-200 font-mono text-xs focus:outline-none focus:border-teal-500"
              >
                <option value="voice_transcription">voice_transcription</option>
                <option value="backup_service">backup_service</option>
                <option value="media_dedup">media_dedup</option>
                <option value="event_bus">event_bus</option>
                <option value="system_doctor">system_doctor</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-mono text-zinc-400 block mb-1">Action Name</label>
              <input
                type="text"
                value={actionName}
                onChange={(e) => setActionName(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-200 font-mono text-xs focus:outline-none focus:border-teal-500"
                required
              />
            </div>

            <div>
              <label className="text-[11px] font-mono text-zinc-400 block mb-1 flex items-center justify-between">
                <span>Idempotency Key</span>
                <span className="text-[10px] text-zinc-500">(Enforces duplicate prevention)</span>
              </label>
              <div className="flex items-center gap-1.5">
                <input
                  type="text"
                  value={idempotencyKey}
                  onChange={(e) => setIdempotencyKey(e.target.value)}
                  className="flex-1 px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-200 font-mono text-xs focus:outline-none focus:border-teal-500"
                  required
                />
                <button
                  type="button"
                  onClick={() => setIdempotencyKey(`idem-${Date.now().toString().slice(-6)}`)}
                  className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700"
                  title="Generate new idempotency key"
                >
                  <Key className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div>
              <label className="text-[11px] font-mono text-zinc-400 block mb-1">Queue Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as any)}
                className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-200 font-mono text-xs focus:outline-none focus:border-teal-500"
              >
                <option value="LOW">LOW</option>
                <option value="NORMAL">NORMAL</option>
                <option value="HIGH">HIGH</option>
                <option value="CRITICAL">CRITICAL</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full py-2 px-4 rounded-lg bg-teal-600 hover:bg-teal-500 text-zinc-950 font-mono font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md"
            >
              <Send className="w-3.5 h-3.5" />
              <span>ENQUEUE MUTATION</span>
            </button>
          </form>

          {/* Test note */}
          <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 text-[11px] font-mono text-zinc-400 space-y-1">
            <span className="text-zinc-300 font-bold block">Idempotency Validation Test:</span>
            <p>
              Click "ENQUEUE MUTATION" twice with the identical idempotency key to verify that the duplicate is strictly blocked.
            </p>
          </div>
        </div>

        {/* Right: Queue Item Inspector */}
        <div className="lg:col-span-2 p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Network className="w-4 h-4 text-teal-400" />
              <h4 className="font-mono font-bold text-sm text-zinc-200 uppercase">
                Offline Queue Pipeline ({queue.length} items)
              </h4>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleFlush}
                disabled={isFlushing || networkMode === 'OFFLINE'}
                className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 disabled:opacity-40 text-zinc-950 font-mono font-bold text-xs flex items-center gap-1.5 transition-all shadow-md"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isFlushing ? 'animate-spin' : ''}`} />
                <span>FLUSH QUEUE</span>
              </button>

              <button
                onClick={onClearSynced}
                className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 font-mono font-medium text-xs flex items-center gap-1.5 transition-all"
              >
                <Trash2 className="w-3.5 h-3.5 text-zinc-400" />
                <span>CLEAR SYNCED</span>
              </button>
            </div>
          </div>

          <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
            {queue.length === 0 ? (
              <div className="p-8 text-center text-zinc-500 text-xs font-mono">
                Queue is empty. All mutations settled and synchronized.
              </div>
            ) : (
              queue.map((item) => (
                <div
                  key={item.id}
                  className={`p-3 rounded-lg bg-zinc-950 border text-xs font-mono space-y-1.5 transition-colors ${
                    item.state === 'QUEUED'
                      ? 'border-amber-500/40 bg-amber-950/10'
                      : item.state === 'PROCESSING'
                      ? 'border-cyan-500/40 bg-cyan-950/10'
                      : item.state === 'FAILED'
                      ? 'border-rose-500/40 bg-rose-950/10'
                      : 'border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-zinc-100">{item.action}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400">
                        {item.targetService}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-teal-300">
                        {item.priority}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          item.state === 'SYNCED'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : item.state === 'QUEUED'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : item.state === 'PROCESSING'
                            ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                            : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {item.state}
                      </span>

                      <span className="text-[10px] text-zinc-500">
                        Att: {item.attempts}/{item.maxAttempts}
                      </span>
                    </div>
                  </div>

                  <div className="text-[11px] text-zinc-400 flex items-center justify-between">
                    <span>Key: <strong className="text-zinc-300">{item.idempotencyKey}</strong></span>
                    <span>{new Date(item.createdAt).toLocaleTimeString()}</span>
                  </div>

                  {item.errorMessage && (
                    <div className="p-1.5 rounded bg-rose-950/30 border border-rose-500/30 text-[10px] text-rose-300">
                      {item.errorMessage}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
