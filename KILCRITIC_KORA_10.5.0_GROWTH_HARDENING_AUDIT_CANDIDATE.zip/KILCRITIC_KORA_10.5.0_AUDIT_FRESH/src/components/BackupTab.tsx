import React, { useState } from 'react';
import {
  HardDrive,
  ShieldCheck,
  RotateCcw,
  Download,
  PlusCircle,
  FileCheck,
  AlertTriangle,
  Clock,
  Database,
  Trash2,
} from 'lucide-react';
import { BackupSnapshot } from '../services/types';

interface BackupTabProps {
  snapshots: BackupSnapshot[];
  onCreateSnapshot: (type: 'INCREMENTAL' | 'FULL') => Promise<void>;
  onVerifyIntegrity: (id: string) => Promise<boolean>;
  onRestore: (id: string) => Promise<{ success: boolean; message: string }>;
  onExportJSON: () => void;
  onPruneExpired: () => void;
}

export const BackupTab: React.FC<BackupTabProps> = ({
  snapshots,
  onCreateSnapshot,
  onVerifyIntegrity,
  onRestore,
  onExportJSON,
  onPruneExpired,
}) => {
  const [verifyingId, setVerifyingId] = useState<string | null>(null);
  const [restoringId, setRestoringId] = useState<string | null>(null);
  const [restoreMessage, setRestoreMessage] = useState<string | null>(null);

  const handleVerify = async (id: string) => {
    setVerifyingId(id);
    await onVerifyIntegrity(id);
    setVerifyingId(null);
  };

  const handleRestore = async (id: string) => {
    setRestoringId(id);
    const res = await onRestore(id);
    setRestoreMessage(res.message);
    setRestoringId(null);
    setTimeout(() => setRestoreMessage(null), 6000);
  };

  const totalBytes = snapshots.reduce((acc, s) => acc + s.sizeBytes, 0);

  return (
    <div className="space-y-6">
      {/* Top Metrics Banner */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
          <span className="text-[11px] font-mono text-zinc-400 uppercase block">Active Snapshots</span>
          <span className="text-2xl font-mono font-bold text-zinc-100">{snapshots.length}</span>
          <span className="text-[10px] text-zinc-500 font-mono block mt-1">Quota limit: 10 max</span>
        </div>

        <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
          <span className="text-[11px] font-mono text-zinc-400 uppercase block">Backup Storage</span>
          <span className="text-2xl font-mono font-bold text-emerald-400">
            {(totalBytes / 1024).toFixed(1)} KB
          </span>
          <span className="text-[10px] text-zinc-500 font-mono block mt-1">Compressed delta chunks</span>
        </div>

        <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
          <span className="text-[11px] font-mono text-zinc-400 uppercase block">Integrity State</span>
          <span className="text-2xl font-mono font-bold text-emerald-400 flex items-center gap-1.5">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            100% SHA-256
          </span>
          <span className="text-[10px] text-zinc-500 font-mono block mt-1">Zero bit-rot detected</span>
        </div>

        <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
          <span className="text-[11px] font-mono text-zinc-400 uppercase block">Cadence</span>
          <span className="text-2xl font-mono font-bold text-cyan-400">15m Auto</span>
          <span className="text-[10px] text-zinc-500 font-mono block mt-1">Automated scheduled cron</span>
        </div>
      </div>

      {/* Action Controls */}
      <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => onCreateSnapshot('INCREMENTAL')}
            className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-zinc-900 text-xs font-mono font-bold flex items-center gap-1.5 transition-all shadow-md"
          >
            <PlusCircle className="w-4 h-4" />
            <span>CREATE INCREMENTAL SNAPSHOT</span>
          </button>

          <button
            onClick={() => onCreateSnapshot('FULL')}
            className="px-3.5 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-mono font-semibold flex items-center gap-1.5 transition-all border border-zinc-700"
          >
            <Database className="w-4 h-4 text-emerald-400" />
            <span>FULL SYSTEM CHECKPOINT</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onPruneExpired}
            className="px-3 py-2 rounded-lg bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 text-xs font-mono font-medium flex items-center gap-1.5 transition-all border border-zinc-700"
          >
            <Trash2 className="w-3.5 h-3.5 text-zinc-400" />
            <span>ENFORCE RETENTION</span>
          </button>

          <button
            onClick={onExportJSON}
            className="px-3 py-2 rounded-lg bg-zinc-800/80 hover:bg-zinc-700 text-cyan-300 text-xs font-mono font-medium flex items-center gap-1.5 transition-all border border-zinc-700"
          >
            <Download className="w-3.5 h-3.5" />
            <span>EXPORT MANIFEST (JSON)</span>
          </button>
        </div>
      </div>

      {/* Restore feedback message */}
      {restoreMessage && (
        <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-mono flex items-center gap-2">
          <FileCheck className="w-4 h-4" />
          <span>{restoreMessage}</span>
        </div>
      )}

      {/* Snapshots Table */}
      <div className="rounded-xl bg-zinc-900/80 border border-zinc-800 overflow-hidden">
        <div className="p-3.5 border-b border-zinc-800 flex items-center justify-between">
          <h3 className="font-mono font-bold text-sm text-zinc-200 flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-emerald-400" />
            <span>Cryptographic Checkpoint Ledger</span>
          </h3>
          <span className="text-xs font-mono text-zinc-400">
            {snapshots.length} manifests recorded
          </span>
        </div>

        <div className="divide-y divide-zinc-800/60">
          {snapshots.map((snap) => (
            <div
              key={snap.id}
              className="p-4 hover:bg-zinc-950/40 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs font-mono"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-zinc-200">{snap.id}</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      snap.type === 'FULL'
                        ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                        : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                    }`}
                  >
                    {snap.type}
                  </span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      snap.status === 'VERIFIED'
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    }`}
                  >
                    {snap.status}
                  </span>
                </div>

                <div className="text-[11px] text-zinc-400 flex items-center gap-3">
                  <span>Size: {(snap.sizeBytes / 1024).toFixed(1)} KB</span>
                  <span>Records: {snap.recordCount}</span>
                  <span className="flex items-center gap-1 text-zinc-500">
                    <Clock className="w-3 h-3" />
                    {new Date(snap.timestamp).toLocaleString()}
                  </span>
                </div>

                <div className="text-[10px] text-zinc-500 font-mono flex items-center gap-1">
                  <span className="text-emerald-500/80">SHA-256:</span>
                  <span className="truncate max-w-md">{snap.checksum}</span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleVerify(snap.id)}
                  disabled={verifyingId === snap.id}
                  className="px-3 py-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 text-xs font-mono font-medium flex items-center gap-1.5 transition-colors"
                >
                  <FileCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{verifyingId === snap.id ? 'Auditing...' : 'Audit Checksum'}</span>
                </button>

                <button
                  onClick={() => handleRestore(snap.id)}
                  disabled={restoringId === snap.id}
                  className="px-3 py-1.5 rounded bg-emerald-950/60 hover:bg-emerald-900/80 text-emerald-300 border border-emerald-500/40 text-xs font-mono font-bold flex items-center gap-1.5 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{restoringId === snap.id ? 'Restoring...' : 'Restore'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
