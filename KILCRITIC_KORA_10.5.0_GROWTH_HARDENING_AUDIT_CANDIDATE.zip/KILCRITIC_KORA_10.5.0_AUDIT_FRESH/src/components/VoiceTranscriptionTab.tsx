import React, { useState, useEffect } from 'react';
import {
  Radio,
  Mic,
  MicOff,
  Volume2,
  Sparkles,
  Sliders,
  ShieldCheck,
  AlertTriangle,
  Play,
  Clock,
  UserCheck,
} from 'lucide-react';
import { AudioTranscript } from '../services/types';

interface VoiceTranscriptionTabProps {
  transcripts: AudioTranscript[];
  vadThreshold: number;
  onSetVadThreshold: (val: number) => void;
  onSimulateTransmission: () => Promise<AudioTranscript>;
  onProcessCustomText: (text: string, speaker: AudioTranscript['speaker']) => Promise<AudioTranscript>;
}

export const VoiceTranscriptionTab: React.FC<VoiceTranscriptionTabProps> = ({
  transcripts,
  vadThreshold,
  onSetVadThreshold,
  onSimulateTransmission,
  onProcessCustomText,
}) => {
  const [customText, setCustomText] = useState('');
  const [selectedSpeaker, setSelectedSpeaker] = useState<AudioTranscript['speaker']>('OPERATOR_1');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isLiveListening, setIsLiveListening] = useState(false);
  const [animatedBars, setAnimatedBars] = useState<number[]>([
    0.3, 0.6, 0.8, 0.4, 0.9, 0.7, 0.5, 0.2, 0.8, 0.6, 0.4, 0.7,
  ]);

  // Waveform animation pulse
  useEffect(() => {
    const timer = setInterval(() => {
      setAnimatedBars((prev) =>
        prev.map(() => Number((Math.random() * 0.75 + 0.15).toFixed(2)))
      );
    }, 180);
    return () => clearInterval(timer);
  }, []);

  const handleSimulate = async () => {
    setIsProcessing(true);
    await onSimulateTransmission();
    setIsProcessing(false);
  };

  const handleSubmitCustom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customText.trim()) return;
    setIsProcessing(true);
    await onProcessCustomText(customText, selectedSpeaker);
    setCustomText('');
    setIsProcessing(false);
  };

  return (
    <div className="space-y-6">
      {/* Waveform & VAD HUD Card */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-zinc-900 via-zinc-900 to-indigo-950/30 border border-indigo-500/30 space-y-4 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-indigo-400 animate-pulse" />
            <div>
              <h3 className="font-mono font-bold text-sm text-zinc-100 uppercase tracking-wider">
                Acoustic Signal Processing & Voice Activity Detection (VAD)
              </h3>
              <p className="text-xs text-zinc-400">
                Real-time spectral analysis, noise gating & speaker diarization model.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSimulate}
              disabled={isProcessing}
              className="px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-mono font-bold text-xs flex items-center gap-1.5 transition-all shadow-md"
            >
              <Play className="w-3.5 h-3.5" />
              <span>TRANSMIT AUDIO BUFFER</span>
            </button>

            <button
              onClick={() => setIsLiveListening(!isLiveListening)}
              className={`px-3 py-2 rounded-lg border font-mono text-xs font-semibold flex items-center gap-1.5 transition-all ${
                isLiveListening
                  ? 'bg-rose-950/60 border-rose-500/40 text-rose-300 animate-pulse'
                  : 'bg-zinc-800 hover:bg-zinc-700 border-zinc-700 text-zinc-300'
              }`}
            >
              {isLiveListening ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5" />}
              <span>{isLiveListening ? 'VAD LISTENING (ACTIVE)' : 'ENABLE MIC VAD'}</span>
            </button>
          </div>
        </div>

        {/* Live FFT Waveform Display */}
        <div className="p-4 rounded-lg bg-zinc-950/90 border border-zinc-800 flex items-center justify-between gap-4">
          <div className="flex items-end gap-1.5 h-14 flex-1">
            {animatedBars.map((height, idx) => (
              <div
                key={idx}
                className="flex-1 bg-gradient-to-t from-indigo-600 to-cyan-400 rounded-t transition-all duration-150"
                style={{ height: `${height * 100}%` }}
              />
            ))}
          </div>

          <div className="flex flex-col gap-2 shrink-0 border-l border-zinc-800 pl-4 text-xs font-mono">
            <div className="flex items-center justify-between gap-3">
              <span className="text-zinc-500">VAD GATE:</span>
              <span className="text-indigo-400 font-bold">{(vadThreshold * 100).toFixed(0)}%</span>
            </div>
            <div className="flex items-center justify-between gap-3">
              <span className="text-zinc-500">SAMPLING:</span>
              <span className="text-emerald-400 font-bold">48.0 kHz 24-bit</span>
            </div>
          </div>
        </div>

        {/* VAD Threshold Adjustment */}
        <div className="flex items-center gap-3 text-xs font-mono text-zinc-400">
          <Sliders className="w-4 h-4 text-zinc-500" />
          <span>VAD Energy Gate Floor:</span>
          <input
            type="range"
            min="0.1"
            max="0.9"
            step="0.05"
            value={vadThreshold}
            onChange={(e) => onSetVadThreshold(parseFloat(e.target.value))}
            className="flex-1 accent-indigo-500"
          />
          <span className="font-bold text-zinc-200">{(vadThreshold * 100).toFixed(0)}%</span>
        </div>
      </div>

      {/* Manual Transmission Ingest & Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Custom speech entry */}
        <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-4">
          <h4 className="font-mono font-bold text-sm text-zinc-200 uppercase flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-indigo-400" />
            <span>Simulate Tactical Audio Stream</span>
          </h4>

          <form onSubmit={handleSubmitCustom} className="space-y-3">
            <div>
              <label className="text-[11px] font-mono text-zinc-400 block mb-1">Speaker Tag</label>
              <select
                value={selectedSpeaker}
                onChange={(e) => setSelectedSpeaker(e.target.value as any)}
                className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-200 font-mono text-xs focus:outline-none focus:border-indigo-500"
              >
                <option value="OPERATOR_1">OPERATOR_1 (Field Ground)</option>
                <option value="TACTICAL_LEAD">TACTICAL_LEAD (Command)</option>
                <option value="KORA_CORE">KORA_CORE (Automated AI)</option>
                <option value="PILOT_ALPHA">PILOT_ALPHA (Air Surveillance)</option>
                <option value="SYSTEM_DOCTOR">SYSTEM_DOCTOR (Telemetry)</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-mono text-zinc-400 block mb-1">
                Audio Transcription Buffer (Text)
              </label>
              <textarea
                value={customText}
                onChange={(e) => setCustomText(e.target.value)}
                placeholder="Type transmission utterance e.g. 'Restore checksum confirmed across offline nodes'..."
                rows={4}
                className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-200 font-mono text-xs focus:outline-none focus:border-indigo-500"
                required
              />
            </div>

            <button
              type="submit"
              disabled={isProcessing}
              className="w-full py-2 px-4 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-mono font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md"
            >
              <Radio className="w-3.5 h-3.5" />
              <span>INGEST TRANSCRIPT</span>
            </button>
          </form>

          {/* Diarization details */}
          <div className="pt-2 border-t border-zinc-800 text-[11px] font-mono text-zinc-400 space-y-1">
            <span className="text-zinc-500 block uppercase">Diarization Engine:</span>
            <p className="text-zinc-400">
              Acoustic biometric embeddings separate overlapping channels with &gt;95% speaker classification accuracy.
            </p>
          </div>
        </div>

        {/* Right: Ingested Transcripts Stream */}
        <div className="lg:col-span-2 p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-mono font-bold text-sm text-zinc-200 uppercase flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-indigo-400" />
              <span>Synchronized Transcript Feed ({transcripts.length})</span>
            </h4>
            <span className="text-xs font-mono text-emerald-400 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              VAD Acoustic Sync
            </span>
          </div>

          <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
            {transcripts.map((t) => (
              <div
                key={t.id}
                className={`p-3 rounded-lg bg-zinc-950 border text-xs font-mono space-y-2 transition-all ${
                  t.status === 'FLAGGED_LOW_CONF'
                    ? 'border-amber-500/40 bg-amber-950/10'
                    : 'border-zinc-800 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-500/30 font-bold text-[10px]">
                      {t.speaker}
                    </span>
                    <span className="text-[10px] text-zinc-500">
                      {t.durationSec}s duration
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                        t.confidence >= 0.85
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      }`}
                    >
                      {(t.confidence * 100).toFixed(0)}% CONF
                    </span>

                    {t.status === 'FLAGGED_LOW_CONF' && (
                      <span className="flex items-center gap-1 text-[10px] text-amber-400 font-bold">
                        <AlertTriangle className="w-3 h-3" />
                        LOW SNR
                      </span>
                    )}
                  </div>
                </div>

                <p className="text-zinc-200 text-xs leading-relaxed font-sans font-medium">
                  "{t.text}"
                </p>

                {/* Keywords extracted */}
                {t.keywords && t.keywords.length > 0 && (
                  <div className="flex items-center gap-1.5 flex-wrap pt-1">
                    <span className="text-[9px] text-zinc-500 uppercase">Tags:</span>
                    {t.keywords.map((kw) => (
                      <span
                        key={kw}
                        className="px-1.5 py-0.5 rounded bg-zinc-800 text-[10px] text-cyan-300 font-mono"
                      >
                        #{kw}
                      </span>
                    ))}
                  </div>
                )}

                <div className="flex items-center justify-between text-[10px] text-zinc-500 pt-1 border-t border-zinc-900">
                  <span>ID: {t.id}</span>
                  <span>{new Date(t.timestamp).toLocaleTimeString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
