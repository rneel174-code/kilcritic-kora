import React, { useState } from 'react';
import {
  CopySlash,
  Trash2,
  Scan,
  ShieldCheck,
  AlertCircle,
  FileImage,
  Hash,
  ArrowRight,
  Sparkles,
  Layers,
} from 'lucide-react';
import { MediaFingerprint } from '../services/types';
import { calculateHammingDistance, calculateSimilarity } from '../services/mediaDedup';

interface MediaDedupTabProps {
  mediaItems: MediaFingerprint[];
  stats: {
    totalItems: number;
    duplicateCount: number;
    totalSizeKb: number;
    reclaimableKb: number;
    dedupRatio: number;
  };
  onPurgeDuplicates: () => { purgedCount: number; reclaimedKb: number };
  onRegisterMedia: (
    fileName: string,
    fileSizeKb: number,
    mimeType: MediaFingerprint['mimeType'],
    customHash?: string
  ) => Promise<MediaFingerprint>;
}

export const MediaDedupTab: React.FC<MediaDedupTabProps> = ({
  mediaItems,
  stats,
  onPurgeDuplicates,
  onRegisterMedia,
}) => {
  const [purgeFeedback, setPurgeFeedback] = useState<string | null>(null);
  const [simName, setSimName] = useState('surveillance_frame_049.png');
  const [simType, setSimType] = useState<MediaFingerprint['mimeType']>('image/png');
  const [simSize, setSimSize] = useState(1840);
  const [forceDuplicateOf, setForceDuplicateOf] = useState<string>('NONE');

  const handlePurge = () => {
    const res = onPurgeDuplicates();
    setPurgeFeedback(`Reclaimed ${(res.reclaimedKb / 1024).toFixed(2)} MB by pruning ${res.purgedCount} redundant assets.`);
    setTimeout(() => setPurgeFeedback(null), 5000);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    let customHash: string | undefined = undefined;

    if (forceDuplicateOf !== 'NONE') {
      const parent = mediaItems.find((m) => m.id === forceDuplicateOf);
      if (parent) {
        // slightly mutate 1 or 2 bits to test Hamming distance similarity
        const chars = parent.perceptualHash.split('');
        chars[60] = chars[60] === '1' ? '0' : '1';
        chars[61] = chars[61] === '1' ? '0' : '1';
        customHash = chars.join('');
      }
    }

    await onRegisterMedia(simName, simSize, simType, customHash);
    setSimName(`media_feed_${Date.now().toString().slice(-4)}.jpg`);
  };

  return (
    <div className="space-y-6">
      {/* Top Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
          <span className="text-[11px] font-mono text-zinc-400 uppercase block">Total Indexed Assets</span>
          <span className="text-2xl font-mono font-bold text-zinc-100">{stats.totalItems}</span>
          <span className="text-[10px] text-zinc-500 font-mono block mt-1">Binary & pHash indexed</span>
        </div>

        <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
          <span className="text-[11px] font-mono text-zinc-400 uppercase block">Duplicate Redundancy</span>
          <span className={`text-2xl font-mono font-bold ${stats.duplicateCount > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
            {stats.duplicateCount} ({stats.dedupRatio}%)
          </span>
          <span className="text-[10px] text-zinc-500 font-mono block mt-1">&gt;85% Hamming similarity</span>
        </div>

        <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
          <span className="text-[11px] font-mono text-zinc-400 uppercase block">Reclaimable Storage</span>
          <span className="text-2xl font-mono font-bold text-emerald-400">
            {(stats.reclaimableKb / 1024).toFixed(2)} MB
          </span>
          <span className="text-[10px] text-zinc-500 font-mono block mt-1">Pending automated purge</span>
        </div>

        <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800">
          <span className="text-[11px] font-mono text-zinc-400 uppercase block">Perceptual Engine</span>
          <span className="text-2xl font-mono font-bold text-cyan-400">64-Bit pHash</span>
          <span className="text-[10px] text-zinc-500 font-mono block mt-1">Bitwise Hamming clusterer</span>
        </div>
      </div>

      {/* Action Controls & Purge Alert */}
      <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 flex flex-wrap items-center justify-between gap-3">
        <div className="space-y-0.5">
          <h4 className="font-mono font-bold text-sm text-zinc-200 uppercase flex items-center gap-2">
            <CopySlash className="w-4 h-4 text-amber-400" />
            <span>Perceptual Deduplication Ledger</span>
          </h4>
          <p className="text-xs text-zinc-400">
            Identifies exact binary collisions (SHA-256) and resized/re-encoded duplicates (pHash Hamming distance).
          </p>
        </div>

        <button
          onClick={handlePurge}
          disabled={stats.duplicateCount === 0}
          className="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 disabled:opacity-40 text-zinc-950 font-mono font-bold text-xs flex items-center gap-2 transition-all shadow-md"
        >
          <Trash2 className="w-4 h-4" />
          <span>PURGE {stats.duplicateCount} DUPLICATES & RECLAIM {(stats.reclaimableKb / 1024).toFixed(1)} MB</span>
        </button>
      </div>

      {purgeFeedback && (
        <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-mono flex items-center gap-2">
          <ShieldCheck className="w-4 h-4" />
          <span>{purgeFeedback}</span>
        </div>
      )}

      {/* Two Column Grid: Scanner Form & Media Assets Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Scan / Register Asset */}
        <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-4">
          <h4 className="font-mono font-bold text-sm text-zinc-200 uppercase flex items-center gap-2">
            <Scan className="w-4 h-4 text-cyan-400" />
            <span>Register & Fingerprint Asset</span>
          </h4>

          <form onSubmit={handleRegister} className="space-y-3">
            <div>
              <label className="text-[11px] font-mono text-zinc-400 block mb-1">Asset Name</label>
              <input
                type="text"
                value={simName}
                onChange={(e) => setSimName(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-200 font-mono text-xs focus:outline-none focus:border-amber-500"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] font-mono text-zinc-400 block mb-1">MIME Type</label>
                <select
                  value={simType}
                  onChange={(e) => setSimType(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-200 font-mono text-xs focus:outline-none focus:border-amber-500"
                >
                  <option value="image/png">image/png</option>
                  <option value="image/jpeg">image/jpeg</option>
                  <option value="video/mp4">video/mp4</option>
                  <option value="audio/wav">audio/wav</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-mono text-zinc-400 block mb-1">Size (KB)</label>
                <input
                  type="number"
                  value={simSize}
                  onChange={(e) => setSimSize(parseInt(e.target.value) || 500)}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-200 font-mono text-xs focus:outline-none focus:border-amber-500"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-mono text-zinc-400 block mb-1">
                Simulate Near-Duplicate Of:
              </label>
              <select
                value={forceDuplicateOf}
                onChange={(e) => setForceDuplicateOf(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-200 font-mono text-xs focus:outline-none focus:border-amber-500"
              >
                <option value="NONE">None (Unique Asset)</option>
                {mediaItems
                  .filter((m) => !m.isDuplicate)
                  .map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.fileName} ({m.clusterId})
                    </option>
                  ))}
              </select>
            </div>

            <button
              type="submit"
              className="w-full py-2 px-4 rounded-lg bg-amber-600 hover:bg-amber-500 text-zinc-950 font-mono font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md"
            >
              <Scan className="w-3.5 h-3.5" />
              <span>SCAN & COMPUTE HASH</span>
            </button>
          </form>

          {/* pHash explanation */}
          <div className="p-3 rounded-lg bg-zinc-950/80 border border-zinc-800 text-[11px] font-mono text-zinc-400 space-y-1">
            <span className="text-zinc-300 font-bold block">Hamming Distance Algorithm:</span>
            <p>
              Compares low-frequency DCT components of images. If Hamming bit-diff ≤ 9 bits (&gt;85% match),
              the item is classified as near-duplicate.
            </p>
          </div>
        </div>

        {/* Right: Media Items List */}
        <div className="lg:col-span-2 p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-mono font-bold text-sm text-zinc-200 uppercase flex items-center gap-2">
              <FileImage className="w-4 h-4 text-amber-400" />
              <span>Media Assets & Fingerprint Matrix ({mediaItems.length})</span>
            </h4>
            <span className="text-xs font-mono text-zinc-400">
              {stats.duplicateCount} marked for reclamation
            </span>
          </div>

          <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
            {mediaItems.map((item) => (
              <div
                key={item.id}
                className={`p-3.5 rounded-lg bg-zinc-950 border text-xs font-mono space-y-2 transition-colors ${
                  item.isDuplicate
                    ? 'border-rose-500/40 bg-rose-950/10'
                    : 'border-zinc-800 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-3 h-3 rounded-full inline-block"
                      style={{ backgroundColor: item.thumbnailColor }}
                    />
                    <span className="font-bold text-zinc-100">{item.fileName}</span>
                    <span className="text-[10px] text-zinc-400">
                      {(item.fileSizeKb / 1024).toFixed(2)} MB
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400">
                      {item.clusterId}
                    </span>

                    {item.isDuplicate ? (
                      <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[10px] font-bold">
                        DUPLICATE ({item.similarityScore}% SIMILAR)
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold">
                        MASTER CANONICAL
                      </span>
                    )}
                  </div>
                </div>

                {/* Perceptual Hash Bits visual */}
                <div className="p-2 rounded bg-zinc-900 border border-zinc-800/80 text-[10px] font-mono space-y-1">
                  <div className="flex items-center justify-between text-zinc-400">
                    <span className="flex items-center gap-1">
                      <Hash className="w-3 h-3 text-amber-400" />
                      <span>64-bit pHash:</span>
                    </span>
                    <span className="text-zinc-500">{item.mimeType}</span>
                  </div>
                  <div className="text-zinc-300 font-mono tracking-wider break-all bg-zinc-950 p-1 rounded">
                    {item.perceptualHash}
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] text-zinc-500 pt-1">
                  <span>SHA-256: {item.sha256.substring(0, 24)}...</span>
                  <span>{new Date(item.timestamp).toLocaleTimeString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
