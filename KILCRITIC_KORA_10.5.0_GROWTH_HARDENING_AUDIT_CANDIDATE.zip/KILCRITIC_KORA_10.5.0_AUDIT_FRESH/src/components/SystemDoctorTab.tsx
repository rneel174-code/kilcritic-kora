import React, { useState } from 'react';
import {
  Stethoscope,
  Activity,
  ShieldCheck,
  Flame,
  CheckCircle2,
  AlertTriangle,
  AlertOctagon,
  RefreshCw,
  Cpu,
  Clock,
  Wrench,
} from 'lucide-react';
import { DoctorProbe, ServiceHealth, ServiceName } from '../services/types';

interface SystemDoctorTabProps {
  probes: DoctorProbe[];
  healthScore: number;
  servicesHealth: Record<ServiceName, ServiceHealth>;
  isAutoHealing: boolean;
  onToggleAutoHealing: () => void;
  onRunDiagnostics: () => void;
  onForceHeal: () => { actionsTaken: string[] };
  onInjectChaos: (type: 'dlq_spike' | 'memory_surge' | 'duplicate_flood') => void;
}

export const SystemDoctorTab: React.FC<SystemDoctorTabProps> = ({
  probes,
  healthScore,
  servicesHealth,
  isAutoHealing,
  onToggleAutoHealing,
  onRunDiagnostics,
  onForceHeal,
  onInjectChaos,
}) => {
  const [healActions, setHealActions] = useState<string[]>([]);
  const [filterLevel, setFilterLevel] = useState<string>('ALL');

  const handleManualHeal = () => {
    const res = onForceHeal();
    setHealActions(res.actionsTaken.length > 0 ? res.actionsTaken : ['All microservice subsystems nominal. No remediation required.']);
    setTimeout(() => setHealActions([]), 7000);
  };

  const filteredProbes = probes.filter((p) => {
    if (filterLevel === 'ALL') return true;
    return p.level === filterLevel;
  });

  const remediatedCount = probes.filter((p) => p.remediated).length;

  return (
    <div className="space-y-6">
      {/* Top Banner: Health Gauge & Auto-Healing Control */}
      <div className="p-5 rounded-xl bg-gradient-to-r from-zinc-900 via-zinc-900 to-rose-950/20 border border-rose-500/30 space-y-4 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-500/40 text-rose-400">
              <Stethoscope className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-mono font-black text-base text-zinc-100 uppercase tracking-widest">
                  System Doctor Telemetry & Auto-Healer
                </h3>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40">
                  KERNEL 8.8.5
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Continuous 5-second synthetic probe loop across all 6 microservices with automated remediation.
              </p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center flex-wrap gap-2.5">
            <button
              onClick={onToggleAutoHealing}
              className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                isAutoHealing
                  ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300 shadow-[0_0_10px_rgba(16,185,129,0.2)]'
                  : 'bg-zinc-800 border-zinc-700 text-zinc-400'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>AUTO-HEAL: {isAutoHealing ? 'ENABLED' : 'PAUSED'}</span>
            </button>

            <button
              onClick={onRunDiagnostics}
              className="px-3.5 py-1.5 rounded-lg bg-cyan-950/60 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-300 text-xs font-mono font-bold transition-all flex items-center gap-1.5"
            >
              <Activity className="w-3.5 h-3.5" />
              <span>RUN SWEEP</span>
            </button>

            <button
              onClick={handleManualHeal}
              className="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-mono font-bold transition-all flex items-center gap-1.5 shadow-md"
            >
              <Wrench className="w-3.5 h-3.5" />
              <span>FORCE HEAL ALL</span>
            </button>
          </div>
        </div>

        {/* Dynamic Metric Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2">
          <div className="p-3 rounded-lg bg-zinc-950/80 border border-zinc-800">
            <span className="text-[10px] font-mono text-zinc-500 uppercase block">Global Health Score</span>
            <span
              className={`text-2xl font-mono font-bold ${
                healthScore >= 90
                  ? 'text-emerald-400'
                  : healthScore >= 70
                  ? 'text-amber-400'
                  : 'text-rose-400'
              }`}
            >
              {healthScore}%
            </span>
          </div>

          <div className="p-3 rounded-lg bg-zinc-950/80 border border-zinc-800">
            <span className="text-[10px] font-mono text-zinc-500 uppercase block">Monitored Services</span>
            <span className="text-2xl font-mono font-bold text-zinc-100">6 / 6 Active</span>
          </div>

          <div className="p-3 rounded-lg bg-zinc-950/80 border border-zinc-800">
            <span className="text-[10px] font-mono text-zinc-500 uppercase block">Auto-Remediated Faults</span>
            <span className="text-2xl font-mono font-bold text-emerald-400">{remediatedCount}</span>
          </div>

          <div className="p-3 rounded-lg bg-zinc-950/80 border border-zinc-800">
            <span className="text-[10px] font-mono text-zinc-500 uppercase block">Sampling Rate</span>
            <span className="text-2xl font-mono font-bold text-cyan-400">5,000ms</span>
          </div>
        </div>
      </div>

      {healActions.length > 0 && (
        <div className="p-4 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 text-xs font-mono space-y-1">
          <span className="font-bold uppercase flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            Remediation Actions Executed:
          </span>
          <ul className="list-disc pl-5 space-y-0.5 text-zinc-300">
            {healActions.map((act, idx) => (
              <li key={idx}>{act}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Chaos Injection Subsystem */}
      <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-3">
        <div className="flex items-center gap-2">
          <Flame className="w-4 h-4 text-rose-400" />
          <h4 className="font-mono font-bold text-sm text-zinc-200 uppercase">
            Chaos Injection Playground
          </h4>
        </div>
        <p className="text-xs text-zinc-400">
          Trigger live failure conditions to observe the Doctor's heuristics and self-healing algorithms in real-time.
        </p>

        <div className="flex flex-wrap gap-2 pt-1">
          <button
            onClick={() => onInjectChaos('dlq_spike')}
            className="px-3 py-2 rounded-lg bg-rose-950/60 hover:bg-rose-900 border border-rose-500/40 text-rose-300 text-xs font-mono font-semibold transition-all"
          >
            Spike DLQ with Dead Letters
          </button>
          <button
            onClick={() => onInjectChaos('memory_surge')}
            className="px-3 py-2 rounded-lg bg-amber-950/60 hover:bg-amber-900 border border-amber-500/40 text-amber-300 text-xs font-mono font-semibold transition-all"
          >
            Surge Memory Allocation (+45MB)
          </button>
          <button
            onClick={() => onInjectChaos('duplicate_flood')}
            className="px-3 py-2 rounded-lg bg-indigo-950/60 hover:bg-indigo-900 border border-indigo-500/40 text-indigo-300 text-xs font-mono font-semibold transition-all"
          >
            Flood Media Dedup Redundancies
          </button>
        </div>
      </div>

      {/* Probe Log Table */}
      <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h4 className="font-mono font-bold text-sm text-zinc-200 uppercase flex items-center gap-2">
            <Activity className="w-4 h-4 text-rose-400" />
            <span>Synthetic Probe Inspection Audit ({filteredProbes.length})</span>
          </h4>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-zinc-500 uppercase">Filter:</span>
            <select
              value={filterLevel}
              onChange={(e) => setFilterLevel(e.target.value)}
              className="px-2 py-1 rounded bg-zinc-950 border border-zinc-700 text-zinc-300 font-mono text-xs focus:outline-none focus:border-rose-500"
            >
              <option value="ALL">All Levels</option>
              <option value="HEALTHY">HEALTHY</option>
              <option value="WARNING">WARNING</option>
              <option value="CRITICAL">CRITICAL</option>
            </select>
          </div>
        </div>

        <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
          {filteredProbes.map((probe) => (
            <div
              key={probe.id}
              className={`p-3 rounded-lg bg-zinc-950 border text-xs font-mono space-y-1.5 transition-colors ${
                probe.level === 'CRITICAL'
                  ? 'border-rose-500/50 bg-rose-950/10'
                  : probe.level === 'WARNING'
                  ? 'border-amber-500/40 bg-amber-950/10'
                  : 'border-zinc-800 hover:border-zinc-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      probe.level === 'HEALTHY'
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : probe.level === 'WARNING'
                        ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    }`}
                  >
                    {probe.level}
                  </span>
                  <span className="font-bold text-zinc-200">{probe.checkName}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400">
                    {probe.service}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {probe.remediated ? (
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />
                      AUTO-REMEDIATED
                    </span>
                  ) : null}
                  <span className="text-[10px] text-zinc-500">
                    {new Date(probe.timestamp).toLocaleTimeString()}
                  </span>
                </div>
              </div>

              <p className="text-zinc-300 text-xs font-sans">{probe.message}</p>

              {probe.remediationAction && (
                <div className="p-2 rounded bg-emerald-950/30 border border-emerald-500/30 text-[11px] text-emerald-300 font-mono">
                  <strong>Action Taken:</strong> {probe.remediationAction}
                </div>
              )}

              <div className="flex items-center justify-between text-[10px] text-zinc-500 pt-1 border-t border-zinc-900">
                <span>Value: {probe.value} (Threshold: {probe.threshold})</span>
                <span>Probe ID: {probe.id}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
