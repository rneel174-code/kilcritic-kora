import React from 'react';
import {
  Activity,
  Layers,
  Radio,
  HardDrive,
  CopySlash,
  Stethoscope,
  Network,
  Zap,
  RefreshCw,
  Flame,
  ShieldCheck,
  CheckCircle2,
  Clock,
  ArrowRightLeft,
} from 'lucide-react';
import { ServiceHealth, ServiceName } from '../services/types';

interface TopologyViewProps {
  servicesHealth: Record<ServiceName, ServiceHealth>;
  onNavigateTab: (tabId: string) => void;
  onInjectChaos: (type: 'dlq_spike' | 'memory_surge' | 'duplicate_flood') => void;
  onRunDiagnostics: () => void;
  onForceHeal: () => void;
  onTriggerBackup: () => void;
  onRunTests: () => void;
  recentEventsCount: number;
}

const SERVICE_META: Record<
  ServiceName,
  { label: string; icon: React.ReactNode; color: string; bg: string; border: string; desc: string; tab: string }
> = {
  event_bus: {
    label: 'event_bus',
    icon: <Layers className="w-5 h-5 text-cyan-400" />,
    color: 'text-cyan-400',
    bg: 'bg-cyan-950/30',
    border: 'border-cyan-500/40',
    desc: 'Core Pub/Sub Broker, Dead-Letter Queue & Event Replay Engine',
    tab: 'event_bus',
  },
  backup_service: {
    label: 'backup_service',
    icon: <HardDrive className="w-5 h-5 text-emerald-400" />,
    color: 'text-emerald-400',
    bg: 'bg-emerald-950/30',
    border: 'border-emerald-500/40',
    desc: 'SHA-256 Manifest Checksum, Delta Snapshots & Zero-Loss Recovery',
    tab: 'backup_service',
  },
  voice_transcription: {
    label: 'voice_transcription',
    icon: <Radio className="w-5 h-5 text-indigo-400" />,
    color: 'text-indigo-400',
    bg: 'bg-indigo-950/30',
    border: 'border-indigo-500/40',
    desc: 'Voice Activity Detection (VAD), FFT Waveform & Multi-Speaker Diarization',
    tab: 'voice_transcription',
  },
  media_dedup: {
    label: 'media_dedup',
    icon: <CopySlash className="w-5 h-5 text-amber-400" />,
    color: 'text-amber-400',
    bg: 'bg-amber-950/30',
    border: 'border-amber-500/40',
    desc: 'Perceptual Hash (pHash), Hamming Distance & Cluster Purge Engine',
    tab: 'media_dedup',
  },
  system_doctor: {
    label: 'system_doctor',
    icon: <Stethoscope className="w-5 h-5 text-rose-400" />,
    color: 'text-rose-400',
    bg: 'bg-rose-950/30',
    border: 'border-rose-500/40',
    desc: 'Autonomous Probes, Self-Healing Subroutines & Chaos Remediation',
    tab: 'system_doctor',
  },
  offline_queue: {
    label: 'offline_queue',
    icon: <Network className="w-5 h-5 text-teal-400" />,
    color: 'text-teal-400',
    bg: 'bg-teal-950/30',
    border: 'border-teal-500/40',
    desc: 'Idempotency Token Enforcer, Exponential Backoff & Local Buffer',
    tab: 'offline_queue',
  },
};

export const TopologyView: React.FC<TopologyViewProps> = ({
  servicesHealth,
  onNavigateTab,
  onInjectChaos,
  onRunDiagnostics,
  onForceHeal,
  onTriggerBackup,
  onRunTests,
}) => {
  const serviceKeys: ServiceName[] = [
    'event_bus',
    'backup_service',
    'voice_transcription',
    'media_dedup',
    'system_doctor',
    'offline_queue',
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner: CTO Status Overview */}
      <div className="p-4 rounded-xl bg-gradient-to-r from-zinc-900 via-zinc-900/90 to-emerald-950/30 border border-emerald-500/30 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 text-xs font-mono font-bold rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 uppercase">
                CTO Active Architecture Matrix
              </span>
              <span className="text-zinc-500 text-xs font-mono">Kernel 8.8.5.0-HARDENED</span>
            </div>
            <p className="text-sm text-zinc-300 max-w-2xl">
              High-concurrency full-duplex mesh linking <strong className="text-emerald-400">all 6 microservices</strong>.
              Event-driven routing with automated self-healing, strict idempotency validation, and zero data-loss resilience.
            </p>
          </div>

          {/* Quick Action Matrix */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={onRunDiagnostics}
              className="px-3 py-2 rounded-lg bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-500/40 text-cyan-300 text-xs font-mono font-semibold flex items-center gap-1.5 transition-all shadow-[0_0_12px_rgba(6,182,212,0.2)]"
            >
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span>DIAGNOSTIC SWEEP</span>
            </button>
            <button
              onClick={onForceHeal}
              className="px-3 py-2 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/40 text-emerald-300 text-xs font-mono font-semibold flex items-center gap-1.5 transition-all shadow-[0_0_12px_rgba(16,185,129,0.2)]"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>FORCE AUTO-HEAL</span>
            </button>
            <button
              onClick={onTriggerBackup}
              className="px-3 py-2 rounded-lg bg-zinc-800/80 hover:bg-zinc-700 border border-zinc-600 text-zinc-200 text-xs font-mono font-semibold flex items-center gap-1.5 transition-all"
            >
              <RefreshCw className="w-3.5 h-3.5 text-zinc-300" />
              <span>SNAPSHOT NOW</span>
            </button>
            <button
              onClick={onRunTests}
              className="px-3 py-2 rounded-lg bg-indigo-950/60 hover:bg-indigo-900/80 border border-indigo-500/40 text-indigo-300 text-xs font-mono font-semibold flex items-center gap-1.5 transition-all shadow-[0_0_12px_rgba(99,102,241,0.2)]"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" />
              <span>RUN 22 TESTS</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mesh Topology Diagram (Interactive Grid of 6 Nodes) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {serviceKeys.map((key) => {
          const meta = SERVICE_META[key];
          const health = servicesHealth[key] || {
            status: 'OPERATIONAL',
            uptimeSeconds: 14220,
            memoryMb: 30,
            latencyMs: 2,
            throughputPerSec: 20,
          };

          return (
            <div
              key={key}
              onClick={() => onNavigateTab(meta.tab)}
              className={`p-4 rounded-xl ${meta.bg} border ${meta.border} hover:scale-[1.01] transition-all cursor-pointer relative overflow-hidden group shadow-md`}
            >
              {/* Corner status pulse */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-zinc-900/80 border border-zinc-700/80">
                    {meta.icon}
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-zinc-100 flex items-center gap-1.5">
                      <span>{meta.label}</span>
                      <span className="text-[10px] text-zinc-500">v8.8.5</span>
                    </h3>
                    <p className="text-[11px] text-zinc-400 font-mono">microservice #{key}</p>
                  </div>
                </div>

                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider ${
                    health.status === 'OPERATIONAL'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : health.status === 'HEALING'
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  }`}
                >
                  {health.status}
                </span>
              </div>

              {/* Service description */}
              <p className="text-xs text-zinc-300 line-clamp-2 mb-4 h-8 font-sans">
                {meta.desc}
              </p>

              {/* Telemetry Readouts */}
              <div className="grid grid-cols-3 gap-2 p-2 rounded-lg bg-zinc-950/70 border border-zinc-800 text-[11px] font-mono">
                <div>
                  <span className="text-zinc-500 block text-[9px] uppercase">Latency</span>
                  <span className="text-zinc-200 font-semibold">{health.latencyMs}ms</span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-[9px] uppercase">Memory</span>
                  <span className="text-zinc-200 font-semibold">{health.memoryMb}MB</span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-[9px] uppercase">Rate</span>
                  <span className="text-emerald-400 font-semibold">{health.throughputPerSec}/s</span>
                </div>
              </div>

              {/* Bottom footer button */}
              <div className="mt-3 flex items-center justify-between text-[11px] text-zinc-400 font-mono">
                <span className="flex items-center gap-1 text-zinc-500">
                  <Clock className="w-3 h-3" />
                  <span>Uptime: 99.98%</span>
                </span>
                <span className="flex items-center gap-1 text-emerald-400 group-hover:translate-x-1 transition-transform">
                  <span>Inspect Service</span>
                  <ArrowRightLeft className="w-3 h-3" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Cross-Service Data Synchronization Pipe */}
      <div className="p-4 rounded-xl bg-zinc-900/70 border border-zinc-800 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <h3 className="font-mono font-bold text-sm text-zinc-200 uppercase tracking-wide">
              Cross-Service Synchronization Flow
            </h3>
          </div>
          <span className="text-xs font-mono text-emerald-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Mesh Concurrency Active
          </span>
        </div>

        {/* Visual Pipeline */}
        <div className="grid grid-cols-1 md:grid-cols-6 gap-2 text-center text-xs font-mono">
          <div className="p-2.5 rounded bg-zinc-950/80 border border-zinc-800 text-indigo-300">
            <span className="text-[10px] text-zinc-500 block">1. INGEST</span>
            <span className="font-bold">voice_transcription</span>
          </div>
          <div className="p-2.5 rounded bg-zinc-950/80 border border-zinc-800 text-cyan-300">
            <span className="text-[10px] text-zinc-500 block">2. ROUTE</span>
            <span className="font-bold">event_bus</span>
          </div>
          <div className="p-2.5 rounded bg-zinc-950/80 border border-zinc-800 text-teal-300">
            <span className="text-[10px] text-zinc-500 block">3. BUFFER</span>
            <span className="font-bold">offline_queue</span>
          </div>
          <div className="p-2.5 rounded bg-zinc-950/80 border border-zinc-800 text-amber-300">
            <span className="text-[10px] text-zinc-500 block">4. DEDUP</span>
            <span className="font-bold">media_dedup</span>
          </div>
          <div className="p-2.5 rounded bg-zinc-950/80 border border-zinc-800 text-emerald-300">
            <span className="text-[10px] text-zinc-500 block">5. PERSIST</span>
            <span className="font-bold">backup_service</span>
          </div>
          <div className="p-2.5 rounded bg-zinc-950/80 border border-zinc-800 text-rose-300">
            <span className="text-[10px] text-zinc-500 block">6. DIAGNOSE</span>
            <span className="font-bold">system_doctor</span>
          </div>
        </div>
      </div>

      {/* Chaos Injection Subsystem */}
      <div className="p-4 rounded-xl bg-gradient-to-r from-zinc-900 to-rose-950/20 border border-rose-500/30">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-rose-400" />
              <h3 className="font-mono font-bold text-sm text-zinc-100 uppercase">
                Chaos Injection & Self-Recovery Tester
              </h3>
            </div>
            <p className="text-xs text-zinc-400">
              Stress-test resilience by injecting faults into active microservices. Watch System Doctor detect and auto-remediate.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onInjectChaos('dlq_spike')}
              className="px-3 py-1.5 rounded-lg bg-rose-950/50 hover:bg-rose-900/60 border border-rose-500/40 text-rose-300 text-xs font-mono font-semibold transition-all"
            >
              Inject DLQ Spike
            </button>
            <button
              onClick={() => onInjectChaos('memory_surge')}
              className="px-3 py-1.5 rounded-lg bg-amber-950/50 hover:bg-amber-900/60 border border-amber-500/40 text-amber-300 text-xs font-mono font-semibold transition-all"
            >
              Inject Memory Surge
            </button>
            <button
              onClick={() => onInjectChaos('duplicate_flood')}
              className="px-3 py-1.5 rounded-lg bg-indigo-950/50 hover:bg-indigo-900/60 border border-indigo-500/40 text-indigo-300 text-xs font-mono font-semibold transition-all"
            >
              Inject Duplicate Flood
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
