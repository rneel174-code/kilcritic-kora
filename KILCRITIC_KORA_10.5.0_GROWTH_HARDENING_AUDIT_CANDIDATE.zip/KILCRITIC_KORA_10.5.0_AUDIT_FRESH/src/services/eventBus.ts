import { BusEvent, ServiceName } from './types';

type EventHandler = (event: BusEvent) => Promise<boolean> | boolean;

interface Subscription {
  id: string;
  topicPattern: string;
  service: ServiceName | 'user_ui';
  handler: EventHandler;
}

class EventBusService {
  private events: BusEvent[] = [];
  private deadLetterQueue: BusEvent[] = [];
  private subscriptions: Map<string, Subscription> = new Map();
  private subscribersByPattern: Subscription[] = [];
  private metrics = {
    totalPublished: 0,
    totalAcked: 0,
    totalDlq: 0,
    totalReplayed: 0,
  };
  private listeners: Array<() => void> = [];

  constructor() {
    this.seedDefaultEvents();
  }

  private seedDefaultEvents() {
    const now = Date.now();
    const seedEvents: Array<Omit<BusEvent, 'id' | 'timestamp' | 'status' | 'attempts'>> = [
      {
        topic: 'system.boot.kora',
        source: 'system_doctor',
        correlationId: 'boot-001',
        payload: { kernel: '8.8.5-KORA-GODFATHER', servicesActive: 6, mode: 'HARDENED' },
      },
      {
        topic: 'voice.vad.triggered',
        source: 'voice_transcription',
        correlationId: 'vad-9941',
        payload: { dbLevel: -18.4, speakerDetected: 'OPERATOR_1', confidence: 0.98 },
      },
      {
        topic: 'media.scan.completed',
        source: 'media_dedup',
        correlationId: 'dedup-7721',
        payload: { inspectedAssets: 142, duplicateClusters: 3, reclaimableMb: 86.4 },
      },
      {
        topic: 'backup.snapshot.verified',
        source: 'backup_service',
        correlationId: 'snap-4402',
        payload: { snapshotId: 'snap-alpha-885', sha256: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' },
      },
      {
        topic: 'queue.sync.checkpoint',
        source: 'offline_queue',
        correlationId: 'sync-1109',
        payload: { pendingItems: 0, flushDurationMs: 14, networkState: 'ONLINE' },
      },
    ];

    seedEvents.forEach((se, idx) => {
      this.events.unshift({
        id: `evt-${now - (5 - idx) * 4500}-${Math.random().toString(36).substring(2, 6)}`,
        topic: se.topic,
        source: se.source,
        timestamp: now - (5 - idx) * 4500,
        payload: se.payload,
        correlationId: se.correlationId,
        status: 'ACKED',
        attempts: 1,
      });
      this.metrics.totalPublished++;
      this.metrics.totalAcked++;
    });
  }

  public subscribe(
    topicPattern: string,
    service: ServiceName | 'user_ui',
    handler: EventHandler
  ): string {
    const id = `sub-${Math.random().toString(36).substring(2, 9)}`;
    const sub: Subscription = { id, topicPattern, service, handler };
    this.subscriptions.set(id, sub);
    this.subscribersByPattern.push(sub);
    return id;
  }

  public unsubscribe(subId: string): boolean {
    const sub = this.subscriptions.get(subId);
    if (!sub) return false;
    this.subscriptions.delete(subId);
    this.subscribersByPattern = this.subscribersByPattern.filter((s) => s.id !== subId);
    return true;
  }

  public matchTopic(pattern: string, topic: string): boolean {
    if (pattern === '#' || pattern === '*' || pattern === topic) return true;

    const regexStr = '^' + pattern
      .split('.')
      .map((part) => {
        if (part === '#') return '.*';
        if (part === '*') return '.*';
        return part.replace(/[-[\]{}()+?.,\\^$|#\s]/g, '\\$&');
      })
      .join('\\.') + '$';

    return new RegExp(regexStr).test(topic);
  }

  public async publish<T = any>(
    topic: string,
    payload: T,
    source: ServiceName | 'user_ui' = 'event_bus',
    correlationId?: string
  ): Promise<BusEvent<T>> {
    const event: BusEvent<T> = {
      id: `evt-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      topic,
      source,
      timestamp: Date.now(),
      payload,
      correlationId: correlationId || `corr-${Math.random().toString(36).substring(2, 8)}`,
      status: 'PUBLISHED',
      attempts: 1,
    };

    this.events.unshift(event);
    if (this.events.length > 250) {
      this.events.pop();
    }
    this.metrics.totalPublished++;

    // Match subscribers
    const matchingSubs = this.subscribersByPattern.filter((s) =>
      this.matchTopic(s.topicPattern, topic)
    );

    let failed = false;
    for (const sub of matchingSubs) {
      try {
        const res = await Promise.resolve(sub.handler(event));
        if (res === false) {
          failed = true;
        }
      } catch (err) {
        failed = true;
      }
    }

    if (failed) {
      event.status = 'DLQ';
      this.deadLetterQueue.unshift({ ...event });
      this.metrics.totalDlq++;
    } else {
      event.status = 'ACKED';
      this.metrics.totalAcked++;
    }

    this.notify();
    return event;
  }

  public async replayEvent(eventId: string): Promise<BusEvent | null> {
    const target = this.events.find((e) => e.id === eventId) ||
                   this.deadLetterQueue.find((e) => e.id === eventId);
    if (!target) return null;

    const replayed = await this.publish(
      target.topic,
      target.payload,
      target.source,
      `replay-${target.id}`
    );
    replayed.status = 'REPLAYED';
    this.metrics.totalReplayed++;
    this.notify();
    return replayed;
  }

  public flushDLQ(): number {
    const count = this.deadLetterQueue.length;
    this.deadLetterQueue = [];
    this.notify();
    return count;
  }

  public getEvents(): BusEvent[] {
    return [...this.events];
  }

  public getDLQ(): BusEvent[] {
    return [...this.deadLetterQueue];
  }

  public getMetrics() {
    return { ...this.metrics, activeSubscriptions: this.subscriptions.size };
  }

  public subscribeChange(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }
}

export const eventBus = new EventBusService();
