import { MediaFingerprint } from './types';
import { eventBus } from './eventBus';

export function calculateHammingDistance(hashA: string, hashB: string): number {
  let distance = 0;
  const len = Math.min(hashA.length, hashB.length);
  for (let i = 0; i < len; i++) {
    if (hashA[i] !== hashB[i]) {
      distance++;
    }
  }
  distance += Math.abs(hashA.length - hashB.length);
  return distance;
}

export function calculateSimilarity(hashA: string, hashB: string): number {
  const dist = calculateHammingDistance(hashA, hashB);
  const maxLen = Math.max(hashA.length, hashB.length, 64);
  return Math.max(0, Math.min(100, Math.round(((maxLen - dist) / maxLen) * 100)));
}

class MediaDedupService {
  private mediaItems: MediaFingerprint[] = [];
  private similarityThreshold: number = 85; // percentage
  private listeners: Array<() => void> = [];

  constructor() {
    this.seedMediaItems();
  }

  private seedMediaItems() {
    const baseHash1 = '1101001011100101010110101001011011010010111001010101101010010110';
    const nearHash1 = '1101001011100101010110101001011011010010111001010101101010010100'; // 2 bits diff (96.8% similar)
    const baseHash2 = '0010110110011010011011001011001100101101100110100110110010110011';
    const nearHash2 = '0010110110011010011011001011001100101101100110100110110010110000'; // 2 bits diff

    const now = Date.now();
    this.mediaItems = [
      {
        id: 'med-01',
        fileName: 'thermal_sat_feed_098.png',
        fileSizeKb: 1420,
        mimeType: 'image/png',
        sha256: '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
        perceptualHash: baseHash1,
        clusterId: 'cluster-alpha',
        isDuplicate: false,
        similarityScore: 100,
        timestamp: now - 300000,
        thumbnailColor: '#0ea5e9',
      },
      {
        id: 'med-02',
        fileName: 'thermal_sat_feed_098_compressed.jpg',
        fileSizeKb: 610,
        mimeType: 'image/jpeg',
        sha256: '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8',
        perceptualHash: nearHash1,
        clusterId: 'cluster-alpha',
        isDuplicate: true,
        duplicateOfId: 'med-01',
        similarityScore: 97,
        timestamp: now - 280000,
        thumbnailColor: '#38bdf8',
      },
      {
        id: 'med-03',
        fileName: 'tactical_telemetry_hud.png',
        fileSizeKb: 2840,
        mimeType: 'image/png',
        sha256: '4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a',
        perceptualHash: baseHash2,
        clusterId: 'cluster-bravo',
        isDuplicate: false,
        similarityScore: 100,
        timestamp: now - 180000,
        thumbnailColor: '#10b981',
      },
      {
        id: 'med-04',
        fileName: 'tactical_telemetry_hud_cached.png',
        fileSizeKb: 2840,
        mimeType: 'image/png',
        sha256: '4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a', // exact binary match
        perceptualHash: baseHash2,
        clusterId: 'cluster-bravo',
        isDuplicate: true,
        duplicateOfId: 'med-03',
        similarityScore: 100,
        timestamp: now - 120000,
        thumbnailColor: '#34d399',
      },
      {
        id: 'med-05',
        fileName: 'voice_spectrum_recording_44100.wav',
        fileSizeKb: 5400,
        mimeType: 'audio/wav',
        sha256: 'ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d',
        perceptualHash: '1111000011110000111100001111000011110000111100001111000011110000',
        clusterId: 'cluster-charlie',
        isDuplicate: false,
        similarityScore: 100,
        timestamp: now - 50000,
        thumbnailColor: '#f59e0b',
      },
    ];
  }

  public generateRandomPHash(): string {
    let hash = '';
    for (let i = 0; i < 64; i++) {
      hash += Math.random() > 0.5 ? '1' : '0';
    }
    return hash;
  }

  public mutatePHash(sourceHash: string, flippedBits: number = 2): string {
    const chars = sourceHash.split('');
    for (let i = 0; i < flippedBits; i++) {
      const idx = Math.floor(Math.random() * chars.length);
      chars[idx] = chars[idx] === '1' ? '0' : '1';
    }
    return chars.join('');
  }

  public async registerMedia(
    fileName: string,
    fileSizeKb: number,
    mimeType: MediaFingerprint['mimeType'],
    customHash?: string,
    customSha256?: string
  ): Promise<MediaFingerprint> {
    const sha256 = customSha256 || Math.random().toString(36).substring(2) + Math.random().toString(36).substring(2);
    const pHash = customHash || this.generateRandomPHash();

    // Check exact binary duplicate first
    const exactMatch = this.mediaItems.find((m) => m.sha256 === sha256);
    let isDuplicate = false;
    let duplicateOfId: string | undefined = undefined;
    let clusterId = `cluster-${Math.random().toString(36).substring(2, 7)}`;
    let highestSim = 0;

    if (exactMatch) {
      isDuplicate = true;
      duplicateOfId = exactMatch.id;
      clusterId = exactMatch.clusterId;
      highestSim = 100;
    } else {
      // Check perceptual similarity
      for (const item of this.mediaItems) {
        const sim = calculateSimilarity(pHash, item.perceptualHash);
        if (sim >= this.similarityThreshold && sim > highestSim) {
          highestSim = sim;
          isDuplicate = true;
          duplicateOfId = item.id;
          clusterId = item.clusterId;
        }
      }
    }

    const newItem: MediaFingerprint = {
      id: `med-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      fileName,
      fileSizeKb,
      mimeType,
      sha256,
      perceptualHash: pHash,
      clusterId,
      isDuplicate,
      duplicateOfId,
      similarityScore: isDuplicate ? highestSim : 100,
      timestamp: Date.now(),
      thumbnailColor: isDuplicate ? '#ef4444' : '#10b981',
    };

    this.mediaItems.unshift(newItem);

    if (isDuplicate) {
      await eventBus.publish(
        'media.dedup.duplicate_detected',
        {
          duplicateId: newItem.id,
          canonicalId: duplicateOfId,
          similarityScore: newItem.similarityScore,
          clusterId: newItem.clusterId,
        },
        'media_dedup'
      );
    } else {
      await eventBus.publish(
        'media.dedup.indexed',
        { mediaId: newItem.id, sha256: newItem.sha256, pHash: newItem.perceptualHash },
        'media_dedup'
      );
    }

    this.notify();
    return newItem;
  }

  public purgeDuplicates(): { purgedCount: number; reclaimedKb: number } {
    const duplicates = this.mediaItems.filter((m) => m.isDuplicate);
    const reclaimedKb = duplicates.reduce((acc, curr) => acc + curr.fileSizeKb, 0);
    const purgedCount = duplicates.length;

    this.mediaItems = this.mediaItems.filter((m) => !m.isDuplicate);

    eventBus.publish(
      'media.dedup.purged',
      { purgedCount, reclaimedKb },
      'media_dedup'
    );

    this.notify();
    return { purgedCount, reclaimedKb };
  }

  public getMediaItems(): MediaFingerprint[] {
    return [...this.mediaItems];
  }

  public getStats() {
    const totalItems = this.mediaItems.length;
    const duplicates = this.mediaItems.filter((m) => m.isDuplicate);
    const totalSizeKb = this.mediaItems.reduce((acc, m) => acc + m.fileSizeKb, 0);
    const reclaimableKb = duplicates.reduce((acc, m) => acc + m.fileSizeKb, 0);

    return {
      totalItems,
      duplicateCount: duplicates.length,
      totalSizeKb,
      reclaimableKb,
      dedupRatio: totalItems > 0 ? Number(((duplicates.length / totalItems) * 100).toFixed(1)) : 0,
    };
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }
}

export const mediaDedup = new MediaDedupService();
