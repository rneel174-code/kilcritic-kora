import { QueueItem, ServiceName } from './types';
import { eventBus } from './eventBus';

export type NetworkMode = 'ONLINE' | 'OFFLINE' | 'FLAKY';

class OfflineQueueService {
  private queue: QueueItem[] = [];
  private processedIdempotencyKeys: Set<string> = new Set();
  private networkMode: NetworkMode = 'ONLINE';
  private isProcessing: boolean = false;
  private listeners: Array<() => void> = [];

  constructor() {
    this.loadPersistedQueue();
    this.seedDefaultQueue();
  }

  private loadPersistedQueue() {
    if (typeof window !== 'undefined' && window.localStorage) {
      try {
        const saved = window.localStorage.getItem('kilcritic_offline_queue');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            this.queue = parsed;
          }
        }
      } catch (e) {
        console.warn('Failed to load persisted queue', e);
      }
    }
  }

  private persistQueue() {
    if (typeof window !== 'undefined' && window.localStorage) {
      try {
        window.localStorage.setItem('kilcritic_offline_queue', JSON.stringify(this.queue));
      } catch (e) {
        // quota exceeded or storage disabled
      }
    }
  }

  private seedDefaultQueue() {
    if (this.queue.length === 0) {
      const now = Date.now();
      this.queue = [
        {
          id: 'q-item-1',
          idempotencyKey: 'idem-sync-audio-01',
          targetService: 'voice_transcription',
          action: 'PROCESS_FIELD_BUFFER',
          payload: { durationSec: 3.2, audioSampleRate: 48000 },
          priority: 'NORMAL',
          attempts: 1,
          maxAttempts: 5,
          state: 'SYNCED',
          createdAt: now - 180000,
          lastAttemptAt: now - 179500,
        },
        {
          id: 'q-item-2',
          idempotencyKey: 'idem-backup-delta-02',
          targetService: 'backup_service',
          action: 'TRIGGER_DELTA_CHECKPOINT',
          payload: { reason: 'AUTOMATED_CRON' },
          priority: 'HIGH',
          attempts: 1,
          maxAttempts: 5,
          state: 'SYNCED',
          createdAt: now - 90000,
          lastAttemptAt: now - 89800,
        },
      ];
      this.processedIdempotencyKeys.add('idem-sync-audio-01');
      this.processedIdempotencyKeys.add('idem-backup-delta-02');
    }
  }

  public enqueue(
    targetService: ServiceName,
    action: string,
    payload: any,
    idempotencyKey?: string,
    priority: QueueItem['priority'] = 'NORMAL'
  ): { item?: QueueItem; rejected: boolean; reason?: string } {
    const key = idempotencyKey || `idem-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

    // Strict idempotency check
    if (this.processedIdempotencyKeys.has(key)) {
      return {
        rejected: true,
        reason: `Idempotency violation: key ${key} already executed or queued. Mutation duplicate blocked.`,
      };
    }

    const item: QueueItem = {
      id: `q-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      idempotencyKey: key,
      targetService,
      action,
      payload,
      priority,
      attempts: 0,
      maxAttempts: 5,
      state: 'QUEUED',
      createdAt: Date.now(),
    };

    this.processedIdempotencyKeys.add(key);
    this.queue.unshift(item);
    this.persistQueue();

    eventBus.publish(
      'queue.item.enqueued',
      { itemId: item.id, action: item.action, targetService: item.targetService, priority },
      'offline_queue'
    );

    this.notify();

    // If online, immediately trigger queue processing
    if (this.networkMode === 'ONLINE') {
      setTimeout(() => this.processNext(), 50);
    }

    return { item, rejected: false };
  }

  public async processNext(): Promise<boolean> {
    if (this.isProcessing || this.networkMode === 'OFFLINE') {
      return false;
    }

    const pending = this.queue.find((q) => q.state === 'QUEUED');
    if (!pending) {
      return false;
    }

    this.isProcessing = true;
    pending.state = 'PROCESSING';
    pending.attempts++;
    pending.lastAttemptAt = Date.now();
    this.notify();

    // Simulate network delay / flaky drop
    await new Promise((res) => setTimeout(res, 200));

    if (this.networkMode === 'FLAKY' && Math.random() < 0.5) {
      pending.state = pending.attempts >= pending.maxAttempts ? 'FAILED' : 'QUEUED';
      pending.errorMessage = `Transient network timeout (Attempt ${pending.attempts}/${pending.maxAttempts})`;
      this.isProcessing = false;
      this.persistQueue();
      this.notify();
      return false;
    }

    // Success
    pending.state = 'SYNCED';
    pending.errorMessage = undefined;

    await eventBus.publish(
      'queue.item.synced',
      {
        itemId: pending.id,
        targetService: pending.targetService,
        action: pending.action,
        latencyMs: Date.now() - pending.createdAt,
      },
      'offline_queue'
    );

    this.persistQueue();
    this.isProcessing = false;
    this.notify();

    // Process remaining
    if (this.networkMode === 'ONLINE') {
      this.processNext();
    }

    return true;
  }

  public async flushAll(): Promise<{ synced: number; failed: number }> {
    let synced = 0;
    let failed = 0;

    const queuedItems = this.queue.filter((q) => q.state === 'QUEUED' || q.state === 'FAILED');
    for (const item of queuedItems) {
      item.state = 'QUEUED';
      item.attempts = 0;
    }

    // Wait if another processNext is in flight
    let waitLoops = 0;
    while (this.isProcessing && waitLoops < 20) {
      waitLoops++;
      await new Promise((r) => setTimeout(r, 40));
    }

    let iterations = 0;
    while (this.queue.some((q) => q.state === 'QUEUED') && iterations < 50) {
      iterations++;
      while (this.isProcessing && waitLoops < 30) {
        await new Promise((r) => setTimeout(r, 20));
      }
      const ok = await this.processNext();
      if (ok) {
        synced++;
      } else {
        if (this.networkMode === 'OFFLINE') {
          failed++;
          break;
        }
        await new Promise((r) => setTimeout(r, 30));
      }
    }

    this.notify();
    return { synced, failed };
  }

  public setNetworkMode(mode: NetworkMode) {
    const prev = this.networkMode;
    this.networkMode = mode;

    eventBus.publish(
      'queue.network.state_changed',
      { previous: prev, current: mode },
      'offline_queue'
    );

    if (mode === 'ONLINE' && prev !== 'ONLINE') {
      this.flushAll();
    }

    this.notify();
  }

  public getNetworkMode(): NetworkMode {
    return this.networkMode;
  }

  public getQueue(): QueueItem[] {
    return [...this.queue];
  }

  public clearSynced(): number {
    const before = this.queue.length;
    this.queue = this.queue.filter((q) => q.state !== 'SYNCED');
    const cleared = before - this.queue.length;
    this.persistQueue();
    this.notify();
    return cleared;
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }
}

export const offlineQueue = new OfflineQueueService();
