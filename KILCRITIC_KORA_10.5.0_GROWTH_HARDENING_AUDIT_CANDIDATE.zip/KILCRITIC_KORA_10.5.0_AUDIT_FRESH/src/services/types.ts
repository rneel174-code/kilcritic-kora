export type ServiceName =
  | 'event_bus'
  | 'backup_service'
  | 'voice_transcription'
  | 'media_dedup'
  | 'system_doctor'
  | 'offline_queue';

export type ServiceStatus = 'OPERATIONAL' | 'DEGRADED' | 'HEALING' | 'OFFLINE';

export interface ServiceHealth {
  name: ServiceName;
  displayName: string;
  status: ServiceStatus;
  uptimeSeconds: number;
  memoryMb: number;
  latencyMs: number;
  throughputPerSec: number;
  lastHeartbeat: number;
  errorCount: number;
  version: string;
}

export interface BusEvent<T = any> {
  id: string;
  topic: string;
  source: ServiceName | 'user_ui';
  timestamp: number;
  payload: T;
  correlationId: string;
  status: 'PUBLISHED' | 'ACKED' | 'DLQ' | 'REPLAYED';
  attempts: number;
}

export interface BackupSnapshot {
  id: string;
  timestamp: number;
  checksum: string;
  sizeBytes: number;
  recordCount: number;
  status: 'VERIFIED' | 'PENDING' | 'CORRUPTED';
  type: 'INCREMENTAL' | 'FULL';
  metadata: {
    eventCount: number;
    transcriptionCount: number;
    dedupFingerprints: number;
    queuePending: number;
    doctorHealthScore: number;
  };
  payloadData?: string;
}

export interface AudioTranscript {
  id: string;
  timestamp: number;
  speaker: 'OPERATOR_1' | 'TACTICAL_LEAD' | 'KORA_CORE' | 'PILOT_ALPHA' | 'SYSTEM_DOCTOR';
  text: string;
  confidence: number; // 0.0 to 1.0
  durationSec: number;
  waveform: number[];
  keywords: string[];
  status: 'VERIFIED' | 'FLAGGED_LOW_CONF' | 'PROCESSING';
}

export interface MediaFingerprint {
  id: string;
  fileName: string;
  fileSizeKb: number;
  mimeType: 'image/jpeg' | 'image/png' | 'video/mp4' | 'audio/wav';
  sha256: string;
  perceptualHash: string; // 64-bit binary string
  clusterId: string;
  isDuplicate: boolean;
  duplicateOfId?: string;
  similarityScore: number; // 0-100%
  timestamp: number;
  thumbnailColor: string;
}

export interface DoctorProbe {
  id: string;
  timestamp: number;
  service: ServiceName;
  checkName: string;
  value: number | string;
  threshold: number | string;
  level: 'HEALTHY' | 'WARNING' | 'CRITICAL';
  message: string;
  remediated: boolean;
  remediationAction?: string;
}

export interface QueueItem {
  id: string;
  idempotencyKey: string;
  targetService: ServiceName;
  action: string;
  payload: any;
  priority: 'LOW' | 'NORMAL' | 'HIGH' | 'CRITICAL';
  attempts: number;
  maxAttempts: number;
  state: 'QUEUED' | 'PROCESSING' | 'SYNCED' | 'FAILED';
  createdAt: number;
  lastAttemptAt?: number;
  errorMessage?: string;
}

export interface TestCaseResult {
  id: number;
  name: string;
  service: ServiceName | 'system_suite';
  category: 'UNIT' | 'INTEGRATION' | 'CHAOS' | 'IDEMPOTENCY' | 'PERFORMANCE';
  description: string;
  durationMs: number;
  status: 'IDLE' | 'RUNNING' | 'PASS' | 'FAIL';
  assertion: string;
  logs: string[];
}
