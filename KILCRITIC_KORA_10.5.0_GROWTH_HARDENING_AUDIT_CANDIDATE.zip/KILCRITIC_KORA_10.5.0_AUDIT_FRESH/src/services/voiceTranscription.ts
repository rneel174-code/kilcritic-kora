import { AudioTranscript } from './types';
import { eventBus } from './eventBus';

const SAMPLE_KEYWORDS = [
  'RESTORE',
  'FAILOVER',
  'ENCRYPTION',
  'LATENCY',
  'HEARTBEAT',
  'SYNCHRONIZATION',
  'CHECKSUM',
  'QUORUM',
  'OFFLINE_QUEUE',
  'DEDUP_PURGE',
  'DOCTOR_PROBE',
];

class VoiceTranscriptionService {
  private transcripts: AudioTranscript[] = [];
  private isListening: boolean = false;
  private vadThreshold: number = 0.45; // energy threshold 0..1
  private currentEnergy: number = 0;
  private listeners: Array<() => void> = [];
  private recognitionInstance: any = null;

  constructor() {
    this.seedTranscripts();
  }

  private seedTranscripts() {
    const now = Date.now();
    this.transcripts = [
      {
        id: `vox-01-${now - 120000}`,
        timestamp: now - 120000,
        speaker: 'TACTICAL_LEAD',
        text: 'All six microservice telemetry streams reporting nominal status. Offline queue idle.',
        confidence: 0.98,
        durationSec: 4.8,
        waveform: [0.1, 0.4, 0.7, 0.9, 0.8, 0.6, 0.3, 0.5, 0.8, 0.4, 0.2],
        keywords: ['OFFLINE_QUEUE', 'HEARTBEAT'],
        status: 'VERIFIED',
      },
      {
        id: `vox-02-${now - 60000}`,
        timestamp: now - 60000,
        speaker: 'KORA_CORE',
        text: 'Automated snapshot verified with cryptographic SHA-256 match. Reclaimable dedup size 86 megabytes.',
        confidence: 0.96,
        durationSec: 5.2,
        waveform: [0.2, 0.6, 0.8, 0.95, 0.7, 0.4, 0.6, 0.9, 0.75, 0.3, 0.1],
        keywords: ['CHECKSUM', 'SYNCHRONIZATION', 'DEDUP_PURGE'],
        status: 'VERIFIED',
      },
      {
        id: `vox-03-${now - 20000}`,
        timestamp: now - 20000,
        speaker: 'OPERATOR_1',
        text: 'Requesting System Doctor full health diagnostics sweep across event bus and memory heap.',
        confidence: 0.94,
        durationSec: 3.9,
        waveform: [0.15, 0.3, 0.55, 0.8, 0.85, 0.7, 0.5, 0.3, 0.2],
        keywords: ['DOCTOR_PROBE', 'LATENCY'],
        status: 'VERIFIED',
      },
    ];
  }

  public extractKeywords(text: string): string[] {
    const upper = text.toUpperCase();
    return SAMPLE_KEYWORDS.filter((kw) => upper.includes(kw));
  }

  public generateSimulatedWaveform(samples: number = 16): number[] {
    return Array.from({ length: samples }, () => Number((Math.random() * 0.8 + 0.15).toFixed(2)));
  }

  public checkVadGate(audioEnergy: number): boolean {
    this.currentEnergy = audioEnergy;
    return audioEnergy >= this.vadThreshold;
  }

  public async processAudioBuffer(
    text: string,
    speaker: AudioTranscript['speaker'] = 'OPERATOR_1',
    forcedConfidence?: number
  ): Promise<AudioTranscript> {
    const confidence = forcedConfidence !== undefined ? forcedConfidence : Number((0.82 + Math.random() * 0.17).toFixed(2));
    const status = confidence < 0.75 ? 'FLAGGED_LOW_CONF' : 'VERIFIED';
    const keywords = this.extractKeywords(text);
    const waveform = this.generateSimulatedWaveform(18);

    const transcript: AudioTranscript = {
      id: `vox-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      speaker,
      text,
      confidence,
      durationSec: Math.max(1.8, Number((text.split(' ').length * 0.38).toFixed(1))),
      waveform,
      keywords,
      status,
    };

    this.transcripts.unshift(transcript);
    if (this.transcripts.length > 50) {
      this.transcripts.pop();
    }

    await eventBus.publish(
      status === 'FLAGGED_LOW_CONF' ? 'voice.transcription.flagged' : 'voice.transcription.recorded',
      {
        transcriptId: transcript.id,
        speaker: transcript.speaker,
        confidence: transcript.confidence,
        status: transcript.status,
        text: transcript.text,
      },
      'voice_transcription'
    );

    this.notify();
    return transcript;
  }

  public async recordSampleVoiceTransmission(): Promise<AudioTranscript> {
    const samples: Array<{ text: string; speaker: AudioTranscript['speaker']; conf: number }> = [
      { text: 'KILCRITIC 8.8.5 event bus latency under 2 milliseconds across all nodes.', speaker: 'OPERATOR_1', conf: 0.97 },
      { text: 'System doctor executing auto-recovery subroutine for event worker threads.', speaker: 'SYSTEM_DOCTOR', conf: 0.95 },
      { text: 'Voice transcription pipeline verified with 98.4 percent acoustic confidence.', speaker: 'KORA_CORE', conf: 0.99 },
      { text: 'Simulating flaky network node; offline queue buffering mutation payloads locally.', speaker: 'PILOT_ALPHA', conf: 0.92 },
      { text: 'Low SNR signal received: restore checksum validation indeterminate, repeating packet.', speaker: 'OPERATOR_1', conf: 0.68 },
    ];

    const pick = samples[Math.floor(Math.random() * samples.length)];
    return this.processAudioBuffer(pick.text, pick.speaker, pick.conf);
  }

  public getTranscripts(): AudioTranscript[] {
    return [...this.transcripts];
  }

  public getVadThreshold(): number {
    return this.vadThreshold;
  }

  public setVadThreshold(val: number) {
    this.vadThreshold = Math.max(0.1, Math.min(0.9, val));
    this.notify();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }
}

export const voiceTranscription = new VoiceTranscriptionService();
