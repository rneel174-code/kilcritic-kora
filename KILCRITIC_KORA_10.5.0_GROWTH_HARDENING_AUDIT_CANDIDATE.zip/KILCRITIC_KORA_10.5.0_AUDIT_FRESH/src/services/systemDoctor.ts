import { DoctorProbe, ServiceHealth, ServiceName } from './types';
import { eventBus } from './eventBus';
import { backupService } from './backupService';
import { mediaDedup } from './mediaDedup';

class SystemDoctorService {
  private probes: DoctorProbe[] = [];
  private healthScore: number = 100;
  private autoHealingEnabled: boolean = true;
  private servicesHealth: Record<ServiceName, ServiceHealth> = {
    event_bus: {
      name: 'event_bus',
      displayName: 'Event Bus Broker',
      status: 'OPERATIONAL',
      uptimeSeconds: 14220,
      memoryMb: 34.2,
      latencyMs: 1.4,
      throughputPerSec: 42,
      lastHeartbeat: Date.now(),
      errorCount: 0,
      version: '8.8.5-kora',
    },
    backup_service: {
      name: 'backup_service',
      displayName: 'Hardened Backup Engine',
      status: 'OPERATIONAL',
      uptimeSeconds: 14220,
      memoryMb: 28.5,
      latencyMs: 4.8,
      throughputPerSec: 12,
      lastHeartbeat: Date.now(),
      errorCount: 0,
      version: '8.8.5-kora',
    },
    voice_transcription: {
      name: 'voice_transcription',
      displayName: 'Voice Transcription & VAD',
      status: 'OPERATIONAL',
      uptimeSeconds: 14220,
      memoryMb: 52.1,
      latencyMs: 8.2,
      throughputPerSec: 18,
      lastHeartbeat: Date.now(),
      errorCount: 0,
      version: '8.8.5-kora',
    },
    media_dedup: {
      name: 'media_dedup',
      displayName: 'Media Deduplication (pHash)',
      status: 'OPERATIONAL',
      uptimeSeconds: 14220,
      memoryMb: 41.7,
      latencyMs: 6.1,
      throughputPerSec: 24,
      lastHeartbeat: Date.now(),
      errorCount: 0,
      version: '8.8.5-kora',
    },
    system_doctor: {
      name: 'system_doctor',
      displayName: 'System Doctor Self-Healer',
      status: 'OPERATIONAL',
      uptimeSeconds: 14220,
      memoryMb: 19.3,
      latencyMs: 0.8,
      throughputPerSec: 60,
      lastHeartbeat: Date.now(),
      errorCount: 0,
      version: '8.8.5-kora',
    },
    offline_queue: {
      name: 'offline_queue',
      displayName: 'Offline Resilient Queue',
      status: 'OPERATIONAL',
      uptimeSeconds: 14220,
      memoryMb: 22.4,
      latencyMs: 2.1,
      throughputPerSec: 35,
      lastHeartbeat: Date.now(),
      errorCount: 0,
      version: '8.8.5-kora',
    },
  };

  private listeners: Array<() => void> = [];
  private diagnosticInterval: any = null;

  constructor() {
    this.seedInitialProbes();
    this.startDiagnosticLoop();
  }

  private seedInitialProbes() {
    const now = Date.now();
    this.probes = [
      {
        id: `probe-01-${now - 180000}`,
        timestamp: now - 180000,
        service: 'event_bus',
        checkName: 'dlq_backpressure_check',
        value: '0 items',
        threshold: '< 5 items',
        level: 'HEALTHY',
        message: 'Dead letter queue clear. Message routing latency 1.4ms.',
        remediated: false,
      },
      {
        id: `probe-02-${now - 120000}`,
        timestamp: now - 120000,
        service: 'backup_service',
        checkName: 'sha256_manifest_audit',
        value: '100% verified',
        threshold: '100% verified',
        level: 'HEALTHY',
        message: 'All cryptographic checksums match store manifests.',
        remediated: false,
      },
      {
        id: `probe-03-${now - 60000}`,
        timestamp: now - 60000,
        service: 'system_doctor',
        checkName: 'cross_service_synthetic_pulse',
        value: '6/6 healthy',
        threshold: '6/6 healthy',
        level: 'HEALTHY',
        message: 'Full mesh communication validated with zero packet drops.',
        remediated: false,
      },
    ];
  }

  private startDiagnosticLoop() {
    if (typeof window !== 'undefined') {
      this.diagnosticInterval = setInterval(() => {
        this.runDiagnostics();
      }, 5000);
    }
  }

  public runDiagnostics(): DoctorProbe[] {
    const now = Date.now();
    const newProbes: DoctorProbe[] = [];
    const dlq = eventBus.getDLQ();

    // Probe 1: DLQ Depth
    if (dlq.length > 0) {
      const probe: DoctorProbe = {
        id: `probe-${now}-dlq`,
        timestamp: now,
        service: 'event_bus',
        checkName: 'dlq_overflow_detector',
        value: `${dlq.length} unrouted events`,
        threshold: '0 items',
        level: dlq.length > 5 ? 'CRITICAL' : 'WARNING',
        message: `Dead letter queue holds ${dlq.length} failed message(s).`,
        remediated: false,
      };

      if (this.autoHealingEnabled) {
        eventBus.flushDLQ();
        probe.remediated = true;
        probe.remediationAction = 'Auto-replayed DLQ and purged dead-letter records.';
      }

      newProbes.push(probe);
    }

    // Probe 2: Memory Heap
    const totalMemory = Object.values(this.servicesHealth).reduce((acc, s) => acc + s.memoryMb, 0);
    if (totalMemory > 280) {
      const probe: DoctorProbe = {
        id: `probe-${now}-mem`,
        timestamp: now,
        service: 'system_doctor',
        checkName: 'heap_footprint_threshold',
        value: `${totalMemory.toFixed(1)} MB`,
        threshold: '250.0 MB',
        level: 'WARNING',
        message: 'Memory footprint elevated across microservice runtime.',
        remediated: false,
      };

      if (this.autoHealingEnabled) {
        Object.keys(this.servicesHealth).forEach((k) => {
          this.servicesHealth[k as ServiceName].memoryMb = Number(
            (this.servicesHealth[k as ServiceName].memoryMb * 0.85).toFixed(1)
          );
        });
        probe.remediated = true;
        probe.remediationAction = 'Triggered proactive garbage collection & ring-buffer compaction.';
      }

      newProbes.push(probe);
    }

    // Probe 3: Media Dedup Accumulation
    const dedupStats = mediaDedup.getStats();
    if (dedupStats.duplicateCount >= 4) {
      const probe: DoctorProbe = {
        id: `probe-${now}-dedup`,
        timestamp: now,
        service: 'media_dedup',
        checkName: 'duplicate_spill_threshold',
        value: `${dedupStats.duplicateCount} duplicates`,
        threshold: '< 3 duplicates',
        level: 'WARNING',
        message: `High volume of redundant media (${dedupStats.reclaimableKb} KB reclaimable).`,
        remediated: false,
      };

      if (this.autoHealingEnabled) {
        const res = mediaDedup.purgeDuplicates();
        probe.remediated = true;
        probe.remediationAction = `Auto-purged ${res.purgedCount} redundant assets, reclaimed ${res.reclaimedKb} KB.`;
      }

      newProbes.push(probe);
    }

    // Default nominal probe if everything clean
    if (newProbes.length === 0) {
      newProbes.push({
        id: `probe-${now}-nom`,
        timestamp: now,
        service: 'system_doctor',
        checkName: 'heartbeat_integrity_pulse',
        value: 'All nominal',
        threshold: '100% pass',
        level: 'HEALTHY',
        message: 'Periodic synthetic health check passed across all 6 microservices.',
        remediated: false,
      });
    }

    // Add to probes list
    this.probes.unshift(...newProbes);
    if (this.probes.length > 60) {
      this.probes = this.probes.slice(0, 60);
    }

    // Update health metrics
    this.updateHealthScore();
    this.notify();
    return newProbes;
  }

  private updateHealthScore() {
    const recent = this.probes.slice(0, 10);
    const criticalCount = recent.filter((p) => p.level === 'CRITICAL' && !p.remediated).length;
    const warningCount = recent.filter((p) => p.level === 'WARNING' && !p.remediated).length;

    let score = 100 - criticalCount * 30 - warningCount * 10;
    this.healthScore = Math.max(20, Math.min(100, score));

    // Update service statuses
    Object.keys(this.servicesHealth).forEach((key) => {
      const sName = key as ServiceName;
      const sErrors = recent.filter((p) => p.service === sName && p.level !== 'HEALTHY');
      const hasUnremediated = sErrors.some((p) => !p.remediated);

      if (hasUnremediated) {
        this.servicesHealth[sName].status = 'DEGRADED';
      } else if (sErrors.some((p) => p.remediated)) {
        this.servicesHealth[sName].status = 'HEALING';
      } else {
        this.servicesHealth[sName].status = 'OPERATIONAL';
      }
      this.servicesHealth[sName].lastHeartbeat = Date.now();
    });
  }

  public injectChaos(scenario: 'dlq_spike' | 'memory_surge' | 'duplicate_flood') {
    const now = Date.now();
    if (scenario === 'dlq_spike') {
      eventBus.publish('fault.injected.dead_route', { corruptPayload: true }, 'system_doctor');
      // Intentionally simulate a failing subscriber
      const tempSub = eventBus.subscribe('fault.injected.*', 'system_doctor', () => {
        throw new Error('Simulated consumer timeout crash');
      });
      eventBus.publish('fault.injected.malformed_stream', { error: 'chaos_injected' }, 'system_doctor');
      setTimeout(() => eventBus.unsubscribe(tempSub), 1000);
    } else if (scenario === 'memory_surge') {
      Object.keys(this.servicesHealth).forEach((k) => {
        this.servicesHealth[k as ServiceName].memoryMb += 45;
      });
    } else if (scenario === 'duplicate_flood') {
      const sampleHash = '1111111100000000111111110000000011111111000000001111111100000000';
      for (let i = 0; i < 4; i++) {
        mediaDedup.registerMedia(`chaos_dup_asset_${i}.jpg`, 2400, 'image/jpeg', sampleHash);
      }
    }

    this.runDiagnostics();
  }

  public forceHealAll(): { actionsTaken: string[] } {
    const actions: string[] = [];

    const flushedDlq = eventBus.flushDLQ();
    if (flushedDlq > 0) {
      actions.push(`Flushed ${flushedDlq} dead letter queue items`);
    }

    const purged = mediaDedup.purgeDuplicates();
    if (purged.purgedCount > 0) {
      actions.push(`Purged ${purged.purgedCount} redundant media duplicates (${purged.reclaimedKb} KB)`);
    }

    backupService.enforceRetentionPolicy();
    actions.push('Enforced backup retention limits');

    // Reset service health
    Object.keys(this.servicesHealth).forEach((k) => {
      const s = this.servicesHealth[k as ServiceName];
      s.status = 'OPERATIONAL';
      s.memoryMb = Number((Math.random() * 20 + 20).toFixed(1));
      s.errorCount = 0;
    });

    this.healthScore = 100;
    this.notify();
    return { actionsTaken: actions };
  }

  public toggleAutoHealing(enabled?: boolean) {
    this.autoHealingEnabled = enabled !== undefined ? enabled : !this.autoHealingEnabled;
    this.notify();
    return this.autoHealingEnabled;
  }

  public isAutoHealing(): boolean {
    return this.autoHealingEnabled;
  }

  public getHealthScore(): number {
    return this.healthScore;
  }

  public getProbes(): DoctorProbe[] {
    return [...this.probes];
  }

  public getServicesHealth(): Record<ServiceName, ServiceHealth> {
    return { ...this.servicesHealth };
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }
}

export const systemDoctor = new SystemDoctorService();
