#!/usr/bin/env bash
# REAL-system_check.sh - honest environment probe. Every line is PASS/FAIL measured now, or NOT_AVAILABLE. Nothing is assumed.
# It never installs anything, never uses the network, never captures traffic unless tshark exists AND you pass --capture.
set -u
say(){ printf '%-34s %s\n' "$1" "$2"; }
command -v python3 >/dev/null && say python3 "PASS $(python3 -V 2>&1)" || say python3 "NOT_AVAILABLE"
python3 - <<'PY'
import os, shutil, sys
try:
    with open("/proc/meminfo") as f: m = {l.split(":")[0]: int(l.split()[1]) for l in f if ":" in l}
    print("%-34s %s" % ("ram_total_mb", m.get("MemTotal", 0) // 1024)); print("%-34s %s" % ("ram_available_mb", m.get("MemAvailable", 0) // 1024))
except Exception: print("%-34s %s" % ("ram", "NOT_AVAILABLE"))
print("%-34s %s" % ("cpu_count", os.cpu_count()))
print("%-34s %s" % ("disk_free_mb", shutil.disk_usage(".").free // (1024 * 1024)))
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM; print("%-34s %s" % ("aes_256_gcm", "PASS (cryptography AESGCM importable)"))
except Exception: print("%-34s %s" % ("aes_256_gcm", "NOT_AVAILABLE (secure_vault fails closed)"))
PY
for t in ffmpeg ffprobe adb tshark; do command -v "$t" >/dev/null && say "$t" "PASS" || say "$t" "NOT_AVAILABLE"; done
if command -v adb >/dev/null; then n=$(adb devices 2>/dev/null | awk 'NR>1 && $2=="device"' | wc -l); say "adb_devices" "$n connected (device benchmarks need >=1; otherwise UNVERIFIED)"; else say adb_devices "NOT_AVAILABLE"; fi
if [ "${1:-}" = "--capture" ]; then
  if command -v tshark >/dev/null; then say network_capture "tshark present: run  tshark -i <iface> -a duration:60 -w capture.pcap  yourself; 'zero outbound' is only claimable from that capture"; else say network_capture "NOT_AVAILABLE (no tshark: 'Wireshark 0' stays UNVERIFIED)"; fi
fi
say android_kotlin_build "NOT_AVAILABLE here (Kotlin/Gradle not built or run in this environment: UNVERIFIED)"
