"""
KORA 8.10.0 PRO - Real Release Packaging & Forbidden Artifact Scanner
"""
import os
import zipfile
import hashlib
import json
import sys

EXCLUDE_PATTERNS = {
    ".env",
    ".db",
    ".db-wal",
    ".db-shm",
    ".pyc",
    "__pycache__",
    "node_modules",
    ".git",
    ".zip",
    ".pytest_cache",
    "kora_complete_source_code.txt",
    "data/temp",
    "data/media_store",
    "data/backups",
    ".log",
    "data/",
}

FORBIDDEN_KEYWORDS = [
    ".env",
    ".db",
    ".pyc",
    "__pycache__",
    "id_rsa",
    ".pem",
    "secrets.json"
]

def should_exclude(file_path: str) -> bool:
    normalized = file_path.replace("\\", "/")
    for pattern in EXCLUDE_PATTERNS:
        if pattern in normalized or normalized.endswith(pattern):
            return True
    return False

def package_release(output_zip: str = "KILCRITIC_SUPREME_10.2_FINAL.zip"):
    print(f"[PACKAGING] Building verified release ZIP: {output_zip}...")

    # 1. Package clean files
    file_count = 0
    manifest = {}
    with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk("."):
            dirs[:] = [d for d in dirs if d not in {"node_modules", ".git", "__pycache__", "dist", "data"}]
            for file in files:
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, ".")

                if should_exclude(rel_path) or rel_path == output_zip or rel_path.replace("\\", "/") == "INTEGRITY_MANIFEST.json":
                    continue

                zf.write(full_path, rel_path)
                with open(full_path, "rb") as fh:
                    manifest[rel_path.replace("\\", "/")] = hashlib.sha256(fh.read()).hexdigest()
                file_count += 1
        zf.writestr("INTEGRITY_MANIFEST.json", json.dumps({"files": dict(sorted(manifest.items())), "algorithm": "sha256"}, indent=1))

    # 2. Verify with testzip()
    print("[VERIFYING] Executing zipfile testzip()...")
    with zipfile.ZipFile(output_zip, "r") as zf:
        corrupt_file = zf.testzip()
        if corrupt_file:
            print(f"[FATAL] Corruption found in zip file: {corrupt_file}")
            sys.exit(1)
        print("[VERIFIED] testzip() passed with 0 corruptions.")

        # 3. Forbidden Artifact Scan
        print("[AUDIT] Running Forbidden Artifact Scanner on all archive entries...")
        infolist = zf.infolist()
        for info in infolist:
            name_lower = info.filename.lower()
            for forbidden in FORBIDDEN_KEYWORDS:
                if forbidden in name_lower:
                    if forbidden == ".env" and "env.example" in name_lower:
                        continue  # .env.example is explicitly allowed
                    print(f"[SECURITY VIOLATION] Forbidden artifact detected in release zip: {info.filename}")
                    sys.exit(1)
        print(f"[AUDIT PASSED] 0 forbidden artifacts detected across {len(infolist)} packaged files.")

    # 4. Calculate exact file size and SHA-256
    file_size = os.path.getsize(output_zip)
    hasher = hashlib.sha256()
    with open(output_zip, "rb") as f:
        while chunk := f.read(65536):
            hasher.update(chunk)
    sha256_hex = hasher.hexdigest()

    abs_path = os.path.abspath(output_zip)
    print("\n" + "=" * 60)
    print("RELEASE PACKAGING & SECURITY SCAN SUCCESSFUL")
    print(f"File Count Included: {file_count}")
    print(f"Absolute Path:       {abs_path}")
    print(f"File Size (Bytes):   {file_size}")
    print(f"SHA-256 Digest:      {sha256_hex}")
    print("=" * 60)

    with open(output_zip + ".sha256", "w") as fh:
        fh.write(f"{sha256_hex}  {os.path.basename(output_zip)}\n")
    return {
        "path": abs_path,
        "size_bytes": file_size,
        "sha256": sha256_hex,
        "file_count": file_count
    }

if __name__ == "__main__":
    package_release()
