"""Legacy entrypoint `app.main:app` -> the KORA PRO bridge (kora.bridge.api)."""
from kora.bridge.api import app  # noqa: F401
