# KORA INFINITE CORE 5.0

## Goal
Make large workloads *manageable* on small devices through out-of-core processing,
lazy loading, bounded concurrency, backpressure and checkpoint-friendly execution.

### Included
- Adaptive RAM/CPU tiering
- LITE sequential evidence mode
- Bounded parallel mode for larger devices
- Chunked streaming for very large files
- mmap when practical, with a normal file-read fallback
- Lazy module loading
- No duplicate scheduler/queue/security/permission engine
- No fake CPU/RAM/GPU/network capacity

### Important truth
A 2 GB device cannot physically become a 32 GB/100 GB computer. This layer avoids
loading the whole workload into RAM and uses the available hardware efficiently.
Some tasks remain limited by CPU, GPU, storage, network, provider limits or algorithmic
requirements. Those tasks must degrade, queue, checkpoint, or report UNAVAILABLE.

## Existing-system rule
Before adding another engine, KORA must reuse the existing Resource Governor,
Smart Scheduler, Capability Graph, Queue, Permission Engine, Circuit Breaker,
Checkpoint/Resume and Provider Router when present.
