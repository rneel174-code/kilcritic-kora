# 2026 Research Gap Audit — KORA/KILCRITIC

## What changed

This audit was performed after the existing Godfather + Living Runtime architecture was locked. The goal was to identify **genuine architectural gaps**, not to increase the module count.

### High-value findings incorporated

- Per-action permission is insufficient when individually permitted actions can form an unsafe trajectory.
- Agent safety is increasingly framed as a runtime contract with both preventive enforcement and evidential proof.
- Long-horizon systems need trajectory-aware validation, bounded horizons, deterministic replay and runtime evidence.
- Delegation requires identity, capability scope and attributable parent/child provenance.
- Memory is a security/control boundary and must support integrity, trust and staleness handling.
- Tool and dependency interfaces are supply-chain surfaces and should be continuously validated.
- Runtime execution needs durable state, checkpointing and recovery rather than whole-task restart.

### New architectural rule

**The unit of trust is the governed execution trajectory with checkable evidence — not merely the model output.**

## Research sources checked

- *Securing Agentic AI: From Per-Action Checks to Trajectory Assurance* — arXiv:2608.01558 (2026).
- *Agent Safety Should Be a Runtime Contract* — arXiv:2608.11274 (2026).
- *A Trace-Based Assurance Framework for Agentic AI Orchestration: Contracts, Testing, and Governance* — arXiv:2603.18096 (2026).
- *Proof of Execution: Runtime Verification for Governed AI Agent Actions* — arXiv:2607.05397 (2026).
- *Beyond Component Testing: Validating Agentic AI Systems* — arXiv:2607.29405 (2026).
- *AgentOps Pattern Catalogue* — Information and Software Technology, 2026.

These papers inform the architecture; they do not imply that KORA has implemented or independently validated every research claim.
