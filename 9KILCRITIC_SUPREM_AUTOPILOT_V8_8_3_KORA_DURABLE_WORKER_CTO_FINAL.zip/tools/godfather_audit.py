#!/usr/bin/env python3
"""Static Godfather release audit. Read-only; never edits the repository."""
from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[1]
required = [
    'app/services/godfather.py',
    'app/services/executive.py',
    'app/services/brahma.py',
    'app/services/security.py',
    'app/main.py',
    '.gitignore',
    'GODFATHER_ULTRA_PROTOCOL.md',
]
missing = [x for x in required if not (ROOT/x).exists()]
if missing:
    print('FAIL: missing:', ', '.join(missing)); raise SystemExit(2)
source = '\n'.join(p.read_text(encoding='utf-8', errors='ignore') for p in ROOT.rglob('*') if p.is_file() and p.suffix in {'.py','.md','.html','.js'} and p.name != 'universal_regression.py')
bad_patterns = (r'100\s*%\s*(?:safe|secure)', r'hack[- ]proof', r'AES-256\s+ON\s*-\s*No\s+leak')
for pattern in bad_patterns:
    if re.search(pattern, source, flags=re.I):
        print('FAIL: absolute security marker detected'); raise SystemExit(2)
if 'automatic_code_write' not in (ROOT/'app/services/brahma.py').read_text():
    print('FAIL: Brahma safety contract missing'); raise SystemExit(2)
if 'automatic_self_deploy' not in source:
    print('FAIL: self-deploy rule missing'); raise SystemExit(2)
print('PASS: Godfather static audit')
print('required files:', len(required))
print('routes: /api/godfather, /api/godfather/audit, /api/godfather/tools, /api/godfather/plan, /api/godfather/verify, /api/godfather/release-manifest, /api/godfather/discovery')
