# 8.8.3 — KORA DURABLE WORKER CTO HARDENED

Release version: `8.8.3-KORA-DURABLE-WORKER-CTO-HARDENED`

- Fixed background worker name-shadowing: execution workers and reminder workers now start independently.
- Added real bounded durable SQLite job queue processing with registered handlers only.
- Added atomic queue claims, leases, stale-lease recovery, retries/backoff, cancellation, idempotency keys and bounded payload size.
- Added execution worker pool sizing and truthful worker/queue diagnostics.
- Hardened schedule claims with worker leases and duplicate-publish protection.
- Hardened token comparison with constant-time comparison.
- Blocked non-local plain HTTP outbound destinations; external connectors remain HTTPS-only.
- Fixed release filenames to canonical `.gitignore` and `.env.example`.
- Preserved existing routes, platform boundaries, approval gates, Brahma safe-cycle and additive architecture.
