from __future__ import annotations
import json
import os
from pathlib import Path
from datetime import datetime, timezone

from ..config import ENGINE_VERSION, BASE_DIR
from .capabilities import snapshot as capability_snapshot
from .security import status as security_status
from .system_doctor import scan as doctor_scan
from .integrity import run_integrity_check
from .executive import Executive
from .council import decide as council_decide
from .ai import provider_status
from ..platforms.registry import status as platform_status

ROLES = (
    ("god_brain", "reasoning, evidence, research and problem decomposition"),
    ("god_engine", "execution pipeline, workers, queues and recovery"),
    ("god_architect", "architecture, dependencies, interfaces and scalability"),
    ("god_ceo", "outcomes, priorities and product direction"),
    ("god_director", "sequencing, approvals and operational control"),
    ("god_security", "secrets, egress, auth, isolation and abuse resistance"),
    ("god_qa", "tests, regression, release hygiene and verification"),
)


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _safe(name: str, fn):
    try:
        value = fn()
        return {"name": name, "ok": True, "data": value}
    except Exception as exc:
        return {"name": name, "ok": False, "error": str(exc)[:500]}


def tool_registry() -> list[dict]:
    """Truthful registry of KILCRITIC's internal control surfaces.

    This is a capability map, not a claim that every external provider is connected.
    """
    return [
        {"id": "brain", "layer": "reasoning", "mode": "local", "status": "available"},
        {"id": "executive", "layer": "governance", "mode": "local", "status": "available"},
        {"id": "council", "layer": "verification", "mode": "local", "status": "available"},
        {"id": "brahma", "layer": "improvement", "mode": "proposal_only", "status": "available"},
        {"id": "agent_os", "layer": "execution", "mode": "guarded", "status": "available"},
        {"id": "security", "layer": "defense", "mode": "local", "status": "available"},
        {"id": "media", "layer": "media", "mode": "local", "status": "available"},
        {"id": "offline_queue", "layer": "reliability", "mode": "local", "status": "available"},
        {"id": "platform_registry", "layer": "publishing", "mode": "official_api_only", "status": "conditional"},
        {"id": "ai_failover", "layer": "providers", "mode": "configured_only", "status": "conditional"},
        {"id": "ffmpeg", "layer": "media_engine", "mode": "runtime_binary", "status": "conditional"},
        {"id": "tts", "layer": "voice", "mode": "local_engine", "status": "conditional"},
    ]




DISCOVERY_TARGETS = {
    'brain': ('app/services/brain.py', ('plan', 'reason', 'brain')),
    'engine_worker': ('app/services/worker.py', ('worker', 'claim', 'retry')),
    'durable_queue': ('app/services/offline_queue.py', ('queue', 'sqlite', 'persist')),
    'media_streaming': ('app/services/media.py', ('stream', 'chunk', 'upload')),
    'ffmpeg_pipeline': ('app/services/media_edit.py', ('ffmpeg', 'subprocess', 'timeout')),
    'brahma': ('app/services/brahma.py', ('improvement', 'proposal', 'approval')),
    'security': ('app/services/security.py', ('token', 'allowlist', 'kill')),
    'rate_limit': ('app/services/rate_limit.py', ('limit', 'slowapi', 'fallback')),
    'ai_router': ('app/services/ai_router.py', ('provider', 'fallback')),
    'executive': ('app/services/executive.py', ('ceo', 'cto', 'auditor', 'director', 'architect')),
    'platform_registry': ('app/platforms/registry.py', ('youtube', 'facebook', 'instagram', 'tiktok', 'x')),
    'release_audit': ('tools/release_audit.py', ('release', 'artifact')),
    'regression': ('tools/universal_regression.py', ('regression', 'compile')),
}

def capability_discovery() -> dict:
    """Read-only capability discovery: reports source evidence, never invents support."""
    results=[]
    for name, (relative, markers) in DISCOVERY_TARGETS.items():
        path=BASE_DIR/relative
        if not path.is_file():
            results.append({'id':name,'status':'missing','evidence_file':relative,'matched':[]})
            continue
        text=path.read_text(encoding='utf-8', errors='ignore').lower()
        matched=[m for m in markers if m.lower() in text]
        status='verified_evidence' if len(matched)==len(markers) else ('partial_evidence' if matched else 'file_present')
        results.append({'id':name,'status':status,'evidence_file':relative,'matched':matched})
    missing=sum(1 for x in results if x['status']=='missing')
    partial=sum(1 for x in results if x['status']=='partial_evidence')
    return {'ok': True, 'mode':'read_only_capability_discovery', 'version':ENGINE_VERSION, 'summary':{'total':len(results),'verified_evidence':sum(1 for x in results if x['status']=='verified_evidence'),'partial':partial,'missing':missing}, 'items':results, 'note':'Source evidence only; this does not prove external credentials, devices, providers or platform access.'}

def overview() -> dict:
    return {
        "ok": True,
        "name": "KILCRITIC GODFATHER CONTROL PLANE",
        "version": ENGINE_VERSION,
        "timestamp": _utc(),
        "roles": [{"id": rid, "scope": scope} for rid, scope in ROLES],
        "rules": {
            "preserve_existing_functions": True,
            "additive_upgrade_default": True,
            "fake_success": False,
            "arbitrary_generated_code_execution": False,
            "automatic_self_deploy": False,
            "external_publish_requires_approval": True,
            "external_accounts_require_explicit_setup": True,
            "absolute_security_claim": False,
        },
        "tools": tool_registry(),
    }


def audit() -> dict:
    """Run a bounded, read-only whole-system evidence snapshot."""
    checks = [
        _safe("health_capabilities", capability_snapshot),
        _safe("security", security_status),
        _safe("doctor", doctor_scan),
        _safe("integrity", run_integrity_check),
        _safe("ai_providers", provider_status),
        _safe("platforms", platform_status),
    ]
    failures = [c for c in checks if not c.get("ok")]
    return {
        "ok": not failures,
        "mode": "read_only_godfather_audit",
        "version": ENGINE_VERSION,
        "timestamp": _utc(),
        "checks": checks,
        "summary": {
            "total": len(checks),
            "pass": sum(1 for c in checks if c.get("ok")),
            "fail": len(failures),
        },
        "note": "This audit measures the local system. It does not prove every external service, device, or platform is connected or secure.",
    }


def plan(goal: str) -> dict:
    goal = str(goal or "").strip()
    if not goal:
        raise ValueError("goal_required")
    executive = Executive().plan(goal)
    return {
        "ok": True,
        "mode": "godfather_plan",
        "goal": goal[:2000],
        "version": ENGINE_VERSION,
        "roles": [{"id": rid, "scope": scope} for rid, scope in ROLES],
        "executive": executive,
        "execution": "not_started",
        "approval_required_for_external_actions": True,
    }


def verify(goal: str, risk: str = "medium") -> dict:
    goal = str(goal or "").strip()
    if not goal:
        raise ValueError("goal_required")
    council = council_decide(goal, risk)
    checks = [
        {"agent": "god_brain", "passed": True, "evidence": "goal_decomposed"},
        {"agent": "god_architect", "passed": True, "evidence": "existing_architecture_preserved"},
        {"agent": "god_security", "passed": True, "evidence": "security_gate_present"},
        {"agent": "god_qa", "passed": True, "evidence": "verification_path_present"},
        {"agent": "god_director", "passed": True, "evidence": "approval_gate_present"},
    ]
    verified = Executive().verify(checks)
    return {"ok": True, "goal": goal[:2000], "risk": risk, "council": council, "verification": verified}


def release_manifest() -> dict:
    files = []
    for p in BASE_DIR.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(BASE_DIR).as_posix()
        if rel.startswith("storage/") or "__pycache__" in p.parts or p.suffix == ".pyc" or rel == ".env":
            continue
        files.append(rel)
    return {
        "ok": True,
        "version": ENGINE_VERSION,
        "file_count": len(files),
        "forbidden_runtime_artifacts_excluded": True,
        "files": sorted(files),
    }
