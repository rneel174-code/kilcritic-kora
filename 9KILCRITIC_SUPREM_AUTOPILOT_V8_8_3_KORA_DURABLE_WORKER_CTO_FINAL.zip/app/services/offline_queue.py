from __future__ import annotations
import json
from datetime import datetime, timezone, timedelta
from uuid import uuid4
from ..db import execute, execute_rowcount, rows, now, conn
from ..config import MAX_QUEUE_SIZE, OFFLINE_PAYLOAD_MAX_BYTES, WORKER_LEASE_SECONDS

SAFE_KINDS = {"command", "maintenance.recovery", "maintenance.reminder_poll"}
TERMINAL = {"done", "failed", "cancelled"}

def _payload_json(payload: dict) -> str:
    raw=json.dumps(payload or {}, ensure_ascii=False, separators=(",", ":"))
    if len(raw.encode("utf-8")) > OFFLINE_PAYLOAD_MAX_BYTES:
        raise ValueError("offline_payload_too_large")
    return raw

def enqueue(kind: str, payload: dict, idempotency_key: str | None = None) -> dict:
    kind=str(kind or "").strip()[:80]
    if kind not in SAFE_KINDS:
        raise ValueError("unsupported_queue_job_kind")
    raw=_payload_json(payload)
    key=idempotency_key[:160] if idempotency_key else None
    qid=str(uuid4()); t=now()
    with conn() as c:
        c.execute("BEGIN IMMEDIATE")
        if key:
            existing=c.execute("SELECT id,status FROM offline_queue WHERE idempotency_key=?",(key,)).fetchone()
            if existing:
                c.commit()
                return {"ok":True,"id":existing[0],"status":existing[1],"deduplicated":True,"durable":True}
        active=c.execute("SELECT COUNT(*) FROM offline_queue WHERE status IN ('queued','processing')").fetchone()[0]
        if active >= MAX_QUEUE_SIZE:
            c.rollback()
            raise ValueError("offline_queue_full")
        c.execute("INSERT INTO offline_queue(id,kind,payload_json,status,attempts,next_attempt_at,last_error,created_at,updated_at,lease_until,worker_id,result_json,idempotency_key) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (qid,kind,raw,"queued",0,t,None,t,t,None,None,None,key))
        c.commit()
    return {"ok":True,"id":qid,"status":"queued","durable":True}

def list_items(limit:int=50) -> list[dict]:
    return rows("SELECT id,kind,status,attempts,next_attempt_at,last_error,created_at,updated_at,lease_until,worker_id,idempotency_key FROM offline_queue ORDER BY created_at DESC LIMIT ?", (max(1,min(200,int(limit))),))

def stats() -> dict:
    rows_ = rows("SELECT status,COUNT(*) n FROM offline_queue GROUP BY status")
    return {"ok":True,"durable":True,"counts":{r["status"]:r["n"] for r in rows_},"max_active":MAX_QUEUE_SIZE}

def recover_expired() -> int:
    t=now()
    return execute_rowcount("UPDATE offline_queue SET status='queued',lease_until=NULL,worker_id=NULL,last_error=COALESCE(last_error,'worker_lease_expired'),updated_at=? WHERE status='processing' AND lease_until IS NOT NULL AND lease_until<?",(t,t))

def claim(worker_id:str, lease_seconds:int=WORKER_LEASE_SECONDS):
    lease=(datetime.now(timezone.utc)+timedelta(seconds=max(30,int(lease_seconds)))).isoformat()
    with conn() as c:
        c.execute("BEGIN IMMEDIATE")
        row=c.execute("SELECT * FROM offline_queue WHERE status='queued' AND next_attempt_at<=? ORDER BY created_at LIMIT 1",(now(),)).fetchone()
        if not row:
            c.commit(); return None
        cur=c.execute("UPDATE offline_queue SET status='processing',lease_until=?,worker_id=?,updated_at=? WHERE id=? AND status='queued'",(lease,worker_id,now(),row[0]))
        if cur.rowcount != 1:
            c.rollback(); return None
        c.commit()
        return dict(c.execute("SELECT * FROM offline_queue WHERE id=?",(row[0],)).fetchone())

def mark_done(qid:str,result:dict) -> None:
    raw=json.dumps(result or {},ensure_ascii=False)[:5000]
    execute("UPDATE offline_queue SET status='done',lease_until=NULL,worker_id=NULL,last_error=NULL,result_json=?,updated_at=? WHERE id=? AND status='processing'",(raw,now(),qid))

def mark_retry(qid:str,error:str,attempts:int) -> None:
    delay=min(3600, max(5, 2**min(attempts,10)))
    nxt=(datetime.now(timezone.utc)+timedelta(seconds=delay)).isoformat()
    execute("UPDATE offline_queue SET status='queued',attempts=?,next_attempt_at=?,last_error=?,lease_until=NULL,worker_id=NULL,updated_at=? WHERE id=? AND status='processing'",(attempts,nxt,str(error)[:500],now(),qid))

def mark_failed(qid:str,error:str,attempts:int) -> None:
    execute("UPDATE offline_queue SET status='failed',attempts=?,last_error=?,lease_until=NULL,worker_id=NULL,updated_at=? WHERE id=? AND status='processing'",(attempts,str(error)[:500],now(),qid))

def cancel(qid:str) -> bool:
    return bool(execute_rowcount("UPDATE offline_queue SET status='cancelled',lease_until=NULL,worker_id=NULL,updated_at=? WHERE id=? AND status IN ('queued','processing')",(now(),qid)))

def purge_terminal(older_than_hours:int=72) -> int:
    cutoff=(datetime.now(timezone.utc)-timedelta(hours=max(1,int(older_than_hours)))).isoformat()
    return execute_rowcount("DELETE FROM offline_queue WHERE status IN ('done','failed','cancelled') AND updated_at<?",(cutoff,))

# Backward-compatible helper retained for existing callers.
def pending_payloads(limit:int=20) -> list[dict]:
    return rows("SELECT * FROM offline_queue WHERE status='queued' AND next_attempt_at<=? ORDER BY created_at LIMIT ?", (now(),max(1,min(100,int(limit)))))

def mark_sent(qid:str) -> None:
    mark_done(qid,{"legacy_status":"sent"})
