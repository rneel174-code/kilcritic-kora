from ..db import execute, execute_rowcount, rows, now
from datetime import datetime, timezone

def recover_stale_jobs():
    current=now()
    stale=rows("SELECT id FROM schedules WHERE status='executing' AND (lease_until IS NULL OR lease_until<?)",(current,))
    recovered=0
    for item in stale:
        execute("UPDATE schedules SET status='retry_wait',lease_until=NULL,worker_id=NULL,next_attempt_at=?,last_error=? WHERE id=? AND status='executing'",(current,'worker_lease_recovered',item['id']))
        recovered += 1
    return {'recovered':recovered,'safe_state':True,'at':current}
