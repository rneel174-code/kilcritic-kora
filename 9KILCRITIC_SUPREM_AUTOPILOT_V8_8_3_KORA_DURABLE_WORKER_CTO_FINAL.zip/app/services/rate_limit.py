from __future__ import annotations

import inspect
import re
import threading
import time
from collections import defaultdict, deque
from functools import wraps

from fastapi import Request
from fastapi.responses import JSONResponse

try:
    from slowapi import Limiter
    from slowapi.errors import RateLimitExceeded
    from slowapi.util import get_remote_address
    SLOWAPI_AVAILABLE = True
    limiter = Limiter(key_func=get_remote_address)
except Exception:  # pragma: no cover - exercised when optional dependency is absent.
    SLOWAPI_AVAILABLE = False
    RateLimitExceeded = Exception

    _WINDOWS = {'second': 1.0, 'minute': 60.0, 'hour': 3600.0, 'day': 86400.0}
    _RATE_RE = re.compile(r'^\s*(\d+)\s*/\s*(second|minute|hour|day)s?\s*$')
    _BUCKETS: dict[tuple[str, str], deque[float]] = defaultdict(deque)
    _LOCK = threading.Lock()

    def _parse_limit(value: str) -> tuple[int, float]:
        match = _RATE_RE.match(str(value))
        if not match:
            raise ValueError(f'unsupported_rate_limit:{value}')
        count = max(1, int(match.group(1)))
        window = _WINDOWS[match.group(2)]
        return count, window

    def _client_key(request: Request) -> str:
        # Prefer the address FastAPI actually sees. Do not trust forwarded headers.
        return request.client.host if request.client else 'unknown'

    class _BuiltinLimiter:
        """Small in-process fallback used only when SlowAPI is unavailable.

        SlowAPI remains the preferred production provider. This fallback prevents a
        missing dependency from silently disabling protection during offline/local
        testing. It is intentionally bounded and process-local; multi-process
        deployments should install SlowAPI and use an appropriate shared limiter.
        """

        def limit(self, value: str):
            count, window = _parse_limit(value)

            def decorator(fn):
                if inspect.iscoroutinefunction(fn):
                    @wraps(fn)
                    async def async_wrapper(*args, **kwargs):
                        request = kwargs.get('request') or next((a for a in args if isinstance(a, Request)), None)
                        if request is None:
                            return await fn(*args, **kwargs)
                        if not _allow(request, fn.__module__ + ':' + fn.__qualname__, count, window):
                            return JSONResponse(status_code=429, content={
                                'ok': False,
                                'error': 'rate_limit_exceeded',
                                'message': 'Too many requests. Please wait and try again.',
                            })
                        return await fn(*args, **kwargs)
                    return async_wrapper

                @wraps(fn)
                def sync_wrapper(*args, **kwargs):
                    request = kwargs.get('request') or next((a for a in args if isinstance(a, Request)), None)
                    if request is None:
                        return fn(*args, **kwargs)
                    if not _allow(request, fn.__module__ + ':' + fn.__qualname__, count, window):
                        return JSONResponse(status_code=429, content={
                            'ok': False,
                            'error': 'rate_limit_exceeded',
                            'message': 'Too many requests. Please wait and try again.',
                        })
                    return fn(*args, **kwargs)
                return sync_wrapper

            return decorator

    def _allow(request: Request, route: str, count: int, window: float) -> bool:
        key = (_client_key(request), route)
        now = time.monotonic()
        with _LOCK:
            bucket = _BUCKETS[key]
            cutoff = now - window
            while bucket and bucket[0] <= cutoff:
                bucket.popleft()
            if len(bucket) >= count:
                return False
            bucket.append(now)
            # Keep fallback state bounded even if many routes/clients are exercised.
            if len(_BUCKETS) > 2048:
                stale = [k for k, b in _BUCKETS.items() if not b or b[-1] <= cutoff]
                for stale_key in stale[:512]:
                    _BUCKETS.pop(stale_key, None)
            return True

    limiter = _BuiltinLimiter()


def install(app) -> None:
    """Install rate limiting without making offline startup depend on SlowAPI."""
    app.state.limiter = limiter
    if SLOWAPI_AVAILABLE:
        @app.exception_handler(RateLimitExceeded)
        async def _rate_limit_handler(request, exc):
            return JSONResponse(
                status_code=429,
                content={
                    'ok': False,
                    'error': 'rate_limit_exceeded',
                    'message': 'Too many requests. Please wait and try again.',
                },
            )


def status() -> dict:
    return {
        'enabled': True,
        'provider': 'slowapi' if SLOWAPI_AVAILABLE else 'builtin_fallback',
        'dependency_required': not SLOWAPI_AVAILABLE,
        'key': 'remote client address',
        'scope': 'process_local_fallback' if not SLOWAPI_AVAILABLE else 'slowapi',
        'note': 'Install SlowAPI for multi-process/shared production rate limiting; builtin fallback remains active for offline/local safety.' if not SLOWAPI_AVAILABLE else 'SlowAPI active.',
    }
