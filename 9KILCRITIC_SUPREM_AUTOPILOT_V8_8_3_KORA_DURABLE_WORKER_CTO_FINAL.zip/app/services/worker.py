from __future__ import annotations
import time
from datetime import datetime,timezone,timedelta
from threading import Event,Thread,Lock
from uuid import uuid4
from ..db import execute,execute_rowcount,rows,now
from ..config import WORKER_COUNT,WORKER_LEASE_SECONDS,OFFLINE_JOB_TIMEOUT_SECONDS
from .performance import WORKER_INTERVAL,MAX_RETRIES,backoff_seconds
from .recovery import recover_stale_jobs
from .offline_queue import claim,recover_expired,mark_done,mark_retry,mark_failed,stats as queue_stats
from .security import get_kill_switch
from ..platforms.registry import get

STOP=Event(); THREADS=[]; START_LOCK=Lock(); WORKER_IDS=[]

def _due_schedules():
    current=datetime.now(timezone.utc).isoformat()
    return rows("SELECT * FROM schedules WHERE status IN ('approved','retry_wait') AND COALESCE(next_attempt_at,publish_at)<=? AND (lease_until IS NULL OR lease_until<=?) ORDER BY publish_at LIMIT 10",(current,current))

def _publish_tick(worker_id:str):
    if get_kill_switch()['active']: return 0
    processed=0
    for item in _due_schedules():
        lease=(datetime.now(timezone.utc)+timedelta(seconds=WORKER_LEASE_SECONDS)).isoformat()
        claimed=execute_rowcount("UPDATE schedules SET status='executing',lease_until=?,worker_id=? WHERE id=? AND status IN ('approved','retry_wait') AND (lease_until IS NULL OR lease_until<=?) AND external_id IS NULL",(lease,worker_id,item['id'],datetime.now(timezone.utc).isoformat()))
        if claimed != 1: continue
        fresh=rows("SELECT * FROM schedules WHERE id=? AND status='executing' AND worker_id=?",(item['id'],worker_id))
        if not fresh: continue
        item=fresh[0]; media=rows("SELECT * FROM media WHERE id=? AND status='ready'",(item['media_id'],)); adapter=get(item['platform'])
        if not media or adapter is None:
            execute("UPDATE schedules SET status='failed',last_error=?,lease_until=NULL,worker_id=NULL WHERE id=?",('media_or_adapter_missing',item['id'])); continue
        try:
            payload={**item,'media_path':media[0]['path'],'media_name':media[0]['name'],'media_kind':media[0]['kind']}
            if item.get('thumbnail_media_id'):
                thumbs=rows("SELECT * FROM media WHERE id=? AND status='ready' AND kind='image'",(item['thumbnail_media_id'],))
                if thumbs: payload['thumbnail_path']=thumbs[0]['path']
            import json
            try: payload.update(json.loads(item.get('metadata_json') or '{}'))
            except Exception: pass
            result=adapter.publish(payload)
            if result.get('ok') and result.get('external_id'):
                ext=result['external_id']; execute("UPDATE schedules SET status='published',external_id=?,last_error=NULL,lease_until=NULL,worker_id=NULL WHERE id=? AND status='executing'",(ext,item['id'])); execute('INSERT INTO publish_events VALUES (?,?,?,?,?,?,?)',(str(uuid4()),item['id'],item['platform'],ext,'published',None,now())); processed+=1
            else:
                attempt=int(item.get('attempts') or 0)+1; err=str(result.get('error','publish_failed'))[:500]
                if attempt<=MAX_RETRIES:
                    nxt=(datetime.now(timezone.utc)+timedelta(seconds=backoff_seconds(attempt))).isoformat(); execute("UPDATE schedules SET status='retry_wait',attempts=?,next_attempt_at=?,last_error=?,lease_until=NULL,worker_id=NULL WHERE id=? AND status='executing'",(attempt,nxt,err,item['id']))
                else: execute("UPDATE schedules SET status='failed',attempts=?,last_error=?,lease_until=NULL,worker_id=NULL WHERE id=? AND status='executing'",(attempt,err,item['id']))
                execute('INSERT INTO publish_events VALUES (?,?,?,?,?,?,?)',(str(uuid4()),item['id'],item['platform'],result.get('external_id'),'failed',err,now()))
        except Exception as exc:
            attempt=int(item.get('attempts') or 0)+1; err=str(exc)[:500]
            if attempt<=MAX_RETRIES:
                nxt=(datetime.now(timezone.utc)+timedelta(seconds=backoff_seconds(attempt))).isoformat(); execute("UPDATE schedules SET status='retry_wait',attempts=?,next_attempt_at=?,last_error=?,lease_until=NULL,worker_id=NULL WHERE id=? AND status='executing'",(attempt,nxt,err,item['id']))
            else: execute("UPDATE schedules SET status='failed',attempts=?,last_error=?,lease_until=NULL,worker_id=NULL WHERE id=? AND status='executing'",(attempt,err,item['id']))
    return processed

def _run_offline_job(job:dict):
    import json
    payload=json.loads(job.get('payload_json') or '{}')
    kind=job['kind']
    if kind=='command':
        from .command_bus import dispatch
        return dispatch(str(payload.get('command','')), web_search=False)
    if kind=='maintenance.recovery':
        return recover_stale_jobs()
    if kind=='maintenance.reminder_poll':
        from .reminders import poll_due
        return {'fired':len(poll_due())}
    raise ValueError('unregistered_queue_job_kind')

def _offline_tick(worker_id:str):
    if get_kill_switch()['active']: return 0
    recover_expired()
    job=claim(worker_id,WORKER_LEASE_SECONDS)
    if not job: return 0
    started=time.monotonic(); attempts=int(job.get('attempts') or 0)+1
    try:
        result=_run_offline_job(job)
        elapsed=time.monotonic()-started
        if elapsed>OFFLINE_JOB_TIMEOUT_SECONDS:
            raise TimeoutError('offline_job_timeout')
        mark_done(job['id'],{'result':result,'elapsed_seconds':round(elapsed,3),'worker_id':worker_id})
        return 1
    except Exception as exc:
        if attempts<=MAX_RETRIES: mark_retry(job['id'],str(exc),attempts)
        else: mark_failed(job['id'],str(exc),attempts)
        return 0

def tick(worker_id:str|None=None):
    wid=worker_id or (WORKER_IDS[0] if WORKER_IDS else 'manual-'+str(uuid4()))
    return _publish_tick(wid)+_offline_tick(wid)

def _loop(worker_id:str):
    recover_stale_jobs(); recover_expired()
    while not STOP.is_set():
        try:
            _publish_tick(worker_id)
            _offline_tick(worker_id)
        except Exception:
            pass
        STOP.wait(WORKER_INTERVAL)

def start_worker():
    global THREADS,WORKER_IDS
    with START_LOCK:
        alive=[t for t in THREADS if t.is_alive()]
        if len(alive)>=WORKER_COUNT: THREADS=alive; return
        STOP.clear(); THREADS=alive; WORKER_IDS=[f'worker-{i+1}-{uuid4().hex[:8]}' for i in range(WORKER_COUNT)]
        for wid in WORKER_IDS[len(THREADS):]:
            t=Thread(target=_loop,args=(wid,),name='kilcritic-'+wid,daemon=True); t.start(); THREADS.append(t)

def stop_worker():
    STOP.set()

def status():
    alive=sum(1 for t in THREADS if t.is_alive())
    return {'running':alive>0,'alive_workers':alive,'configured_workers':WORKER_COUNT,'worker_ids':WORKER_IDS[:WORKER_COUNT],'queue':queue_stats(),'worker_interval_seconds':WORKER_INTERVAL,'lease_seconds':WORKER_LEASE_SECONDS,'timeout_seconds':OFFLINE_JOB_TIMEOUT_SECONDS}
