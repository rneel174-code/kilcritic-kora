from fastapi import FastAPI,UploadFile,File,HTTPException,Request
from pathlib import Path
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import FileResponse,JSONResponse
from pydantic import BaseModel, Field
from .config import CORS_ORIGINS,MEDIA_DIR,BASE_DIR,ALLOWED_HOSTS,MAX_UPLOAD_BYTES,KILCRITIC_ACCESS_TOKEN,ENGINE_VERSION
from .db import init_db,rows,execute,now
from .services.media import list_media,register_existing
from .services.media_edit import edit_media
from .services.tts import status as tts_status, synthesize
from .services.audience import modes,validate_mode
from .services.brain import decide,autopilot_policy
from .services.scheduler import add_schedule,list_schedules
from .services.insights import trend_plan,monetization_plan
from .services.comments import comment_plan
from .services.quality import validate_content
from .services.metadata import build_metadata, build_discovery_metadata
from .services.ai import provider_status,generate_text,generate_media_plan,generate_supreme_plan
from .services.learning import summarize, ingest
from .services.worker import start_worker as start_execution_workers, status as worker_status
from .services.recovery import recover_stale_jobs
from .services.integrity import run_integrity_check
from .services.capabilities import snapshot as capability_snapshot
from .services.autopilot import run_once as run_autopilot_once, list_runs, maybe_followups
from .services.assistant_core import capabilities, remember, memories, ask as assistant_ask, propose_ideas
from .services.command_bus import dispatch as dispatch_command
from .services.campaign import build_30_day
from .services.agent_os import plan as agent_plan, execute_safe as agent_execute, propose_improvements, kora_task_graph
from .services.reminders import create_reminder, list_reminders, acknowledge, poll_due, start_worker as start_reminder_worker
from .services.ultra_memory import remember as ultra_remember, search as ultra_memory_search
from .services.skill_learning import top as skill_top
from .services.council import decide as council_decide
from .services.offline_queue import enqueue as offline_enqueue, list_items as offline_list, stats as offline_stats, cancel as offline_cancel
from .services.system_doctor import scan as doctor_scan
from .services.supreme import capability_matrix
from .services.security import status as security_status, events as security_events, set_kill_switch, authorize_control, assert_running, authorize_remote_request, is_local_request, security_event
from .services.executive import overview as executive_overview, audit_and_record as executive_audit, Executive
from .services.rate_limit import limiter, install as install_rate_limiting, status as rate_limit_status
from .services.brahma import improve_self as brahma_improve_self
from .services.godfather import overview as godfather_overview, audit as godfather_audit, plan as godfather_plan, verify as godfather_verify, tool_registry as godfather_tools, release_manifest as godfather_release_manifest, capability_discovery as godfather_capability_discovery
from .platforms.registry import status as platform_status, get
from .services.media_urls import sign_media, serve as serve_signed_media

app=FastAPI(title='KILCRITIC SUPREME ENGINE',version=ENGINE_VERSION)
install_rate_limiting(app)

@app.on_event('startup')
def _start_kora_background_services():
    start_execution_workers()
    start_reminder_worker()
app.add_middleware(TrustedHostMiddleware, allowed_hosts=ALLOWED_HOSTS)
app.add_middleware(CORSMiddleware,allow_origins=CORS_ORIGINS,allow_credentials=False,allow_methods=['GET','POST','OPTIONS'],allow_headers=['*'])

@app.middleware('http')
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault('X-Content-Type-Options','nosniff')
    response.headers.setdefault('X-Frame-Options','DENY')
    response.headers.setdefault('Referrer-Policy','no-referrer')
    response.headers.setdefault('Permissions-Policy','camera=(), geolocation=(), payment=()')
    if request.url.path.startswith('/api/'):
        response.headers['Cache-Control']='no-store'
    return response

@app.middleware('http')
async def remote_access_guard(request: Request, call_next):
    path=request.url.path
    if path.startswith('/api/'):
        public={'/api/health'}
        if path not in public and not is_local_request(request):
            token=request.headers.get('X-Kilcritic-Token','')
            if not authorize_remote_request(request,token):
                security_event('security_denied', {'action':'remote_access','path':path}, request)
                return JSONResponse(status_code=403, content={'ok':False,'error':'remote_access_token_required'})
    return await call_next(request)

@app.middleware('http')
async def request_size_guard(request: Request, call_next):
    if request.method in {'POST','PUT','PATCH'}:
        raw=request.headers.get('content-length')
        if raw:
            try:
                length=int(raw)
                limit=MAX_UPLOAD_BYTES + (2*1024*1024) if request.url.path=='/api/upload' else 2*1024*1024
                if length > limit:
                    return JSONResponse(status_code=413, content={'ok':False,'error':'request_too_large','limit_bytes':limit})
            except ValueError:
                return JSONResponse(status_code=400, content={'ok':False,'error':'invalid_content_length'})
    return await call_next(request)

@app.middleware('http')
async def kill_switch_guard(request: Request, call_next):
    path = request.url.path
    safe = {'/api/security/status','/api/security/events','/api/security/kill-switch','/api/health'}
    if path.startswith('/api/') and path not in safe:
        from .services.security import get_kill_switch
        if get_kill_switch()['active']:
            return JSONResponse(status_code=503, content={'ok':False,'error':'system_kill_switch_active','message':'KILCRITIC is OFF by Malak control.'})
    return await call_next(request)

init_db()

@app.get('/storage/media/{filename}', include_in_schema=False)
def signed_media(filename: str, exp: str, sig: str):
    return serve_signed_media(filename, exp, sig)

@app.get('/', include_in_schema=False)
def dashboard(): return FileResponse(str(BASE_DIR/'index.html'))

# PWA/static control files are served explicitly so they work regardless of
# which API/static mounts are enabled. This is additive and does not replace
# the existing dashboard or media routes.
@app.get('/manifest.json', include_in_schema=False)
def pwa_manifest(): return FileResponse(str(BASE_DIR/'manifest.json'), media_type='application/manifest+json')

@app.get('/sw.js', include_in_schema=False)
def pwa_service_worker(): return FileResponse(str(BASE_DIR/'sw.js'), media_type='application/javascript')

class PlanIn(BaseModel):
 topic:str=''; audience:str='GENERAL'; platforms:list[str]=['youtube','facebook','instagram','tiktok','x']; content_type:str='video'
class ScheduleIn(BaseModel):
 media_id:str; platform:str; publish_at:str; audience:str='GENERAL'; quality:str='1080p'; plan_id:str|None=None; thumbnail_media_id:str|None=None; metadata:dict=Field(default_factory=dict)
class QualityIn(BaseModel):
 topic:str; audience:str='GENERAL'; content_type:str='video'; quality:str='1080p'; flags:list[str]=Field(default_factory=list)
class MetadataIn(BaseModel):
 topic:str; content_type:str='video'; platform:str
 region:str='IN'; trend_terms:list[str]=Field(default_factory=list); hide_hashtags:bool=True
class ApprovalIn(BaseModel): approved:bool; note:str=''
class AutopilotIn(BaseModel):
    region:str='IN'
    category_id:str=''
    audience:str='GENERAL'
    quality:str='1080p'
    platform:str='youtube'
    auto_schedule:bool=True



@app.get('/api/security/status')
def security_status_api():
    return {**security_status(), 'remote_access': {'required_for_non_local': True, 'token_configured': bool(KILCRITIC_ACCESS_TOKEN)}}

@app.get('/api/security/events')
def security_events_api(limit: int = 50):
    return {'items': security_events(limit)}

class SecurityControlIn(BaseModel):
    active: bool
    reason: str = 'Malak emergency control'
    token: str = ''

@app.post('/api/security/kill-switch')
def security_kill_switch(b: SecurityControlIn, request: Request):
    if not authorize_control(request, b.token):
        from .services.security import security_event
        security_event('security_denied', {'action':'kill_switch'}, request)
        raise HTTPException(403, 'Malak control authorization required')
    return {'ok': True, **set_kill_switch(b.active, b.reason)}



# GODFATHER control plane: additive orchestration/inspection only.
@app.get('/api/godfather')
def godfather():
    return godfather_overview()

@app.get('/api/godfather/audit')
def godfather_audit_api():
    return godfather_audit()

@app.get('/api/godfather/tools')
def godfather_tools_api():
    return {'ok': True, 'items': godfather_tools()}

class GodfatherGoalIn(BaseModel):
    goal: str
    risk: str = 'medium'

@app.post('/api/godfather/plan')
def godfather_plan_api(b: GodfatherGoalIn):
    try:
        return godfather_plan(b.goal)
    except ValueError as e:
        raise HTTPException(400, str(e))

@app.post('/api/godfather/verify')
def godfather_verify_api(b: GodfatherGoalIn):
    try:
        return godfather_verify(b.goal, b.risk)
    except ValueError as e:
        raise HTTPException(400, str(e))

@app.get('/api/godfather/discovery')
def godfather_discovery_api():
    return godfather_capability_discovery()

@app.get('/api/godfather/release-manifest')
def godfather_release_manifest_api():
    return godfather_release_manifest()

@app.get('/api/kora/executive')
def kora_executive():
    return executive_overview()

@app.post('/api/kora/executive/audit')
def kora_executive_audit():
    return executive_audit()

class ExecutiveGoalIn(BaseModel):
    goal: str

class ExecutiveVerifyIn(BaseModel):
    checks: list[dict]

@app.post('/api/kora/executive/plan')
def kora_executive_plan(b: ExecutiveGoalIn):
    try: return Executive().plan(b.goal)
    except ValueError as e: raise HTTPException(400, str(e))

@app.post('/api/kora/executive/delegate')
def kora_executive_delegate(b: ExecutiveGoalIn):
    try: return Executive().delegate(b.goal)
    except ValueError as e: raise HTTPException(400, str(e))

@app.post('/api/kora/executive/verify')
def kora_executive_verify(b: ExecutiveVerifyIn):
    try: return Executive().verify(b.checks)
    except ValueError as e: raise HTTPException(400, str(e))

@app.get('/api/setup/steps')
def setup_steps():
    from .services.ai_router import status as router_status
    from .services.tts import status as voice_status
    return {
        'ok': True,
        'steps': [
            {'step': 1, 'title': 'Local KORA test', 'action': 'Open KORA Face and ask: KORA, are you there?', 'done_when': 'KORA returns a local response'},
            {'step': 2, 'title': 'Voice test', 'action': 'Tap Listen, speak one short command, then send it', 'done_when': 'KORA receives the transcript or asks you to type if the browser lacks speech input'},
            {'step': 3, 'title': 'Memory test', 'action': 'Say/type: remember this: test memory', 'done_when': 'A memory_id is returned'},
            {'step': 4, 'title': 'Reminder test', 'action': 'Say/type: remind me in 1 minute to test KORA', 'done_when': 'A reminder is stored and later fires'},
            {'step': 5, 'title': 'External AI key (optional)', 'action': 'Only after local tests pass, add one approved provider key to .env and restart', 'done_when': 'AI status shows the provider configured and a real request succeeds'},
        ],
        'external_ai_configured': any(x.get('configured') for x in router_status().get('providers', []) if x.get('provider') != 'local'),
        'voice': voice_status(),
        'note': 'A provider key is NOT required for the local KORA tests. Never paste a secret key into chat.'
    }

@app.get('/api/health')
def health():
 return {'ok':True,'version':ENGINE_VERSION,'worker':worker_status(),'rate_limit':rate_limit_status(),'modules':['brain','media','audience','autopilot','scheduler','execution-worker','platforms','trend','monetization','comments','analytics','learning','quality','metadata','ai-adapter','supreme-ai','performance','recovery','provider-failover','kora-agent','continuous-improvement','executive-os']}

@app.get('/api/test/suite')
def test_suite():
    """Read-only KORA regression suite for local/runtime capabilities."""
    checks = []
    def check(name, fn, warn_if=None):
        try:
            result = fn()
            state = 'PASS'
            if isinstance(result, dict) and result.get('ok') is False:
                state = 'WARN'
            if warn_if and warn_if(result):
                state = 'WARN'
            checks.append({'name': name, 'status': state, 'detail': result})
        except Exception as exc:
            checks.append({'name': name, 'status': 'FAIL', 'detail': str(exc)[:500]})
    check('health', health)
    check('hud', kora_hud)
    check('setup', setup_status)
    check('doctor', doctor_scan)
    check('integrity', run_integrity_check)
    check('capabilities', capability_snapshot)
    check('kora_capabilities', capability_matrix)
    check('ai_status', provider_status, lambda r: not bool(r.get('connected')) if isinstance(r, dict) else False)
    check('ai_failover', __import__('app.services.ai_router', fromlist=['status']).status)
    check('platforms', platform_status)
    check('audience_modes', modes)
    check('performance', lambda: {'worker_interval_seconds': __import__('app.services.performance', fromlist=['WORKER_INTERVAL']).WORKER_INTERVAL, 'max_retries': __import__('app.services.performance', fromlist=['MAX_RETRIES']).MAX_RETRIES})
    check('media_store', lambda: {'count': len(list_media())})
    check('schedules', lambda: {'count': len(list_schedules())})
    check('offline_queue', lambda: {'count': len(offline_list())})
    check('learning', summarize)
    check('security', security_status)
    check('executive', executive_overview)
    required = ['index.html','manifest.json','sw.js','app/main.py','app/services/ai.py','app/services/command_bus.py','app/services/security.py','app/services/media_edit.py','app/services/worker.py','app/platforms/youtube.py']
    missing = [x for x in required if not (BASE_DIR / x).exists()]
    checks.append({'name':'required_files','status':'PASS' if not missing else 'FAIL','detail':{'missing':missing}})
    api_routes = sorted({r.path for r in app.routes if getattr(r, 'path', '').startswith('/api/')})
    passed = sum(1 for x in checks if x['status']=='PASS')
    warned = sum(1 for x in checks if x['status']=='WARN')
    failed = sum(1 for x in checks if x['status']=='FAIL')
    return {
        'ok': failed == 0,
        'version': app.version,
        'mode': 'read_only_regression',
        'summary': {'total': len(checks), 'pass': passed, 'warn': warned, 'fail': failed, 'api_routes': len(api_routes)},
        'checks': checks,
        'notes': [
            'WARN on AI means no remote credential/connection was verified; local fallback remains available.',
            'WARN on platform entries means an official OAuth/API adapter or credential may still be unavailable.',
            'This suite never publishes, spends money, deletes media, or changes security state.'
        ]
    }

@app.get('/api/kora/hud')
def kora_hud():
    """Single guarded snapshot for the touch-first KORA HUD."""
    def safe(label, fn):
        try:
            return fn()
        except Exception as e:
            return {'ok': False, 'component': label, 'error': str(e)[:240]}
    return {
        'ok': True,
        'version': app.version,
        'health': safe('health', health),
        'capabilities': safe('capabilities', capability_snapshot),
        'platforms': safe('platforms', platform_status),
        'ai': safe('ai', provider_status),
        'security': safe('security', security_status),
        'doctor': safe('doctor', doctor_scan),
        'executive': safe('executive', executive_overview),
        'performance': safe('performance', lambda: {'worker_interval_seconds': __import__('app.services.performance', fromlist=['WORKER_INTERVAL']).WORKER_INTERVAL, 'max_retries': __import__('app.services.performance', fromlist=['MAX_RETRIES']).MAX_RETRIES}),
        'media_count': safe('media', lambda: len(list_media())),
        'schedule_count': safe('schedules', lambda: len(list_schedules())),
        'learning': safe('learning', summarize),
        'autopilot': safe('autopilot', autopilot_policy),
        'offline_queue': safe('offline_queue', lambda: {'items': offline_list()}),
        'rules': {'publish_requires_approval': True, 'no_fake_success': True, 'self_deploy': False, 'telemetry_default': False}
    }

class AssistantAskIn(BaseModel):
    prompt:str
    web_search:bool=False

class MemoryIn(BaseModel):
    text:str
    kind:str='project'
    importance:int=5

@app.get('/api/assistant/capabilities')
def assistant_capabilities(): return {'items':capabilities()}

@app.post('/api/assistant/ask')
@limiter.limit('10/minute')
def assistant_ask_api(request: Request, b:AssistantAskIn):
    try: return assistant_ask(b.prompt,b.web_search)
    except ValueError as e: raise HTTPException(400,str(e))

class ReminderIn(BaseModel):
    text:str
    due_at:str
    repeat:str|None=None

@app.get('/api/reminders')
def reminders_api(): return {'ok':True,'items':list_reminders()}

@app.post('/api/reminders')
def reminders_add_api(b:ReminderIn):
    try: return create_reminder(b.text,b.due_at,b.repeat)
    except ValueError as e: raise HTTPException(400,str(e))

@app.post('/api/reminders/poll')
def reminders_poll_api(): return {'ok':True,'items':poll_due()}

@app.post('/api/reminders/{reminder_id}/ack')
def reminders_ack_api(reminder_id:str): return acknowledge(reminder_id)

class CommandIn(BaseModel):
    command:str
    web_search:bool=True

@app.post('/api/command')
def command_api(b:CommandIn):
    try:
        assert_running()
        return agent_execute(b.command,b.web_search)
    except ValueError as e: raise HTTPException(400,str(e))

class Campaign30In(BaseModel):
    topic:str
    audience:str='GENERAL'
    platform:str='youtube'
    start_at:str|None=None

@app.post('/api/campaign/30days')
def campaign_30(b:Campaign30In):
    try: return build_30_day(b.topic,b.audience,b.platform,b.start_at)
    except ValueError as e: raise HTTPException(400,str(e))

@app.get('/api/assistant/memory')
def assistant_memory(): return {'items':memories()}

@app.post('/api/assistant/memory')
def assistant_memory_add(b:MemoryIn):
    try: return remember(b.text,b.kind,b.importance)
    except ValueError as e: raise HTTPException(400,str(e))

class MemorySearchIn(BaseModel):
    query:str
    limit:int=12

@app.post('/api/assistant/memory/search')
def assistant_memory_search(b:MemorySearchIn):
    return {'ok':True,'items':ultra_memory_search(b.query,b.limit),'mode':'local_hash_vector','note':'Vector-like local retrieval; no external embedding service is required.'}

@app.post('/api/assistant/memory/remember-indexed')
def assistant_memory_remember_indexed(b:MemoryIn):
    try: return ultra_remember(b.text,b.kind,b.importance)
    except ValueError as e: raise HTTPException(400,str(e))

@app.get('/api/skills')
def skill_metrics(): return {'items':skill_top()}

class CouncilIn(BaseModel):
    question:str
    risk:str='medium'

@app.post('/api/kora/council')
def kora_council(b:CouncilIn):
    try: return council_decide(b.question,b.risk)
    except ValueError as e: raise HTTPException(400,str(e))

@app.get('/api/agent/traces')
def agent_traces(limit:int=50):
    return {'items':rows('SELECT workflow_id,state,action,observation,result,created_at FROM agent_traces ORDER BY created_at DESC LIMIT ?', (max(1,min(200,int(limit))),))}

@app.get('/api/assistant/ideas')
def assistant_ideas(): return {'items':rows('SELECT id,idea_json,status,created_at FROM assistant_ideas ORDER BY created_at DESC LIMIT 50')}

@app.post('/api/assistant/ideas/generate')
def assistant_ideas_generate(): return propose_ideas()

@app.get('/api/self-improvement')
def self_improvement():
    return {'mode':'guarded','automatic_analysis':True,'automatic_code_deploy':False,'reason':'Ideas can be generated and tested, but code deployment requires explicit approval and a passing integrity/compile test.','proposals':rows('SELECT id,title,proposal_json,status,created_at FROM self_improvement_proposals ORDER BY created_at DESC LIMIT 50')}

@app.post('/api/self-improvement/analyze')
@limiter.limit('3/minute')
def self_improvement_analyze(request: Request):
    return propose_improvements()

@app.post('/api/self-improvement/cycle')
@limiter.limit('2/hour')
def brahma_cycle(request: Request):
    return brahma_improve_self()

class AgentIn(BaseModel):
    command:str
    web_search:bool=True

@app.post('/api/agent/plan')
def agent_plan_api(b:AgentIn):
    try: return agent_plan(b.command)
    except ValueError as e: raise HTTPException(400,str(e))

@app.post('/api/agent/execute')
@limiter.limit('10/minute')
def agent_execute_api(request: Request, b:AgentIn):
    try: return agent_execute(b.command,b.web_search)
    except ValueError as e: raise HTTPException(400,str(e))

@app.get('/api/audience-modes')
def audience_modes(): return {'items':modes()}
@app.get('/api/autopilot')
def autopilot(): return autopilot_policy()
@app.post('/api/brain/plan')
def brain_plan(b:PlanIn): return decide(b.topic,validate_mode(b.audience),b.platforms,b.content_type)
@app.post('/api/quality/check')
def quality(b:QualityIn): return validate_content(b.topic,b.audience,b.content_type,b.flags, b.quality)
@app.post('/api/metadata')
def metadata(b:MetadataIn): return build_metadata(b.topic,b.content_type,b.platform)
@app.get('/api/ai')
def ai(): return provider_status()

class AIGenerateIn(BaseModel):
 prompt:str
 web_search:bool=False

class AISupremeIn(BaseModel):
    topic:str
    audience:str='GENERAL'
    content_type:str='video'
    quality:str='1080p'
    platforms:list[str]=['youtube','facebook','instagram','tiktok','x']
    web_search:bool=True
    plan_id:str|None=None

class AIMediaPlanIn(BaseModel):
 topic:str
 audience:str='GENERAL'
 content_type:str='video'
 platforms:list[str]=['youtube','facebook','instagram','tiktok','x']

@app.post('/api/ai/generate')
@limiter.limit('10/minute')
def ai_generate(request: Request, b:AIGenerateIn):
 return generate_text(b.prompt,b.web_search)

@app.post('/api/ai/media-plan')
def ai_media_plan(b:AIMediaPlanIn):
 return generate_media_plan(b.topic,b.content_type,validate_mode(b.audience),b.platforms)

@app.post('/api/ai/supreme')
def ai_supreme(b:AISupremeIn):
 
 result=generate_supreme_plan(b.topic,b.content_type,validate_mode(b.audience),b.platforms,b.web_search,b.quality,b.plan_id)
 if result.get('plan_id'):
  import json
  execute('INSERT OR REPLACE INTO ai_plans(id,topic,content_type,audience,quality,platforms,plan_json,created_at) VALUES (?,?,?,?,?,?,?,?)',(result['plan_id'],b.topic,b.content_type,validate_mode(b.audience),b.quality,json.dumps(b.platforms),json.dumps(result.get('plan')),now()))
 return result
class MediaEditIn(BaseModel):
 media_id:str; operation:str; audience:str='GENERAL'; start:float=0; end:float|None=None; quality:str='1080p'; width:int=1080; height:int=1920; x:int=0; y:int=0; text:str=''; audio_media_id:str=''; duration:float=5

@app.post('/api/media/edit')
@limiter.limit('10/minute')
def media_edit(request: Request, b:MediaEditIn):
 try:
  return edit_media(b.media_id,b.operation,validate_mode(b.audience),start=b.start,end=b.end,quality=b.quality,width=b.width,height=b.height,x=b.x,y=b.y,text=b.text,audio_media_id=b.audio_media_id,duration=b.duration)
 except (ValueError,RuntimeError) as e: raise HTTPException(400,str(e))

class TTSIn(BaseModel):
 text:str; language:str='en'

@app.get('/api/tts')
def tts_info(): return tts_status()
@app.post('/api/tts')
def tts(b:TTSIn):
 try:
  path=synthesize(b.text,b.language); mid=register_existing(path,name='tts.wav',audience='GENERAL',kind='audio',operation='tts'); return {'ok':True,'media_id':mid}
 except (ValueError,RuntimeError) as e: raise HTTPException(400,str(e))

@app.get('/api/ai/plans')
def ai_plans(): return {'items':rows('SELECT id,topic,content_type,audience,quality,platforms,created_at FROM ai_plans ORDER BY created_at DESC LIMIT 50')}

@app.get('/api/os')
def os_status():
    import os, shutil, sys
    from .config import FFMPEG_BIN
    from .services.ai_router import status as router_status
    from .services.media_edit import ffmpeg_available
    return {
        'os': os.name,
        'python': sys.version.split()[0],
        'ffmpeg': {'available': ffmpeg_available(), 'binary': shutil.which(FFMPEG_BIN)},
        'worker': 'running',
        'database': 'sqlite',
        'tts': tts_status(),
        'ai': provider_status(),
        'fallback_providers': router_status(),
        'fake_data_policy': 'disabled',
        'real_publish_policy': 'official OAuth/API only'
    }

@app.get('/api/integrity')
def integrity(): return run_integrity_check()

@app.get('/api/capabilities')
def capabilities(): return capability_snapshot()

@app.get('/api/kora/capabilities')
def kora_capabilities(): return {'items': capability_matrix()}

class KoraPlanIn(BaseModel):
    command: str

@app.post('/api/kora/plan')
def kora_plan_api(b: KoraPlanIn):
    try: return kora_task_graph(b.command)
    except ValueError as e: raise HTTPException(400, str(e))

@app.get('/api/ai/failover')
def ai_failover_status():
    from .services.provider_hub import health as provider_health
    return provider_health()

@app.get('/api/ai/rescue')
def ai_rescue():
    from .services.provider_hub import rescue_recommendations
    return rescue_recommendations()

@app.get('/api/self-improvement/proposals')
def self_improvement_proposals():
    return {'items': rows('SELECT id,title,proposal_json,status,created_at FROM self_improvement_proposals ORDER BY created_at DESC LIMIT 50')}

class ImprovementDecisionIn(BaseModel):
    approved: bool
    note: str = ''

@app.post('/api/self-improvement/proposals/{proposal_id}/decision')
def self_improvement_decision(proposal_id: str, b: ImprovementDecisionIn):
    item=rows('SELECT id FROM self_improvement_proposals WHERE id=?',(proposal_id,))
    if not item: raise HTTPException(404,'Proposal not found')
    status='approved' if b.approved else 'rejected'
    execute('UPDATE self_improvement_proposals SET status=? WHERE id=?',(status,proposal_id))
    return {'ok':True,'id':proposal_id,'status':status,'note':b.note[:500],'next_step':'approved proposals still require tests and explicit deployment; this endpoint never executes code'}

@app.get('/api/doctor')
def system_doctor():
    return doctor_scan()

class OfflineQueueIn(BaseModel):
    kind: str='command'
    payload: dict = {}
    idempotency_key: str|None = None

@app.post('/api/offline/queue')
def offline_queue_add(b: OfflineQueueIn):
    try: return offline_enqueue(b.kind,b.payload,b.idempotency_key)
    except ValueError as e: raise HTTPException(400,str(e))

@app.get('/api/offline/queue')
def offline_queue_list(limit:int=50):
    return {'items':offline_list(limit),'durable':True,'stats':offline_stats()}

@app.post('/api/offline/queue/{job_id}/cancel')
def offline_queue_cancel(job_id:str):
    if not offline_cancel(job_id): raise HTTPException(409,'Queue job cannot be cancelled in its current state')
    return {'ok':True,'id':job_id,'status':'cancelled'}

@app.get('/api/worker/status')
def worker_status_api():
    return worker_status()

@app.get('/api/setup-status')
def setup_status():
    return {'system_ready': True, 'ai_connected': provider_status().get('connected', False), 'fallback_providers': __import__('app.services.ai_router', fromlist=['status']).status(), 'live_trends_connected': bool(__import__('app.config', fromlist=['YOUTUBE_API_KEY']).YOUTUBE_API_KEY), 'platforms': platform_status(), 'autopilot_worker': True, 'message': 'Local engine is ready. External AI, live trend sources and official platform OAuth/API connections require user authorization/configuration.'}
@app.post('/api/upload')
@limiter.limit('20/minute')
async def upload(request: Request, file:UploadFile=File(...),audience='GENERAL'):
 from .services.media import save_upload_stream
 try: return {'ok':True,'media_id':save_upload_stream(file,file.filename or 'upload.bin',audience)}
 except ValueError as e: raise HTTPException(400,str(e))
@app.get('/api/media')
def media():
    items=[]
    for item in list_media():
        x=dict(item)
        stored_name=Path(x['path']).name
        x.pop('path',None)
        x['url']=sign_media(stored_name)
        x['media_name']=x['name']
        items.append(x)
    return {'items':items}
@app.get('/api/schedules')
def schedules(): return {'items':list_schedules()}
@app.post('/api/schedules')
def schedule(b:ScheduleIn):
 try: return {'ok':True,'schedule_id':add_schedule(b.media_id,b.platform,b.publish_at,validate_mode(b.audience),b.quality,b.plan_id,b.thumbnail_media_id,b.metadata)}
 except ValueError as e: raise HTTPException(400,str(e))
@app.post('/api/schedules/{schedule_id}/approval')
def approval(schedule_id:str,b:ApprovalIn):
 item=rows('SELECT id FROM schedules WHERE id=?',(schedule_id,))
 if not item: raise HTTPException(404,'Schedule not found')
 execute('INSERT INTO approvals(id,target_type,target_id,approved,note,updated_at) VALUES(?,?,?,?,?,datetime(\'now\'))',
         (schedule_id,'schedule',schedule_id,1 if b.approved else 0,b.note))
 execute('UPDATE schedules SET status=? WHERE id=?',('approved' if b.approved else 'rejected',schedule_id))
 return {'ok':True,'status':'approved' if b.approved else 'rejected'}
@app.post('/api/worker/tick')
def worker_tick():
 from .services.worker import tick
 return {'ok':True,'processed':tick()}
@app.post('/api/recovery')
def recovery(): return recover_stale_jobs()
@app.get('/api/autopilot/runs')
def autopilot_runs(): return {'items':list_runs()}

@app.post('/api/autopilot/run')
def autopilot_run(b:AutopilotIn):
    from .config import AUTOPILOT_ENABLED
    if not AUTOPILOT_ENABLED: raise HTTPException(409,'Autopilot is disabled. Set ENABLE_AUTOPILOT=true and restart.')
    try: return run_autopilot_once(b.region,b.category_id,validate_mode(b.audience),b.quality,b.platform,b.auto_schedule)
    except (ValueError,RuntimeError) as e: raise HTTPException(400,str(e))

@app.post('/api/autopilot/followups')
def autopilot_followups(schedule_id:str, views:int):
    return maybe_followups(schedule_id,views)

@app.post('/api/trends')
def trends(b:PlanIn): return trend_plan(b.topic,b.platforms)

@app.get('/api/trends/youtube')
def youtube_trends(region:str='IN',category_id:str=''):
 from .config import YOUTUBE_API_KEY
 if not YOUTUBE_API_KEY: return {'connected':False,'status':'not_configured','note':'Set YOUTUBE_API_KEY to query YouTube mostPopular. No fake trend data is returned.'}
 import urllib.request, urllib.parse, json
 q={'part':'snippet,statistics','chart':'mostPopular','regionCode':region.upper(),'maxResults':'10','key':YOUTUBE_API_KEY}
 if category_id: q['videoCategoryId']=category_id
 try:
  with urllib.request.urlopen('https://www.googleapis.com/youtube/v3/videos?'+urllib.parse.urlencode(q),timeout=20) as r: data=json.loads(r.read().decode())
  items=[]
  for x in data.get('items',[]):
   items.append({'id':x.get('id'),'title':x.get('snippet',{}).get('title'),'channel':x.get('snippet',{}).get('channelTitle'),'views':x.get('statistics',{}).get('viewCount'),'url':'https://www.youtube.com/watch?v='+str(x.get('id'))})
  return {'connected':True,'region':region.upper(),'items':items,'source':'YouTube Data API mostPopular'}
 except Exception as e: return {'connected':True,'status':'error','error':str(e)[:300]}

@app.get('/api/monetization')
def monetization(): return monetization_plan()
@app.get('/api/comments')
def comments(mode='MIX'): return comment_plan(mode)
@app.get('/api/platforms')
def platforms(): return {'items':platform_status(),'note':'Real publishing requires official OAuth/API adapter implementation and user authorization.'}
@app.get('/api/analytics')
def analytics(): return {'items':rows('SELECT * FROM analytics ORDER BY captured_at DESC LIMIT 100'),'live_sync':False}
@app.get('/api/learning')
def learning(): return summarize()

class AnalyticsIn(BaseModel):
 platform:str; media_id:str; views:int=0; likes:int=0; comments:int=0; shares:int=0
@app.post('/api/analytics/ingest')
def analytics_ingest(b:AnalyticsIn): return ingest(b.platform,b.media_id,b.views,b.likes,b.comments,b.shares)

@app.post('/api/analytics/sync')
def analytics_sync(platform:str='youtube',limit:int=50):
 if platform!='youtube': raise HTTPException(400,'Only YouTube analytics sync is implemented in this build')
 adapter=get('youtube')
 if adapter is None or not hasattr(adapter,'analytics'): raise HTTPException(503,'YouTube analytics adapter unavailable')
 items=rows("SELECT id,media_id,external_id FROM schedules WHERE platform='youtube' AND status='published' AND external_id IS NOT NULL ORDER BY publish_at DESC LIMIT ?",(max(1,min(limit,100)),))
 out=[]
 for x in items:
  result=adapter.analytics(x['external_id'])
  if result.get('ok'):
   ingest('youtube',x['media_id'],result.get('views',0),result.get('likes',0),result.get('comments',0),result.get('shares',0))
  out.append({'schedule_id':x['id'],'external_id':x['external_id'],'result':result})
 return {'platform':'youtube','synced':len(out),'items':out}

@app.post('/api/growth/plan')
def growth_plan(b:AISupremeIn):
 from .services.growth import build_growth_plan
 return build_growth_plan(b.topic,b.platforms,validate_mode(b.audience),b.content_type,b.web_search)
@app.post('/api/growth/metadata')
def growth_metadata(b: MetadataIn):
    return build_discovery_metadata(b.topic, b.content_type, b.platform, b.region, b.trend_terms, b.hide_hashtags)

@app.get('/api/audit')
def audit():
 return {'version':ENGINE_VERSION,'findings':[{'id':'fake_success','status':'fixed','detail':'Publish success requires a real adapter response and external_id.'},{'id':'ram_upload','status':'fixed','detail':'Inbound uploads stream in bounded chunks.'},{'id':'ram_youtube','status':'fixed','detail':'YouTube resumable upload sends bounded chunks instead of reading the full file.'},{'id':'ai_contract','status':'fixed','detail':'AI Supreme now carries content_type, quality, platforms, web_search and plan_id end-to-end.'},{'id':'media_studio','status':'added','detail':'Real FFmpeg trim, resize, portrait, crop, text overlay, mute, audio mux, extraction and image-to-video operations.'},{'id':'voice','status':'added','detail':'Browser voice preview plus optional local server TTS; unavailable engines report failure instead of fake audio.'},{'id':'player','status':'added','detail':'Media Hub now exposes real video/audio playback controls.'},{'id':'growth','status':'added','detail':'Retention, discovery, follower conversion and experiment planning.'},{'id':'learning','status':'added','detail':'Analytics ingestion plus measurement-based recommendations.'},{'id':'recovery','status':'fixed','detail':'Bounded delayed retries with persisted errors.'},{'id':'queue','status':'hardened','detail':'Persistent SQLite queue now has bounded capacity, atomic claims, worker leases, retries, cancellation and registered job handlers.'},{'id':'platform_integrations','status':'partial','detail':'YouTube has a real resumable adapter; Facebook, Instagram, TikTok and X remain disabled until official API adapters and credentials are configured.'},{'id':'trend_edit_boundary','status':'protected','detail':'Trend discovery may inform ideas, but editing/publishing third-party media requires user ownership or lawful permission.'},{'id':'v7_os','status':'added','detail':'Truthful OS, provider and FFmpeg diagnostics; no fake ready claims.'},{'id':'provider_fallback','status':'hardened','detail':'Primary provider is selected explicitly; Groq GPT-OSS 120B uses the OpenAI-compatible Responses API and browser_search, with local fallback.'},{'id':'runtime_integrity','status':'added','detail':'Runtime self-check verifies critical imports, storage writability, FFmpeg availability and absence of known fake publish markers.'},{'id':'db_durability','status':'hardened','detail':'SQLite uses WAL, FULL synchronous mode, foreign keys and busy timeout for stronger crash/concurrency behavior.'},{'id':'autopilot_pipeline','status':'added','detail':'Official YouTube mostPopular trend -> AI/Groq text -> real TTS -> real FFmpeg video -> real PNG thumbnail -> normal approval/schedule/publish path.'},{'id':'youtube_thumbnail','status':'added','detail':'Approved YouTube uploads can set the generated PNG thumbnail through the official thumbnails.set endpoint.'},{'id':'oauth_refresh','status':'added','detail':'YouTube adapter supports OAuth access tokens and optional refresh-token renewal when client credentials are configured.'},{'id':'bounded_followups','status':'added','detail':'Analytics threshold can trigger at most three follow-up plans per source schedule; no unbounded self-replicating loop.'},{'id':'capability_matrix','status':'added','detail':'Runtime capability and credential state are exposed separately; configured credentials are not treated as validated publishing access.'},{'id':'local_publish_dedup','status':'hardened','detail':'Schedules support unique idempotency keys and worker/publish paths refuse to republish schedules already carrying an external_id.'},{'id':'jarvis_ui','status':'added','detail':'Full-screen KORA face with platform dock, live web-search command, voice input/output, phone dialer handoff, and mobile/laptop full-screen controls.'},{'id':'command_os','status':'added','detail':'Voice/text command bus routes common actions to real engine capabilities; publish remains approval-gated.'},{'id':'campaign_30_day','status':'added','detail':'30-day content calendar planner with persisted event record; media generation and external publishing still use the normal guarded pipeline.'},{'id':'current_api_boundary','status':'verified','detail':'Platform-specific permissions, audits and visibility restrictions are treated as external prerequisites rather than hidden inside the core.'},{'id':'ai_failover_chain','status':'added','detail':'Configured-provider cascade can move from Groq to Gemini, OpenRouter, Cerebras, Ollama and finally the deterministic local planner; a failed provider is not reported as success.'},{'id':'kora_agent','status':'added','detail':'KORA Supreme Agent creates multi-step workflow plans and executes only capabilities exposed by the guarded command bus; publishing remains Malak-approved.'},{'id':'continuous_improvement','status':'added','detail':'Evidence-based improvement analysis is available; uncontrolled internet code execution and automatic self-deployment remain disabled.'},{'id':'security_center','status':'added','detail':'Trusted hosts, defensive outbound allowlist, redacted security events, persistent Malak kill switch and no automatic hackback.'},{'id':'privacy_guard','status':'added','detail':'Telemetry is disabled by default; external requests are limited to configured/known connectors and are blocked while the kill switch is active.'},{'id':'supreme_task_graph','status':'added','detail':'Deterministic inspectable KORA task graph separates planning from permissions and execution.'},{'id':'provider_circuit_breaker','status':'added','detail':'Repeated provider failures trigger a short cooldown so one failing AI does not stall the entire cascade.'},{'id':'self_improvement_ledger','status':'added','detail':'Improvement proposals are persisted with explicit approval state; approval never executes code automatically.'},{'id':'secure_egress_validation','status':'hardened','detail':'Outbound URLs now require HTTP(S), reject URL userinfo, and remain constrained by the host allowlist.'},{'id':'durable_offline_queue','status':'hardened','detail':'Offline commands/messages persist in SQLite and are processed by registered worker handlers with leases, retries, deduplication and bounded payloads.'},{'id':'truthful_system_doctor','status':'added','detail':'System Doctor reports measured database, FFmpeg, storage, kill-switch, AI-failover and queue state without fake fixed/healthy claims.'},{'id':'skill_confidence','status':'added','detail':'Skill learning now exposes a conservative statistical confidence bound and exploration need, reducing overconfidence from a tiny sample.'},{'id':'discovery_metadata','status':'added','detail':'Topic/trend-aware hashtag, emoji and regional-flag suggestions with internal-metadata preference; no viral guarantee and no claim of hidden placement where a platform does not support it.'},{'id':'additive_upgrade_guard','status':'hardened','detail':'Required source files and critical capability markers are checked by tools/additive_upgrade_guard.py before release; runtime caches/databases are excluded from regression comparison.'},{'id':'pwa_static_routes','status':'fixed','detail':'manifest.json and sw.js are served explicitly, eliminating the prior /manifest.json 404 without removing existing routes.'},{'id':'continuous_face','status':'added','detail':'KORA Face now routes typed/voice commands, speaks returned answers, and persists reminders in SQLite with a server-side due worker.'},{'id':'remote_access_guard','status':'added','detail':'Non-local API clients require a separate access token; localhost remains available for laptop-only testing.'},{'id':'signed_media_urls','status':'added','detail':'Media file URLs are short-lived HMAC capabilities and raw storage paths are no longer exposed by the media API.'},{'id':'request_size_guard','status':'added','detail':'Non-upload API bodies are bounded and upload requests are bounded before application processing.'},{'id':'upload_signature_check','status':'added','detail':'Common media uploads are checked against file signatures in addition to extensions.'},{'id':'security_headers','status':'added','detail':'Defensive browser response headers and no-store API caching are enabled.'},{'id':'rate_limiting','status':'added','detail':'Sensitive assistant, AI, agent, upload, media-edit, publish and self-improvement endpoints use bounded request limits; SlowAPI is required in the release environment.'},{'id':'brahma_safe_cycle','status':'added','detail':'Evidence-based self-improvement cycle creates a reviewable proposal only; it cannot write arbitrary code or restart the process automatically.'}]}
@app.get('/api/performance')
def performance():
 from .services.performance import MAX_RETRIES,WORKER_INTERVAL
 return {'worker_interval_seconds':WORKER_INTERVAL,'max_retries':MAX_RETRIES,'strategy':'bounded retries, persistent SQLite state, safe failure handling'}
@app.post('/api/publish')
@limiter.limit('5/minute')
def publish(request: Request, schedule_id:str):
 assert_running()
 item=rows('SELECT * FROM schedules WHERE id=?',(schedule_id,))
 if not item: raise HTTPException(404,'Schedule not found')
 x=item[0]
 if x.get('external_id') or x['status']=='published': raise HTTPException(409,'Schedule already has an external_id; duplicate publish blocked')
 if x['status']!='approved': raise HTTPException(409,f'Schedule status is {x["status"]}; explicit approval required')
 media=rows('SELECT * FROM media WHERE id=?',(x['media_id'],))
 if not media: raise HTTPException(404,'Media not found')
 adapter=get(x['platform'])
 if adapter is None: raise HTTPException(503,'No adapter configured')
 result=adapter.publish({**x,'media_path':media[0]['path'],'media_name':media[0]['name'],'media_kind':media[0]['kind']})
 if not result.get('ok'): raise HTTPException(502,result.get('error','publish_failed'))
 execute("UPDATE schedules SET status='published',external_id=?,last_error=NULL,idempotency_key=? WHERE id=?",(result.get('external_id'),schedule_id,schedule_id))
 return result
