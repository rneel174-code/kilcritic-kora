# 8.8.1 — KORA GODFATHER LIVE HARDENED

Additive hardening release from 8.8.0. Existing functions and routes are preserved.

## Added
- Real bounded in-process rate-limit fallback when SlowAPI is unavailable, instead of silently becoming a no-op.
- Per-client/per-route windows with bounded cleanup for offline/local testing.
- Health diagnostics now identify the active limiter provider truthfully.

## Preserved
- Godfather control plane and all existing services/routes.
- SlowAPI remains the preferred limiter when installed.
- External publishing, account changes, destructive actions and self-deployment remain approval-gated.
- No arbitrary generated-code execution.

## Verification
- Static Godfather audit.
- Universal regression.
- Additive baseline guard.
- Live localhost API smoke tests.
- Builtin fallback rate-limit test: 3 allowed, 4th blocked with HTTP 429.
- Security response headers verified.
