KILCRITIC SUPREME ENGINE 8.6.3 — KORA CONTINUOUS FACE OS

## V8.1.0 KORA TOUCH SECURITY
- Touch-first full-screen HUD showing core modules in one view.
- Persistent Malak kill switch, trusted-host protection and allowlisted outbound egress guard.
- Security event log with redaction; no telemetry by default.
- No automatic hackback, remote code execution or automatic self-deployment.

# KILCRITIC SUPREME ENGINE — 7.3.2 FREE-FIRST JARVIS HARDENED

This build is the hardened continuation of 6.4 SUPREME GROWTH.

## Real capabilities in this package
- Streaming inbound media uploads with bounded RAM usage.
- Real media playback in the dashboard for video, image and audio.
- Real FFmpeg editing: trim, resize/quality, portrait 9:16, crop, text overlay, mute, add audio, extract audio, and image-to-video.
- Text-to-speech preview in the browser and optional local server TTS when an OS voice engine is available.
- Supreme AI request contract includes topic, content type, audience, quality, platforms, web search and plan ID.
- AI plans are persisted in SQLite.
- Bounded schedule queue, explicit approval, delayed retries and recovery.
- YouTube resumable upload uses bounded chunks instead of loading the whole video into RAM.
- YouTube video statistics sync is available when the required OAuth access token is authorized.
- Growth planning and analytics learning remain measurement-based.
- Trend discovery never returns fabricated trend data. YouTube most-popular discovery requires a real API key.
- Third-party media is not automatically downloaded/reused; edit/publish only media the user owns or is lawfully allowed to use.

## Explicit boundaries
- Facebook, Instagram, TikTok and X publishing adapters are still disabled until their official API/OAuth implementations and credentials are configured.
- Primary AI route is selected with `PROVIDER`. The default is Groq + `openai/gpt-oss-120b`; Groq is wired through the OpenAI-compatible Responses API. If no external key is configured, the engine uses the honest local deterministic fallback.
- Local TTS depends on the operating system voice engine. The browser voice preview can work without server TTS.
- 4K/8K are delivery targets. Upscaling does not create missing source detail.
- No guaranteed virality, followers or income.

## Run
Windows: `START_WINDOWS.bat`
Linux/macOS: `START_LINUX_MAC.sh`
Then open `http://127.0.0.1:8000/` or `/docs`.

## Verify first
1. `/api/health`
2. `/api/audit`
3. `/api/setup-status`

Do not treat a token being present as proof that a platform connection is valid. Real publish success requires the official adapter to complete the operation and return an external ID.


## V7.1 CORE INTEGRITY
- SQLite remains the authoritative application database.
- Small JSON artifacts can use `app/services/atomic_json.py`, which uses a lock, temp file, `fsync`, and atomic replace. It is not a replacement for SQLite.
- `/api/integrity` performs truthful runtime checks for critical module imports, writable storage, FFmpeg availability, and known fake-publish markers.
- SQLite is hardened with WAL, `synchronous=FULL`, foreign keys, and busy timeout.
- The system deliberately has no claim of guaranteed virality, guaranteed income, or unlimited future capability.
- New providers/platforms remain isolated behind adapters so the core does not need to be rewritten for each integration.


## V7.3.2 Free-First JARVIS Hardening + Creator Autopilot

Optional bounded creator pipeline:
1. official YouTube Data API `mostPopular` trend discovery;
2. script generation through configured AI/Groq fallback or the honest local fallback;
3. real local TTS when a supported engine exists;
4. real FFmpeg title-card video creation;
5. real PNG thumbnail extraction;
6. schedule enters the normal explicit-approval + official OAuth/API publish path;
7. analytics can trigger at most three bounded follow-up plans when the configured view threshold is reached.

The pipeline does not scrape or download third-party videos, does not copy source scripts, does not claim virality/income, and does not create an unbounded self-replicating publishing loop. YouTube's official `videos.insert` and `thumbnails.set` APIs require authorized credentials; unverified upload projects can be restricted to private videos.


## V7.3 JARVIS Core
- Voice input when the browser supports SpeechRecognition; browser/local TTS for output.
- Capability registry reports what is available, conditional, or guarded.
- Explicit project memory stored in SQLite.
- Evidence-based idea generator using recorded analytics/trend snapshots.
- Guarded self-improvement: the system can propose and test improvements, but it does not silently rewrite/deploy its own code.
- Full-screen JARVIS face includes YouTube/Facebook/Instagram/TikTok/X launch controls, live web-search command, voice input/output, phone dialer handoff, and minimize/full-screen controls. Incoming-call interception remains controlled by the mobile OS/browser and is not falsely claimed as available.
- External publishing remains official OAuth/API only.


## KORA Command OS (7.4)
- Original face/assistant name: **KORA** (KILCRITIC Operations & Response Assistant).
- Name is a UI/persona label and can be changed later without changing the core engine.
- Voice and text share the same command bus for supported actions.
- 30-day planner creates a dated content calendar; generation/publishing still obey the existing approval, credential, platform and policy gates.
- Publish success is never faked. YouTube has the real adapter in this build; other platforms remain conditional on their official APIs/OAuth.
- Browser voice support varies by browser/device; text input remains the fallback.


## V7.5 KORA SUPREME AGENT
- Provider failover: Groq -> Gemini -> OpenRouter -> Cerebras -> Ollama -> local, using only providers actually configured.
- External AI is optional; the FastAPI core and deterministic planner do not depend on a paid AI service.
- KORA Agent endpoints: `/api/agent/plan` and `/api/agent/execute`.
- Continuous-improvement analysis: `/api/self-improvement/analyze`. Suggestions remain proposal/test/approval gated; no uncontrolled self-modification.
- A provider failure or rate limit must not be treated as successful work.
- Search claims remain honest: a fallback text model is not presented as live web verification unless it actually used a search-capable tool.


## KORA Security / Privacy HUD
- Full-screen KORA now exposes Brain, Media, Editor, Voice, Research, Metadata, 30-day, Schedule, Approval, Social, Analytics, Learning, Memory, AI, Security and Emergency controls in one touch-first HUD.
- Persistent Malak kill switch pauses API actions and the execution worker. Security status/control endpoints remain available so Malak can restore the system.
- Trusted hosts and a defensive outbound allowlist are enabled. Unexpected outbound destinations are blocked and recorded as security events.
- Telemetry is disabled by default. External AI/provider calls share only the data required by that explicitly invoked provider; this is not treated as private/local-only data.
- Security logs may record the source network address seen by the local server for defensive auditing. The system does not perform physical-address lookup, hackback, retaliation, or unauthorized tracking.
- Automatic remote code execution and automatic self-deployment remain disabled; improvements require testing and explicit approval.


## V8.0 Supreme OS
- Inspectable KORA task graph separates planning, permissions and execution.
- Provider failover has a short circuit-breaker cooldown after repeated failures.
- Improvement proposals have a persistent approval ledger; approval never executes code automatically.
- Outbound URL validation rejects unsupported schemes and URL userinfo and remains allowlist-based.
- Secure-by-default goal: external side effects require explicit authorization/approval.


## V8.1 Resilience additions
- Persistent provider failure counters and cooldowns across restarts.
- Default AI rescue order: Groq -> OpenRouter -> Gemini -> Cerebras -> Ollama -> OpenAI -> local. Configure only providers you are authorized to use.
- `/api/ai/rescue` reports provider setup links; free tiers/quotas are not guaranteed and must be checked with the provider.
- Local vector-like memory retrieval without an external embedding service.
- Skill metrics track attempts/successes/failures; they improve routing evidence without changing code automatically.
- Five-role KORA Council is advisory only; it cannot bypass Malak approval.
- Compact Thought -> Action -> Observation -> Final execution trace is persisted without storing private chain-of-thought.


## V8.2 additions
- Durable SQLite offline queue
- Truthful measured System Doctor
- Conservative skill confidence/exploration metrics

## V8.4 KORA Executive OS
V8.4 adds a measurable executive control plane with CEO, CTO, Auditor, Director and Architect roles. These roles are software governance views, not claims of human experience. The executive audit checks version consistency, runtime health, security state, provider health, platform truth, release cleanliness, capabilities and evidence-based priorities. It cannot bypass Malak approval, execute arbitrary internet code, or self-deploy changes.


## V8.6.3 KORA Continuous Face OS
- Persistent SQLite reminders with background due-check worker while the server process is running.
- KORA Face can listen, route commands, show responses and speak the result.
- Local fallback remains valid when external AI credentials are unavailable.
- 24/7 behavior means the server/worker remains running; Android/browser OS may still suspend a process, so no false 100% uptime claim is made.


## KORA step-by-step first run
1. Start the server and open http://127.0.0.1:8000.
2. Do NOT enter an AI key yet.
3. Open KORA Face and ask: `KORA, are you there?`
4. Test `remember this: test memory`.
5. Test `remind me in 1 minute to test KORA`.
6. Only after those local tests pass, configure one external AI provider in `.env` if you want richer reasoning/live search.
7. Never paste an API secret into chat or screenshots.

External provider availability, quotas and pricing can change. Local KORA mode is the zero-cost baseline.

## 8.7 Universal security / LAN mode
- Default bind remains `127.0.0.1`, so a fresh install is local-only.
- Non-local API clients are fail-closed unless `KILCRITIC_ACCESS_TOKEN` is configured and sent as `X-Kilcritic-Token`.
- The dashboard can ask for that token once per browser session; it is stored only in `sessionStorage`.
- For phone-on-same-Wi-Fi testing: set `KILCRITIC_BIND_HOST=0.0.0.0`, create a token with `python tools/generate_access_token.py`, put it in `.env`, restart, then open the laptop's LAN IP from the phone.
- Leave `ALLOWED_HOSTS` blank for automatic local-host/IP detection, or set it to the exact laptop IP for a tighter host policy.
- Uploaded media is checked against common file signatures, and `/api/media` no longer exposes raw filesystem paths. Media playback uses short-lived signed URLs.
- API responses use defensive browser headers and `no-store` caching.
- This is defensive hardening, not a claim of absolute or 100% security. External platform/API security and the host OS still matter.

## KORA Godfather Ultra Control Plane (8.8.0)
This release adds an additive control plane that coordinates reasoning, engine, architecture, CEO, director, security and QA roles. It exposes truthful read-only audit and guarded planning/verification endpoints. It does not claim universal security or automatic external publishing.


## Durable worker hardening (8.8.3)
The execution worker pool processes only registered queue job kinds. Queue entries are SQLite-backed, bounded, atomically claimed, lease-protected, retryable and cancellable. This does not provide unlimited capacity or zero RAM; media uploads remain streaming/bounded.
