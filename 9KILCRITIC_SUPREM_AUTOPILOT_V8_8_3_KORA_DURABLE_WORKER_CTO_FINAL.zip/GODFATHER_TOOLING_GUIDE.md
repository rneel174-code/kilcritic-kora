# External Godfather-grade coding tools — official references

KILCRITIC can be reviewed by external coding agents, but they are external tools, not embedded runtime dependencies.

- OpenAI Codex — https://openai.com/codex/
- Anthropic Claude Code — https://docs.anthropic.com/en/docs/claude-code/overview
- Cursor Agents — https://cursor.com/agents
- Google Antigravity — https://www.antigravity.google/

Use agents in **audit -> plan -> patch -> test -> re-audit** order. Keep KILCRITIC's additive-upgrade rule and approval gates.

Do not give any agent production secrets unless the environment is intentionally configured for that purpose. Never enable unrestricted destructive commands merely to make an agent appear more autonomous.
