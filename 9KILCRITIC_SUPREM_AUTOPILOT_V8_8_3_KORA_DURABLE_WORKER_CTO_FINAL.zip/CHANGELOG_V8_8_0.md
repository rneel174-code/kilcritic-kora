# 8.8.0 — KORA GODFATHER ULTRA HARDENED

Additive upgrade from 8.7.4.

## Added
- `app/services/godfather.py` control plane.
- Seven-role orchestration map: brain, engine, architect, CEO, director, security, QA.
- Read-only whole-system evidence audit.
- Goal planning and guarded verification endpoints.
- Truthful internal tool/capability registry.
- Clean release manifest endpoint.
- Godfather protocol and hard safety rules.

## Preserved
- Existing KILCRITIC services and routes.
- Brahma proposal-only self-improvement.
- Executive five-role governance.
- KORA Council.
- Security/kill-switch/remote access gates.
- Platform approval and official API/OAuth boundary.

## Not claimed
- No universal guarantee of security or superiority.
- No automatic activation of external credentials.
- No fake live publishing or provider connectivity.
