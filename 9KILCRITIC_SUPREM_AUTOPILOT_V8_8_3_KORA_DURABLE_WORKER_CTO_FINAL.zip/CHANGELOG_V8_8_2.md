# 8.8.2 — KORA GODFATHER AUTONOMOUS HARDENED

- Preserved all 8.8.1 source capabilities; no working files/routes removed.
- Fixed Executive version-truth check so it validates the FastAPI app uses the canonical ENGINE_VERSION symbol.
- Added read-only Godfather capability discovery at `/api/godfather/discovery`.
- Added source-evidence capability map for brain, worker, durable queue, media streaming, FFmpeg, Brahma, security, rate limiting, AI routing, executive roles, platform registry, release audit and regression tooling.
- Discovery reports missing/partial evidence instead of inventing capability.
- External credentials/OAuth and device-level verification remain explicitly unverified until configured/tested.
