#!/usr/bin/env python3
"""KILCRITIC additive-upgrade regression guard.
Fails if baseline source files or critical markers disappear.
It intentionally does not compare runtime caches/databases.
"""
from __future__ import annotations
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'tools'/'additive_baseline.json'
base=json.loads(BASE.read_text())
missing_files=[]
for rel in base['required_files']:
    p=ROOT/rel
    if not p.exists(): missing_files.append(rel)
missing_markers=[]
for item in base['critical_markers']:
    p=ROOT/item['file']
    if not p.exists() or item['marker'] not in p.read_text(errors='ignore'):
        missing_markers.append(item)
print(f"BASELINE: {base['baseline_version']}")
print(f"REQUIRED FILES: {len(base['required_files'])}")
print(f"CRITICAL MARKERS: {len(base['critical_markers'])}")
if missing_files:
    print('MISSING FILES:')
    for x in missing_files: print(' -',x)
if missing_markers:
    print('MISSING MARKERS:')
    for x in missing_markers: print(' -',x['file'],':',x['marker'])
if missing_files or missing_markers:
    print('RESULT: FAIL - additive regression detected')
    sys.exit(2)
print('RESULT: PASS - baseline capabilities preserved')
