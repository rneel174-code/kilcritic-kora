from __future__ import annotations
import base64, os, re, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def fail(msg):
    print('FAIL:',msg); raise SystemExit(1)

# Static release checks
text='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in ROOT.rglob('*') if p.is_file() and p != Path(__file__) and p.suffix in {'.py','.html','.js','.md','.example'})
for pat in [r'sk-[A-Za-z0-9_-]{20,}', r'gsk_[A-Za-z0-9_-]{20,}', r'AIza[A-Za-z0-9_-]{20,}', r'BEGIN (?:RSA|OPENSSH|EC|PRIVATE) KEY']:
    if re.search(pat,text): fail('secret-like material found: '+pat)
for marker in ('hack proof','hack-proof','100% safe','100% secure','AES-256 ON - No leak','published_to_youtube_real_api'):
    if marker.lower() in text.lower(): fail('fake/absolute marker found: '+marker)
for marker in ('os.system(', 'shell=True', 'pickle.loads(', 'yaml.load('):
    if marker in text: fail('dangerous execution marker found: '+marker)

# Compile
subprocess.run([sys.executable,'-m','compileall','-q','.'],cwd=ROOT,check=True)

os.environ['KILCRITIC_ACCESS_TOKEN']='REGRESSION-TOKEN-ONLY'
os.environ['ALLOWED_HOSTS']='testclient,127.0.0.1,localhost'
from fastapi.testclient import TestClient
from app.main import app
from app.services.security import authorize_remote_request
from starlette.requests import Request

client=TestClient(app,base_url='http://testclient:8000'); H={'X-Kilcritic-Token':'REGRESSION-TOKEN-ONLY'}
assert client.get('/api/health').status_code==200
assert client.get('/api/media',headers=H).status_code==200
assert client.get('/api/security/status',headers=H).status_code==200
assert client.get('/api/media',headers={'X-Kilcritic-Token':'bad'}).status_code==403

# Real remote-auth policy function check.
scope={'type':'http','client':('10.0.0.5',12345),'method':'GET','path':'/api/media','headers':[],'scheme':'http','server':('10.0.0.2',8000)}
req=Request(scope)
assert authorize_remote_request(req,'') is False
assert authorize_remote_request(req,'REGRESSION-TOKEN-ONLY') is True

# File-signature and signed-media path check.
png=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=')
r=client.post('/api/upload',headers=H,files={'file':('tiny.png',png,'image/png')}); assert r.status_code==200
item=client.get('/api/media',headers=H).json()['items'][0]
assert 'path' not in item and item.get('url','').startswith('/storage/media/')
assert client.get(item['url']).status_code==200
assert client.post('/api/upload',headers=H,files={'file':('spoof.png',b'not-image','image/png')}).status_code==400

# Executive/version consistency.
health=client.get('/api/health').json(); exec_data=client.get('/api/kora/executive',headers=H).json()
assert exec_data['version_truth']['expected']==health['version']
assert client.post('/api/assistant/ask',headers=H,json={'prompt':'test','web_search':False}).status_code in {200,400}
assert client.post('/api/self-improvement/cycle',headers=H).status_code in {200,500,503}
# Rate-limit wiring and safe Brahma cycle must be present in source even when SlowAPI is absent in the test environment.
rate_src=(ROOT/'app/services/rate_limit.py').read_text(encoding='utf-8')
brahma_src=(ROOT/'app/services/brahma.py').read_text(encoding='utf-8')
main_src=(ROOT/'app/main.py').read_text(encoding='utf-8')
assert 'slowapi' in rate_src.lower()
assert "@limiter.limit('10/minute')" in main_src
assert '/api/self-improvement/cycle' in main_src
assert 'automatic_code_write' in brahma_src and 'automatic_restart' in brahma_src
assert 'write_file(' not in brahma_src and 'restart(' not in brahma_src

# Read-only suite must not have failures.
suite=client.get('/api/test/suite',headers=H).json()
if suite['summary']['fail']:
    fail(str(suite['summary']))
print('PASS: universal regression',suite['summary'])
