#!/usr/bin/env python3
"""Clean release audit for KILCRITIC. Exits non-zero on obvious release hazards."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
forbidden=[]
for p in ROOT.rglob('*'):
    if not p.is_file(): continue
    rel=p.relative_to(ROOT).as_posix()
    if '__pycache__' in p.parts or p.suffix=='.pyc' or rel.startswith('storage/kilcritic.db'):
        forbidden.append(rel)
if forbidden:
    print('FAIL: runtime/cache artifacts in release:')
    print('\n'.join(' - '+x for x in forbidden))
    sys.exit(2)
for req in ['manifest.json','sw.js','index.html','run.py','app/main.py','.gitignore','app/services/executive.py','tools/additive_upgrade_guard.py','tools/additive_baseline.json']:
    if not (ROOT/req).exists():
        print('FAIL: missing required release file:',req); sys.exit(2)
print('PASS: clean release audit')
