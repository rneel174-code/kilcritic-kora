# KORA 8.7.2 — BRAHMA SAFE IMPROVEMENT + RATE LIMIT HARDENING

## Added
- SlowAPI request-rate protection on sensitive API endpoints.
- `/api/self-improvement/cycle` as a bounded Brahma improvement cycle.
- `app/services/brahma.py` for evidence-first improvement proposals.
- Rate-limit status is visible in `/api/health`.

## Safety fixes
- Replaced the unsafe idea of arbitrary `write_file(...new_better.py)` with proposal-only persistence.
- No automatic Python code injection, process restart, self-deployment, hack-back, or unbounded `while True` loop.
- Existing Malak approval, kill-switch, remote-access and official-platform gates remain active.

## Dependency decision
- Added `slowapi==0.1.9` because rate limiting is an actual runtime dependency.
- Did **not** add `supabase==2.10.0`: the current engine uses durable local SQLite and has no Supabase adapter, so adding an unused cloud dependency would add complexity without capability.

## Upgrade rule
- Additive by default. Existing working modules/routes were preserved.
