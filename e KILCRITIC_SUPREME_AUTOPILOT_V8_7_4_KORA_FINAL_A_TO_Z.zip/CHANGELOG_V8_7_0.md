# KILCRITIC KORA 8.7.0 — UNIVERSAL CTO HARDENED

## Upgrade contract
- Additive upgrade from V8.6.4; existing engine modules remain in place.
- No runtime DB/WAL/cache artifacts are packaged.

## Added / hardened
- Local-first bind remains `127.0.0.1` by default.
- Non-local API access is fail-closed unless `KILCRITIC_ACCESS_TOKEN` is configured.
- Remote auth uses `X-Kilcritic-Token`, session-only browser storage, and a small failed-auth throttle.
- Raw filesystem media paths are removed from `/api/media`.
- Media playback uses short-lived HMAC-signed URLs.
- Common media types receive file-signature checks in addition to extension checks.
- Non-upload request bodies have an early size bound.
- Defensive browser headers and `no-store` API responses are enabled.
- Engine version is centralized so CEO/CTO/auditor diagnostics cannot drift to an old version string.
- Added a release-safe access-token generator.

## Verified in local regression
- Python compile: PASS
- Additive capability guard: PASS
- Clean release audit: PASS
- Fake-success/secret marker scan: PASS
- Signed media round-trip: PASS
- Spoofed media signature rejection: PASS
- Remote access without token: BLOCKED
- Remote access with correct token: ALLOWED
- Read-only runtime suite: 18 PASS / 1 WARN / 0 FAIL in the test environment; the WARN is expected when no external AI credential is configured.
