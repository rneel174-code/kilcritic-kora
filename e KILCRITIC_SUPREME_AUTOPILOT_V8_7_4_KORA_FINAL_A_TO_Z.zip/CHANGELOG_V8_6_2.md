# V8.6.2 — KORA Universal HUD hotfix

- Fixed the AI failover bug where the deterministic local provider was marked as available but immediately skipped.
- KORA now returns a truthful local response when no external AI provider is configured.
- External AI remains clearly reported as disconnected until a real provider request succeeds.
- No publish, payment, deletion, self-deployment, or security boundary was weakened.
- Existing modules and guarded workflows are preserved.
