# KILCRITIC 6.5 CTO HARDENED CHANGELOG

## 6.5.0
- Fixed AI Supreme request contract: `content_type`, `quality`, `platforms`, `web_search`, `plan_id` are preserved end-to-end.
- Persisted AI plans in SQLite.
- Added real media studio operations using FFmpeg.
- Added real Media Hub playback.
- Added browser text-to-speech preview and optional local TTS file generation.
- Added YouTube resumable chunked upload to eliminate whole-file RAM reads during publish.
- Added YouTube video statistics sync adapter.
- Added YouTube most-popular trend discovery endpoint with explicit no-fake-data behavior.
- Added quality presets and quality validation.
- Added schedule `quality` and `plan_id` fields.
- Hardened output registration so edited media is immediately playable from the Media Hub.
- Removed legacy fake publish/viral success wording from the package.
- Preserved explicit boundaries for platforms without official adapters.


V8.1.0 KORA RESILIENCE: persistent AI failover health, rescue links, local vector-like memory, skill metrics, five-role advisory council, and compact execution traces.

## V8.6.0 — KORA UNIVERSAL HUD
- Added a touch-first full-screen KORA HUD covering the existing Brain, Media, Editor, Voice, Research, Trends, Discovery, Metadata, 30-day planning, Autopilot, Scheduler, Approval, Social, Monetization, Comments, Analytics, Learning, Memory, AI, Skills, Council, Agent, Improvement, Security, Integrity, Performance, Offline Queue, Audit and Setup capabilities.
- Added a persistent in-page KORA mini-screen for quick commands without leaving the dashboard.
- Added `/api/kora/hud` as a guarded single-snapshot system overview; component failures are reported individually rather than hidden.
- Preserved approval gates, official OAuth/API boundaries, kill switch, no-fake-success policy, bounded queues/retries, and additive upgrade guard.
- Browser/PWA background behavior remains subject to Android/browser lifecycle limits; server-side worker continues while the local server is running.
