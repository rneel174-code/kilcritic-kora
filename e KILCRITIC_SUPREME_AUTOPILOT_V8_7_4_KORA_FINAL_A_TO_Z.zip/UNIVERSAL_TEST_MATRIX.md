# KILCRITIC KORA 8.7.2 — Universal Test Matrix

## Automatically verified in the release
- Python compile/import integrity
- additive capability guard
- clean-release audit (no `__pycache__`, `.pyc`, runtime DB/WAL/SHM)
- fake-success / secret-like marker scan
- remote API token fail-closed behavior
- short-lived signed media URL round-trip
- raw media filesystem path is not exposed by `/api/media`
- common media signature mismatch rejection
- response security headers
- executive version consistency
- read-only runtime regression suite

## Manual device matrix for Malak
### Android / Google phone
- Chrome portrait + landscape
- Firefox portrait + landscape
- Edge if installed
- upload photo/video/audio
- play media
- voice input/output where browser supports it
- PWA install/open
- remote token prompt from the same Wi-Fi laptop server

### iPhone / iPad
- Safari portrait + landscape
- PWA install/open
- upload/playback
- voice capability check

### Laptop / desktop
- Windows Chrome + Edge + Firefox
- macOS Safari + Chrome
- Linux Chrome/Firefox
- upload, FFmpeg edit, TTS, planner, scheduler, approval, audit, recovery

### Network
- normal Wi-Fi
- mobile hotspot
- slow connection
- disconnect/reconnect
- restart server while queued work exists

### External integrations
- AI provider: configure only a real key, then verify a real request
- YouTube: verify OAuth scopes, upload to a safe visibility first, then verify thumbnail and analytics
- Facebook/Instagram/TikTok/X: remain clearly `not publish-ready` until their official adapter and credentials are implemented and tested

## Important boundary
“Universal” here means one responsive web/PWA client plus a portable Python engine, not a claim that every browser, OS, driver, codec, AI provider, or social platform has identical native capabilities. The release reports unavailable capabilities instead of pretending they work.


## 8.7.2 additions
- Rate-limit sensitive API endpoints with SlowAPI (10/minute baseline for assistant/AI/agent; tighter limits for publish/self-improvement).
- Brahma safe self-improvement cycle: read bounded evidence, create Executive plan, persist proposal; no arbitrary code write and no automatic restart.
- Regression checks cover rate-limit wiring, Brahma safety markers, and version consistency.
