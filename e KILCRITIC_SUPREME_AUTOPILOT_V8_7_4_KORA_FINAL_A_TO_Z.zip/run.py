import os
import uvicorn

if __name__ == '__main__':
    host = os.getenv('KILCRITIC_BIND_HOST', '127.0.0.1').strip() or '127.0.0.1'
    port = int(os.getenv('KILCRITIC_PORT', '8000'))
    uvicorn.run('app.main:app', host=host, port=port)
