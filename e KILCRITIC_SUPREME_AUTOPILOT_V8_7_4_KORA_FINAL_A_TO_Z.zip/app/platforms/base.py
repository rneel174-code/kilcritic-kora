class PlatformAdapter:
    name = 'base'
    connected = False

    def status(self):
        return {'connected': bool(self.connected), 'publish_ready': False, 'analytics_ready': False}

    def publish(self, payload):
        return {'ok': False, 'platform': self.name, 'error': 'Real approved OAuth/API adapter is not connected.'}

    def analytics(self, external_id):
        return {'ok': False, 'platform': self.name, 'error': 'Platform analytics API is not connected.'}
