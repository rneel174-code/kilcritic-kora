from .youtube import YouTube
from .facebook import Facebook
from .instagram import Instagram
from .tiktok import TikTok
from .x import X

ADAPTERS = {
    "youtube": YouTube(),
    "facebook": Facebook(),
    "instagram": Instagram(),
    "tiktok": TikTok(),
    "x": X(),
}

def status():
    return [{"name": name, **adapter.status()} for name, adapter in ADAPTERS.items()]

def get(platform: str):
    return ADAPTERS.get(platform)
