import os
from .base import PlatformAdapter

class Instagram(PlatformAdapter):
    name = 'instagram'
    connected = bool(os.getenv('INSTAGRAM_ACCESS_TOKEN'))

    def status(self):
        return {'connected': self.connected, 'publish_ready': False, 'analytics_ready': False,
                'note': 'Token detected, but an official platform-specific API adapter must still be configured.'}
