import os,json,mimetypes,urllib.request,urllib.error,urllib.parse
from .base import PlatformAdapter
from ..services.security import guard_url

class YouTube(PlatformAdapter):
    name='youtube'
    def __init__(self):
        self.token=os.getenv('YOUTUBE_ACCESS_TOKEN','').strip()
        self.refresh_token=os.getenv('YOUTUBE_REFRESH_TOKEN','').strip()
        self.client_id=os.getenv('YOUTUBE_CLIENT_ID','').strip()
        self.client_secret=os.getenv('YOUTUBE_CLIENT_SECRET','').strip()

    def _refresh(self):
        if not (self.refresh_token and self.client_id and self.client_secret): return False
        body=urllib.parse.urlencode({'client_id':self.client_id,'client_secret':self.client_secret,'refresh_token':self.refresh_token,'grant_type':'refresh_token'}).encode()
        req=urllib.request.Request('https://oauth2.googleapis.com/token',data=body,method='POST',headers={'Content-Type':'application/x-www-form-urlencoded','Accept':'application/json'})
        try:
            guard_url(req.full_url, 'youtube_oauth')
            with urllib.request.urlopen(req,timeout=30) as r: data=json.loads(r.read().decode())
            token=data.get('access_token','').strip()
            if token:
                self.token=token
                return True
        except Exception:
            return False
        return False

    def _ensure_token(self):
        if self.token: return True
        return self._refresh()

    def status(self):
        configured=bool(self.token or (self.refresh_token and self.client_id and self.client_secret))
        return {'connected':configured,'credential_present':configured,'publish_ready':configured,'analytics_ready':configured,'thumbnail_ready':configured,'note':'Real YouTube API path. OAuth access token or refresh-token credentials are required; upload scope must authorize the operation.'}

    def publish(self,payload):
        if not self._ensure_token(): return {'ok':False,'platform':self.name,'error':'YouTube OAuth credentials missing'}
        path=payload.get('media_path')
        if not path or not os.path.isfile(path): return {'ok':False,'platform':self.name,'error':'media_file_missing'}
        meta=payload.get('metadata') if isinstance(payload.get('metadata'),dict) else payload
        title=str(meta.get('title') or os.path.splitext(os.path.basename(path))[0])[:100]
        description=str(meta.get('description') or 'KILCRITIC SUPREME ENGINE')[:5000]
        tags=meta.get('tags_json') or meta.get('tags') or []
        if isinstance(tags,str):
            try: tags=json.loads(tags)
            except Exception: tags=[x.strip() for x in tags.split(',') if x.strip()]
        mime=mimetypes.guess_type(path)[0] or 'application/octet-stream'; total=os.path.getsize(path)
        privacy=os.getenv('YOUTUBE_PRIVACY','private')
        metadata=json.dumps({'snippet':{'title':title,'description':description,'tags':tags},'status':{'privacyStatus':privacy}}).encode()
        init=urllib.request.Request('https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status',data=metadata,method='POST',headers={'Authorization':'Bearer '+self.token,'Content-Type':'application/json; charset=UTF-8','X-Upload-Content-Type':mime,'X-Upload-Content-Length':str(total)})
        try:
            guard_url(init.full_url, 'youtube_upload_init')
            with urllib.request.urlopen(init,timeout=30) as r: upload_url=r.headers.get('Location')
            if not upload_url: return {'ok':False,'platform':self.name,'error':'youtube_upload_session_missing'}
            chunk_size=8*1024*1024; chunk_size-=chunk_size%(256*1024); offset=0; result=None
            while offset<total:
                end=min(offset+chunk_size,total)-1
                with open(path,'rb') as fh: fh.seek(offset); data=fh.read(end-offset+1)
                for attempt in range(4):
                    req=urllib.request.Request(upload_url,data=data,method='PUT',headers={'Authorization':'Bearer '+self.token,'Content-Type':mime,'Content-Length':str(len(data)),'Content-Range':f'bytes {offset}-{end}/{total}'})
                    try:
                        guard_url(req.full_url, 'youtube_upload_chunk')
                        with urllib.request.urlopen(req,timeout=300) as r:
                            body=r.read().decode(errors='ignore')
                            if r.status in (200,201): result=json.loads(body or '{}'); offset=total; break
                            offset=end+1; break
                    except urllib.error.HTTPError as e:
                        if e.code==401 and self._refresh(): continue
                        if e.code==308:
                            rng=e.headers.get('Range','')
                            if rng.startswith('bytes='):
                                try: offset=int(rng.split('-')[-1])+1
                                except Exception: pass
                            else: offset=end+1
                            break
                        if attempt==3: raise
                    except Exception:
                        if attempt==3: raise
                else: return {'ok':False,'platform':self.name,'error':'youtube_chunk_retry_exhausted'}
            if not result or not result.get('id'): return {'ok':False,'platform':self.name,'error':'youtube_upload_no_external_id'}
            video_id=result['id']; thumb_result=None
            thumb=payload.get('thumbnail_path')
            if thumb and os.path.isfile(thumb):
                thumb_result=self.set_thumbnail(video_id,thumb)
            return {'ok':True,'platform':self.name,'external_id':video_id,'thumbnail':thumb_result,'response':result}
        except urllib.error.HTTPError as e: return {'ok':False,'platform':self.name,'error':f'youtube_http_{e.code}','detail':e.read().decode(errors='ignore')[:500]}
        except Exception as e: return {'ok':False,'platform':self.name,'error':str(e)[:500]}

    def set_thumbnail(self,video_id,path):
        if not self._ensure_token(): return {'ok':False,'error':'oauth_missing'}
        size=os.path.getsize(path)
        if size>50*1024*1024: return {'ok':False,'error':'thumbnail_over_50MB'}
        mime=mimetypes.guess_type(path)[0] or 'image/png'
        if mime not in ('image/jpeg','image/png','application/octet-stream'): mime='image/png'
        with open(path,'rb') as f: data=f.read()
        url='https://www.googleapis.com/upload/youtube/v3/thumbnails/set?videoId='+urllib.parse.quote(str(video_id))
        req=urllib.request.Request(url,data=data,method='POST',headers={'Authorization':'Bearer '+self.token,'Content-Type':mime,'Content-Length':str(len(data))})
        try:
            guard_url(req.full_url, 'youtube_thumbnail')
            with urllib.request.urlopen(req,timeout=120) as r: return {'ok':r.status in (200,201),'status':r.status}
        except urllib.error.HTTPError as e:
            if e.code==401 and self._refresh(): return self.set_thumbnail(video_id,path)
            return {'ok':False,'error':f'youtube_thumbnail_http_{e.code}'}
        except Exception as e: return {'ok':False,'error':str(e)[:300]}

    def analytics(self, external_id):
        if not self._ensure_token(): return {'ok':False,'error':'YouTube OAuth credentials missing'}
        q='https://www.googleapis.com/youtube/v3/videos?part=statistics&id='+urllib.parse.quote(str(external_id))
        req=urllib.request.Request(q,headers={'Authorization':'Bearer '+self.token})
        try:
            guard_url(req.full_url, 'youtube_oauth')
            with urllib.request.urlopen(req,timeout=30) as r: data=json.loads(r.read().decode())
            item=(data.get('items') or [{}])[0]; st=item.get('statistics',{})
            return {'ok':True,'views':int(st.get('viewCount',0)),'likes':int(st.get('likeCount',0)),'comments':int(st.get('commentCount',0)),'shares':0,'raw':st}
        except urllib.error.HTTPError as e:
            if e.code==401 and self._refresh(): return self.analytics(external_id)
            return {'ok':False,'error':f'youtube_http_{e.code}'}
        except Exception as e: return {'ok':False,'error':str(e)[:500]}
