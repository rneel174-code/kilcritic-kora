import os
from .base import PlatformAdapter

class Facebook(PlatformAdapter):
    name = 'facebook'
    connected = bool(os.getenv('FACEBOOK_ACCESS_TOKEN'))

    def status(self):
        return {'connected': self.connected, 'publish_ready': False, 'analytics_ready': False,
                'note': 'Token detected, but an official platform-specific API adapter must still be configured.'}
