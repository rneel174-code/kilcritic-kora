import sqlite3
from datetime import datetime, timezone
from .config import DB_PATH

def now(): return datetime.now(timezone.utc).isoformat()
def conn():
    c=sqlite3.connect(DB_PATH, timeout=30); c.row_factory=sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL'); c.execute('PRAGMA synchronous=FULL'); c.execute('PRAGMA foreign_keys=ON'); c.execute('PRAGMA busy_timeout=5000'); c.execute('PRAGMA wal_autocheckpoint=1000'); return c
def _columns(c, table): return {r[1] for r in c.execute(f'PRAGMA table_info({table})').fetchall()}
def _add(c, table, col, ddl):
    if col not in _columns(c, table): c.execute(f'ALTER TABLE {table} ADD COLUMN {col} {ddl}')
def init_db():
    with conn() as c:
        c.executescript('''
CREATE TABLE IF NOT EXISTS media(id TEXT PRIMARY KEY,name TEXT,path TEXT,kind TEXT,audience TEXT,status TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS schedules(id TEXT PRIMARY KEY,media_id TEXT,platform TEXT,publish_at TEXT,status TEXT,audience TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS approvals(id TEXT PRIMARY KEY,target_type TEXT,target_id TEXT,approved INTEGER,note TEXT,updated_at TEXT);
CREATE TABLE IF NOT EXISTS analytics(id TEXT PRIMARY KEY,platform TEXT,media_id TEXT,views INTEGER DEFAULT 0,likes INTEGER DEFAULT 0,comments INTEGER DEFAULT 0,shares INTEGER DEFAULT 0,captured_at TEXT);
CREATE TABLE IF NOT EXISTS comments(id TEXT PRIMARY KEY,platform TEXT,external_id TEXT,media_id TEXT,text TEXT,action TEXT,status TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS publish_events(id TEXT PRIMARY KEY,schedule_id TEXT,platform TEXT,external_id TEXT,status TEXT,error TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS ai_plans(id TEXT PRIMARY KEY,topic TEXT,content_type TEXT,audience TEXT,quality TEXT,platforms TEXT,plan_json TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS media_jobs(id TEXT PRIMARY KEY,media_id TEXT,operation TEXT,status TEXT,error TEXT,output_media_id TEXT,created_at TEXT,finished_at TEXT);
CREATE TABLE IF NOT EXISTS autopilot_runs(id TEXT PRIMARY KEY,status TEXT,region TEXT,topic TEXT,trend_title TEXT,script TEXT,media_id TEXT,thumbnail_media_id TEXT,schedule_id TEXT,error TEXT,created_at TEXT,updated_at TEXT);
CREATE TABLE IF NOT EXISTS autopilot_followups(id TEXT PRIMARY KEY,source_schedule_id TEXT,sequence INTEGER,topic TEXT,status TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS trend_snapshots(id TEXT PRIMARY KEY,source TEXT,region TEXT,items_json TEXT,captured_at TEXT);
CREATE TABLE IF NOT EXISTS assistant_memory(id TEXT PRIMARY KEY,kind TEXT,text TEXT,importance INTEGER,created_at TEXT,updated_at TEXT);
CREATE TABLE IF NOT EXISTS assistant_events(id TEXT PRIMARY KEY,event_type TEXT,detail TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS assistant_ideas(id TEXT PRIMARY KEY,idea_json TEXT,status TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS reminders(id TEXT PRIMARY KEY,text TEXT NOT NULL,due_at TEXT NOT NULL,status TEXT NOT NULL,repeat_rule TEXT,last_fired_at TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS self_improvement_proposals(id TEXT PRIMARY KEY,title TEXT,proposal_json TEXT,status TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS assistant_memory_vectors(memory_id TEXT PRIMARY KEY,vector_json TEXT NOT NULL,updated_at TEXT);
CREATE TABLE IF NOT EXISTS skill_metrics(skill_key TEXT PRIMARY KEY,attempts INTEGER DEFAULT 0,successes INTEGER DEFAULT 0,failures INTEGER DEFAULT 0,score REAL DEFAULT 0,last_latency_ms INTEGER,updated_at TEXT);
CREATE TABLE IF NOT EXISTS agent_traces(id TEXT PRIMARY KEY,workflow_id TEXT,state TEXT,action TEXT,observation TEXT,result TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS ai_provider_health(provider TEXT PRIMARY KEY,failures INTEGER DEFAULT 0,cooldown_until REAL DEFAULT 0,last_error TEXT,last_success TEXT,updated_at TEXT);
CREATE TABLE IF NOT EXISTS offline_queue(id TEXT PRIMARY KEY,kind TEXT,payload_json TEXT,status TEXT,attempts INTEGER DEFAULT 0,next_attempt_at TEXT,last_error TEXT,created_at TEXT,updated_at TEXT);
CREATE INDEX IF NOT EXISTS idx_memory_updated ON assistant_memory(updated_at);
CREATE INDEX IF NOT EXISTS idx_assistant_events_time ON assistant_events(created_at);
''')
        _add(c,'schedules','next_attempt_at','TEXT'); _add(c,'schedules','attempts','INTEGER DEFAULT 0'); _add(c,'schedules','external_id','TEXT'); _add(c,'schedules','last_error','TEXT'); _add(c,'schedules','plan_id','TEXT'); _add(c,'schedules','quality','TEXT'); _add(c,'schedules','thumbnail_media_id','TEXT'); _add(c,'schedules','metadata_json','TEXT'); _add(c,'schedules','idempotency_key','TEXT')
        _add(c,'media','size_bytes','INTEGER DEFAULT 0'); _add(c,'media','sha256','TEXT'); _add(c,'media','source_media_id','TEXT'); _add(c,'media','operation','TEXT')
        c.execute('CREATE INDEX IF NOT EXISTS idx_sched_due ON schedules(status,publish_at,next_attempt_at)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_analytics_media ON analytics(media_id,captured_at)'); c.execute('CREATE INDEX IF NOT EXISTS idx_offline_queue_due ON offline_queue(status,next_attempt_at,created_at)'); c.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_schedule_idempotency ON schedules(idempotency_key) WHERE idempotency_key IS NOT NULL')
def execute(sql,args=()):
    with conn() as c: return c.execute(sql,args).lastrowid
def rows(sql,args=()):
    with conn() as c: return [dict(r) for r in c.execute(sql,args).fetchall()]
