from ..db import execute, rows


def recover_stale_jobs():
    # Only recover transient execution states; never auto-approve or auto-publish.
    stale = rows("SELECT id FROM schedules WHERE status='executing'")
    recovered = 0
    for item in stale:
        execute("UPDATE schedules SET status=? WHERE id=?", ('retry_wait', item['id']))
        recovered += 1
    return {'recovered': recovered, 'safe_state': True}
