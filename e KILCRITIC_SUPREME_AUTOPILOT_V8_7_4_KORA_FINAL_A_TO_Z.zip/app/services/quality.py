from .audience import policy_check, validate_mode
from ..config import ALLOWED_QUALITY


def validate_content(topic: str, audience: str, content_type: str, flags=None, quality='1080p') -> dict:
    issues = []
    audience = validate_mode(audience)
    if not (topic or '').strip():
        issues.append('topic_required')
    if content_type not in {'video', 'photo', 'wallpaper', 'story'}:
        issues.append('unsupported_content_type')
    if quality not in ALLOWED_QUALITY: issues.append('unsupported_quality')
    policy = policy_check(audience, flags or [])
    if not policy['allowed']:
        issues.append(policy.get('reason', 'audience_policy_blocked'))
    return {'ok': not issues, 'issues': issues, 'quality':quality, 'audience_policy': policy}
