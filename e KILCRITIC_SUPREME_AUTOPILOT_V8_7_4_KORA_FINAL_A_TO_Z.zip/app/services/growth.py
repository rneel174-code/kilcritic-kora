from .ai import generate_text
def build_growth_plan(topic, platforms, audience='GENERAL', content_type='video', web_search=True):
    platforms=platforms or ['youtube','facebook','instagram','tiktok','x']
    base={'topic':topic or 'user_selected_topic','audience':audience,'content_type':content_type,'platforms':platforms,
      'experiments':['hook_A_curiosity','hook_B_benefit','hook_C_result'],
      'retention_design':['0-2s hook','early payoff','pattern interruption','clear ending/loop opportunity'],
      'conversion':['clear reason to follow','series/next-part cue','comment prompt','profile-to-content consistency'],
      'discovery':['search-intent title','topic-relevant keywords','small relevant hashtag set','platform-native metadata'],
      'originality':['original angle','meaningful transformation check','duplicate/reuse risk check'],
      'learning':['views','watch time/retention where available','likes','comments','shares','follows','profile actions','revenue'],
      'rules':['never buy/fake views or followers','never spam hashtags','never guarantee virality/income','respect platform limits and audience mode']}
    if not topic: return base|{'ai':None,'status':'plan_ready'}
    prompt=f'''Act as KILCRITIC Supreme Growth Director. Create a practical growth experiment plan for topic={topic}, audience={audience}, content_type={content_type}, platforms={platforms}. Focus on legitimate retention, discoverability, originality, follower conversion and monetization measurement. Do not recommend fake engagement, spam, manipulation or policy bypass. Identify what should be tested and what metrics decide the next iteration. Keep it concise and actionable.'''
    ai=generate_text(prompt,web_search=web_search); base['ai']=ai; base['status']='ai_plan_ready' if ai.get('ok') else 'local_plan_ready'; return base
