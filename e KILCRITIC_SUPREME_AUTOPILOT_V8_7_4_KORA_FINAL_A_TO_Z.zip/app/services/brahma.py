from __future__ import annotations

import json
import uuid

from ..db import execute, rows, now
from .agent_os import improvement_snapshot, propose_improvements
from .executive import Executive


def read_logs(limit: int = 40) -> list[dict]:
    """Read bounded runtime evidence; secrets, request bodies and media are not collected."""
    limit = max(1, min(int(limit), 100))
    return rows(
        'SELECT event_type,detail,created_at FROM assistant_events '
        'ORDER BY created_at DESC LIMIT ?',
        (limit,),
    )


def improve_self() -> dict:
    """Safe self-improvement cycle: analyze -> propose -> persist -> await approval.

    This deliberately does NOT write arbitrary Python, restart the process, or deploy code.
    """
    evidence = improvement_snapshot()
    logs = read_logs(40)
    goal = 'Improve KILCRITIC from measured runtime evidence without weakening security or approval gates.'
    plan = Executive().plan(goal)
    analysis = propose_improvements()
    proposal_id = str(uuid.uuid4())
    payload = {
        'source': 'brahma_safe_cycle',
        'goal': goal,
        'executive_plan': plan['steps'],
        'evidence': evidence,
        'recent_log_count': len(logs),
        'analysis': analysis,
        'deployment': 'approval_required',
        'automatic_code_write': False,
        'automatic_restart': False,
    }
    execute(
        'INSERT INTO self_improvement_proposals(id,title,proposal_json,status,created_at) VALUES (?,?,?,?,?)',
        (proposal_id, 'Brahma evidence-based improvement cycle', json.dumps(payload, ensure_ascii=False), 'proposed', now()),
    )
    return {
        'ok': True,
        'proposal_id': proposal_id,
        'status': 'proposed',
        'automatic_code_write': False,
        'automatic_restart': False,
        'next_step': 'review -> test -> explicit approval -> controlled deployment',
        'evidence': evidence,
        'log_count': len(logs),
        'executive': plan,
        'analysis': analysis,
    }
