"""Runtime integrity checks: diagnostics only, never fake a healthy result."""
from __future__ import annotations
import os
import shutil
import importlib
from pathlib import Path
from ..config import BASE_DIR, STORAGE, MEDIA_DIR, JOBS_DIR, EXPORTS_DIR, DB_PATH, FFMPEG_BIN

CRITICAL_MODULES = (
    "app.db", "app.services.worker", "app.services.scheduler",
    "app.services.media", "app.services.media_edit", "app.services.ai",
    "app.platforms.registry", "app.platforms.youtube",
)
FORBIDDEN_SUCCESS_MARKERS = (
    "published_to_" + "youtube_real_api",
    "published_to_" + "facebook_real_api",
    "published_to_" + "instagram_real_api",
    "published_to_" + "tiktok_real_api",
    "published_to_" + "x_real_api",
)


def _writable(path: Path) -> bool:
    path.mkdir(parents=True, exist_ok=True)
    probe = path / ".integrity_probe"
    try:
        probe.write_bytes(b"ok")
        probe.unlink(missing_ok=True)
        return True
    except OSError:
        return False


def run_integrity_check() -> dict:
    modules = {}
    for name in CRITICAL_MODULES:
        try:
            importlib.import_module(name)
            modules[name] = "ok"
        except Exception as exc:
            modules[name] = f"failed: {type(exc).__name__}: {str(exc)[:160]}"

    forbidden = []
    for root in (BASE_DIR / "app", BASE_DIR / "run.py"):
        paths = [root] if root.is_file() else list(root.rglob("*.py"))
        for path in paths:
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for marker in FORBIDDEN_SUCCESS_MARKERS:
                if marker in text:
                    forbidden.append(str(path.relative_to(BASE_DIR)) + ":" + marker)

    ffmpeg = shutil.which(FFMPEG_BIN)
    checks = {
        "database_parent_writable": _writable(DB_PATH.parent),
        "media_writable": _writable(MEDIA_DIR),
        "jobs_writable": _writable(JOBS_DIR),
        "exports_writable": _writable(EXPORTS_DIR),
        "ffmpeg_available": bool(ffmpeg),
        "critical_modules_import": all(v == "ok" for v in modules.values()),
        "forbidden_fake_publish_markers_absent": not forbidden,
    }
    return {
        "ok": all(checks.values()),
        "checks": checks,
        "ffmpeg": ffmpeg,
        "critical_modules": modules,
        "forbidden_markers": forbidden,
        "policy": {
            "fake_success": "disabled",
            "real_publish": "official OAuth/API only",
            "database": "SQLite authoritative; JSON helper is artifact-only",
        },
    }
