def comment_plan(mode="MIX"):
 mode=mode.upper()
 if mode not in {"AUTO","HUMAN","MIX"}: raise ValueError("mode must be AUTO, HUMAN or MIX")
 return {"mode":mode,"rules":["spam filtering","risk-sensitive comments to human review","never impersonate user","respect platform limits"]}
