import os
from typing import Any
import json
from uuid import uuid4
from .provider_hub import status as provider_hub_status

class AIProvider:
    """Provider router for KILCRITIC.

    Supported primary providers:
      - groq: OpenAI-compatible Responses API; GPT-OSS 120B.
      - openai: OpenAI Responses API.

    If a primary API call fails, the existing optional text router and finally
    the deterministic local planner remain available. No provider is reported
    as connected until a client can actually be constructed from credentials.
    """

    _SCHEMA = {
        "type": "object",
        "properties": {
            "strategy": {"type": "string"},
            "hook": {"type": "string"},
            "script": {"type": "string"},
            "titles": {"type": "array", "items": {"type": "string"}},
            "caption": {"type": "string"},
            "hashtags": {"type": "array", "items": {"type": "string"}},
            "visual_direction": {"type": "string"},
            "platform_adaptations": {"type": "array", "items": {"type": "string"}},
            "risks_and_checks": {"type": "array", "items": {"type": "string"}},
        },
        "required": [
            "strategy", "hook", "script", "titles", "caption", "hashtags",
            "visual_direction", "platform_adaptations", "risks_and_checks",
        ],
        "additionalProperties": False,
    }

    def __init__(self):
        self.provider = os.getenv("PROVIDER", "groq").strip().lower() or "groq"
        self.reasoning = os.getenv("AI_REASONING", os.getenv("OPENAI_REASONING", "medium")).strip() or "medium"
        self._client = None
        self.api_key = ""

        if self.provider == "groq":
            self.api_key = os.getenv("GROQ_API_KEY", "").strip()
            self.model = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b").strip() or "openai/gpt-oss-120b"
            self.base_url = os.getenv("GROQ_BASE_URL", "https://api.groq.com/openai/v1").strip()
        elif self.provider == "openai":
            self.api_key = os.getenv("OPENAI_API_KEY", "").strip()
            self.model = os.getenv("OPENAI_MODEL", "gpt-5.6-luna").strip() or "gpt-5.6-luna"
            self.base_url = os.getenv("OPENAI_BASE_URL", "").strip()
        elif self.provider == "openrouter":
            self.api_key = os.getenv("OPENROUTER_KEY", "").strip()
            self.model = os.getenv("OPENROUTER_MODEL", "openrouter/free").strip() or "openrouter/free"
            self.base_url = "https://openrouter.ai/api/v1"
        else:
            self.provider = "local"
            self.model = None
            self.base_url = ""

        if self.api_key:
            try:
                from openai import OpenAI
                kwargs = {"api_key": self.api_key}
                if self.base_url:
                    kwargs["base_url"] = self.base_url
                if self.provider == "openrouter":
                    kwargs["default_headers"] = {
                        "HTTP-Referer": os.getenv("OPENROUTER_SITE_URL", "http://127.0.0.1:8000").strip(),
                        "X-Title": "KILCRITIC SUPREME ENGINE",
                    }
                self._client = OpenAI(**kwargs)
            except Exception:
                self._client = None

    @property
    def connected(self) -> bool:
        return self._client is not None and bool(self.api_key)

    def status(self) -> dict:
        return {
            "connected": self.connected,
            "provider": self.provider,
            "model": self.model,
            "reasoning_effort": self.reasoning,
            "mode": "api" if self.connected else "offline",
            "base_url_configured": bool(self.base_url),
            "capabilities": [
                "deep_reasoning", "web_search", "structured_outputs",
                "function_calling", "vision_input", "agentic_workflows",
            ],
            "failover": provider_hub_status(),
            "note": (
                f"{self.provider} AI client configured. A real request is still required to verify API access."
                if self.connected else
                "External AI is not connected; the provider failover chain and local/free fallback remain available."
            ),
        }

    def _request(self, prompt: str, web_search: bool = False, reasoning: str | None = None,
                 structured: bool = False) -> dict:
        kwargs: dict[str, Any] = {
            "model": self.model,
            "input": prompt,
        }
        if self.provider in {"groq", "openai"}:
            kwargs["reasoning"] = {"effort": reasoning or self.reasoning}
        if web_search:
            if self.provider == "groq":
                # Groq documents browser_search for GPT-OSS. Browser search and
                # structured outputs cannot be requested in the same call.
                kwargs["tool_choice"] = "required"
                kwargs["tools"] = [{"type": "browser_search"}]
            elif self.provider == "openai":
                kwargs["tools"] = [{"type": "web_search", "search_context_size": "high"}]
        if structured:
            if self.provider == "groq" and web_search:
                raise RuntimeError("groq_browser_search_and_structured_outputs_are_incompatible")
            kwargs["text"] = {"format": {
                "type": "json_schema",
                "name": "kilcritic_supreme_plan",
                "strict": True,
                "schema": self._SCHEMA,
            }}
        response = self._client.responses.create(**kwargs)
        return {
            "ok": True,
            "provider": self.provider,
            "model": self.model,
            "reasoning_effort": reasoning or self.reasoning,
            "output": getattr(response, "output_text", ""),
            "response_id": getattr(response, "id", None),
            "web_search": bool(web_search),
        }

    def _call(self, prompt: str, web_search: bool = False, reasoning: str | None = None,
              structured: bool = False) -> dict:
        if not self.connected:
            return {
                "ok": False, "provider": self.provider, "model": self.model,
                "error": "AI provider not connected",
                "hint": "Check PROVIDER and the matching API key in .env, then restart the server.",
            }
        if not (prompt or "").strip():
            return {"ok": False, "provider": self.provider, "model": self.model, "error": "prompt_required"}
        try:
            return self._request(prompt, web_search=web_search, reasoning=reasoning, structured=structured)
        except Exception as exc:
            return {"ok": False, "provider": self.provider, "model": self.model, "error": str(exc)[:800]}

    def generate_text(self, prompt: str, web_search: bool = False) -> dict:
        primary = self._call(prompt, web_search=web_search)
        if primary.get("ok"):
            primary["ai_connected"] = True
            return primary
        from .ai_router import generate
        fallback = generate(prompt, web_search=web_search, skip={self.provider})
        if fallback:
            fallback["ok"] = True
            # A local fallback keeps KORA responsive but is not an external AI connection.
            fallback["ai_connected"] = bool(fallback.get("ai_connected", False))
            fallback["fallback_from"] = primary.get("error")
            return fallback
        return primary

    def generate_supreme_plan(self, topic: str, content_type: str, audience: str,
                              platforms: list[str] | None = None, web_search: bool = True,
                              quality: str = "1080p", plan_id: str | None = None) -> dict:
        platforms = platforms or ["youtube", "facebook", "instagram", "tiktok", "x"]
        plan_id = plan_id or str(uuid4())

        if not self.connected:
            from .ai_router import generate
            fallback_prompt = (
                f"Build a concise content plan. Topic: {topic}. Content type: {content_type}. "
                f"Audience: {audience}. Quality: {quality}. Platforms: {', '.join(platforms)}. "
                "Return JSON with keys strategy, hook, script, titles, caption, hashtags, "
                "visual_direction, platform_adaptations, risks_and_checks. Do not promise virality or income."
            )
            routed = generate(fallback_prompt, web_search=web_search, skip={self.provider})
            if routed:
                routed["plan_id"] = plan_id
                routed["request"] = {
                    "topic": topic, "content_type": content_type, "audience": audience,
                    "quality": quality, "platforms": platforms, "web_search": web_search,
                }
                try:
                    routed["plan"] = json.loads(routed.get("output", ""))
                except Exception:
                    routed["plan"] = None
                return routed

            t = (topic or "your topic").strip()[:160]
            plan = {
                "strategy": f"Create an original {content_type} around {t} with a clear first-second hook and useful payoff.",
                "hook": f"Hook the viewer immediately around the main question or result in: {t}.",
                "script": f"Opening: {t}.\nValue: give one clear useful or entertaining point.\nClose: invite a relevant comment or next-part request.",
                "titles": [t[:70], f"{t[:55]} — quick guide", f"{t[:50]} | KILCRITIC"],
                "caption": f"{t} — original content prepared for {audience.lower()} audience.",
                "hashtags": [f"#{w.lower()}" for w in t.split() if w.isalnum()][:5],
                "visual_direction": f"Use source-owned media, readable text, clean cuts and {quality} delivery target.",
                "platform_adaptations": [f"{p}: adapt title, crop, caption and length to native format." for p in platforms],
                "risks_and_checks": [
                    "Run audience/policy check before publishing.",
                    "Do not reuse third-party media without permission.",
                    "Quality is a delivery target; upscaling does not add missing detail.",
                ],
            }
            return {
                "ok": True, "provider": "local_rule_engine", "model": None, "free": True,
                "ai_connected": False, "plan_id": plan_id, "plan": plan,
                "output": json.dumps(plan),
                "request": {
                    "topic": topic, "content_type": content_type, "audience": audience,
                    "quality": quality, "platforms": platforms, "web_search": False,
                },
                "note": "External AI is not connected; this is a deterministic free fallback, not an AI-provider claim.",
            }

        prompt = f"""You are KILCRITIC SUPREME ENGINE's senior strategy brain.
Build one evidence-aware, platform-adapted content plan that can be handed to a downstream media pipeline.

Plan ID: {plan_id}
Topic: {topic}
Content type: {content_type}
Audience mode: {audience}
Requested quality: {quality}
Platforms: {', '.join(platforms)}

Think deeply before answering. If web search is enabled, research current relevant signals first.
Optimize for originality, audience value, retention, discoverability and legitimate monetization opportunities.
Do not promise guaranteed virality, guaranteed income, or bypass platform rules.
Respect the requested audience mode and require a policy check before publication.
The requested quality is a delivery target, not a claim that upscaling creates missing source detail.
Return the exact structured fields requested by the response schema."""

        # Groq browser search cannot be combined with structured outputs. Research
        # first, then hand the returned evidence to a second structured call.
        research = ""
        if self.provider == "groq" and web_search:
            research_result = self._call(
                f"Research current, relevant signals for this content plan. Topic: {topic}. "
                f"Audience: {audience}. Platforms: {', '.join(platforms)}. "
                "Return concise factual findings with source names/URLs where available. "
                "Do not invent data or promise virality.",
                web_search=True,
                reasoning=self.reasoning,
                structured=False,
            )
            if research_result.get("ok"):
                research = research_result.get("output", "")[:12000]
            else:
                research = "Web research failed; continue without claiming current verification."

        if research:
            prompt += "\n\nCURRENT RESEARCH SIGNALS:\n" + research
        result = self._call(prompt, web_search=False, reasoning=self.reasoning, structured=True)
        if not result.get("ok"):
            primary_error = result.get("error") or "primary_structured_call_failed"
            from .ai_router import generate
            fallback_prompt = prompt + "\nReturn valid JSON with exactly these keys: strategy, hook, script, titles, caption, hashtags, visual_direction, platform_adaptations, risks_and_checks."
            routed = generate(fallback_prompt, web_search=False, skip={self.provider})
            if routed:
                result = routed
                result["fallback_from"] = primary_error
            else:
                # Final local guarantee: planning still works when every external AI is unavailable.
                t = (topic or "your topic").strip()[:160]
                local_plan = {
                    "strategy": f"Create an original {content_type} around {t} with a clear first-second hook and useful payoff.",
                    "hook": f"Hook the viewer immediately around the main question or result in: {t}.",
                    "script": f"Opening: {t}.\nValue: give one clear useful or entertaining point.\nClose: invite a relevant comment or next-part request.",
                    "titles": [t[:70], f"{t[:55]} — quick guide", f"{t[:50]} | KILCRITIC"],
                    "caption": f"{t} — original content prepared for {audience.lower()} audience.",
                    "hashtags": [f"#{w.lower()}" for w in t.split() if w.isalnum()][:5],
                    "visual_direction": f"Use source-owned media, readable text, clean cuts and {quality} delivery target.",
                    "platform_adaptations": [f"{p}: adapt title, crop, caption and length to native format." for p in platforms],
                    "risks_and_checks": ["Run audience/policy check before publishing.", "Do not reuse third-party media without permission.", "Quality is a delivery target; upscaling does not add missing source detail."],
                }
                result = {"ok": True, "provider": "local_rule_engine", "model": None, "free": True, "ai_connected": False, "plan": local_plan, "output": json.dumps(local_plan), "fallback_from": primary_error, "note": "All external AI routes failed; local deterministic planner kept the workflow alive."}
        result["plan_id"] = plan_id
        result["request"] = {
            "topic": topic, "content_type": content_type, "audience": audience,
            "quality": quality, "platforms": platforms, "web_search": web_search,
        }
        if result.get("ok"):
            raw = result.get("output", "")
            try:
                result["plan"] = json.loads(raw)
            except Exception:
                result["plan"] = None
        return result

    def generate_media_plan(self, topic: str, content_type: str, audience: str,
                            platforms: list[str] | None = None) -> dict:
        return self.generate_supreme_plan(topic, content_type, audience, platforms, web_search=False)


_PROVIDER = AIProvider()


def provider_status() -> dict:
    return _PROVIDER.status()


def generate_text(prompt: str, web_search: bool = False) -> dict:
    return _PROVIDER.generate_text(prompt, web_search=web_search)


def generate_media_plan(topic: str, content_type: str, audience: str,
                        platforms: list[str] | None = None) -> dict:
    return _PROVIDER.generate_media_plan(topic, content_type, audience, platforms)


def generate_supreme_plan(topic: str, content_type: str, audience: str,
                          platforms: list[str] | None = None, web_search: bool = True,
                          quality: str = '1080p', plan_id: str | None = None) -> dict:
    return _PROVIDER.generate_supreme_plan(topic, content_type, audience, platforms, web_search, quality, plan_id)
