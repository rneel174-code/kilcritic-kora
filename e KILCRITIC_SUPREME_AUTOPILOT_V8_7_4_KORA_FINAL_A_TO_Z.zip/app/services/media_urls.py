from __future__ import annotations
import hashlib, hmac, time
from pathlib import Path
from urllib.parse import urlencode
from fastapi import HTTPException
from fastapi.responses import FileResponse
from ..config import MEDIA_DIR, MEDIA_SIGNING_SECRET, KILCRITIC_ACCESS_TOKEN

def _secret() -> bytes:
    seed = MEDIA_SIGNING_SECRET or KILCRITIC_ACCESS_TOKEN or 'kilcritic-local-media-capability'
    return hashlib.sha256(seed.encode('utf-8')).digest()

def sign_media(filename: str, ttl: int = 900) -> str:
    name = Path(filename).name
    exp = int(time.time()) + max(60, min(int(ttl), 3600))
    sig = hmac.new(_secret(), f'{name}.{exp}'.encode('utf-8'), hashlib.sha256).hexdigest()
    return f'/storage/media/{name}?{urlencode({"exp": exp, "sig": sig})}'

def _verify(filename: str, exp: str, sig: str) -> Path:
    name = Path(filename).name
    if name != filename: raise HTTPException(400, 'invalid_media_name')
    try: expiry = int(exp)
    except Exception: raise HTTPException(400, 'invalid_media_signature')
    if expiry < int(time.time()) or expiry > int(time.time()) + 7200: raise HTTPException(403, 'media_signature_expired')
    expected = hmac.new(_secret(), f'{name}.{expiry}'.encode('utf-8'), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, sig or ''): raise HTTPException(403, 'media_signature_invalid')
    path = (MEDIA_DIR / name).resolve()
    if MEDIA_DIR.resolve() not in path.parents or not path.is_file(): raise HTTPException(404, 'media_not_found')
    return path

def serve(filename: str, exp: str, sig: str):
    path = _verify(filename, exp, sig)
    return FileResponse(path, headers={'Cache-Control':'private, max-age=300', 'X-Content-Type-Options':'nosniff', 'Referrer-Policy':'no-referrer'})
