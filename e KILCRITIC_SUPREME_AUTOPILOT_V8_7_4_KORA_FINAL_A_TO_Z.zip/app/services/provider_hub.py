from __future__ import annotations
import json, os, time
from typing import Any
from urllib import request as urlrequest
from urllib.error import HTTPError, URLError
from .security import guard_url
from ..db import execute, rows, now


DEFAULT_ORDER = ('groq', 'openrouter', 'gemini', 'cerebras', 'ollama', 'openai', 'local')
_FAILURES: dict[str, int] = {}
_COOLDOWN_UNTIL: dict[str, float] = {}
COOLDOWN_SECONDS = 60

SETUP_LINKS = {
    'groq': 'https://console.groq.com/keys',
    'openrouter': 'https://openrouter.ai/keys',
    'gemini': 'https://aistudio.google.com/apikey',
    'cerebras': 'https://cloud.cerebras.ai/',
    'ollama': 'https://ollama.com/download',
    'openai': 'https://platform.openai.com/api-keys',
}


def _env_bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {'1', 'true', 'yes', 'on'}


def _post_json(url: str, payload: dict, headers: dict | None = None, timeout: int = 35) -> dict:
    guard_url(url, 'ai_provider')
    body = json.dumps(payload).encode('utf-8')
    req = urlrequest.Request(url, data=body, method='POST', headers={'Content-Type': 'application/json', **(headers or {})})
    try:
        with urlrequest.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode('utf-8'))
    except HTTPError as e:
        try:
            detail = e.read().decode('utf-8')[:600]
        except Exception:
            detail = str(e)
        raise RuntimeError(f'http_{e.code}: {detail}')
    except URLError as e:
        raise RuntimeError(f'network_error: {e.reason}')


def _chat_openai_compatible(provider: str, prompt: str, timeout: int = 35) -> dict:
    if provider == 'groq':
        key = os.getenv('GROQ_API_KEY', '').strip()
        if not key:
            raise RuntimeError('not_configured')
        url = os.getenv('GROQ_CHAT_URL', 'https://api.groq.com/openai/v1/chat/completions').strip()
        model = os.getenv('GROQ_MODEL', 'openai/gpt-oss-120b').strip()
        headers = {'Authorization': f'Bearer {key}'}
    elif provider == 'openrouter':
        key = os.getenv('OPENROUTER_KEY', '').strip()
        if not key:
            raise RuntimeError('not_configured')
        url = os.getenv('OPENROUTER_CHAT_URL', 'https://openrouter.ai/api/v1/chat/completions').strip()
        model = os.getenv('OPENROUTER_MODEL', 'openrouter/free').strip()
        headers = {
            'Authorization': f'Bearer {key}',
            'HTTP-Referer': os.getenv('OPENROUTER_SITE_URL', 'http://127.0.0.1:8000').strip(),
            'X-Title': 'KILCRITIC SUPREME ENGINE',
        }
    elif provider == 'cerebras':
        key = os.getenv('CEREBRAS_API_KEY', '').strip()
        if not key:
            raise RuntimeError('not_configured')
        url = os.getenv('CEREBRAS_CHAT_URL', 'https://api.cerebras.ai/v1/chat/completions').strip()
        model = os.getenv('CEREBRAS_MODEL', 'llama-3.3-70b').strip()
        headers = {'Authorization': f'Bearer {key}'}
    elif provider == 'openai':
        key = os.getenv('OPENAI_API_KEY', '').strip()
        if not key:
            raise RuntimeError('not_configured')
        url = os.getenv('OPENAI_CHAT_URL', 'https://api.openai.com/v1/chat/completions').strip()
        model = os.getenv('OPENAI_MODEL', 'gpt-5.6-luna').strip()
        headers = {'Authorization': f'Bearer {key}'}
    elif provider == 'ollama':
        url = os.getenv('OLLAMA_CHAT_URL', 'http://127.0.0.1:11434/v1/chat/completions').strip()
        model = os.getenv('OLLAMA_MODEL', 'llama3.2:3b').strip()
        headers = {}
    else:
        raise RuntimeError('unsupported_provider')
    data = _post_json(url, {
        'model': model,
        'messages': [{'role': 'user', 'content': prompt}],
        'temperature': 0,
        'max_tokens': int(os.getenv('AI_FALLBACK_MAX_TOKENS', '1400')),
    }, headers, timeout)
    text = (((data.get('choices') or [{}])[0]).get('message') or {}).get('content', '')
    if isinstance(text, list):
        text = ''.join(x.get('text', '') if isinstance(x, dict) else str(x) for x in text)
    if not text:
        raise RuntimeError('provider_returned_empty_output')
    return {'provider': provider, 'model': model, 'output': text}


def _gemini(prompt: str, timeout: int = 35) -> dict:
    key = os.getenv('GEMINI_API_KEY', '').strip()
    if not key:
        raise RuntimeError('not_configured')
    model = os.getenv('GEMINI_MODEL', 'gemini-3.8-flash').strip()
    base = os.getenv('GEMINI_BASE_URL', 'https://generativelanguage.googleapis.com/v1beta').rstrip('/')
    url = f'{base}/models/{model}:generateContent?key={key}'
    data = _post_json(url, {
        'contents': [{'role': 'user', 'parts': [{'text': prompt}]}],
        'generationConfig': {'temperature': 0, 'maxOutputTokens': int(os.getenv('AI_FALLBACK_MAX_TOKENS', '1400'))},
    }, timeout=timeout)
    parts = []
    for cand in data.get('candidates', []) or []:
        for part in (cand.get('content') or {}).get('parts', []) or []:
            if part.get('text'):
                parts.append(part['text'])
    text = ''.join(parts).strip()
    if not text:
        raise RuntimeError('provider_returned_empty_output')
    return {'provider': 'gemini', 'model': model, 'output': text}


def _configured(provider: str) -> bool:
    return {
        'groq': bool(os.getenv('GROQ_API_KEY', '').strip()),
        'gemini': bool(os.getenv('GEMINI_API_KEY', '').strip()),
        'openrouter': bool(os.getenv('OPENROUTER_KEY', '').strip()),
        'cerebras': bool(os.getenv('CEREBRAS_API_KEY', '').strip()),
        'openai': bool(os.getenv('OPENAI_API_KEY', '').strip()),
        'ollama': _env_bool('OLLAMA_ENABLED', False),
        'local': True,
    }.get(provider, False)


def order() -> list[str]:
    raw = os.getenv('AI_PROVIDER_ORDER', ','.join(DEFAULT_ORDER))
    seen = []
    for p in [x.strip().lower() for x in raw.split(',') if x.strip()] + list(DEFAULT_ORDER):
        if p not in seen:
            seen.append(p)
    return seen


def status() -> dict:
    models = {
        'groq': os.getenv('GROQ_MODEL', 'openai/gpt-oss-120b'),
        'gemini': os.getenv('GEMINI_MODEL', 'gemini-3.8-flash'),
        'openrouter': os.getenv('OPENROUTER_MODEL', 'openrouter/free'),
        'cerebras': os.getenv('CEREBRAS_MODEL', 'llama-3.3-70b'),
        'openai': os.getenv('OPENAI_MODEL', 'gpt-5.6-luna'),
        'ollama': os.getenv('OLLAMA_MODEL', 'llama3.2:3b'),
        'local': 'deterministic-rule-engine',
    }
    return {
        'order': order(),
        'providers': [
            {'provider': p, 'configured': _configured(p), 'model': models.get(p), 'mode': 'local' if p in {'local', 'ollama'} else 'remote'}
            for p in order()
        ],
        'failover': True,
        'local_last_resort': True,
        'note': 'The core server does not depend on any single AI provider. Provider failure falls through the configured chain; local deterministic mode remains available.'
    }


def _persist_failure(provider: str, error: str) -> int:
    current = rows('SELECT failures FROM ai_provider_health WHERE provider=?', (provider,))
    failures = int(current[0]['failures']) + 1 if current else 1
    cooldown = time.time() + COOLDOWN_SECONDS if failures >= 2 else 0
    execute('INSERT OR REPLACE INTO ai_provider_health(provider,failures,cooldown_until,last_error,last_success,updated_at) VALUES (?,?,?,?,?,?)',
            (provider, failures, cooldown, str(error)[:500], current[0]['last_success'] if current else None, now()))
    _FAILURES[provider] = failures
    if cooldown:
        _COOLDOWN_UNTIL[provider] = cooldown
    return failures


def _persist_success(provider: str) -> None:
    execute('INSERT OR REPLACE INTO ai_provider_health(provider,failures,cooldown_until,last_error,last_success,updated_at) VALUES (?,?,?,?,?,?)',
            (provider, 0, 0, None, now(), now()))
    _FAILURES[provider] = 0
    _COOLDOWN_UNTIL.pop(provider, None)


def _local_generate(prompt: str) -> dict:
    """Deterministic last-resort responder. It never pretends to be an external AI."""
    text = (prompt or '').strip()
    low = text.lower()
    if any(x in low for x in ('hello', 'hi ', 'hey', 'are you there', 'are you here', 'who are you')):
        output = (
            'Yes — KORA is online. The local KILCRITIC engine is running. '
            'External AI is currently not connected, so this reply is coming from the local fallback. '
            'You can continue using the guarded local functions; connect an approved AI provider when you want external AI reasoning or live web search.'
        )
    elif any(x in low for x in ('status', 'system check', 'health', 'alive')):
        output = (
            'KORA status: core server is responding and local fallback is active. '
            'External AI provider status is separate and currently not verified. '
            'Publishing remains approval-gated and official API/OAuth-only.'
        )
    elif 'remember' in low or 'memory' in low:
        output = (
            'KORA can store explicit project memories locally. Use the Remember/Save Memory command to persist a specific item.'
        )
    elif any(x in low for x in ('make plan', 'create plan', 'plan', 'idea')):
        output = (
            'Local planner is active. Give a topic and KORA can prepare a deterministic content-plan skeleton. '
            'External AI is required for richer model-generated reasoning.'
        )
    else:
        compact = ' '.join(text.split())[:300]
        output = (
            f'KORA received your command: {compact}. '
            'KORA local mode is active and the server is responding. '
            'For richer reasoning or live web results, connect an approved AI provider; '
            'local mode will not pretend that external search or AI was used.'
        )
    return {
        'provider': 'local_rule_engine',
        'model': None,
        'output': output,
        'free': True,
        'local': True,
    }


def generate(prompt: str, skip: set[str] | None = None, timeout: int = 35, web_search: bool = False) -> dict | None:
    skip = skip or set()
    errors = []
    now_ts = time.time()
    if web_search:
        # Only providers with an implemented search tool should claim live search.
        # The local/offline fallback remains honest and does not fabricate web results.
        errors.append({'note': 'web_search_requested'})
    for provider in order():
        persisted = rows('SELECT failures,cooldown_until FROM ai_provider_health WHERE provider=?', (provider,))
        persisted_until = float(persisted[0]['cooldown_until']) if persisted else 0
        until = max(_COOLDOWN_UNTIL.get(provider, 0), persisted_until)
        if until > now_ts:
            errors.append({'provider': provider, 'error': 'temporary_cooldown', 'cooldown_seconds': int(until-now_ts)})
            continue
        if provider in skip or not _configured(provider):
            continue
        try:
            if provider == 'local':
                result = _local_generate(prompt)
                _persist_success(provider)
                result.update({'ok': True, 'ai_connected': False, 'fallback': bool(errors), 'errors_before_success': errors})
                return result
            if provider == 'gemini':
                result = _gemini(prompt, timeout)
            else:
                result = _chat_openai_compatible(provider, prompt, timeout)
            _persist_success(provider)
            result.update({'ok': True, 'ai_connected': True, 'fallback': bool(errors), 'errors_before_success': errors})
            return result
        except Exception as exc:
            err = str(exc)[:300]
            _persist_failure(provider, err)
            errors.append({'provider': provider, 'error': err})
    return None

def health() -> dict:
    now_ts = time.time()
    out=[]
    for p in order():
        r=rows('SELECT failures,cooldown_until,last_error,last_success,updated_at FROM ai_provider_health WHERE provider=?',(p,))
        x=r[0] if r else {}
        out.append({'provider':p,'failures':int(x.get('failures',0) or 0),'cooldown':max(0,int(float(x.get('cooldown_until',0) or 0)-now_ts)),'last_error':x.get('last_error'),'last_success':x.get('last_success'),'updated_at':x.get('updated_at')})
    return {'providers':out,'cooldown_seconds':COOLDOWN_SECONDS,'persistent':True}


def rescue_recommendations() -> dict:
    defaults = {
        'groq': 'openai/gpt-oss-120b', 'openrouter': 'openrouter/free', 'gemini': 'gemini-3.8-flash',
        'cerebras': 'llama-3.3-70b', 'ollama': 'llama3.2:3b', 'openai': 'gpt-5.6-luna'
    }
    env_names = {'groq':'GROQ_MODEL','openrouter':'OPENROUTER_MODEL','gemini':'GEMINI_MODEL','cerebras':'CEREBRAS_MODEL','ollama':'OLLAMA_MODEL','openai':'OPENAI_MODEL'}
    return {'ok': True, 'note': 'Free tiers, quotas and pricing can change; verify the provider before use.', 'chain': [
        {'provider': p, 'configured': _configured(p), 'model': os.getenv(env_names.get(p,''), defaults.get(p)), 'setup_link': SETUP_LINKS.get(p)}
        for p in order() if p != 'local'
    ]}
