import shutil, subprocess, tempfile
from pathlib import Path
from uuid import uuid4
from ..config import EXPORTS_DIR

def status():
    return {'browser_preview':True,'local_tts_available':bool(shutil.which('espeak-ng') or shutil.which('espeak') or _pyttsx3_available()),'note':'Browser SpeechSynthesis is available for preview. Local server TTS depends on an installed OS voice engine.'}

def _pyttsx3_available():
    try:
        import pyttsx3  # optional
        return True
    except Exception:
        return False

def synthesize(text, language='en'):
    text=(text or '').strip()
    if not text: raise ValueError('text_required')
    if len(text)>5000: raise ValueError('text_too_long')
    out=EXPORTS_DIR/f'{uuid4()}_tts.wav'
    exe=shutil.which('espeak-ng') or shutil.which('espeak')
    if exe:
        subprocess.run([exe,'-w',str(out),text],check=True,timeout=120,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return str(out)
    try:
        import pyttsx3
        engine=pyttsx3.init()
        engine.save_to_file(text,str(out)); engine.runAndWait()
        if out.is_file() and out.stat().st_size>0: return str(out)
    except Exception as e:
        out.unlink(missing_ok=True)
        raise RuntimeError('Local TTS engine is unavailable on this device') from e
    raise RuntimeError('Local TTS engine is unavailable on this device')
