MODES={"KIDS","GENERAL","ADULT"}
def validate_mode(mode):
 mode=(mode or "GENERAL").upper()
 if mode not in MODES: raise ValueError("Audience mode must be KIDS, GENERAL or ADULT")
 return mode
def policy_check(audience,flags=None):
 audience=validate_mode(audience); flags={str(x).lower() for x in (flags or [])}
 if audience=="KIDS" and flags & {"explicit_sexual","pornographic","adult_sexual"}:
  return {"allowed":False,"reason":"Adult sexual content is blocked in KIDS mode."}
 return {"allowed":True,"audience":audience,"checks":["audience separation","platform policy","lawful-content requirement"]}
def modes():
 return [{"id":"KIDS","label":"Kids","description":"Child-appropriate content only; adult sexual content blocked."},{"id":"GENERAL","label":"General / Mixed","description":"Broad audience content with normal safety/platform checks."},{"id":"ADULT","label":"18+","description":"Adult-audience mode; only lawful and platform-permitted content."}]
