from __future__ import annotations
import hashlib, os, re, time
from datetime import datetime, timezone
from urllib.parse import urlparse
from fastapi import Request
from ..db import execute, rows, now
from ..config import KILCRITIC_ACCESS_TOKEN, REMOTE_ACCESS_REQUIRED

DEFAULT_ALLOWED_HOSTS = {
    'api.groq.com', 'generativelanguage.googleapis.com', 'openrouter.ai', 'openrouter.ai',
    'api.cerebras.ai', '127.0.0.1', 'localhost', 'oauth2.googleapis.com',
    'www.googleapis.com', 'youtube.googleapis.com', 'www.youtube.com', 'x.com',
    'www.facebook.com', 'graph.facebook.com', 'graph.instagram.com', 'api.instagram.com',
    'www.tiktok.com', 'open.tiktokapis.com'
}
PUBLIC_SAFE_PATHS = {'/api/security/status', '/api/security/kill-switch', '/api/security/events'}

def _token_ok(token: str | None) -> bool:
    expected = os.getenv('MALAK_CONTROL_TOKEN', '').strip()
    if expected:
        return bool(token) and hashlib.sha256(token.encode()).digest() == hashlib.sha256(expected.encode()).digest()
    return False

def _local_request(request: Request | None) -> bool:
    if request is None or not request.client:
        return False
    return request.client.host in {'127.0.0.1', '::1', 'localhost'}


_AUTH_FAILS: dict[str, list[float]] = {}

def is_local_request(request: Request | None) -> bool:
    return _local_request(request)

def hmac_compare(a: str, b: str) -> bool:
    return hashlib.sha256(a.encode()).digest() == hashlib.sha256(b.encode()).digest()

def authorize_remote_request(request: Request | None, token: str | None) -> bool:
    if not REMOTE_ACCESS_REQUIRED or _local_request(request):
        return True
    if not KILCRITIC_ACCESS_TOKEN:
        return False
    ip = request.client.host if request and request.client else 'unknown'
    now_ts = time.time()
    recent = [x for x in _AUTH_FAILS.get(ip, []) if now_ts - x < 60]
    _AUTH_FAILS[ip] = recent
    if len(recent) >= 5:
        return False
    supplied = (token or '').strip()
    ok = bool(supplied) and hmac_compare(supplied, KILCRITIC_ACCESS_TOKEN)
    if not ok:
        recent.append(now_ts)
        _AUTH_FAILS[ip] = recent
    else:
        _AUTH_FAILS.pop(ip, None)
    return ok

def authorize_control(request: Request | None, token: str | None) -> bool:
    # If a Malak token is configured it is always required. For the default
    # localhost-first build, emergency control is also available locally.
    return _token_ok(token) or (not os.getenv('MALAK_CONTROL_TOKEN', '').strip() and _local_request(request))

def get_kill_switch() -> dict:
    r = rows("SELECT value FROM settings WHERE key='system.kill_switch'")
    active = bool(r and str(r[0]['value']).lower() == 'on')
    rr = rows("SELECT value FROM settings WHERE key='system.kill_reason'")
    return {'active': active, 'reason': rr[0]['value'] if rr else '', 'updated_at': (rows("SELECT value FROM settings WHERE key='system.kill_updated_at'") or [{'value':''}])[0]['value']}

def set_kill_switch(active: bool, reason: str = 'Malak emergency control') -> dict:
    val = 'on' if active else 'off'
    t = now()
    execute("INSERT OR REPLACE INTO settings(key,value) VALUES ('system.kill_switch',?)", (val,))
    execute("INSERT OR REPLACE INTO settings(key,value) VALUES ('system.kill_reason',?)", (reason[:500],))
    execute("INSERT OR REPLACE INTO settings(key,value) VALUES ('system.kill_updated_at',?)", (t,))
    security_event('kill_switch', {'active': active, 'reason': reason[:500]})
    return get_kill_switch()

def assert_running() -> None:
    if get_kill_switch()['active']:
        raise RuntimeError('system_kill_switch_active')

def _allowed_hosts() -> set[str]:
    raw = os.getenv('SECURITY_ALLOWED_OUTBOUND_HOSTS', '').strip()
    if not raw:
        return DEFAULT_ALLOWED_HOSTS
    return {x.strip().lower() for x in raw.split(',') if x.strip()} | {'127.0.0.1','localhost'}

def guard_url(url: str, purpose: str = 'external_request') -> str:
    """Allowlist known external connectors and block unexpected destinations.
    This is a defensive egress guard; it does not inspect or attack remote systems.
    """
    assert_running()
    parsed = urlparse(url)
    if parsed.scheme not in {'https','http'}:
        security_event('blocked_outbound', {'host': parsed.hostname or '', 'purpose': purpose, 'reason':'unsupported_scheme'})
        raise RuntimeError('outbound_scheme_blocked')
    if parsed.username or parsed.password:
        security_event('blocked_outbound', {'host': parsed.hostname or '', 'purpose': purpose, 'reason':'userinfo_in_url'})
        raise RuntimeError('outbound_userinfo_blocked')
    host = (parsed.hostname or '').lower().rstrip('.')
    allowed = _allowed_hosts()
    if host not in allowed:
        security_event('blocked_outbound', {'host': host, 'purpose': purpose})
        raise RuntimeError('outbound_destination_blocked')
    security_event('outbound_allowed', {'host': host, 'purpose': purpose})
    return url

def security_event(event_type: str, detail: dict | str, request: Request | None = None) -> None:
    # Store only a short, redacted security record. Do not store secrets, request bodies or media.
    import json
    payload = detail if isinstance(detail, dict) else {'detail': str(detail)}
    payload.pop('authorization', None); payload.pop('token', None); payload.pop('api_key', None)
    if request is not None and request.client:
        payload['source_ip'] = request.client.host
        payload['method'] = request.method
        payload['path'] = request.url.path
    execute('INSERT INTO assistant_events(id,event_type,detail,created_at) VALUES (lower(hex(randomblob(16))),?,?,?)',
            (event_type, json.dumps(payload, ensure_ascii=False)[:1500], now()))

def status() -> dict:
    ks = get_kill_switch()
    return {
        'ok': True,
        'kill_switch': ks,
        'privacy': {
            'telemetry': False,
            'unsolicited_third_party_sharing': False,
            'provider_data_sharing': 'only when an explicitly configured external provider is invoked',
            'external_requests': 'allowlisted connectors only',
            'secrets_in_logs': False,
            'media_uploads_to_ai': 'only when an explicitly configured provider/capability requires it',
        },
        'defense': {
            'outbound_allowlist': True,
            'security_event_log': True,
            'publish_requires_malak_approval': True,
            'duplicate_publish_block': True,
            'remote_code_execution': False,
            'automatic_self_deploy': False,
            'automatic_hackback': False,
        },
        'allowed_outbound_hosts': sorted(_allowed_hosts()),
        'source_address_note': 'Security logs can record the network address seen by this server for defensive auditing; it is not a physical-address lookup.',
        'secure_defaults': True,
        'remote_code_execution': False,
        'self_update': 'proposal -> test -> Malak approval only',
    }

def events(limit: int = 50) -> list[dict]:
    limit = max(1, min(int(limit), 200))
    return rows("SELECT event_type,detail,created_at FROM assistant_events WHERE event_type IN ('kill_switch','blocked_outbound','outbound_allowed','security_denied') ORDER BY created_at DESC LIMIT ?", (limit,))
