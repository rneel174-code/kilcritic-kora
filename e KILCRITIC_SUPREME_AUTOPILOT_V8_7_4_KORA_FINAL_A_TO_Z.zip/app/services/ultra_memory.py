from __future__ import annotations
import hashlib, math, re
from collections import Counter
from uuid import uuid4
from ..db import execute, rows, now

# Lightweight local vector-like memory: hashed bag-of-words + recency/importance.
# It is intentionally deterministic and requires no external embedding service.
_DIM = 256
_WORD = re.compile(r"[\w']+", re.UNICODE)


def _vec(text: str) -> list[float]:
    v = [0.0] * _DIM
    tokens = [x.lower() for x in _WORD.findall(text or '')]
    if not tokens:
        return v
    counts = Counter(tokens)
    for token, n in counts.items():
        h = int.from_bytes(hashlib.blake2b(token.encode('utf-8'), digest_size=4).digest(), 'big') % _DIM
        sign = -1.0 if (h & 1) else 1.0
        v[h] += sign * (1.0 + math.log1p(n))
    norm = math.sqrt(sum(x*x for x in v)) or 1.0
    return [x / norm for x in v]


def _cos(a: list[float], b: list[float]) -> float:
    return sum(x*y for x, y in zip(a, b))


def remember(text: str, kind: str = 'project', importance: int = 5) -> dict:
    text = (text or '').strip()
    if not text:
        raise ValueError('memory_text_required')
    importance = max(1, min(10, int(importance)))
    mid = str(uuid4())
    execute('INSERT INTO assistant_memory(id,kind,text,importance,created_at,updated_at) VALUES (?,?,?,?,?,?)',
            (mid, kind[:40], text[:10000], importance, now(), now()))
    execute('INSERT OR REPLACE INTO assistant_memory_vectors(memory_id,vector_json,updated_at) VALUES (?,?,?)',
            (mid, __import__('json').dumps(_vec(text), separators=(',', ':')), now()))
    return {'ok': True, 'memory_id': mid, 'indexed': True, 'index': 'local_hash_vector'}


def search(query: str, limit: int = 12) -> list[dict]:
    query = (query or '').strip()
    if not query:
        return []
    import json
    qv = _vec(query)
    qtokens = set(x.lower() for x in _WORD.findall(query))
    out = []
    for m in rows('SELECT m.id,m.kind,m.text,m.importance,m.created_at,m.updated_at,v.vector_json FROM assistant_memory m LEFT JOIN assistant_memory_vectors v ON v.memory_id=m.id'):
        try:
            vv = json.loads(m.get('vector_json') or '[]')
            score = _cos(qv, vv) if len(vv) == _DIM else 0.0
        except Exception:
            score = 0.0
        mtokens = set(x.lower() for x in _WORD.findall(m['text']))
        overlap = len(qtokens & mtokens) / max(1, len(qtokens))
        score = 0.75 * max(0.0, score) + 0.20 * overlap + 0.05 * (m['importance'] / 10.0)
        out.append({k: m[k] for k in ('id','kind','text','importance','created_at','updated_at')} | {'score': round(score, 5)})
    out.sort(key=lambda x: (x['score'], x['importance']), reverse=True)
    return out[:max(1, min(50, int(limit)))]
