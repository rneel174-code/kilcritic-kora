from __future__ import annotations
import json, os, re, subprocess, uuid, urllib.parse, urllib.request
from pathlib import Path
from datetime import datetime, timezone
from ..config import FFMPEG_BIN, MEDIA_DIR, EXPORTS_DIR, QUALITY_PRESETS, AUTOPILOT_FOLLOWUP_VIEW_THRESHOLD, AUTOPILOT_MAX_FOLLOWUPS
from ..db import execute, rows, now
from .ai import generate_text
from .tts import synthesize
from .audience import validate_mode
from .security import guard_url


def _slug(text: str) -> str:
    s = re.sub(r'[^A-Za-z0-9._-]+', '_', text or 'autopilot').strip('_')
    return s[:70] or 'autopilot'


def _youtube_trends(region='IN', category_id=''):
    key = os.getenv('YOUTUBE_API_KEY', '').strip()
    if not key:
        raise RuntimeError('YOUTUBE_API_KEY is required for official YouTube trend discovery')
    q = {'part':'snippet,statistics', 'chart':'mostPopular', 'regionCode':region.upper(), 'maxResults':'10', 'key':key}
    if category_id:
        q['videoCategoryId'] = category_id
    url = 'https://www.googleapis.com/youtube/v3/videos?' + urllib.parse.urlencode(q)
    guard_url(url, 'youtube_trends')
    req = urllib.request.Request(url, headers={'Accept':'application/json'})
    with urllib.request.urlopen(req, timeout=20) as r:
        data = json.loads(r.read().decode('utf-8'))
    items=[]
    for x in data.get('items',[]):
        sn=x.get('snippet',{}); st=x.get('statistics',{})
        items.append({'id':x.get('id'),'title':sn.get('title',''),'channel':sn.get('channelTitle',''),'views':int(st.get('viewCount',0) or 0),'url':'https://www.youtube.com/watch?v='+str(x.get('id'))})
    if not items:
        raise RuntimeError('YouTube returned no trend items')
    execute('INSERT INTO trend_snapshots(id,source,region,items_json,captured_at) VALUES (?,?,?,?,?)',(str(uuid.uuid4()),'youtube_official',region.upper(),json.dumps(items,ensure_ascii=False),now()))
    return items


def _extract_script(output: str, fallback_title: str) -> str:
    text=(output or '').strip()
    if not text:
        return f"Today we are covering: {fallback_title}. Give one useful, original takeaway and a concise closing."
    try:
        obj=json.loads(text)
        for k in ('script','voiceover','body','summary'):
            if isinstance(obj.get(k), str) and obj[k].strip(): return obj[k].strip()
    except Exception:
        pass
    return text[:12000]


def _ffmpeg_video(title: str, script: str, audio_path: str, quality: str, run_id: str) -> Path:
    size = QUALITY_PRESETS.get(quality) or QUALITY_PRESETS['1080p']
    w,h=size
    out=EXPORTS_DIR/f'{run_id}_autopilot.mp4'
    tf=EXPORTS_DIR/f'{run_id}_title.txt'; sf=EXPORTS_DIR/f'{run_id}_script.txt'
    tf.write_text(title[:180], encoding='utf-8'); sf.write_text(script[:4000], encoding='utf-8')
    # A real, deterministic visual: title card + voice track. It is deliberately simple rather than pretending to be generative video.
    vf=(f"drawtext=textfile='{tf.as_posix()}':fontcolor=white:fontsize=64:"
        f"x=(w-text_w)/2:y=(h-text_h)/2:box=1:boxcolor=black@0.55:boxborderw=24")
    args=[FFMPEG_BIN,'-y','-f','lavfi','-i',f'color=c=0x111827:s={w}x{h}:r=30','-i',str(audio_path),'-vf',vf,'-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-shortest',str(out)]
    try:
        subprocess.run(args,check=True,timeout=1800,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    finally:
        tf.unlink(missing_ok=True); sf.unlink(missing_ok=True)
    if not out.is_file() or out.stat().st_size <= 0: raise RuntimeError('FFmpeg produced no video')
    return out


def _thumbnail(video: Path, run_id: str) -> Path:
    out=EXPORTS_DIR/f'{run_id}_thumbnail.png'
    args=[FFMPEG_BIN,'-y','-ss','0','-i',str(video),'-frames:v','1','-q:v','2',str(out)]
    subprocess.run(args,check=True,timeout=120,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    if not out.is_file() or out.stat().st_size <= 0: raise RuntimeError('Thumbnail generation failed')
    return out


def _register(path: Path, kind: str, audience: str, operation: str, source_media_id=None):
    import hashlib
    mid=str(uuid.uuid4()); final=MEDIA_DIR/f'{mid}_{path.name}'; path.replace(final)
    h=hashlib.sha256()
    with final.open('rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
    execute('INSERT INTO media(id,name,path,kind,audience,status,created_at,size_bytes,sha256,source_media_id,operation) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
            (mid,final.name,str(final),kind,audience,'ready',now(),final.stat().st_size,h.hexdigest(),source_media_id,operation))
    return mid


def run_once(region='IN', category_id='', audience='GENERAL', quality='1080p', platform='youtube', auto_schedule=True):
    audience=validate_mode(audience)
    if quality not in QUALITY_PRESETS: raise ValueError('Unsupported quality')
    if platform != 'youtube': raise ValueError('Autopilot creator pipeline currently supports YouTube only')
    run_id=str(uuid.uuid4())
    execute('INSERT INTO autopilot_runs(id,status,region,topic,trend_title,script,media_id,thumbnail_media_id,schedule_id,error,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
            (run_id,'running',region.upper(),None,None,None,None,None,None,None,now(),now()))
    try:
        trends=_youtube_trends(region,category_id)
        chosen=trends[0]
        title=chosen['title']
        prompt=(f"Create an original short-form video voiceover script inspired by this YouTube trend title: {title}. "
                f"Do not copy the source video, lyrics, or creator wording. Audience: {audience}. "
                f"Make it useful/entertaining, concise, and suitable for {quality}. Return only the script.")
        ai=generate_text(prompt, web_search=False)
        script=_extract_script(ai.get('output','') if ai else '', title)
        audio=synthesize(script, 'en')
        video=_ffmpeg_video(title,script,audio,quality,run_id)
        thumb=_thumbnail(video,run_id)
        media_id=_register(video,'video',audience,'autopilot_video')
        thumb_id=_register(thumb,'image',audience,'autopilot_thumbnail',media_id)
        schedule_id=None
        if auto_schedule:
            from .scheduler import add_schedule
            publish_at=datetime.now(timezone.utc).isoformat()
            schedule_id=add_schedule(media_id,platform,publish_at,audience,quality,run_id,thumb_id,{'title':title[:100],'description':f'Original content inspired by a current trend signal. Source trend title: {title}.','tags_json':['original','kilcritic','trend']})
        execute('UPDATE autopilot_runs SET status=?,topic=?,trend_title=?,script=?,media_id=?,thumbnail_media_id=?,schedule_id=?,updated_at=? WHERE id=?',
                ('ready_for_approval',title,title,script,media_id,thumb_id,schedule_id,now(),run_id))
        return {'ok':True,'run_id':run_id,'source':'YouTube Data API mostPopular','trend':chosen,'script':script,'media_id':media_id,'thumbnail_media_id':thumb_id,'schedule_id':schedule_id,'ai_provider':(ai or {}).get('provider','local_rule_engine'),'publish_policy':'explicit approval + official OAuth/API'}
    except Exception as exc:
        execute('UPDATE autopilot_runs SET status=?,error=?,updated_at=? WHERE id=?',('failed',str(exc)[:800],now(),run_id))
        raise


def list_runs():
    return rows('SELECT id,status,region,trend_title,media_id,thumbnail_media_id,schedule_id,error,created_at,updated_at FROM autopilot_runs ORDER BY created_at DESC LIMIT 50')


def maybe_followups(schedule_id: str, views: int):
    if views < AUTOPILOT_FOLLOWUP_VIEW_THRESHOLD: return {'triggered':False,'reason':'threshold_not_met','views':views}
    source=rows('SELECT s.*, m.name media_name FROM schedules s JOIN media m ON m.id=s.media_id WHERE s.id=?',(schedule_id,))
    if not source: return {'triggered':False,'reason':'schedule_not_found'}
    src=source[0]
    count=rows('SELECT COUNT(*) n FROM autopilot_followups WHERE source_schedule_id=?',(schedule_id,))[0]['n']
    remaining=max(0,AUTOPILOT_MAX_FOLLOWUPS-int(count))
    if remaining==0: return {'triggered':False,'reason':'max_followups_reached','created':0}
    base=src.get('plan_id') or src.get('media_name') or 'topic'
    created=[]
    for i in range(remaining):
        fid=str(uuid.uuid4())
        topic=f"Follow-up {i+1}: {base} — answer a new question from the same audience"
        execute('INSERT INTO autopilot_followups(id,source_schedule_id,sequence,topic,status,created_at) VALUES (?,?,?,?,?,?)',(fid,schedule_id,i+1,topic,'planned',now()))
        created.append({'id':fid,'topic':topic})
    return {'triggered':True,'views':views,'created':len(created),'items':created,'note':'Follow-up plans are bounded; media generation and publishing still require the normal policy/approval path.'}
