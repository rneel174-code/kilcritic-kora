from __future__ import annotations
import re
from datetime import datetime, timezone
from uuid import uuid4

ROLES = [
    ('policy', 'Policy/Safety', 'Checks audience, platform-policy and rights risks; not legal advice.'),
    ('quality', 'Quality', 'Checks completeness, quality target and missing prerequisites.'),
    ('security', 'Security', 'Checks external side effects, credentials and unsafe destinations.'),
    ('evidence', 'Evidence/Data', 'Checks whether claims are supported by available evidence.'),
    ('intent', 'User Intent', 'Checks whether the requested action matches the command.'),
]


def decide(question: str, risk: str = 'medium') -> dict:
    q = (question or '').strip()
    if not q:
        raise ValueError('council_question_required')
    low = q.lower()
    checks = []
    risky_external = any(x in low for x in ('publish', 'post', 'upload', 'delete', 'send', 'pay', 'buy'))
    rights_risk = any(x in low for x in ('download', 'repost', 'copy', 'third party', 'copyright'))
    for key, name, desc in ROLES:
        passed = True
        note = 'No blocking signal found.'
        if key == 'security' and risky_external:
            passed = False; note = 'External side effect detected; Malak approval is required.'
        elif key == 'policy' and rights_risk:
            passed = False; note = 'Rights/permission check required before reuse.'
        elif key == 'evidence' and any(x in low for x in ('latest', 'current', 'news', 'price')):
            passed = False; note = 'Current-source verification is required.'
        checks.append({'role': name, 'passed': passed, 'note': note, 'description': desc})
    votes = sum(1 for x in checks if x['passed'])
    advisory = votes >= 3
    final = 'malak_required' if risky_external or risk in {'high', 'critical'} else ('advisory_pass' if advisory else 'hold_for_review')
    return {
        'ok': True, 'decision_id': str(uuid4()), 'created_at': datetime.now(timezone.utc).isoformat(),
        'votes': f'{votes}/5', 'advisory_majority': advisory, 'final_gate': final,
        'checks': checks,
        'rule': 'Council is advisory. It never bypasses Malak approval or grants permission to publish, delete, pay, or execute untrusted code.'
    }
