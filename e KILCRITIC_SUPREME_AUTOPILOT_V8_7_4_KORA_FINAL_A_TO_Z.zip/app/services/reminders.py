from __future__ import annotations
import re, threading, time, uuid
from datetime import datetime, timezone, timedelta
from ..db import execute, rows, now

_STOP = threading.Event()
_STARTED = False
_LOCK = threading.Lock()


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat()


def create_reminder(text: str, due_at: str, repeat: str | None = None):
    text = (text or '').strip()
    if not text:
        raise ValueError('reminder_text_required')
    try:
        dt = datetime.fromisoformat(due_at.replace('Z', '+00:00'))
    except Exception as exc:
        raise ValueError('invalid_due_at') from exc
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    rid = str(uuid.uuid4())
    execute('INSERT INTO reminders(id,text,due_at,status,repeat_rule,last_fired_at,created_at) VALUES (?,?,?,?,?,?,?)',
            (rid, text, _iso(dt), 'pending', repeat or '', None, now()))
    return {'ok': True, 'reminder_id': rid, 'text': text, 'due_at': _iso(dt), 'repeat': repeat or None}


def list_reminders(limit: int = 100):
    return rows('SELECT id,text,due_at,status,repeat_rule,last_fired_at,created_at FROM reminders ORDER BY due_at ASC LIMIT ?',
                (max(1, min(500, int(limit))),))


def acknowledge(reminder_id: str):
    execute('UPDATE reminders SET status=? WHERE id=?', ('acknowledged', reminder_id))
    return {'ok': True, 'reminder_id': reminder_id, 'status': 'acknowledged'}


def _next_repeat(due: datetime, rule: str):
    if rule == 'daily': return due + timedelta(days=1)
    if rule == 'weekly': return due + timedelta(days=7)
    return None


def poll_due(limit: int = 20):
    current = datetime.now(timezone.utc)
    due = rows("SELECT id,text,due_at,status,repeat_rule FROM reminders WHERE status='pending' ORDER BY due_at ASC LIMIT ?", (max(1, min(100, int(limit))),))
    fired = []
    for r in due:
        try: dt = datetime.fromisoformat(r['due_at'].replace('Z','+00:00'))
        except Exception: continue
        if dt > current: continue
        execute('UPDATE reminders SET status=?,last_fired_at=? WHERE id=? AND status=?', ('fired', now(), r['id'], 'pending'))
        fired.append(r)
        nxt = _next_repeat(dt, r.get('repeat_rule') or '')
        if nxt:
            execute('UPDATE reminders SET due_at=?,status=? WHERE id=?', (_iso(nxt), 'pending', r['id']))
    return fired


def worker_loop():
    while not _STOP.wait(5):
        try:
            fired = poll_due()
            for r in fired:
                execute('INSERT INTO assistant_events(id,event_type,detail,created_at) VALUES (lower(hex(randomblob(16))),?,?,?)',
                        ('reminder_fired', f"{r['id']}|{r['text']}", now()))
        except Exception:
            # Reminder failure must never bring down the main server.
            pass


def start_worker():
    global _STARTED
    with _LOCK:
        if _STARTED:
            return
        _STARTED = True
        t = threading.Thread(target=worker_loop, name='kora-reminders', daemon=True)
        t.start()
