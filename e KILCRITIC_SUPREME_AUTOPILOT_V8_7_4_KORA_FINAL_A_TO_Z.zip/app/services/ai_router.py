from __future__ import annotations
from .provider_hub import generate as _generate, status as _status

def status():
    return _status()

def generate(prompt: str, web_search: bool = False, skip: set[str] | None = None):
    # Browser/search tools remain provider-specific. This fallback path is text-first;
    # the primary AI provider handles its native web-search capability when available.
    result = _generate(prompt, skip=skip)
    if result and web_search:
        result['web_search'] = False
        result['web_search_note'] = 'Fallback provider used without native search; do not treat its output as independently verified current web research.'
    return result
