from __future__ import annotations
import json, uuid
from ..db import execute, rows, now
from .ai import generate_text

CAPABILITIES = {
    'speak': {'status':'available','how':'Browser SpeechSynthesis or local TTS'},
    'listen': {'status':'available','how':'Browser SpeechRecognition when supported; otherwise type'},
    'search_web': {'status':'conditional','how':'Primary provider search plus safe AI failover; current web verification is only claimed when a real search-capable provider returns it'},
    'agent_mode': {'status':'available','how':'KORA plans multi-step workflows and executes only verified capabilities'},
    'ai_failover': {'status':'available','how':'Configured providers are tried in order; local deterministic fallback keeps core planning alive'},
    'create_script': {'status':'available','how':'OpenAI/Groq/OpenRouter/local deterministic planner'},
    'create_voice': {'status':'available','how':'Local TTS if installed'},
    'edit_media': {'status':'available','how':'FFmpeg'},
    'create_thumbnail': {'status':'available','how':'FFmpeg frame extraction'},
    'schedule': {'status':'available','how':'SQLite scheduler + approval'},
    'youtube_publish': {'status':'conditional','how':'Official OAuth/API only'},
    'facebook_publish': {'status':'conditional','how':'Official Meta API/OAuth adapter required'},
    'instagram_publish': {'status':'conditional','how':'Official Meta API/OAuth adapter required'},
    'tiktok_publish': {'status':'conditional','how':'Official TikTok Content Posting API/OAuth required'},
    'x_publish': {'status':'conditional','how':'Official X API/OAuth adapter required'},
    'learn': {'status':'available','how':'Recorded analytics and bounded recommendations'},
    'self_improve': {'status':'guarded','how':'Generate/test improvement proposals; deployment requires approval'},
    'remember': {'status':'available','how':'Explicit project memories stored in SQLite'},
}

def capabilities(): return CAPABILITIES

def remember(text: str, kind: str='project', importance: int=5):
    text=(text or '').strip()
    if not text: raise ValueError('memory_text_required')
    importance=max(1,min(10,int(importance)))
    mid=str(uuid.uuid4())
    execute('INSERT INTO assistant_memory(id,kind,text,importance,created_at,updated_at) VALUES (?,?,?,?,?,?)',(mid,kind,text,importance,now(),now()))
    return {'ok':True,'memory_id':mid}

def memories(limit=50):
    return rows('SELECT id,kind,text,importance,created_at,updated_at FROM assistant_memory ORDER BY importance DESC,updated_at DESC LIMIT ?',(max(1,min(200,int(limit))),))

def record_event(event_type, detail):
    execute('INSERT INTO assistant_events(id,event_type,detail,created_at) VALUES (?,?,?,?)',(str(uuid.uuid4()),event_type,json.dumps(detail,ensure_ascii=False),now()))

def ask(prompt: str, web_search: bool=False):
    prompt=(prompt or '').strip()
    if not prompt: raise ValueError('prompt_required')
    mem=memories(12)
    context='\n'.join(f"- {m['text']}" for m in mem)
    system=("You are KILCRITIC SUPREME ENGINE, a truthful personal project operator. "
            "Explain what you can do, what needs credentials/approval, and never claim an action happened unless the system returned success. "
            "Use project memory only as context. Suggest concrete next actions.\nPROJECT MEMORY:\n"+context)
    r=generate_text(system+'\nUSER COMMAND:\n'+prompt, web_search=web_search)
    record_event('assistant_ask',{'prompt':prompt,'web_search':web_search,'provider':r.get('provider'),'ok':r.get('ok')})
    return r

def propose_ideas():
    analytics=rows('SELECT platform,COALESCE(SUM(views),0) views,COALESCE(SUM(likes),0) likes,COALESCE(SUM(comments),0) comments,COALESCE(SUM(shares),0) shares FROM analytics GROUP BY platform ORDER BY views DESC')
    trends=rows('SELECT source,region,items_json,captured_at FROM trend_snapshots ORDER BY captured_at DESC LIMIT 5')
    audit=rows('SELECT id,status,error,created_at FROM autopilot_runs ORDER BY created_at DESC LIMIT 5')
    prompt=('Generate 5 concrete product/content improvement ideas for KILCRITIC based only on the supplied evidence. '
            'Do not claim guaranteed virality/income. Mark each idea as low/medium/high implementation risk and include a test metric. '
            'Return JSON array.\nANALYTICS='+json.dumps(analytics)+'\nTRENDS='+json.dumps(trends)+'\nRECENT RUNS='+json.dumps(audit))
    r=generate_text(prompt, web_search=False)
    raw=r.get('output','') if r else ''
    ideas=[]
    try:
        x=json.loads(raw); ideas=x if isinstance(x,list) else x.get('ideas',[])
    except Exception:
        ideas=[]
    if not ideas:
        ideas=[{'idea':'Add platform-specific content variants','risk':'low','test_metric':'publish-ready rate'},
               {'idea':'Use retention and engagement-per-view to rank future topics','risk':'low','test_metric':'engagement_per_view'},
               {'idea':'Add approval queue before any external publish','risk':'low','test_metric':'zero unauthorized publishes'},
               {'idea':'Add failure classification and retry budgets per adapter','risk':'medium','test_metric':'failed-job recovery rate'},
               {'idea':'Add voice command shortcuts for common workflows','risk':'medium','test_metric':'command completion rate'}]
    out=[]
    for i in ideas[:10]:
        iid=str(uuid.uuid4()); txt=i if isinstance(i,str) else json.dumps(i,ensure_ascii=False)
        execute('INSERT INTO assistant_ideas(id,idea_json,status,created_at) VALUES (?,?,?,?)',(iid,txt,'proposed',now()))
        out.append({'id':iid,'idea':i})
    record_event('ideas_generated',{'count':len(out),'provider':r.get('provider') if r else None})
    return {'ok':True,'items':out,'evidence':{'analytics':analytics,'trend_snapshots':len(trends)}}
