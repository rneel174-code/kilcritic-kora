from uuid import uuid4
from ..db import execute,rows,now
from ..config import SUPPORTED_PLATFORMS,MAX_QUEUE_SIZE,ALLOWED_QUALITY
def add_schedule(media_id,platform,publish_at,audience='GENERAL',quality='1080p',plan_id=None,thumbnail_media_id=None,metadata=None):
    if platform not in SUPPORTED_PLATFORMS: raise ValueError('Unsupported platform')
    if quality not in ALLOWED_QUALITY: raise ValueError('Unsupported quality preset')
    if not rows("SELECT id FROM media WHERE id=? AND status='ready'",(media_id,)): raise ValueError('Media ID not found or not ready')
    count=rows("SELECT COUNT(*) n FROM schedules WHERE status IN ('waiting_approval','approved','retry_wait','executing')")[0]['n']
    if count>=MAX_QUEUE_SIZE: raise ValueError('Schedule queue is full')
    sid=str(uuid4());
    import json
    meta=json.dumps(metadata or {},ensure_ascii=False)
    if thumbnail_media_id and not rows("SELECT id FROM media WHERE id=? AND status='ready' AND kind='image'",(thumbnail_media_id,)): raise ValueError('Thumbnail media ID not found or not ready')
    execute('INSERT INTO schedules(id,media_id,platform,publish_at,status,audience,created_at,next_attempt_at,attempts,quality,plan_id,thumbnail_media_id,metadata_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',(sid,media_id,platform,publish_at,'waiting_approval',audience,now(),publish_at,0,quality,plan_id,thumbnail_media_id,meta)); return sid
def list_schedules(): return rows('SELECT * FROM schedules ORDER BY publish_at')
