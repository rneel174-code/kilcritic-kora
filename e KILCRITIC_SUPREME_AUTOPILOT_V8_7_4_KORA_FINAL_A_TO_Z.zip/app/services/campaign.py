from __future__ import annotations
from datetime import datetime, timedelta, timezone
import json, uuid
from .ai import generate_text
from .audience import validate_mode
from ..db import execute, rows, now


def build_30_day(topic: str, audience: str='GENERAL', platform: str='youtube', start_at: str|None=None):
    topic=(topic or '').strip()
    if not topic: raise ValueError('topic_required')
    audience=validate_mode(audience)
    if platform not in {'youtube','facebook','instagram','tiktok','x'}: raise ValueError('unsupported_platform')
    base=datetime.fromisoformat(start_at.replace('Z','+00:00')) if start_at else datetime.now(timezone.utc)
    prompt=(f'Create a 30-day original content calendar for the topic "{topic}". Audience: {audience}. '
            'Return a JSON array of 30 objects with day, title, angle, hook, content_type. Avoid copied wording and do not promise virality or income.')
    ai=generate_text(prompt, False)
    items=[]
    try:
        obj=json.loads(ai.get('output',''))
        items=obj if isinstance(obj,list) else obj.get('days',[])
    except Exception:
        items=[]
    if len(items)<30:
        items=[{'day':i,'title':f'{topic} — Day {i}','angle':'original practical angle','hook':'One useful idea for the audience','content_type':'reel'} for i in range(1,31)]
    items=items[:30]
    out=[]
    campaign_id=str(uuid.uuid4())
    for i,item in enumerate(items,1):
        publish_at=(base+timedelta(days=i-1)).isoformat()
        out.append({'day':i,'publish_at':publish_at,'platform':platform,**(item if isinstance(item,dict) else {'title':str(item)})})
    execute('INSERT INTO assistant_events(id,event_type,detail,created_at) VALUES (?,?,?,?)',(str(uuid.uuid4()),'campaign_30_day',json.dumps({'campaign_id':campaign_id,'topic':topic,'audience':audience,'platform':platform,'count':30},ensure_ascii=False),now()))
    return {'ok':True,'campaign_id':campaign_id,'days':out,'status':'planned','note':'This creates a 30-day plan. Actual media generation and external publishing remain subject to the normal media pipeline, credentials and explicit approval.'}
