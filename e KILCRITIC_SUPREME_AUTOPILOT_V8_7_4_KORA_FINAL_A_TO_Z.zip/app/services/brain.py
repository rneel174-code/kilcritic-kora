PLATFORMS=["youtube","facebook","instagram","tiktok","x"]
def decide(topic,audience,platforms,content_type="video"):
 return {"decision":"PLAN","topic":topic or "user topic","content_type":content_type,"audience":audience,"platforms":[p for p in platforms if p in PLATFORMS],"pipeline":["trend signals","competition analysis","content creation","quality check","audience/policy check","approval policy","schedule","publish through approved adapter","monitor analytics","learn and adjust"]}
def autopilot_policy():
 return {"human_busy_mode":True,"flow":"create -> validate -> schedule -> publish when approved adapter permits -> monitor -> learn","emergency_stop":True,"no_guaranteed_viral_or_income":True}
