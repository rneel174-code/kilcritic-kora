from __future__ import annotations
import json
from datetime import datetime, timezone, timedelta
from uuid import uuid4
from ..db import execute, rows, now

def enqueue(kind: str, payload: dict) -> dict:
    qid=str(uuid4())
    t=now()
    execute("INSERT INTO offline_queue(id,kind,payload_json,status,attempts,next_attempt_at,last_error,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (qid,kind[:80],json.dumps(payload,ensure_ascii=False)[:50000],'queued',0,t,None,t,t))
    return {'ok':True,'id':qid,'status':'queued','durable':True}

def list_items(limit:int=50) -> list[dict]:
    out=[]
    for r in rows('SELECT id,kind,status,attempts,next_attempt_at,last_error,created_at,updated_at FROM offline_queue ORDER BY created_at DESC LIMIT ?', (max(1,min(200,int(limit))),)):
        out.append(r)
    return out

def pending_payloads(limit:int=20) -> list[dict]:
    t=now()
    return rows("SELECT id,kind,payload_json,attempts,next_attempt_at,last_error,created_at,updated_at FROM offline_queue WHERE status='queued' AND next_attempt_at<=? ORDER BY created_at LIMIT ?", (t,max(1,min(100,int(limit)))))

def mark_sent(qid:str) -> None:
    execute("UPDATE offline_queue SET status='sent',updated_at=?,last_error=NULL WHERE id=?",(now(),qid))

def mark_retry(qid:str,error:str,attempts:int) -> None:
    delay=min(3600, max(5, 2**min(attempts,10)))
    nxt=(datetime.now(timezone.utc)+timedelta(seconds=delay)).isoformat()
    execute("UPDATE offline_queue SET status='queued',attempts=?,next_attempt_at=?,last_error=?,updated_at=? WHERE id=?",(attempts,nxt,str(error)[:500],now(),qid))

def purge_sent(older_than_hours:int=72) -> int:
    cutoff=(datetime.now(timezone.utc)-timedelta(hours=max(1,int(older_than_hours)))).isoformat()
    r=rows("SELECT id FROM offline_queue WHERE status='sent' AND updated_at<?",(cutoff,))
    if r:
        execute("DELETE FROM offline_queue WHERE status='sent' AND updated_at<?",(cutoff,))
    return len(r)
