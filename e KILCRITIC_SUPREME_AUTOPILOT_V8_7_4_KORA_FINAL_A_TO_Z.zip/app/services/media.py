from pathlib import Path
from uuid import uuid4
from hashlib import sha256
from ..config import MEDIA_DIR,MAX_UPLOAD_BYTES,UPLOAD_CHUNK_BYTES
from ..db import execute,rows,now
from .audience import validate_mode
ALLOWED={'.mp4','.mov','.m4v','.avi','.mkv','.jpg','.jpeg','.png','.webp','.gif','.wav','.mp3','.webm'}

def _valid_signature(ext: str, head: bytes) -> bool:
    if ext in {'.jpg','.jpeg'}: return head.startswith(b'\xff\xd8\xff')
    if ext == '.png': return head.startswith(b'\x89PNG\r\n\x1a\n')
    if ext == '.gif': return head.startswith((b'GIF87a', b'GIF89a'))
    if ext == '.webp': return len(head) >= 12 and head[:4] == b'RIFF' and head[8:12] == b'WEBP'
    if ext in {'.wav','.avi'}: return len(head) >= 12 and head[:4] == b'RIFF' and head[8:12] in (b'WAVE', b'AVI ')
    if ext == '.mp3': return head.startswith(b'ID3') or (len(head) >= 2 and head[0] == 0xFF and (head[1] & 0xE0) == 0xE0)
    if ext in {'.mp4','.mov','.m4v'}: return len(head) >= 12 and head[4:8] == b'ftyp'
    if ext in {'.mkv','.webm'}: return head.startswith(b'\x1a\x45\xdf\xa3')
    return False

def _valid_signature(ext: str, head: bytes) -> bool:
    if ext in {'.jpg','.jpeg'}: return head.startswith(b'\xff\xd8\xff')
    if ext == '.png': return head.startswith(b'\x89PNG\r\n\x1a\n')
    if ext == '.gif': return head.startswith((b'GIF87a', b'GIF89a'))
    if ext == '.webp': return len(head) >= 12 and head[:4] == b'RIFF' and head[8:12] == b'WEBP'
    if ext in {'.wav','.avi'}: return len(head) >= 12 and head[:4] == b'RIFF' and head[8:12] in (b'WAVE', b'AVI ')
    if ext == '.mp3': return head.startswith(b'ID3') or (len(head) >= 2 and head[0] == 0xFF and (head[1] & 0xE0) == 0xE0)
    if ext in {'.mp4','.mov','.m4v'}: return len(head) >= 12 and head[4:8] == b'ftyp'
    if ext in {'.mkv','.webm'}: return head.startswith(b'\x1a\x45\xdf\xa3')
    return False
def save_upload_stream(upload, filename, audience='GENERAL'):
    audience=validate_mode(audience); name=Path(filename).name.replace(' ','_') or 'upload.bin'; ext=Path(name).suffix.lower()
    if ext not in ALLOWED: raise ValueError('Unsupported media type')
    mid=str(uuid4()); path=MEDIA_DIR/f'{mid}_{name}'; total=0; digest=sha256()
    try:
        first = upload.file.read(min(UPLOAD_CHUNK_BYTES, 64 * 1024))
        if not first: raise ValueError('empty_upload')
        if not _valid_signature(ext, first[:64]): raise ValueError('file_signature_mismatch')
        with path.open('wb') as out:
            chunk = first
            while chunk:
                total += len(chunk)
                if total > MAX_UPLOAD_BYTES: raise ValueError('Upload exceeds configured size limit')
                out.write(chunk); digest.update(chunk)
                chunk=upload.file.read(UPLOAD_CHUNK_BYTES)
        kind='video' if ext in {'.mp4','.mov','.m4v','.avi','.mkv','.webm'} else ('image' if ext in {'.jpg','.jpeg','.png','.webp','.gif'} else 'audio')
        execute('INSERT INTO media(id,name,path,kind,audience,status,created_at,size_bytes,sha256) VALUES (?,?,?,?,?,?,?,?,?)',(mid,name,str(path),kind,audience,'ready',now(),total,digest.hexdigest()))
        return mid
    except Exception:
        path.unlink(missing_ok=True); raise
def list_media(): return rows('SELECT * FROM media ORDER BY created_at DESC')


def register_existing(path, name=None, audience='GENERAL', kind=None, source_media_id=None, operation=''):
    audience=validate_mode(audience); p=Path(path)
    if not p.is_file(): raise ValueError('media_file_missing')
    ext=p.suffix.lower()
    if kind is None:
        kind='video' if ext in {'.mp4','.mov','.m4v','.avi','.mkv','.webm'} else ('image' if ext in {'.jpg','.jpeg','.png','.webp','.gif'} else 'audio')
    mid=str(uuid4()); final=MEDIA_DIR/f'{mid}_{p.name}'
    p.replace(final)
    import hashlib
    h=hashlib.sha256()
    with final.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    execute('INSERT INTO media(id,name,path,kind,audience,status,created_at,size_bytes,sha256,source_media_id,operation) VALUES (?,?,?,?,?,?,?,?,?,?,?)',(mid,final.name,str(final),kind,audience,'ready',now(),final.stat().st_size,h.hexdigest(),source_media_id,operation))
    return mid
