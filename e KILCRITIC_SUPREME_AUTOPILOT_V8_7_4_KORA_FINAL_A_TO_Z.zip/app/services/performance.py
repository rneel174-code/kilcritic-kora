import os, time
from contextlib import contextmanager

MAX_RETRIES = max(0, int(os.getenv("MAX_JOB_RETRIES", "3")))
WORKER_INTERVAL = max(2, int(os.getenv("WORKER_INTERVAL_SECONDS", "10")))

@contextmanager
def timed(label: str):
    started = time.perf_counter()
    try:
        yield
    finally:
        elapsed = time.perf_counter() - started
        # Hook for future metrics; intentionally no noisy logging.
        _ = (label, elapsed)

def backoff_seconds(attempt: int) -> int:
    return min(300, 2 ** max(0, attempt))
