from __future__ import annotations
import re, uuid
from datetime import datetime, timezone
from .ai import generate_text
from .command_bus import dispatch
from .supreme import build_task_graph
from ..db import execute, rows, now
from .skill_learning import record as record_skill
from .council import decide as council_decide


def _tasks_for(command: str) -> list[dict]:
    low = command.lower()
    tasks = []
    def add(key, label, kind='analysis', approval=False):
        tasks.append({'id': key, 'label': label, 'kind': kind, 'approval_required': approval, 'status': 'ready'})
    if any(x in low for x in ('research', 'trend', 'internet', 'search')):
        add('research', 'Research current signals', 'research')
    if any(x in low for x in ('video', 'reel', 'story', 'wallpaper', 'photo', 'image', 'media')):
        add('media_plan', 'Build media production plan', 'media')
        add('quality', 'Run quality and audience checks', 'verification')
    if any(x in low for x in ('caption', 'hashtag', 'title', 'seo')):
        add('metadata', 'Prepare titles, caption and hashtags', 'metadata')
    if any(x in low for x in ('30 day', '30-day', 'month', 'campaign')):
        add('campaign', 'Build 30-day content schedule', 'planning')
    if any(x in low for x in ('post', 'publish', 'upload', 'schedule')):
        add('approval', 'Place action in Malak approval queue', 'approval', True)
        add('publish', 'Publish through official platform adapter', 'publish', True)
    if any(x in low for x in ('learn', 'improve', 'growth', 'optimize')):
        add('learning', 'Analyze results and propose improvements', 'learning')
    if not tasks:
        add('understand', 'Understand command and choose available capabilities')
        add('execute', 'Execute only verified capabilities', 'execution')
    return tasks


def plan(command: str) -> dict:
    command = (command or '').strip()
    if not command:
        raise ValueError('command_required')
    tasks = _tasks_for(command)
    graph = build_task_graph(command)
    return {
        'ok': True,
        'agent': 'KORA_SUPREME_AGENT',
        'command': command,
        'workflow_id': str(uuid.uuid4()),
        'created_at': datetime.now(timezone.utc).isoformat(),
        'tasks': tasks,
        'task_graph': graph['nodes'],
        'rules': {
            'malak_approval_for_publish': True,
            'official_api_only': True,
            'no_fake_success': True,
            'external_ai_is_optional': True,
            'local_fallback_keeps_core_alive': True,
            'self_modification_requires_test_and_approval': True,
        },
    }


def _trace(workflow_id: str, state: str, action: str, observation: str = '', result: str = ''):
    execute('INSERT INTO agent_traces(id,workflow_id,state,action,observation,result,created_at) VALUES (lower(hex(randomblob(16))),?,?,?,?,?,?)',
            (workflow_id,state,action,observation[:1500],result[:1500],now()))


def execute_safe(command: str, web_search: bool = True) -> dict:
    """Execute guarded actions and persist a compact execution trace, not private chain-of-thought."""
    p = plan(command); workflow_id = p['workflow_id']; started = __import__('time').perf_counter()
    _trace(workflow_id, 'thought', 'interpret_command', 'Intent classified into a guarded workflow.')
    _trace(workflow_id, 'action', 'policy_check', 'External side effects remain permission-gated.')
    low = command.lower()
    council = council_decide(command, 'critical' if any(x in low for x in ('publish','post','delete','pay')) else 'medium')
    p['council'] = council
    if 'publish' in low or 'post' in low:
        p['execution'] = {'ok': False, 'requires_approval': True, 'message': 'Publish action stopped at Malak approval gate.'}
        _trace(workflow_id, 'observation', 'malak_gate', 'Publish/post request requires Malak approval.', 'blocked_pending_approval')
        record_skill('publish_gate', True, int((__import__('time').perf_counter()-started)*1000))
        return p
    result = dispatch(command, web_search=web_search)
    p['execution'] = result
    _trace(workflow_id, 'observation', 'command_bus_result', 'Guarded capability returned a result.', str(result)[:1200])
    record_skill('command_bus', bool(result.get('ok', False)), int((__import__('time').perf_counter()-started)*1000))
    _trace(workflow_id, 'final', 'complete', 'Workflow completed or reported its real capability boundary.', str(result)[:1200])
    return p


def improvement_snapshot() -> dict:
    analytics = rows('SELECT platform,COALESCE(SUM(views),0) views,COALESCE(SUM(likes),0) likes,COALESCE(SUM(comments),0) comments,COALESCE(SUM(shares),0) shares FROM analytics GROUP BY platform ORDER BY views DESC')
    recent = rows('SELECT event_type,detail,created_at FROM assistant_events ORDER BY created_at DESC LIMIT 20')
    failures = rows('SELECT platform,status,error,created_at FROM publish_events WHERE status NOT IN (\'success\') ORDER BY created_at DESC LIMIT 20')
    return {'analytics': analytics, 'recent_events': recent, 'recent_publish_failures': failures}


def propose_improvements() -> dict:
    evidence = improvement_snapshot()
    prompt = ('You are the KILCRITIC continuous-improvement analyst. Based ONLY on the evidence below, propose up to 8 concrete, testable improvements. '
              'Do not claim guaranteed growth, virality or income. Each item must include title, reason, change, risk, metric and rollback. '
              'Do not propose arbitrary code downloaded from the internet. Code changes must be reviewed, tested and explicitly approved. Return JSON.\n'
              + str(evidence))
    r = generate_text(prompt, web_search=False)
    return {'ok': True, 'provider': r.get('provider'), 'evidence': evidence, 'proposal_output': r.get('output',''), 'guardrail': 'proposal_only_until_test_and_approval'}


def kora_task_graph(command: str) -> dict:
    return build_task_graph(command)
