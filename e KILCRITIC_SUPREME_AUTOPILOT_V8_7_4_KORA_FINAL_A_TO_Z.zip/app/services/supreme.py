from __future__ import annotations
from datetime import datetime, timezone
import re, uuid

CAPABILITIES = [
    ('brain','Supreme Brain','Plan, reason and route tasks', 'core'),
    ('voice','Voice I/O','Browser voice input/output and local TTS when available', 'core'),
    ('memory','Memory','Project/user memory with SQLite persistence', 'core'),
    ('research','Internet Research','Configured AI/web and official trend connectors', 'external'),
    ('media','Media Studio','FFmpeg editing, media registration and playback', 'core'),
    ('quality','Quality & Audience','Quality presets and audience/policy checks', 'core'),
    ('metadata','Metadata','Titles, captions, tags and platform metadata', 'core'),
    ('campaign','30-Day Autopilot','Persisted campaign planning and scheduling', 'core'),
    ('scheduler','Scheduler','Bounded persisted schedule queue', 'core'),
    ('approval','Malak Approval','Human approval gate for external side effects', 'security'),
    ('publish','Official Publishing','Platform adapter publishing after approval', 'external'),
    ('analytics','Analytics','Ingest and supported live analytics sync', 'external'),
    ('learning','Learning','Evidence-based optimization proposals', 'core'),
    ('agent','KORA Agent','Multi-step plans with guarded execution', 'core'),
    ('failover','AI Failover','Provider cascade with honest fallback', 'external'),
    ('security','Security Center','Kill switch, egress allowlist and audit events', 'security'),
    ('recovery','Recovery','Bounded retries and stale-job recovery', 'core'),
    ('integrity','Integrity','Runtime health/integrity checks', 'security'),
]

RISK = {
    'brain':'low','voice':'low','memory':'medium','research':'medium','media':'medium',
    'quality':'low','metadata':'low','campaign':'medium','scheduler':'medium',
    'approval':'high','publish':'critical','analytics':'medium','learning':'medium',
    'agent':'high','failover':'medium','security':'critical','recovery':'high','integrity':'high'
}


def capability_matrix() -> list[dict]:
    from .capabilities import snapshot
    live = snapshot()
    return [{
        'id': key, 'name': name, 'description': desc, 'class': cls,
        'risk': RISK.get(key,'medium'), 'live': live
    } for key,name,desc,cls in CAPABILITIES]


def _has(text: str, *terms: str) -> bool:
    return any(t in text for t in terms)


def build_task_graph(command: str) -> dict:
    """Create a deterministic, inspectable graph. It plans; it does not grant permissions."""
    raw = (command or '').strip()
    low = raw.lower()
    if not raw:
        raise ValueError('command_required')
    nodes = []
    def add(i, label, capability, deps=(), approval=False):
        nodes.append({'id':i,'label':label,'capability':capability,'depends_on':list(deps),
                      'risk':RISK.get(capability,'medium'),'approval_required':approval,'status':'planned'})
    add('understand','Understand command','brain')
    last='understand'
    if _has(low,'search','research','trend','internet','latest','current'):
        add('research','Research current signals','research',[last]); last='research'
    if _has(low,'video','reel','story','wallpaper','photo','image','media','edit'):
        add('media','Prepare or edit media','media',[last]); last='media'
        add('quality','Verify quality and audience','quality',[last]); last='quality'
    if _has(low,'title','caption','hashtag','hash tag','seo','description'):
        add('metadata','Prepare metadata','metadata',[last]); last='metadata'
    if _has(low,'30 day','30-day','month','campaign','autopilot'):
        add('campaign','Build 30-day plan','campaign',[last]); last='campaign'
    if _has(low,'schedule','calendar'):
        add('schedule','Schedule approved work','scheduler',[last],True); last='schedule'
    if _has(low,'publish','post','upload','share'):
        add('approval','Wait for Malak approval','approval',[last],True); last='approval'
        add('publish','Publish via official adapter','publish',[last],True); last='publish'
    if _has(low,'analytics','performance','growth','improve','learn','optimize'):
        add('analytics','Measure results','analytics',[last]); last='analytics'
        add('learning','Generate evidence-based improvement proposal','learning',[last]); last='learning'
    if len(nodes)==1:
        add('execute','Execute available safe capability','agent',[last]); last='execute'
    return {
        'ok':True,'agent':'KORA_SUPREME_OS','workflow_id':str(uuid.uuid4()),
        'created_at':datetime.now(timezone.utc).isoformat(),'command':raw,
        'nodes':nodes,
        'policy':{
            'human_approval_for_external_side_effects':True,
            'official_api_or_user_authorized_connector_only':True,
            'no_automatic_hackback':True,
            'no_unreviewed_self_modification':True,
            'no_fake_success':True,
            'kill_switch_honored':True,
        }
    }
