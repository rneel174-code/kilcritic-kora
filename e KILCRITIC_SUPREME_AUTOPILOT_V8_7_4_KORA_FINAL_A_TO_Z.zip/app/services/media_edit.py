from pathlib import Path
from uuid import uuid4
import json, os, shutil, subprocess
from ..config import FFMPEG_BIN, EXPORTS_DIR, MEDIA_DIR, MEDIA_EDIT_TIMEOUT_SECONDS, QUALITY_PRESETS
from ..db import execute, rows, now

VIDEO_EXT={'.mp4','.mov','.m4v','.avi','.mkv','.webm'}
IMAGE_EXT={'.jpg','.jpeg','.png','.webp','.gif'}
AUDIO_EXT={'.wav','.mp3','.m4a','.aac','.ogg','.flac'}

def ffmpeg_available(): return shutil.which(FFMPEG_BIN) is not None

def _media(mid):
    x=rows('SELECT * FROM media WHERE id=? AND status=\'ready\'',(mid,))
    if not x: raise ValueError('Media ID not found or not ready')
    p=Path(x[0]['path'])
    if not p.is_file(): raise ValueError('Media file is missing from storage')
    return x[0],p

def _safe_name(text):
    return ''.join(c if c.isalnum() or c in '-_.' else '_' for c in (text or 'output'))[:80]

def _register_output(src, output, kind, audience, source_media_id, operation):
    mid=str(uuid4()); out=Path(output)
    final=MEDIA_DIR/f'{mid}_{out.name}'
    out.replace(final)
    size=final.stat().st_size
    import hashlib
    h=hashlib.sha256()
    with final.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    execute('INSERT INTO media(id,name,path,kind,audience,status,created_at,size_bytes,sha256,source_media_id,operation) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
            (mid,final.name,str(final),kind,audience,'ready',now(),size,h.hexdigest(),source_media_id,operation))
    return mid

def _run(args, job_id):
    if not ffmpeg_available(): raise RuntimeError('FFmpeg is not installed or not on PATH')
    try:
        subprocess.run(args, check=True, timeout=MEDIA_EDIT_TIMEOUT_SECONDS, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        raise RuntimeError('Media edit timed out; original file was not changed')
    return job_id

def edit_media(media_id, operation, audience='GENERAL', **kw):
    meta,src=_media(media_id); ext=src.suffix.lower(); job_id=str(uuid4())
    execute('INSERT INTO media_jobs(id,media_id,operation,status,error,output_media_id,created_at,finished_at) VALUES (?,?,?,?,?,?,?,?)',(job_id,media_id,operation,'running',None,None,now(),None))
    out=EXPORTS_DIR/f'{job_id}_{_safe_name(operation)}.mp4'
    try:
        if ext not in VIDEO_EXT and operation not in {'image_to_video'}:
            raise ValueError('This operation requires a video input')
        vf=[]; af=[]; args=[FFMPEG_BIN,'-y']
        if operation=='trim':
            start=float(kw.get('start',0)); end=kw.get('end')
            if start<0: raise ValueError('start must be >= 0')
            args += ['-ss',str(start),'-i',str(src)]
            if end is not None:
                dur=float(end)-start
                if dur<=0: raise ValueError('end must be greater than start')
                args += ['-t',str(dur)]
            args += ['-c:v','libx264','-preset','fast','-crf','19','-c:a','aac','-b:a','128k',str(out)]
        elif operation in {'resize','portrait'}:
            quality=kw.get('quality','1080p')
            if operation=='portrait': size=(1080,1920)
            else:
                size=QUALITY_PRESETS.get(quality)
                if not size: raise ValueError('Invalid quality preset')
            w,h=size; vf=[f'scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h}']
            args += ['-i',str(src),'-vf',','.join(vf),'-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k',str(out)]
        elif operation=='crop':
            w=int(kw.get('width',1080)); h=int(kw.get('height',1920)); x=int(kw.get('x',0)); y=int(kw.get('y',0))
            if min(w,h)<16 or max(w,h)>10000 or min(x,y)<0: raise ValueError('Invalid crop values')
            args += ['-i',str(src),'-vf',f'crop={w}:{h}:{x}:{y}','-c:v','libx264','-preset','fast','-crf','19','-c:a','aac','-b:a','128k',str(out)]
        elif operation=='text_overlay':
            text=str(kw.get('text','')).strip()
            if not text: raise ValueError('text required')
            if len(text)>500: raise ValueError('text too long')
            # Use drawtext textfile to avoid filter-string injection and preserve Unicode when font supports it.
            tf=EXPORTS_DIR/f'{job_id}.txt'; tf.write_text(text,encoding='utf-8')
            args += ['-i',str(src),'-vf',f"drawtext=textfile='{tf.as_posix().replace(chr(39),chr(92)+chr(39))}':x=(w-text_w)/2:y=h-text_h-80:fontsize=48:fontcolor=white:box=1:boxcolor=black@0.55:boxborderw=12",'-c:v','libx264','-preset','fast','-crf','19','-c:a','aac','-b:a','128k',str(out)]
        elif operation=='mute':
            args += ['-i',str(src),'-c:v','copy','-an',str(out)]
        elif operation=='add_audio':
            audio_meta,audio=_media(str(kw.get('audio_media_id','')))
            if audio.suffix.lower() not in AUDIO_EXT: raise ValueError('audio_media_id must point to an audio file')
            args += ['-i',str(src),'-i',str(audio),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-shortest',str(out)]
        elif operation=='extract_audio':
            out=EXPORTS_DIR/f'{job_id}_audio.mp3'
            args += ['-i',str(src),'-vn','-c:a','libmp3lame','-b:a','192k',str(out)]
        elif operation=='image_to_video':
            if ext not in IMAGE_EXT: raise ValueError('image_to_video requires an image input')
            duration=max(1,min(120,float(kw.get('duration',5))))
            args += ['-loop','1','-i',str(src),'-t',str(duration),'-vf','scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920','-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-an',str(out)]
        else:
            raise ValueError('Unsupported operation')
        _run(args,job_id)
        kind='audio' if operation=='extract_audio' else 'video'
        out_mid=_register_output(src,out,kind,audience,media_id,operation)
        execute("UPDATE media_jobs SET status='done',output_media_id=?,finished_at=? WHERE id=?",(out_mid,now(),job_id))
        return {'ok':True,'job_id':job_id,'media_id':out_mid,'operation':operation,'path':str(out)}
    except Exception as e:
        Path(out).unlink(missing_ok=True)
        execute("UPDATE media_jobs SET status='failed',error=?,finished_at=? WHERE id=?",(str(e)[:500],now(),job_id))
        raise
