from __future__ import annotations
import json, math
from ..db import execute, rows, now


def _key(value: str) -> str:
    return ''.join(ch.lower() if ch.isalnum() else '_' for ch in (value or '').strip())[:80] or 'general'


def record(skill: str, success: bool, latency_ms: int | None = None) -> dict:
    k = _key(skill)
    row = rows('SELECT * FROM skill_metrics WHERE skill_key=?', (k,))
    if row:
        r = row[0]
        attempts = int(r['attempts']) + 1
        successes = int(r['successes']) + (1 if success else 0)
        failures = int(r['failures']) + (0 if success else 1)
        score = round(successes / attempts, 4)
        execute('UPDATE skill_metrics SET attempts=?,successes=?,failures=?,score=?,last_latency_ms=?,updated_at=? WHERE skill_key=?',
                (attempts, successes, failures, score, latency_ms, now(), k))
    else:
        execute('INSERT INTO skill_metrics(skill_key,attempts,successes,failures,score,last_latency_ms,updated_at) VALUES (?,?,?,?,?,?,?)',
                (k, 1, 1 if success else 0, 0 if success else 1, 1.0 if success else 0.0, latency_ms, now()))
    return rows('SELECT * FROM skill_metrics WHERE skill_key=?', (k,))[0]


def _wilson_lower(successes: int, attempts: int, z: float = 1.96) -> float:
    if attempts <= 0:
        return 0.0
    p = successes / attempts
    den = 1.0 + (z*z)/attempts
    centre = p + (z*z)/(2*attempts)
    margin = z * math.sqrt((p*(1-p) + (z*z)/(4*attempts))/attempts)
    return max(0.0, (centre-margin)/den)

def top(limit: int = 30) -> list[dict]:
    out=[]
    for r in rows('SELECT skill_key,attempts,successes,failures,score,last_latency_ms,updated_at FROM skill_metrics ORDER BY score DESC,attempts DESC LIMIT ?',
                   (max(1, min(100, int(limit))),)):
        attempts=int(r['attempts']); successes=int(r['successes'])
        lb=_wilson_lower(successes, attempts)
        exploration=max(0.0, 1.0-min(1.0, attempts/20.0))
        out.append(dict(r, confidence_lower_bound=round(lb,4), exploration_need=round(exploration,4)))
    return out
