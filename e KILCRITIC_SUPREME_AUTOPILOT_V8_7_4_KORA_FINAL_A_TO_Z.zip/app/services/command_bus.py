from __future__ import annotations
import re
from datetime import datetime, timezone, timedelta
from .assistant_core import ask, remember
from .ai import generate_supreme_plan
from .audience import validate_mode
from .reminders import create_reminder

PLATFORMS = {'youtube','facebook','instagram','tiktok','x'}


def _topic_from(text: str, prefix: str):
    x=text.strip()
    m=re.match(prefix, x, re.I)
    return (m.group(1).strip() if m else '')


def dispatch(command: str, web_search: bool = True):
    """Voice/text command bus. It routes only to real capabilities; it never fakes publish success."""
    raw=(command or '').strip()
    if not raw:
        raise ValueError('command_required')
    low=raw.lower()

    if low in {'status','system status','check status','system check'}:
        return {'ok':True,'intent':'status','message':'Use /api/os and /api/platforms for live capability state.'}

    for p in PLATFORMS:
        if low in {f'open {p}', f'go to {p}', f'{p} open'}:
            return {'ok':True,'intent':'open_platform','platform':p,'client_action':'open_platform'}

    m=re.match(r'^(?:remind me in)\s+(\d+)\s+(minute|minutes|hour|hours|day|days)\s+(?:to\s+)?(.+)$', raw, re.I)
    if m:
        amount=int(m.group(1)); unit=m.group(2).lower(); text=m.group(3).strip()
        seconds=amount * (60 if unit.startswith('minute') else 3600 if unit.startswith('hour') else 86400)
        due=datetime.now(timezone.utc)+timedelta(seconds=seconds)
        return {'ok':True,'intent':'reminder','result':create_reminder(text,due.isoformat())}

    m=re.match(r'^(?:remember|save memory)\s+(.+)$', raw, re.I)
    if m:
        return {'ok':True,'intent':'remember','result':remember(m.group(1).strip(),'project',7)}

    m=re.match(r'^(?:search|search web|internet search)\s+(.+)$', raw, re.I)
    if m:
        result=ask(m.group(1).strip(), True)
        return {'ok':bool(result.get('ok')), 'intent':'search','result':result}

    m=re.match(r'^(?:make plan|create plan|plan)\s+(.+)$', raw, re.I)
    if m:
        topic=m.group(1).strip()
        result=generate_supreme_plan(topic,'video',validate_mode('GENERAL'),['youtube','facebook','instagram','tiktok','x'],web_search,'1080p',None)
        return {'ok':bool(result.get('ok')), 'intent':'plan','topic':topic,'result':result}

    m=re.match(r'^(?:edit|edit media)\s+([0-9a-f-]{8,})\s+(trim|resize|crop|portrait|mute|extract_audio|add_audio|text_overlay)$', raw, re.I)
    if m:
        return {'ok':True,'intent':'edit','media_id':m.group(1),'operation':m.group(2).lower(),'message':'Edit intent parsed. The media editor endpoint must receive the operation parameters.'}

    if 'publish' in low or 'post' in low:
        return {'ok':False,'intent':'publish','requires_approval':True,'message':'Publishing is approval-gated and must use an official platform OAuth/API adapter. Voice/text cannot bypass that gate.'}

    return {'ok':True,'intent':'assistant','result':ask(raw, web_search)}
