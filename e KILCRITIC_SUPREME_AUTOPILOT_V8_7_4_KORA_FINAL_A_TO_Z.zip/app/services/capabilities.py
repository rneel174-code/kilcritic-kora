from __future__ import annotations
import os
import shutil
from ..config import FFMPEG_BIN, AUTOPILOT_ENABLED
from ..platforms.registry import status as platform_status

def _credential_state(name: str):
    return bool(os.getenv(name, '').strip())

def snapshot():
    return {
        'core': {
            'status': 'ready',
            'autopilot_enabled': bool(AUTOPILOT_ENABLED),
            'media_streaming': True,
            'ffmpeg': bool(shutil.which(FFMPEG_BIN) or os.path.isfile(FFMPEG_BIN)),
            'tts': 'conditional_local_engine',
            'memory': 'sqlite + local vector-like retrieval',
            'learning': True,
            'self_improvement': 'proposal_and_test_only',
            'web_search': 'conditional_official_provider',
            'ai_failover': 'groq -> openrouter -> gemini -> cerebras -> ollama -> openai -> local (configured providers only; persistent failure counters)',
            'agent_orchestrator': 'plan -> execute -> verify; publish remains approval-gated',
        },
        'platforms': platform_status(),
        'credential_presence': {
            'youtube': bool(os.getenv('YOUTUBE_ACCESS_TOKEN','').strip() or os.getenv('YOUTUBE_REFRESH_TOKEN','').strip()),
            'facebook': _credential_state('FACEBOOK_ACCESS_TOKEN'),
            'instagram': _credential_state('INSTAGRAM_ACCESS_TOKEN'),
            'tiktok': _credential_state('TIKTOK_ACCESS_TOKEN'),
            'x': _credential_state('X_ACCESS_TOKEN'),
        },
        'rules': {
            'no_fake_publish_success': True,
            'no_fake_trend_data': True,
            'no_unbounded_followup_generation': True,
            'no_uncontrolled_self_modification': True,
            'third_party_media_requires_rights': True,
        }
    }
