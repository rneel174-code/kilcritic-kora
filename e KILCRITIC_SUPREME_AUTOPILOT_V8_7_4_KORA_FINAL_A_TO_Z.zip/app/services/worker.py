from datetime import datetime,timezone,timedelta
from threading import Event,Thread
from uuid import uuid4
from ..db import execute,rows,now
from .performance import WORKER_INTERVAL,MAX_RETRIES
from .recovery import recover_stale_jobs
from .performance import backoff_seconds
from ..platforms.registry import get
from .security import get_kill_switch
STOP=Event(); THREAD=None
def _due_schedules():
    current=datetime.now(timezone.utc).isoformat(); return rows("SELECT * FROM schedules WHERE status IN ('approved','retry_wait') AND COALESCE(next_attempt_at,publish_at)<=? ORDER BY publish_at LIMIT 10",(current,))
def tick():
    if get_kill_switch()['active']:
        return 0
    processed=0
    for item in _due_schedules():
        execute("UPDATE schedules SET status='executing' WHERE id=? AND status IN ('approved','retry_wait')",(item['id'],)); fresh=rows('SELECT * FROM schedules WHERE id=? AND status=\'executing\'',(item['id'],))
        if not fresh: continue
        item=fresh[0]; media=rows('SELECT * FROM media WHERE id=?',(item['media_id'],)); adapter=get(item['platform'])
        if not media or adapter is None:
            execute("UPDATE schedules SET status='failed',last_error=? WHERE id=?",('media_or_adapter_missing',item['id'])); continue
        try:
            payload={**item,'media_path':media[0]['path'],'media_name':media[0]['name'],'media_kind':media[0]['kind']}
            if item.get('thumbnail_media_id'):
                thumbs=rows('SELECT * FROM media WHERE id=? AND status=\'ready\'',(item['thumbnail_media_id'],))
                if thumbs: payload['thumbnail_path']=thumbs[0]['path']
            try:
                import json as _json
                payload.update(_json.loads(item.get('metadata_json') or '{}'))
            except Exception:
                pass
            result=adapter.publish(payload)
            if result.get('ok'):
                ext=result.get('external_id'); execute("UPDATE schedules SET status='published',external_id=?,last_error=NULL WHERE id=?",(ext,item['id'])); execute('INSERT INTO publish_events VALUES (?,?,?,?,?,?,?)',(str(uuid4()),item['id'],item['platform'],ext,'published',None,now())); processed+=1
            else:
                attempt=int(item.get('attempts') or 0)+1; err=str(result.get('error','publish_failed'))[:500]
                if attempt<=MAX_RETRIES:
                    nxt=(datetime.now(timezone.utc)+timedelta(seconds=backoff_seconds(attempt))).isoformat(); execute("UPDATE schedules SET status='retry_wait',attempts=?,next_attempt_at=?,last_error=? WHERE id=?",(attempt,nxt,err,item['id']))
                else: execute("UPDATE schedules SET status='failed',attempts=?,last_error=? WHERE id=?",(attempt,err,item['id']))
                execute('INSERT INTO publish_events VALUES (?,?,?,?,?,?,?)',(str(uuid4()),item['id'],item['platform'],result.get('external_id'),'failed',err,now()))
        except Exception as exc:
            attempt=int(item.get('attempts') or 0)+1; err=str(exc)[:500]
            if attempt<=MAX_RETRIES:
                nxt=(datetime.now(timezone.utc)+timedelta(seconds=backoff_seconds(attempt))).isoformat(); execute("UPDATE schedules SET status='retry_wait',attempts=?,next_attempt_at=?,last_error=? WHERE id=?",(attempt,nxt,err,item['id']))
            else: execute("UPDATE schedules SET status='failed',attempts=?,last_error=? WHERE id=?",(attempt,err,item['id']))
    return processed
def _loop():
    recover_stale_jobs()
    while not STOP.is_set():
        try: tick()
        except Exception: pass
        STOP.wait(WORKER_INTERVAL)
def start_worker():
    global THREAD
    if THREAD and THREAD.is_alive(): return
    STOP.clear(); THREAD=Thread(target=_loop,name='kilcritic-worker',daemon=True); THREAD.start()
def stop_worker(): STOP.set()
