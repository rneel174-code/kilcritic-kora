from __future__ import annotations
import os, shutil, sys
from ..db import rows
from ..config import FFMPEG_BIN
from .media_edit import ffmpeg_available
from .security import get_kill_switch
from .provider_hub import health as provider_health

def scan() -> dict:
    checks={}
    try:
        rows('SELECT 1')
        checks['database']={'status':'ok','detail':'SQLite query succeeded'}
    except Exception as e:
        checks['database']={'status':'error','detail':str(e)[:200]}
    checks['ffmpeg']={'status':'ok' if ffmpeg_available() else 'missing','binary':shutil.which(FFMPEG_BIN)}
    checks['python']={'status':'ok','version':sys.version.split()[0]}
    checks['storage']={'status':'ok' if os.access('.',os.W_OK) else 'warning','cwd_writable':os.access('.',os.W_OK)}
    ks=get_kill_switch(); checks['kill_switch']={'status':'active' if ks['active'] else 'off','reason':ks['reason']}
    ph=provider_health(); configured=sum(1 for x in ph['providers'] if x['provider']!='local' and x.get('failures',0)>=0)
    checks['ai_failover']={'status':'ok','providers':len(ph['providers']),'persistent':ph['persistent']}
    checks['queue']={'status':'ok','pending':len(rows("SELECT id FROM offline_queue WHERE status='queued'"))}
    checks['truthfulness']={'status':'ok','note':'Doctor reports measured checks only; it never claims a component was fixed merely because a fix endpoint was called.'}
    errors=sum(1 for x in checks.values() if x.get('status') in {'error','missing'})
    return {'ok':errors==0,'overall':'healthy' if errors==0 else 'attention_required','checks':checks}
