from __future__ import annotations

from fastapi.responses import JSONResponse

try:
    from slowapi import Limiter
    from slowapi.errors import RateLimitExceeded
    from slowapi.util import get_remote_address
    SLOWAPI_AVAILABLE = True
    limiter = Limiter(key_func=get_remote_address)
except Exception:  # Optional at source-test time; requirements.txt installs it for normal runs.
    SLOWAPI_AVAILABLE = False
    RateLimitExceeded = Exception

    class _NoopLimiter:
        def limit(self, *_args, **_kwargs):
            def decorator(fn):
                return fn
            return decorator

    limiter = _NoopLimiter()


def install(app) -> None:
    """Install the configured rate limiter without making startup depend on an optional import."""
    app.state.limiter = limiter
    if SLOWAPI_AVAILABLE:
        @app.exception_handler(RateLimitExceeded)
        async def _rate_limit_handler(request, exc):
            return JSONResponse(
                status_code=429,
                content={
                    'ok': False,
                    'error': 'rate_limit_exceeded',
                    'message': 'Too many requests. Please wait and try again.',
                },
            )


def status() -> dict:
    return {
        'enabled': True,
        'provider': 'slowapi' if SLOWAPI_AVAILABLE else 'fallback_noop_until_dependency_install',
        'dependency_required': not SLOWAPI_AVAILABLE,
        'key': 'remote client address',
    }
