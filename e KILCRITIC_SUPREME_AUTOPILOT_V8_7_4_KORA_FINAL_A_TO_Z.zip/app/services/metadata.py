from __future__ import annotations
import re

PLATFORM_RULES = {
    "youtube": {"caption_style": "title_description_tags", "formats": ["video"]},
    "facebook": {"caption_style": "caption_hashtags", "formats": ["video", "photo", "story"]},
    "instagram": {"caption_style": "caption_hashtags", "formats": ["video", "photo", "story"]},
    "tiktok": {"caption_style": "short_caption_hashtags", "formats": ["video"]},
    "x": {"caption_style": "short_post", "formats": ["video", "photo"]},
}

_FLAG_BY_REGION = {
    "IN":"🇮🇳", "CA":"🇨🇦", "US":"🇺🇸", "GB":"🇬🇧", "AE":"🇦🇪", "AU":"🇦🇺"
}
_EMOJI_BY_TOPIC = {
    "tech":["🤖","💻","⚡"], "business":["💼","📈","💰"], "travel":["✈️","🌍","📍"],
    "food":["🍽️","🔥","😋"], "music":["🎵","🎧","🔥"], "fitness":["💪","🔥","🏃"],
    "gaming":["🎮","⚡","🏆"], "education":["📚","🧠","💡"], "general":["🔥","✨","🚀"]
}

def _slug_words(text: str) -> list[str]:
    words = re.findall(r"[A-Za-z0-9_]+", (text or "").lower())
    seen=[]
    for w in words:
        if len(w) >= 3 and w not in seen:
            seen.append(w)
    return seen[:8]

def _topic_key(topic: str) -> str:
    t=(topic or '').lower()
    for k in _EMOJI_BY_TOPIC:
        if k in t: return k
    return 'general'

def build_metadata(topic: str, content_type: str, platform: str) -> dict:
    rule = PLATFORM_RULES.get(platform, {})
    return {"platform": platform, "topic": topic.strip(), "content_type": content_type, "caption_style": rule.get("caption_style", "generic"), "hashtags": [], "title": topic.strip()[:100]}

def build_discovery_metadata(topic: str, content_type: str, platform: str, region: str='IN', trend_terms: list[str] | None=None, hide_hashtags: bool=True) -> dict:
    """Create discovery suggestions without claiming virality. Hashtags are metadata suggestions; placement depends on platform."""
    words=_slug_words(topic)
    trend=[]
    for item in trend_terms or []:
        trend.extend(_slug_words(item))
    candidates=[]
    for w in words + trend:
        if w not in candidates: candidates.append(w)
    # Keep a small relevant set instead of spam.
    tags=[f"#{w}" for w in candidates[:6]]
    if not tags and topic.strip():
        tags=[f"#{topic.strip().replace(' ','')[:40]}"]
    flag=_FLAG_BY_REGION.get((region or 'IN').upper())
    emojis=_EMOJI_BY_TOPIC.get(_topic_key(topic), _EMOJI_BY_TOPIC['general'])[:3]
    visible_caption = ' '.join(emojis + ([flag] if flag else []))
    placement = 'internal_metadata_preferred' if hide_hashtags else 'caption_or_platform_tags'
    return {
        'ok': True, 'platform': platform, 'content_type': content_type, 'region': (region or 'IN').upper(),
        'hashtags': tags, 'hashtag_visibility': 'internal_preferred' if hide_hashtags else 'visible',
        'placement_note': 'Hidden placement is only used where the connected platform/API supports metadata fields; otherwise KILCRITIC will not pretend tags are hidden.',
        'emojis': emojis, 'flag': flag, 'caption_decoration': visible_caption,
        'trend_terms_used': trend[:12], 'virality_guarantee': False,
        'selection_rule': 'relevance + topic/trend overlap + small set; no spam'
    }
