from ..db import rows,execute,now
def summarize():
    data=rows('SELECT platform,COUNT(*) posts,COALESCE(SUM(views),0) views,COALESCE(SUM(likes),0) likes,COALESCE(SUM(comments),0) comments,COALESCE(SUM(shares),0) shares FROM analytics GROUP BY platform ORDER BY views DESC')
    rec=[]
    for x in data:
        v=max(1,int(x['views'])); rec.append({'platform':x['platform'],'engagement_per_view':round((x['likes']+x['comments']+x['shares'])/v,4)})
    return {'enabled':True,'mode':'measurement_based_feedback','platform_summary':data,'recommendations':rec,'note':'Recommendations use recorded analytics only; no fabricated performance is inferred.'}
def ingest(platform,media_id,views=0,likes=0,comments=0,shares=0):
    import uuid
    vals=[int(views),int(likes),int(comments),int(shares)]
    if any(v<0 for v in vals): raise ValueError('analytics values cannot be negative')
    execute('INSERT INTO analytics(id,platform,media_id,views,likes,comments,shares,captured_at) VALUES (?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),platform,media_id,*vals,now())); return {'ok':True,'recorded':True}
