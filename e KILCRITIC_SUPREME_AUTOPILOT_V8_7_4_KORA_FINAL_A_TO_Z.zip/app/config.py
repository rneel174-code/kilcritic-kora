import os, socket
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()
BASE_DIR=Path(__file__).resolve().parent.parent
STORAGE=BASE_DIR/'storage'; MEDIA_DIR=STORAGE/'media'; JOBS_DIR=STORAGE/'jobs'; EXPORTS_DIR=STORAGE/'exports'
for p in (MEDIA_DIR,JOBS_DIR,EXPORTS_DIR): p.mkdir(parents=True,exist_ok=True)
DB_PATH=Path(os.getenv('DB_PATH',str(STORAGE/'kilcritic.db')))
if not DB_PATH.is_absolute(): DB_PATH=BASE_DIR/DB_PATH
MAX_UPLOAD_BYTES=int(os.getenv('MAX_UPLOAD_BYTES','536870912'))
FFMPEG_BIN=os.getenv('FFMPEG_BIN','ffmpeg')
SUPPORTED_PLATFORMS=('youtube','facebook','instagram','tiktok','x')
ENGINE_VERSION='8.7.2-KORA-BRAHMA-RATE-LIMIT-HARDENED'
OPENAI_MODEL=os.getenv('OPENAI_MODEL','gpt-5.6-luna')
CORS_ORIGINS=[x.strip() for x in os.getenv('CORS_ORIGINS','http://127.0.0.1:8000,http://localhost:8000').split(',') if x.strip()]
_detected_hosts={'127.0.0.1','localhost',socket.gethostname()}
try:
    _detected_hosts.add(socket.gethostbyname(socket.gethostname()))
except Exception:
    pass
_host_env=os.getenv('ALLOWED_HOSTS','').strip()
ALLOWED_HOSTS=[x.strip() for x in (_host_env.split(',') if _host_env else sorted(_detected_hosts)) if x.strip()]
MALAK_CONTROL_TOKEN=os.getenv('MALAK_CONTROL_TOKEN','').strip()
KILCRITIC_ACCESS_TOKEN=os.getenv('KILCRITIC_ACCESS_TOKEN','').strip()
REMOTE_ACCESS_REQUIRED=os.getenv('REMOTE_ACCESS_REQUIRED','true').strip().lower() in {'1','true','yes','on'}
MEDIA_SIGNING_SECRET=os.getenv('MEDIA_SIGNING_SECRET','').strip()

MAX_QUEUE_SIZE=max(1,int(os.getenv('MAX_QUEUE_SIZE','500')))
UPLOAD_CHUNK_BYTES=max(262144,int(os.getenv('UPLOAD_CHUNK_BYTES','1048576')))
MEDIA_EDIT_TIMEOUT_SECONDS=max(30,int(os.getenv('MEDIA_EDIT_TIMEOUT_SECONDS','1800')))
QUALITY_PRESETS={
    'source': None,
    '720p': (1280,720),
    '1080p': (1920,1080),
    '1440p': (2560,1440),
    '4K': (3840,2160),
    '8K': (7680,4320),
}
ALLOWED_QUALITY=tuple(QUALITY_PRESETS.keys())

YOUTUBE_API_KEY=os.getenv('YOUTUBE_API_KEY','').strip()
YOUTUBE_CLIENT_ID=os.getenv('YOUTUBE_CLIENT_ID','').strip()
YOUTUBE_CLIENT_SECRET=os.getenv('YOUTUBE_CLIENT_SECRET','').strip()
YOUTUBE_REFRESH_TOKEN=os.getenv('YOUTUBE_REFRESH_TOKEN','').strip()
GROQ_API_KEY=os.getenv('GROQ_API_KEY','').strip()
GROQ_MODEL=os.getenv('GROQ_MODEL','openai/gpt-oss-120b').strip()
OPENROUTER_KEY=os.getenv('OPENROUTER_KEY','').strip()
OPENROUTER_MODEL=os.getenv('OPENROUTER_MODEL','openrouter/free').strip()
OPENROUTER_SITE_URL=os.getenv('OPENROUTER_SITE_URL','http://127.0.0.1:8000').strip()

GEMINI_API_KEY=os.getenv('GEMINI_API_KEY','').strip()
GEMINI_MODEL=os.getenv('GEMINI_MODEL','gemini-3.8-flash').strip()
GEMINI_BASE_URL=os.getenv('GEMINI_BASE_URL','https://generativelanguage.googleapis.com/v1beta').strip()
CEREBRAS_API_KEY=os.getenv('CEREBRAS_API_KEY','').strip()
CEREBRAS_MODEL=os.getenv('CEREBRAS_MODEL','llama-3.3-70b').strip()
OLLAMA_ENABLED=os.getenv('OLLAMA_ENABLED','false').strip().lower() in {'1','true','yes','on'}
OLLAMA_MODEL=os.getenv('OLLAMA_MODEL','llama3.2:3b').strip()
AI_PROVIDER_ORDER=os.getenv('AI_PROVIDER_ORDER','groq,gemini,openrouter,cerebras,ollama,local').strip()
AI_FALLBACK_MAX_TOKENS=max(256,int(os.getenv('AI_FALLBACK_MAX_TOKENS','1400')))

AUTOPILOT_ENABLED=os.getenv('ENABLE_AUTOPILOT','false').strip().lower() in {'1','true','yes','on'}
AUTOPILOT_AUTO_APPROVE=os.getenv('AUTOPILOT_AUTO_APPROVE','false').strip().lower() in {'1','true','yes','on'}
AUTOPILOT_FOLLOWUP_VIEW_THRESHOLD=max(1,int(os.getenv('AUTOPILOT_FOLLOWUP_VIEW_THRESHOLD','1000')))
AUTOPILOT_MAX_FOLLOWUPS=max(0,min(3,int(os.getenv('AUTOPILOT_MAX_FOLLOWUPS','3'))))
AUTOPILOT_REGION=os.getenv('AUTOPILOT_REGION','IN').strip().upper()
AUTOPILOT_CATEGORY_ID=os.getenv('AUTOPILOT_CATEGORY_ID','').strip()
