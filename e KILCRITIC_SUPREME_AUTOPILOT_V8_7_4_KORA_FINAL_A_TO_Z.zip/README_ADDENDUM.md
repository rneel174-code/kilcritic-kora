# V8.6.0 — KORA UNIVERSAL HUD

This release is additive on the V8.5.1 KORA Additive Guard baseline. The existing engine modules remain in place; the main addition is a touch-first universal HUD and mini-screen plus a guarded `/api/kora/hud` snapshot.

## V8.5.1 baseline


This release adds upgrade-governance protection on top of the V8.4 executive baseline.

- Existing V8.4 source capabilities are preserved.
- `tools/additive_baseline.json` records the baseline inventory and critical markers.
- `tools/additive_upgrade_guard.py` detects missing baseline files/markers.
- `ADDITIVE_UPGRADE_CONTRACT.md` defines the permanent preserve-before-delete rule.
- Runtime caches and SQLite runtime state are intentionally excluded from release archives.


## V8.5.1 additive release guard
- Upgrade policy is preserve + add + integrate + test.
- `python tools/additive_upgrade_guard.py` checks the 8.5.1 baseline.
- `python tools/release_audit.py` checks the release for runtime/cache artifacts.
- `/manifest.json` and `/sw.js` are explicit additive routes for PWA reliability.
