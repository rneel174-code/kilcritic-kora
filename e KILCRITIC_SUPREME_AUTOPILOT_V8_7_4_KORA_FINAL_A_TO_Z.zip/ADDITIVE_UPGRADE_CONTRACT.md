# KILCRITIC Additive Upgrade Contract

## Rule
**Upgrade = preserve + add + integrate + test.** Existing working capabilities are preserved by default.

A capability may be removed/replaced only when it is proven to be:
1. duplicate,
2. broken or unsafe, or
3. explicitly obsolete.

## Release gates
1. Freeze the previous release as a backup.
2. Run `python tools/additive_upgrade_guard.py` before changes.
3. Add new capability without silently deleting existing modules/routes/UI contracts.
4. Run compile/tests and functional smoke tests.
5. Run the additive guard again.
6. Run an audit for fake-success markers, secrets, runtime caches and unauthorized platform claims.
7. Only then create the clean release ZIP.

## ZIP policy
Release ZIPs contain source/config/examples/tests/docs. They intentionally exclude runtime SQLite DB/WAL/SHM, `__pycache__`, `.pyc`, logs, and secrets. Their absence is not a capability deletion.

## Removal record
Any intentional removal must be documented with: `removed`, `reason`, `replacement`, `regression result`.
