# KORA 8.7.1 — CLEAN EXECUTIVE RELEASE

- Added `.gitignore` covering Python cache, `.env`, SQLite runtime state, logs and local media.
- Added evidence-first `Executive` class with `plan()`, `delegate()` and `verify()` (3/5 advisory majority).
- Added `/api/kora/executive/plan`, `/delegate`, `/verify` endpoints.
- Extended release audit to require `.gitignore` and `executive.py`.
- Preserved existing APIs, platform adapters, memory, scheduler, worker, security and approval gates.
- No runtime database, `.env`, `__pycache__` or `.pyc` files are packaged.
