"""T44+ : governance layer (policy, proposals, truth, malak, legal guard, cost, checkpoints, SENA, emergency, bridge wiring)."""
import io
import json
import os
import tempfile
import threading
import time
from dataclasses import replace

from kora.config.settings import load_settings
from kora.core import policy
from kora.core.contracts import Risk, Truth
from kora.core.db import get_connection, init_db
from kora.services import cost, dharma, emergency, governance, legal_guard, sena, social


def _db():
    p = os.path.join(tempfile.mkdtemp(prefix="kora-g-"), "g.db")
    init_db(p)
    return p


def register(run_test):
    def t_policy():
        assert policy.evaluate("READ_LOCAL_FILE")["decision"] == "ALLOW_WITH_GUARDS"
        assert policy.evaluate("NETWORK_ACCESS")["decision"] == "ALLOW_WITH_GUARDS"
        assert policy.evaluate("PUBLISH_SOCIAL")["decision"] == "APPROVAL_REQUIRED"
        assert policy.evaluate("CHANGE_SECURITY")["decision"] == "APPROVAL_REQUIRED"
        assert policy.evaluate("bypass_auth")["decision"] == "BLOCK"
        assert policy.evaluate("MADE_UP_PERMISSION")["decision"] == "BLOCK", "unknown must fail closed"
        assert policy.evaluate("READ_LOCAL_FILE", Risk.HIGH)["decision"] == "APPROVAL_REQUIRED", "requested risk can only raise"
        db = _db()
        emergency.set_safe_mode(True, "t", db)
        assert policy.evaluate("WRITE_LOCAL_FILE", None, db)["reason"] == "safe_mode"
        assert policy.evaluate("READ_LOCAL_FILE", None, db)["decision"] == "ALLOW_WITH_GUARDS"
        emergency.set_safe_mode(False, "t", db)
        assert policy.evaluate("WRITE_LOCAL_FILE", None, db)["decision"] == "ALLOW_WITH_GUARDS"
        assert policy.evaluate("X") and "PUBLISH_SOCIAL" in policy.PERMISSIONS and len(policy.PERMISSIONS) == 19
    run_test("T44", "Policy: single permission table, hard blocks, fail-closed unknown, safe mode, risk only rises", t_policy)

    def t_governed():
        db = _db()
        ran = []
        r = governance.execute_governed("READ_LOCAL_FILE", lambda: ran.append(1) or {"v": 1}, db)
        assert r["status"] == "VERIFIED" and ran == [1]
        r = governance.execute_governed("BYPASS_DRM", lambda: ran.append(2) or {}, db)
        assert r["status"] == "BLOCKED" and ran == [1]
        r = governance.execute_governed("DEPLOY_APP", lambda: ran.append(3) or {"ok": True}, db, reason="ship")
        assert r["status"] == "PENDING_APPROVAL" and ran == [1], "high risk must not run before approval"
        pid = r["proposal_id"]
        assert governance.execute_governed("DEPLOY_APP", lambda: ran.append(4) or {}, db, proposal_id=pid)["status"] == "PENDING_APPROVAL", "unapproved id is not accepted (new proposal)"
        assert ran == [1]
        assert governance.decide(pid, True, "me", db) and not governance.decide(pid, False, "me", db), "decide once"
        # proposal approved for DEPLOY_APP cannot be spent on another action
        assert governance.execute_governed("DELETE_DATA", lambda: ran.append(5) or {}, db, proposal_id=pid)["status"] == "PENDING_APPROVAL" and ran == [1]
        r = governance.execute_governed("DEPLOY_APP", lambda: ran.append(6) or {"ok": True}, db, proposal_id=pid)
        assert r["status"] == "VERIFIED" and ran == [1, 6]
        again = governance.execute_governed("DEPLOY_APP", lambda: ran.append(7) or {}, db, proposal_id=pid)
        assert again["status"] == "PENDING_APPROVAL" and ran == [1, 6], "approval is single-use"
        # failure path: verification FAIL -> rollback runs
        pid2 = governance.create_proposal("DELETE_DATA", "x", "HIGH", db_path=db)
        governance.decide(pid2, True, "me", db)
        rb = []
        r = governance.execute_governed("DELETE_DATA", lambda: {"ok": False, "error": "boom"}, db, proposal_id=pid2, rollback=lambda: rb.append(1))
        assert r["status"] == "FAILED" and r["rolled_back"] and rb == [1]
        r = governance.execute_governed("READ_LOCAL_FILE", lambda: "not a dict", db)
        assert r["status"] == "FAILED"
        r = governance.execute_governed("READ_LOCAL_FILE", lambda: 1 / 0, db)
        assert r["status"] == "FAILED" and "ZeroDivisionError" in r["verification"]["notes"][0]
    run_test("T45", "Governed execution: approval single-use & action-bound, real verification, rollback on failure/exception", t_governed)

    def t_truth_malak():
        from kora.core import truth
        assert truth.classify(None) == Truth.UNAVAILABLE and truth.classify("x") == Truth.UNCERTAIN
        assert truth.classify("x", ["src"]) == Truth.SOURCE_BASED and truth.classify("x", ["src"], verified=True) == Truth.VERIFIED
        assert truth.classify("x", ["src"], user_preference=True) == Truth.USER_PREFERENCE
        assert not truth.can_assert_as_fact(Truth.USER_PREFERENCE) and not truth.can_assert_as_fact(Truth.GOAL) and not truth.can_assert_as_fact(Truth.INFERRED)
        db = _db()
        assert dharma.get_rules(db)["version"] == 1
        dharma.set_rule("tone", "formal", "o", db)
        dharma.set_rule("emoji_level", "low", "o", db)
        v3 = dharma.set_rule("tone", "casual", "o", db)
        assert v3["version"] == 4 and v3["rules"]["tone"] == "casual"
        for bad in (("auth_required", False), ("rate_limit", 0), ("legal_guard", "off"), ("tone", "angry"), ("auto_hashtags", "yes"), ("is_earth_flat", True)):
            try:
                dharma.set_rule(bad[0], bad[1], "o", db)
                assert False, bad
            except dharma.MalakViolation:
                pass
        r = dharma.rollback(2, "o", db)
        assert r["rules"] == {"tone": "formal"} and r["version"] == 5, r
        assert dharma.get_rule("tone", None, db) == "formal" and dharma.get_rule("nope", "d", db) == "d"
        # DEFAULT is never shared/mutated between stores
        assert dharma.get_rules(_db())["rules"] == {}
    run_test("T46", "Truth + Malak: preferences never become facts, closed rule whitelist, versioned rollback", t_truth_malak)

    def t_repair():
        log = []
        mk = lambda **k: dharma.repair_flow(k.get("d", lambda: True), lambda: log.append("repair"), k.get("t", lambda: True), k.get("v", lambda: True), lambda: log.append("rb"), k.get("risk", Risk.LOW))
        assert mk(d=lambda: False)["status"] == "NO_ISSUE" and log == []
        assert mk()["status"] == "REPAIRED"
        assert mk(t=lambda: False)["status"] == "ROLLED_BACK" and log[-1] == "rb"
        assert mk(v=lambda: False)["status"] == "ROLLED_BACK"
        n = len(log)
        assert mk(t=lambda: 1 / 0)["status"] == "ROLLED_BACK" and log[-1] == "rb" and len(log) > n, "exception in test must still roll back"
        assert mk(risk=Risk.HIGH)["status"] == "APPROVAL_REQUIRED" and mk(risk=Risk.CRITICAL)["status"] == "APPROVAL_REQUIRED"
    run_test("T47", "Auto Sudhaar: repair->test->verify, rollback on failure/exception, HIGH/CRITICAL never auto", t_repair)

    def t_legal():
        p = legal_guard.preflight
        assert p({"content": "hello", "rights": "OWNED", "source": "original"})["status"] == "PASS"
        assert p({"content": "hello"})["status"] == "HUMAN_REVIEW", "undeclared rights never PASS (audit R1)"
        assert p({"content": "hi", "source": "DRM"})["status"] == "BLOCKED"
        assert p({"content": "hi", "rights": "UNAUTHORIZED"})["status"] == "BLOCKED"
        assert p({"content": "hi", "audience": "KIDS", "adult_content": True})["status"] == "BLOCKED"
        assert p({"content": "hi", "media": True})["status"] == "HUMAN_REVIEW", "unknown rights are never assumed OK"
        assert p({"content": "hi", "media": True, "rights": "licensed"})["status"] == "PASS"
        assert p({"content": "hi", "duplicate_risk": True})["status"] == "HUMAN_REVIEW"
        r = p({"content": "x " + " ".join(f"#t{i}" for i in range(40)), "rights": "OWNED", "source": "original"})
        assert r["status"] == "AUTO_FIXED" and r["asset"]["content"].count("#") == 30
        r = p({"content": "pic", "ai_generated": True, "rights": "OWNED", "source": "original"})
        assert r["status"] == "AUTO_FIXED" and "[AI-generated]" in r["asset"]["content"]
        assert p({"content": "a" * 300, "platform": "X"})["status"] == "HUMAN_REVIEW"
        assert all(p({"content": "x"})["legal_guarantee"] is False for _ in range(1))
    run_test("T48", "Legal/platform preflight: PASS / AUTO_FIXED / HUMAN_REVIEW / BLOCKED, no legal guarantee claimed", t_legal)

    def t_social_gate():
        db = _db()
        base = dict(db_path=db, auto_approve=True, auto_publish=False, env={})
        r = social.create_social_post("X", "plain text", "GENERAL", asset_meta={"rights": "OWNED", "source": "original"}, **base)
        assert r["preflight"] == "PASS" and r["status"] != "PENDING_APPROVAL", r  # auto-approved only when preflight is clean
        r = social.create_social_post("X", "hello", "GENERAL", asset_meta={"duplicate_risk": True}, **base)
        assert r["status"] == "PENDING_APPROVAL" and r["preflight"] == "HUMAN_REVIEW", "HUMAN_REVIEW is never auto-approved"
        try:
            social.create_social_post("X", "hello", "GENERAL", asset_meta={"source": "DRM"}, **base)
            assert False
        except social.SocialPublishError as e:
            assert "legal_preflight_blocked" in str(e)
        fixed = social.create_social_post("X", "ai img", "GENERAL", asset_meta={"ai_generated": True}, db_path=db, auto_approve=False)
        assert "[AI-generated]" in social.get_post(fixed["post_id"], db)["content"]
        emergency.set_safe_mode(True, "t", db)
        for fn in (lambda: social.create_social_post("X", "z", "GENERAL", db_path=db), lambda: social.approve_and_publish_post(fixed["post_id"], db)):
            try:
                fn()
                assert False
            except social.SocialPublishError as e:
                assert "safe_mode" in str(e)
        emergency.set_safe_mode(False, "t", db)
    run_test("T49", "Social x governance: preflight stored, BLOCKED refused, HUMAN_REVIEW never auto-approved, safe mode denies", t_social_gate)

    def t_cost():
        db = _db()
        daily, monthly = {"ai_calls": 3}, {"ai_calls": 100}
        for _ in range(3):
            cost.charge("ai_calls", daily, monthly, db)
        try:
            cost.charge("ai_calls", daily, monthly, db)
            assert False
        except cost.BudgetExceeded as e:
            assert e.resource == "ai_calls"
        # reservations count against the cap and releasing frees it
        db2 = _db()
        r1 = cost.reserve("ai_calls", 2, daily, monthly, db2)
        try:
            cost.reserve("ai_calls", 2, daily, monthly, db2)
            assert False
        except cost.BudgetExceeded:
            pass
        cost.settle(r1, 0, db2)
        cost.reserve("ai_calls", 3, daily, monthly, db2)
        # uncapped resources work; monthly cap enforced; next day resets daily only
        cost.charge("tokens", daily, monthly, db2, 10)
        db3 = _db()
        t0 = 1_700_000_000
        cost.settle(cost.reserve("ai_calls", 3, daily, {"ai_calls": 4}, db3, now=t0), None, db3)
        cost.settle(cost.reserve("ai_calls", 1, daily, {"ai_calls": 4}, db3, now=t0 + 86400), None, db3)
        try:
            cost.reserve("ai_calls", 1, daily, {"ai_calls": 4}, db3, now=t0 + 2 * 86400)
            assert False, "monthly cap"
        except cost.BudgetExceeded as e:
            assert e.period.startswith("m:")
        assert cost.parse_caps("ai_calls=5, bad, x=oops,n=2") == {"ai_calls": 5.0, "n": 2.0}
        snap = cost.snapshot(daily, monthly, db)
        assert snap["usage"]["ai_calls"]["day"]["used"] == 3
        # concurrent reservations never exceed the cap
        db4 = _db()
        ok = []

        def w():
            try:
                cost.reserve("ai_calls", 1, {"ai_calls": 5}, {}, db4)
                ok.append(1)
            except cost.BudgetExceeded:
                pass
        ts = [threading.Thread(target=w) for _ in range(20)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        assert len(ok) == 5, len(ok)
    run_test("T50", "Cost governor: persistent reserve/settle/release, daily+monthly caps, race-safe", t_cost)

    def t_checkpoint_sena():
        db = _db()
        governance.checkpoint_save("job-1", {"step": 2}, db)
        assert governance.checkpoint_load("job-1", db) == {"step": 2} and governance.checkpoint_load("nope", db) is None
        for bad in ("../../etc/passwd", "a/b", "", "x" * 200):
            try:
                governance.checkpoint_save(bad, {}, db)
                assert False, bad
            except ValueError:
                pass
        try:
            governance.checkpoint_save("big", {"x": "a" * 300000}, db)
            assert False
        except ValueError:
            pass
        assert governance.checkpoint_delete("job-1", db)
        # SENA: real parallelism, bounded, isolated errors
        t0 = time.monotonic()
        res = sena.run_parallel(list(range(8)), lambda i: (time.sleep(0.2), i * 2)[1], max_workers=8)
        assert [r["result"] for r in res] == [i * 2 for i in range(8)] and time.monotonic() - t0 < 1.0, "must run in parallel"
        res = sena.run_parallel([1, 2, 3], lambda i: 1 / 0 if i == 2 else i)
        assert [r["status"] for r in res] == ["OK", "ERROR", "OK"]
        try:
            sena.run_parallel(list(range(21)), lambda i: i)
            assert False
        except ValueError:
            pass
        res = sena.run_parallel([1], lambda i: sena.run_parallel([1], lambda j: j))
        assert res[0]["status"] == "ERROR" and "nested" in res[0]["error"]
        res = sena.run_parallel([1, 2], lambda i: time.sleep(2) or i, timeout=0.3, max_workers=2)
        assert [r["status"] for r in res] == ["TIMEOUT", "TIMEOUT"]
        # resume: completed jobs are not executed again
        calls = []
        fail_once = {"on": True}

        def work(i):
            calls.append(i)
            if i == 2 and fail_once["on"]:
                raise RuntimeError("crash")
            return i
        sena.run_parallel([0, 1, 2], work, task_id="t-resume", db_path=db, max_workers=1)
        fail_once["on"] = False
        calls.clear()
        res = sena.run_parallel([0, 1, 2], work, task_id="t-resume", db_path=db, max_workers=1)
        assert calls == [2] and [r["status"] for r in res] == ["OK"] * 3 and res[0].get("resumed")
        plan = sena.attack_plan("python tips")
        assert plan["kind"] == "PLAN_ONLY" and len(plan["angles"]) == 10
        team = sena.clone_team(["Researcher", "analyst"])
        assert team["members"][0]["permissions"] == ["WEB_SEARCH", "NETWORK_ACCESS", "READ_LOCAL_FILE"]
        for bad in (["root"], [], ["editor"] * 11):
            try:
                sena.clone_team(bad)
                assert False
            except ValueError:
                pass
    run_test("T51", "Checkpoints (no path traversal, size cap) + SENA (parallel, bounded, isolated, no nesting, resume)", t_checkpoint_sena)

    def t_emergency():
        db = _db()
        r = emergency.emergency_recovery("t", db)
        names = {s["step"]: s["status"] for s in r["steps"]}
        assert r["status"] == "SAFE_MODE_ACTIVE" and policy.is_safe_mode(db)
        assert names["QUARANTINE_PROCESSES"] == "REQUIRES_OPERATOR" and names["RESTORE_TRUSTED_BASELINE"] == "REQUIRES_OPERATOR", "must not claim unimplemented steps"
        assert "PUBLISH_SOCIAL" in policy.revoked(db)
        from kora.core.queue import DurableQueue
        q = DurableQueue(db)
        assert q.is_kill_switch_active()
        try:
            q.enqueue("noop", {})
            assert False
        except Exception as e:
            assert e.__class__.__name__ == "KillSwitchActiveException"
        res = emergency.resume("t", db) if r["resume_allowed"] else {"status": "REFUSED"}
        if r["resume_allowed"]:
            assert res["status"] == "RESUMED" and not policy.is_safe_mode(db) and not policy.revoked(db) and not q.is_kill_switch_active()
        conn = get_connection(db)
        n = conn.execute("SELECT COUNT(*) FROM audit_events WHERE event_type IN ('emergency_recovery','safe_mode','emergency_snapshot');").fetchone()[0]
        conn.close()
        assert n >= 3, "audited"
    run_test("T52", "Emergency recovery: freeze, revoke, preserve, repair, verify; honest REQUIRES_OPERATOR; guarded resume", t_emergency)

    def t_bridge_gov():
        from kora.bridge.api import KoraApp
        d = tempfile.mkdtemp()
        s = replace(load_settings({}, dotenv_path="/nonexistent"), auth_token="tok-gov-123", db_path=os.path.join(d, "b.db"),
                    rate_write_per_min=1000, rate_read_per_min=1000, rate_heavy_per_min=1000, cron_enabled=False,
                    budget_daily="net_calls=2", budget_monthly="")
        app = KoraApp(s)
        H = {"Authorization": "Bearer tok-gov-123"}

        def call(method, path, body=None, headers=H):
            raw = json.dumps(body).encode() if body is not None else b""
            env = {"REQUEST_METHOD": method, "PATH_INFO": path, "REMOTE_ADDR": "203.0.113.9", "HTTP_HOST": "127.0.0.1:8000", "wsgi.input": io.BytesIO(raw),
                   "CONTENT_LENGTH": str(len(raw)) if raw else "", "CONTENT_TYPE": "application/json" if raw else ""}
            for k, v in (headers or {}).items():
                env["HTTP_" + k.upper().replace("-", "_")] = v
            out = {}
            data = b"".join(app(env, lambda st, h: out.update(status=int(st.split()[0]))))
            return out["status"], json.loads(data)
        for path in ("/api/governance/proposals", "/api/malak", "/api/cost"):
            assert call("GET", path, headers=None)[0] == 403, path
        assert call("POST", "/api/malak", {"key": "tone", "value": "formal"})[1]["rules"] == {"tone": "formal"}
        assert call("POST", "/api/malak", {"key": "auth_required", "value": False})[0] == 400
        assert call("POST", "/api/malak", {"rollback_to": 1})[1]["rules"] == {}
        assert call("POST", "/api/legal/preflight", {"content": "x", "source": "DRM"})[1]["status"] == "BLOCKED"
        assert call("POST", "/api/social/posts", {"platform": "X", "content": "x", "source": "DRM"})[0] == 400
        s_, r = call("POST", "/api/social/posts", {"platform": "X", "content": "ok post", "rights": "OWNED", "source": "original"})
        assert s_ == 201 and r["preflight"] == "PASS" and r["status"] == "PENDING_APPROVAL"
        # proposals appear in /api/active and can be decided once
        pid = governance.create_proposal("DEPLOY_APP", "ship", "HIGH", db_path=app.db_path)
        act = call("GET", "/api/active")[1]
        assert [p["id"] for p in act["proposals"]] == [pid] and act["idle"] is False and act["safe_mode"] is False
        assert call("POST", f"/api/governance/proposals/{pid}/approve")[0] == 200
        assert call("POST", f"/api/governance/proposals/{pid}/approve")[0] == 409
        assert call("GET", "/api/active")[1]["proposals"] == []
        # budget cap on research (2 calls allowed, 3rd refused BEFORE any network)
        for _ in range(2):
            cost.charge("net_calls", {"net_calls": 2}, {}, app.db_path)
        assert call("POST", "/api/research/fetch", {"url": "https://example.com/"})[0] == 429
        cs = call("GET", "/api/cost")[1]
        assert cs["usage"]["net_calls"]["day"]["used"] == 2
        # sena + safe mode + emergency via API
        assert len(call("POST", "/api/sena/attack", {"topic": "cats"})[1]["angles"]) == 10
        assert call("POST", "/api/sena/team", {"roles": ["root"]})[0] == 400
        assert call("POST", "/api/safe-mode", {"active": True})[1]["safe_mode"] is True
        assert call("GET", "/api/active")[1]["safe_mode"] is True
        assert call("POST", "/api/social/posts", {"platform": "X", "content": "blocked in safe mode"})[0] == 400
        assert call("POST", "/api/safe-mode", {"active": "yes"})[0] == 400
        assert call("POST", "/api/safe-mode", {"active": False})[1]["safe_mode"] is False
        e = call("POST", "/api/emergency")[1]
        assert e["status"] == "SAFE_MODE_ACTIVE"
        if e["resume_allowed"]:
            assert call("POST", "/api/emergency/resume")[1]["status"] == "RESUMED"
        # no route exists that accepts code for a proposal
        assert call("POST", f"/api/governance/proposals/{pid}/execute")[0] in (404, 405)
    run_test("T53", "Bridge x governance: auth on all new routes, malak/legal/cost/proposals/sena/safe-mode/emergency E2E", t_bridge_gov)
