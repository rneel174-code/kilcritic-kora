"""T54+ : identity/roles, voice=text brain, DNA/time machine, ATMA (restore/Phoenix/mission), Shadow, trust/skills, deep research,
provider states, ledger/revenue verifier, anti-loop, ops (lifecycle/export/delete/migration/audit chain), consent, bridge E2E.
All run against real SQLite files; network is replaced only by injected fakes (live providers stay UNVERIFIED)."""
import io
import json
import os
import shutil
import sqlite3
import tempfile
import time
import zipfile
from dataclasses import replace

from kora.config.settings import load_settings
from kora.core import anti_loop, identity, policy
from kora.core.db import get_connection, init_db, record_audit, verify_audit_chain
from kora.core.queue import DurableQueue
from kora.core.worker import HANDLERS, SafeWorker, register_handler
from kora.services import (atma, brain, dhanda, dna, emergency, fusion, governance, ops, shadow, social, trust, voice_consent)


def _db():
    p = os.path.join(tempfile.mkdtemp(prefix="kora-s-"), "s.db")
    init_db(p)
    return p


OWNER = {"id": "owner", "role": "owner"}


def register(run_test):
    def t_identity():
        db = _db()
        u = identity.create_principal("alice", "user", db_path=db)
        assert u["token"] and len(u["token"]) > 30
        conn = get_connection(db)
        stored = conn.execute("SELECT token_hash FROM principals;").fetchone()[0]
        conn.close()
        assert stored != u["token"] and u["token"] not in stored, "only a hash is stored"
        assert identity.authenticate_token(u["token"], db)["id"] == u["id"] and identity.authenticate_token("wrong", db) is None
        assert not identity.has_permission(u["id"], "WEB_SEARCH", db)
        g = identity.grant(u["id"], "WEB_SEARCH", 100, "owner", db, now=1000.0)
        assert identity.has_permission(u["id"], "WEB_SEARCH", db, now=1050.0) and not identity.has_permission(u["id"], "WEB_SEARCH", db, now=1101.0), "expiry"
        identity.grant(u["id"], "READ_LOCAL_FILE", None, "owner", db)
        assert identity.has_permission(u["id"], "READ_LOCAL_FILE", db, now=1e12), "permanent grant"
        assert identity.revoke_grant(g["grant_id"], "owner", db) and not identity.has_permission(u["id"], "WEB_SEARCH", db, now=1050.0), "instant revoke"
        for bad in ("CHANGE_SECURITY", "CHANGE_CREDENTIALS", "NOT_A_PERMISSION"):
            try:
                identity.grant(u["id"], bad, 10, "owner", db)
                assert False, bad
            except identity.IdentityError:
                pass
        try:
            identity.grant(u["id"], "WEB_SEARCH", 10 ** 9, "owner", db)
            assert False
        except identity.IdentityError:
            pass
        d = identity.create_principal("phone", "device", db_path=db, ttl_seconds=60, now=5000.0)
        assert identity.authenticate_token(d["token"], db, now=5030.0) and identity.authenticate_token(d["token"], db, now=5061.0) is None, "session expiry"
        assert identity.revoke_principal(u["id"], "owner", db) and identity.authenticate_token(u["token"], db) is None
        assert not identity.has_permission(u["id"], "READ_LOCAL_FILE", db), "revoking a principal kills its grants"
        try:
            identity.create_principal("x", "owner", db_path=db)
            assert False
        except identity.IdentityError:
            pass
        conn = get_connection(db)
        n = conn.execute("SELECT COUNT(*) FROM audit_events WHERE event_type IN ('principal_created','grant','grant_revoked','principal_revoked');").fetchone()[0]
        conn.close()
        assert n >= 6, "audited"
    run_test("T54", "Identity: hashed tokens, temporary/permanent grants, expiry, instant revoke, protected perms, device session expiry, audit", t_identity)

    def t_totp():
        db = _db()
        assert identity.step_up("123456", db) == "NOT_ENROLLED"
        sec = identity.totp_enroll(db)["secret"]
        t = 1_700_000_000.0
        ctr = int(t // 30)
        # RFC 6238 test vector (secret "12345678901234567890", T=59 -> counter 1 -> 94287082 => 6 digits 287082)
        import base64
        rfc = base64.b32encode(b"12345678901234567890").decode()
        assert identity._code(rfc, 1) == "287082"
        assert identity.step_up("000000", db, t) == "INVALID" and identity.step_up("abc", db, t) == "INVALID"
        good = identity._code(sec, ctr)
        assert identity.step_up(good, db, t) == "OK"
        assert identity.step_up(good, db, t) == "INVALID", "a code is single-use (replay)"
        assert identity.step_up(identity._code(sec, ctr - 1), db, t) == "INVALID", "older counter than last used"
        assert identity.step_up(identity._code(sec, ctr + 1), db, t) == "OK" and identity.step_up(identity._code(sec, ctr + 5), db, t) == "INVALID", "window +-1 only"
        try:
            identity.totp_enroll(db, "000000", t)
            assert False, "re-enrol needs a valid current code"
        except identity.IdentityError:
            pass
    run_test("T55", "TOTP step-up: RFC 6238 vector, single-use codes, window, re-enrol protection", t_totp)

    def t_brain():
        db = _db()
        # voice OFF by default: nothing is processed
        assert brain.handle("ho ja shuru", principal=OWNER, source="voice", db_path=db, voice_verified=True)["status"] == "VOICE_OFF"
        text = brain.handle("ho ja shuru", principal=OWNER, source="text", db_path=db)
        assert text["status"] == "OK" and "KORA online" in text["message"]
        brain.set_voice(True, "owner", db)
        v = brain.handle("Ho ja shuru", principal=OWNER, source="voice", db_path=db, voice_verified=True)
        assert v["status"] == "OK" and v["data"]["queue"] == text["data"]["queue"] and "speech" in v and "speech" not in text, "voice = text engine"
        # unknown voice = guest: read-only status only
        g = brain.handle("system doctor", principal=OWNER, source="voice", db_path=db, voice_verified=False)
        assert g["status"] == "DENIED"
        assert brain.handle("status", principal=OWNER, source="voice", db_path=db, voice_verified=False)["status"] == "OK"
        assert brain.handle("attack cats", principal=OWNER, source="voice", db_path=db, voice_verified=False)["status"] == "DENIED"
        # sensitive by voice without 2FA enrolled => refused even for the verified owner voice
        e = brain.handle("emergency recovery", principal=OWNER, source="voice", db_path=db, voice_verified=True)
        assert e["status"] == "STEP_UP_REQUIRED" and not policy.is_safe_mode(db)
        sec = identity.totp_enroll(db)["secret"]
        t = 1_800_000_000.0
        assert brain.handle("emergency recovery", principal=OWNER, source="voice", db_path=db, voice_verified=True, now=t)["status"] == "STEP_UP_REQUIRED"
        assert brain.handle("emergency recovery", principal=OWNER, source="voice", db_path=db, voice_verified=True, totp_code="111111", now=t)["status"] == "STEP_UP_REQUIRED"
        ok = brain.handle("emergency recovery", principal=OWNER, source="text", db_path=db, totp_code=identity._code(sec, int(t // 30)), now=t)
        assert ok["status"] == "OK" and policy.is_safe_mode(db)
        # safe mode mutes voice; voice can't be switched on during safe mode
        assert brain.handle("status", principal=OWNER, source="voice", db_path=db, voice_verified=True)["status"] == "MUTED"
        assert brain.set_voice(True, "owner", db)["voice"] is False
        emergency.set_safe_mode(False, "t", db)
        # voice off => processing stops
        assert brain.handle("voice off", principal=OWNER, source="voice", db_path=db, voice_verified=True)["status"] == "OK"
        assert brain.handle("status", principal=OWNER, source="voice", db_path=db, voice_verified=True)["status"] == "VOICE_OFF"
        # clarification, not guessing; bad inputs
        c = brain.handle("make me a sandwich", principal=OWNER, db_path=db)
        assert c["status"] == "NEEDS_CLARIFICATION" and c["examples"]
        assert brain.handle("", principal=OWNER, db_path=db)["status"] == "INVALID" and brain.handle("x" * 501, principal=OWNER, db_path=db)["status"] == "INVALID"
        assert brain.handle("status", principal=OWNER, source="telepathy", db_path=db)["status"] == "INVALID"
        # assigned user: needs a grant for the permission behind each intent
        u = identity.create_principal("bob", "user", db_path=db)
        up = {"id": u["id"], "role": "user"}
        assert brain.handle("attack cats", principal=up, db_path=db)["status"] == "DENIED"
        identity.grant(u["id"], "WEB_SEARCH", 100, "owner", db)
        assert brain.handle("attack cats", principal=up, db_path=db)["status"] == "OK"
        assert brain.handle("emergency recovery", principal=up, db_path=db)["status"] == "DENIED", "CHANGE_SECURITY can never be granted"
        # secrets are never spoken
        sp = brain.safe_to_speak("token: abcdef123456 and key " + "A" * 40)
        assert "abcdef123456" not in sp and "A" * 40 not in sp
        # every command is audited with the same trail for both sources
        conn = get_connection(db)
        n = conn.execute("SELECT COUNT(*) FROM audit_events WHERE event_type='brain_command';").fetchone()[0]
        conn.close()
        assert n >= 10
    run_test("T56", "Brain: voice=text parity, voice OFF, unknown voice = guest, sensitive needs 2FA, safe-mode mute, user permissions, no secrets spoken", t_brain)

    def t_dna():
        db = _db()
        assert dna.get("style", db)["version"] == 0
        dna.set_pref("style", "tone", "funny", actor="o", db_path=db, now=1000.0)
        dna.set_pref("style", "pace", "fast", source="learned", confidence=0.3, db_path=db, now=1000.0)
        r = dna.set_pref("style", "tone", "serious", source="learned", db_path=db, now=1001.0)
        assert r.get("skipped") and dna.get("style", db)["data"]["tone"]["value"] == "funny", "learned never overrides explicit"
        dna.set_pref("style", "tone", "calm", db_path=db, now=2000.0)
        assert dna.get("style", db)["data"]["tone"]["corrections"] == 1
        assert [h["version"] for h in dna.history("style", db)] == [3, 2, 1]
        d = dna.diff("style", 1, 3, db)
        assert d["added"] == ["pace"] and d["changed"] == {"tone": ["funny", "calm"]}
        # time machine
        day = 86400
        prev = dna.restore("style", 1, "o", db)
        assert prev["status"] == "PREVIEW" and dna.get("style", db)["version"] == 3, "preview must not change anything"
        y = dna.yesterday("style", db, now=1000.0 + day + 1)
        assert y["status"] == "PREVIEW" and y["restore_version"] == 2 and y["changed"] == {"tone": ["calm", "funny"]}, y
        assert dna.yesterday("style", db, now=500.0)["status"] == "NOTHING_TO_RESTORE"
        # priority: explicit request > DNA > default; stale detection
        res = dna.resolve("style", {"tone": "angry"}, {"tone": "x", "lang": "pa+hi+en"}, db)
        assert res["tone"] == {"value": "angry", "from": "explicit_request"} and res["lang"]["from"] == "default"
        assert dna.resolve("style", None, None, db)["pace"]["from"] == "dna:learned"
        assert dna.stale("style", db, now=1000.0) == ["pace"], "low-confidence learned value is stale"
        rs = dna.restore("style", 1, "o", db, confirm=True)
        assert rs["status"] == "RESTORED" and rs["new_version"] == 4 and dna.get("style", db)["data"]["tone"]["value"] == "funny"
        assert dna.get("style", db, version=3)["data"]["tone"]["value"] == "calm", "history is never erased"
        try:
            dna.restore("style", 99, "o", db)
            assert False
        except dna.DnaError:
            pass
        for bad in ("voice_face", "nope"):
            try:
                dna.get(bad, db)
                assert False
            except dna.DnaError:
                pass
        for bad_key in ("../x", "", "a b"):
            try:
                dna.set_pref("style", bad_key, 1, db_path=db)
                assert False
            except dna.DnaError:
                pass
        dna.learn("make reel", "ok", "shorter", "pace=fast", "owner", 0.7, db)
        assert dna.learn_log(db)[0]["task"] == "make reel"
    run_test("T57", "DNA vault + Time Machine: versions, diff, preview/restore, explicit>DNA>default, learned never overrides explicit, staleness", t_dna)

    def t_atma():
        d = tempfile.mkdtemp(prefix="kora-a-")
        cwd = os.getcwd()
        os.chdir(d)  # backups land in ./data/backups of this temp dir
        try:
            import kora.services.backup as B
            B.BACKUPS_DIR = os.path.join(d, "data", "backups")
            os.makedirs(B.BACKUPS_DIR, exist_ok=True)
            db = os.path.join(d, "live.db")
            init_db(db)
            assert atma.identity(db)["atma_id"] == atma.identity(db)["atma_id"]
            governance.create_proposal("DEPLOY_APP", "before", "HIGH", db_path=db)
            bk = B.create_verified_backup(db)
            assert atma.verify_restore_point(bk["backup_id"], db)["ok"]
            governance.create_proposal("DELETE_DATA", "after", "HIGH", db_path=db)
            assert len(governance.list_proposals(db)) == 2
            # failures first: unknown, missing file, corrupted, truncated, not a database
            assert atma.phoenix_restore("nope", "o", db)["reason"] == "unknown_backup"
            path = bk["path"]
            good = open(path, "rb").read()
            with open(path, "r+b") as f:
                f.seek(2000)
                f.write(b"CORRUPT!")
            r = atma.phoenix_restore(bk["backup_id"], "o", db)
            assert r["status"] == "REFUSED" and "hash_mismatch" in r["reason"], r
            open(path, "wb").write(good[: len(good) // 2])
            assert atma.phoenix_restore(bk["backup_id"], "o", db)["reason"].startswith("hash_mismatch"), "partial/truncated file"
            os.remove(path)
            assert atma.phoenix_restore(bk["backup_id"], "o", db)["reason"] == "file_missing"
            assert len(governance.list_proposals(db)) == 2 and not policy.is_safe_mode(db), "failed restores change nothing"
            # tampered record + valid sqlite but wrong hash
            open(path, "wb").write(good)
            conn = get_connection(db)
            conn.execute("UPDATE backups SET sha256='0'*1 WHERE id=?;", (bk["backup_id"],))
            conn.close()
            assert atma.phoenix_restore(bk["backup_id"], "o", db)["status"] == "REFUSED"
            conn = get_connection(db)
            conn.execute("UPDATE backups SET sha256=? WHERE id=?;", (bk["sha256"], bk["backup_id"]))
            conn.close()
            # real restore from the VERIFIED snapshot
            r = atma.phoenix_restore(bk["backup_id"], "o", db)
            assert r["status"] == "RESTORED_SAFE_MODE_ON" and os.path.exists(r["safety_copy"])
            assert [p["action"] for p in governance.list_proposals(db)] == ["DEPLOY_APP"], "state went back to the snapshot"
            assert policy.is_safe_mode(db) and DurableQueue(db).is_kill_switch_active(), "stays frozen until the owner resumes"
            safe = sqlite3.connect(r["safety_copy"])
            assert safe.execute("SELECT COUNT(*) FROM proposals;").fetchone()[0] == 2, "pre-restore state is preserved"
            safe.close()
        finally:
            os.chdir(cwd)
        # guardian + mission lock
        db2 = _db()
        assert atma.guardian_status(db2)["state"] == "NO_HEARTBEAT_YET"
        atma.heartbeat(db2, now=1000.0)
        assert atma.guardian_status(db2, 1800, now=1500.0)["state"] == "ONLINE" and atma.guardian_status(db2, 1800, now=9000.0)["state"] == "STALE"
        m = atma.mission_set("grow channel", ["10 videos", "1k subs"], db2)
        try:
            atma.mission_progress(m["id"], 0, "  ", db2)
            assert False, "evidence required"
        except ValueError:
            pass
        m = atma.mission_progress(m["id"], 0, "10 videos listed on channel page", db2)
        assert m["progress"] == {"done": 1, "total": 2} and m["status"] == "ACTIVE"
        assert atma.mission_progress(m["id"], 1, "analytics screenshot ref 123", db2)["status"] == "COMPLETE"
    run_test("T58", "ATMA/Phoenix: verified restore, corrupted/truncated/missing/tampered backup refused, safety copy, stays safe; guardian; mission evidence", t_atma)

    def t_shadow():
        db = _db()
        a = social.create_social_post("X", "Launch day! Big news", "GENERAL", db_path=db, auto_approve=False, env={})
        b = social.create_social_post("X", "  launch DAY!   big news ", "GENERAL", db_path=db, auto_approve=True, auto_publish=False, env={})
        assert b["preflight"] == "HUMAN_REVIEW" and b["status"] == "PENDING_APPROVAL", "duplicate content is held for review, never auto-approved"
        rep = shadow.preview_post(b["post_id"], db, env={})
        assert rep["status"] == "HUMAN REVIEW" and rep["duplicate_of"] == [a["post_id"]] and rep["read_only"] is True
        assert rep["estimated_performance"]["status"] == "UNAVAILABLE" and rep["estimated_performance"]["guarantee"] is False and rep["legal_guarantee"] is False
        assert rep["provenance_records"] >= 1
        c = social.create_social_post("X", "Totally unique text", "GENERAL", db_path=db, auto_approve=False, env={}, asset_meta={"rights": "OWNED", "source": "original"})
        r2 = shadow.preview_post(c["post_id"], db, env={})
        assert r2["status"] == "HUMAN REVIEW" and any(i.startswith("credentials_missing") for i in r2["issues"]), "no credentials => cannot be called PASS"
        r3 = shadow.preview_post(c["post_id"], db, env={"X_OAUTH2_USER_TOKEN": "t"})
        assert r3["status"] == "PASS", r3
        ig = social.create_social_post("INSTAGRAM", "hello ig", "GENERAL", db_path=db, auto_approve=False)
        assert any("credentials_missing" in i for i in shadow.preview_post(ig["post_id"], db)["issues"])
        assert shadow.preview_post("post-missing", db)["status"] == "NOT_FOUND"
        # read-only: writing through the shadow connection must fail; production unchanged
        c_ = shadow._ro(db)
        try:
            c_.execute("DELETE FROM social_posts;")
            assert False
        except sqlite3.OperationalError:
            pass
        c_.close()
        # isolated shadow copy for experiments
        before = len(social.list_posts(db))
        sp = shadow.clone_state(db)
        w = sqlite3.connect(sp)
        w.execute("DELETE FROM social_posts;")
        w.commit()
        w.close()
        assert len(social.list_posts(db)) == before, "production untouched"
        df = shadow.diff_counts(db, sp)
        assert df["differs"] and df["tables"]["social_posts"]["shadow"] == 0 and df["applied_to_production"] is False
        assert shadow.discard(sp) and not os.path.exists(sp)
        try:
            shadow.discard(db)
            assert False, "only shadow files may be discarded"
        except ValueError:
            pass
    run_test("T59", "ATMA Shadow + Shadow Publish: read-only preview, duplicate hold, truthful credentials/adapter status, no performance claim, isolated clone", t_shadow)

    def t_trust():
        db = _db()
        lv = trust.sync_skills(HANDLERS, db)
        assert lv["noop"] == "VERIFIED" and lv["social_publish"] == "VERIFIED"
        assert trust.get_trust("skill", "never-seen", db)["level"] == "UNKNOWN" and not trust.is_trusted("skill", "never-seen", db), "unknown is never trusted"

        @register_handler("t_unregistered_skill")
        def _h(p):
            return {"ok": True}
        assert trust.sync_skills(HANDLERS, db)["t_unregistered_skill"] == "UNKNOWN" and not trust.skill_runnable("t_unregistered_skill", db)
        # code change => SUSPICIOUS => not runnable until the owner re-approves
        trust.set_trust("skill", "noop", "VERIFIED", "deadbeef" * 8, "tampered baseline", "t", db)
        assert trust.sync_skills(HANDLERS, db)["noop"] == "SUSPICIOUS" and not trust.skill_runnable("noop", db)
        q = DurableQueue(db)
        gate = lambda n: trust.skill_runnable(n, db)
        j = q.enqueue("noop", {"x": 1})
        r = SafeWorker(q, "w1", skill_gate=gate).process_one()
        assert r["status"] == "FAILED" and r["error"] == "skill_not_trusted" and q.list_dead_letters(5)[0]["id"] == j["id"]
        assert trust.approve_skill("noop", HANDLERS, "owner", db) == "TRUSTED" and trust.skill_runnable("noop", db)
        q.requeue_dead_letter(j["id"])
        assert SafeWorker(q, "w2", skill_gate=gate).process_one()["status"] == "COMPLETED"
        trust.set_trust("skill", "noop", "BLOCKED", "", "x", "t", db)
        assert not trust.skill_runnable("noop", db)
        trust.record_provenance("file", "f1", source="user upload", tool="importer", license="CC0", rights="CC0", transformations="resize", verification="sha256 ok", version="1", db_path=db)
        assert trust.provenance_for("file", "f1", db)[0]["rights"] == "CC0"
        try:
            trust.set_trust("skill", "x", "SUPER", db_path=db)
            assert False
        except ValueError:
            pass
        assert all("permission" in s and "risk" in s for s in trust.list_skills({"noop": HANDLERS["noop"]}, db))
    run_test("T60", "Trust: unknown never trusted, skill hash change => SUSPICIOUS => gated worker refuses until owner approves; provenance", t_trust)

    def t_loop():
        db = _db()
        calls = []

        @register_handler("t_always_fails")
        def _bad(p):
            calls.append(1)
            raise RuntimeError("upstream exploded")
        q = DurableQueue(db, retry_base=0)
        w = SafeWorker(q, "w", loop_threshold=3)
        ids = [q.enqueue("t_always_fails", {"i": i}, max_retries=1)["id"] for i in range(5)]
        res = [w.process_one() for _ in range(5)]
        assert len(calls) == 3, f"3 distinct jobs failed identically -> operation frozen, got {len(calls)} runs"
        assert res[3]["error"] == "operation_frozen_after_repeated_errors" and anti_loop.is_frozen("t_always_fails", db)
        conn = get_connection(db)
        assert conn.execute("SELECT COUNT(*) FROM audit_events WHERE event_type='operation_frozen';").fetchone()[0] == 1, "logs preserved"
        conn.close()
        assert len(q.list_dead_letters(10)) == 5, "frozen jobs are visible in the DLQ, not lost"
        anti_loop.unfreeze("t_always_fails", "owner", db)
        j = q.enqueue("t_always_fails", {}, max_retries=1)
        w.process_one()
        assert len(calls) == 4, "after unfreeze the operation runs again"
        # one job retrying many times must NOT freeze by itself
        db2 = _db()
        q2 = DurableQueue(db2, retry_base=0)
        w2 = SafeWorker(q2, "w", loop_threshold=3)
        q2.enqueue("t_always_fails", {}, max_retries=6)
        for _ in range(6):
            w2.process_one()
        assert not anti_loop.is_frozen("t_always_fails", db2)
        # different errors never accumulate
        anti_loop.record_failure("opx", "a", db2, 3)
        anti_loop.record_failure("opx", "b", db2, 3)
        assert not anti_loop.record_failure("opx", "a", db2, 3) and not anti_loop.is_frozen("opx", db2)
        # recursion guard
        with anti_loop.DepthGuard(2):
            with anti_loop.DepthGuard(2):
                try:
                    with anti_loop.DepthGuard(2):
                        assert False
                except RecursionError:
                    pass
    run_test("T61", "Anti-loop: same error from 3 distinct jobs freezes the operation (logs kept, DLQ'd, owner unfreeze); retries alone don't; recursion cap", t_loop)

    def t_fusion():
        pages = {
            "https://a.university.edu/study": "Published 2025-03-02. The Zephyr battery retains 82 percent capacity after 500 charge cycles in laboratory testing of the Zephyr battery.",
            "https://nature.com/x": "Researchers report the Zephyr battery retains 82 percent capacity after 500 charge cycles, measured across cells.",
            "https://blog.example.com/p": "Our reviewer felt the Zephyr battery retains 40 percent capacity after 500 charge cycles in testing of the Zephyr battery.",
            "https://solo.example.org/p": "Zephyr battery retains 82 percent capacity after 500 charge cycles according to this article about the Zephyr battery.",
        }

        def fetch(u):
            if u not in pages:
                raise RuntimeError("403 paywall")
            return {"url": u, "title": "T " + u, "text": pages[u]}
        q = "Zephyr battery capacity after 500 charge cycles"
        r = fusion.deep_research(q, ["https://a.university.edu/study", "https://nature.com/x"], fetch=fetch, now=1_760_000_000.0)
        assert r["status"] == "VERIFIED" and r["independent_domains"] == 2 and r["evidence_origin"] == "fresh_web" and r["stored_knowledge_used"] is False
        assert [x["url"] for x in r["references"]] == [s["url"] for s in r["sources"]] and all(x["fetched_at"] for x in r["references"])
        assert r["sources"][0]["date"] == "2025-03-02" or any(s["date"] == "2025-03-02" for s in r["sources"])
        r = fusion.deep_research(q, ["https://a.university.edu/study", "https://blog.example.com/p"], fetch=fetch)
        assert r["status"] == "UNCERTAIN" and r["contradictions"], "different numbers on the same claim => contradiction, never VERIFIED"
        r = fusion.deep_research(q, ["https://solo.example.org/p"], fetch=fetch)
        assert r["status"] == "UNCERTAIN" and r["confidence"] < 0.5, "one source is never VERIFIED"
        r = fusion.deep_research(q, ["https://solo.example.org/p", "https://blocked.example.com/x"], fetch=fetch)
        assert r["failed_sources"] and r["failed_sources"][0]["url"].endswith("/x") and all("blocked" not in x["url"] for x in r["references"]), "failed pages are reported, never cited"
        r = fusion.deep_research(q, search=lambda s: {"ok": False, "status": "CONFIGURATION_REQUIRED", "error": "no key"}, fetch=fetch)
        assert r["status"] == "UNAVAILABLE" and r["references"] == [] and r["search"] == "CONFIGURATION_REQUIRED"
        found = fusion.deep_research(q, search=lambda s: {"ok": True, "status": "OK", "results": [{"url": "https://a.university.edu/study"}, {"url": "https://nature.com/x"}]}, fetch=fetch)
        assert found["status"] == "VERIFIED" and found["search"] == "OK"
        assert fusion.source_class("cs.stanford.edu") == "OFFICIAL_OR_UNIVERSITY" and fusion.source_class("www.nature.com") == "ACADEMIC" and fusion.source_class("random.com") == "OTHER"
        assert fusion.find_date("on March 5, 2024 we") == "2024-03-05" and fusion.find_date("no date") is None
        # science lab never invents experiments
        sci = fusion.science_report("Zephyr keeps 82% capacity", found, {"values": [80.0, 82.0, 84.0]})
        assert sci["experiments_run"] == [] and sci["simulation"] == "NOT_RUN" and sci["calculation"]["mean"] == 82.0 and "not measured by KORA" in sci["calculation"]["provenance"]
        weak = fusion.science_report("x", {"status": "UNCERTAIN", "references": []})
        assert "no conclusion supported" in weak["conclusion"]
        for bad in ({"values": []}, {"values": ["a"]}):
            try:
                fusion.science_report("h", found, bad)
                assert False
            except ValueError:
                pass
        try:
            fusion.deep_research("", ["https://x.com"], fetch=fetch)
            assert False
        except ValueError:
            pass
    run_test("T62", "Deep research: cross-check, contradictions, source quality, dates, only fetched sources cited, UNAVAILABLE without evidence; Science Lab never invents data", t_fusion)

    def t_providers():
        from kora.services import ai_failover as A
        A.reset_breakers()
        st = {s["provider"]: s["state"] for s in A.provider_states({})}
        assert st["gemini"] == "UNAVAILABLE" and st["local_deterministic_fallback"] == "AVAILABLE"
        st = {s["provider"]: s["state"] for s in A.provider_states({"GEMINI_API_KEY": "k", "OPENROUTER_API_KEY": "k"})}
        assert st["gemini"] == "CONFIGURED" and st["openrouter"] == "CONFIGURED_NOT_IMPLEMENTED"
        clock = [1000.0]

        def tr429(m, u, h, b, t):
            return 429, {}, b"{}"
        for _ in range(3):
            A.query_ai_model("hi", env={"GROQ_API_KEY": "k"}, transport=tr429, clock=lambda: clock[0])
        assert {s["provider"]: s["state"] for s in A.provider_states({"GROQ_API_KEY": "k"}, clock=lambda: clock[0])}["groq"] == "RATE_LIMITED"
        A.reset_breakers()
        ok = lambda m, u, h, b, t: (200, {}, json.dumps({"choices": [{"message": {"content": "hello"}}]}).encode())
        res = A.query_ai_model("hi", env={"GROQ_API_KEY": "k"}, transport=ok)
        assert res["provider"] == "groq" and {s["provider"]: s["state"] for s in A.provider_states({"GROQ_API_KEY": "k"})}["groq"] == "HEALTHY"
        # failed provider => labelled local fallback, never a fake provider answer
        A.reset_breakers()
        bad = A.query_ai_model("hi", env={"GROQ_API_KEY": "k"}, transport=lambda *a: (500, {}, b""))
        assert bad["provider"] == "local_deterministic_fallback" and bad["errors"]
        A.reset_breakers()
    run_test("T63", "Provider router states: UNAVAILABLE/CONFIGURED/HEALTHY/RATE_LIMITED, not-implemented honesty, failed provider => labelled fallback", t_providers)

    def t_ledger():
        db = _db()
        a = dhanda.add_entry("revenue", 100, "ad payout", db_path=db, evidence="receipt#1", source="youtube-api", fees=10)
        b = dhanda.add_entry("revenue", 50, "paid out", db_path=db, evidence="receipt#2", source="youtube-api", payout_ref="PAY-9")
        c = dhanda.add_entry("revenue", 999, "i earned this", db_path=db)
        d = dhanda.add_entry("revenue", 500, "projection", db_path=db, estimated=True)
        e = dhanda.add_entry("cost", 20, "stock footage", db_path=db, evidence="invoice 5")
        assert (a["status"], b["status"], c["status"], d["status"], e["status"]) == ("VERIFIED", "PAYOUT_RECEIVED", "UNVERIFIED_ESTIMATE", "ESTIMATE", "VERIFIED")
        assert c["warning"] and c["estimated"]
        s = dhanda.summary(db)["USD"]
        assert s["actual_revenue"] == 150 and s["actual_fees"] == 10 and s["actual_cost"] == 20 and s["actual_net_profit"] == 120
        assert s["estimated_revenue"] == 1499, "unverified claims never enter actual profit"
        for bad in (("revenue", 0, "x"), ("revenue", -5, "x"), ("gift", 5, "x"), ("cost", 5, " ")):
            try:
                dhanda.add_entry(*bad, db_path=db)
                assert False, bad
            except ValueError:
                pass
        try:
            dhanda.add_entry("revenue", 10, "x", db_path=db, evidence="e", source="s", fees=11)
            assert False
        except ValueError:
            pass
        good = {"opportunity": .8, "demand": .7, "competition": .4, "effort": .3, "cost": .2, "risk": .2, "monetization": .6}
        no_ev = dhanda.score(good)
        two = dhanda.score({**good, "evidence": ["trend report", "search volume"]})
        assert no_ev["confidence"] <= 0.1 and no_ev["status"] == "UNCERTAIN" and two["status"] == "SOURCE_BASED" and two["guaranteed_income"] is False and two["label"] == "ESTIMATE"
        assert dhanda.rank([{"name": "a", **good}, {"name": "b", **good, "evidence": ["x", "y", "z"]}])[0]["name"] == "b"
        try:
            dhanda.score({**good, "risk": 2})
            assert False
        except ValueError:
            pass
    run_test("T64", "Dhanda ledger + revenue verifier: ESTIMATE/UNVERIFIED/VERIFIED/PAYOUT_RECEIVED, net profit from verified only, scoring capped by evidence", t_ledger)

    def t_ops():
        db = _db()
        now = time.time()
        governance.checkpoint_save("old", {"a": 1}, db)
        conn = get_connection(db)
        conn.execute("UPDATE checkpoints SET updated_at=?;", (now - 40 * 86400,))
        conn.close()
        governance.checkpoint_save("new", {"a": 1}, db)
        pid = governance.create_proposal("DEPLOY_APP", "x", "HIGH", db_path=db)
        governance.decide(pid, False, "o", db)
        conn = get_connection(db)
        conn.execute("UPDATE proposals SET created_at=?;", (now - 100 * 86400,))
        conn.close()
        keep = governance.create_proposal("DEPLOY_APP", "pending stays", "HIGH", db_path=db)
        sd = os.path.join(os.path.dirname(db), "shadow")
        os.makedirs(sd)
        old = os.path.join(sd, "old.db")
        open(old, "w").write("x")
        os.utime(old, (now - 9 * 86400, now - 9 * 86400))
        n = ops.lifecycle(db, now=now)
        assert n["checkpoints"] == 1 and n["proposals_done"] == 1 and n["shadow_files"] == 1, n
        assert governance.checkpoint_load("old", db) is None and governance.checkpoint_load("new", db) == {"a": 1}
        assert [p["id"] for p in governance.list_proposals(db)] == [keep], "pending approvals are protected"
        # flags
        assert ops.flag_get("experimental_voice", db) is False and ops.flag_get("shadow_publish_required", db) is True
        ops.flag_set("experimental_voice", True, "o", db)
        assert ops.flags(db)["experimental_voice"] is True
        try:
            ops.flag_set("made_up", True, "o", db)
            assert False
        except KeyError:
            pass
        # notifications grouped
        for _ in range(5):
            ops.notify("IMPORTANT", "dlq", "jobs failing", db, now=100.0)
        ops.notify("CRITICAL", "audit", "tamper", db, now=101.0)
        ns = ops.notifications(db)
        assert len(ns) == 2 and ns[0]["level"] == "CRITICAL" and [x for x in ns if x["key"] == "dlq"][0]["count"] == 5
        ops.notify("IMPORTANT", "dlq", "later", db, now=100.0 + 7200)
        assert len(ops.notifications(db)) == 3, "outside the grouping window -> new entry"
        # measured resources
        r = ops.resources(db)
        assert r["process_max_rss_mb"] > 0 and r["disk_free_mb"] > 0 and r["db_size_mb"] >= 0
        # export excludes secrets
        identity.totp_enroll(db)
        identity.create_principal("p", "user", db_path=db)
        dna.set_pref("style", "tone", "calm", db_path=db)
        z = os.path.join(os.path.dirname(db), "e.zip")
        ops.export_zip(db, z)
        with zipfile.ZipFile(z) as zf:
            names = zf.namelist()
            blob = b"".join(zf.read(x) for x in names)
        assert "dna_versions.json" in names and "MANIFEST.json" in names and "principals.json" not in names
        assert b"owner_totp_secret" not in blob and b"token_hash" not in blob
        # controlled deletion
        assert ops.delete_user_data(db, "yes", "o")["status"] == "CONFIRMATION_REQUIRED" and dna.get("style", db)["version"] == 1
        out = ops.delete_user_data(db, "MERA DATA DELETE KAR", "o")
        assert out["status"] == "DELETED_FROM_LIVE_DB" and out["rows_deleted"]["dna_versions"] == 1 and dna.get("style", db)["version"] == 0
        assert "backups_still_containing_data" in out["not_deleted"]
        assert "NOT deleted" in out["note"]
        conn = get_connection(db)
        assert conn.execute("SELECT COUNT(*) FROM audit_events WHERE event_type='user_data_deleted';").fetchone()[0] == 1
        conn.close()
    run_test("T65", "Ops: lifecycle protects pending data, feature flags, grouped notifications, measured resources, export w/o secrets, confirmed deletion with proof", t_ops)

    def t_audit_migrate():
        db = _db()
        for i in range(5):
            record_audit("e", "a", {"i": i, "password": "hunter2"}, db)
        assert verify_audit_chain(db)["ok"]
        conn = get_connection(db)
        assert "hunter2" not in "".join(r[0] for r in conn.execute("SELECT details FROM audit_events;")), "secrets never logged"
        conn.close()
        for tamper, expect in (("UPDATE audit_events SET actor='evil' WHERE id=(SELECT MIN(id)+2 FROM audit_events WHERE hash IS NOT NULL);", "row_modified"),):
            c = get_connection(db)
            c.execute(tamper)
            c.close()
            r = verify_audit_chain(db)
            assert not r["ok"] and r["reason"] == expect, r
        db2 = _db()
        for i in range(6):
            record_audit("e", "a", {"i": i}, db2)
        c = get_connection(db2)
        c.execute("DELETE FROM audit_events WHERE id=(SELECT MIN(id)+3 FROM audit_events WHERE hash IS NOT NULL);")
        c.close()
        r = verify_audit_chain(db2)
        assert not r["ok"] and r["reason"] == "chain_link_mismatch_or_row_deleted"
        # safe migration
        d = _db()
        c = get_connection(d)
        c.execute("INSERT INTO settings(key,value,updated_at) VALUES ('sentinel','keep',1);")
        c.close()

        def bad_migrate(path):
            cc = sqlite3.connect(path, isolation_level=None)
            cc.execute("INSERT INTO settings(key,value,updated_at) VALUES ('half','done',1);")
            cc.execute("DROP TABLE jobs;")  # destructive half-migration
            cc.close()
            raise RuntimeError("migration crashed")
        r = ops.migrate_safely(d, bad_migrate)
        assert r["status"] == "ROLLED_BACK" and os.path.exists(r["backup"])
        c = get_connection(d)
        assert c.execute("SELECT value FROM settings WHERE key='sentinel';").fetchone()[0] == "keep"
        assert c.execute("SELECT COUNT(*) FROM settings WHERE key='half';").fetchone()[0] == 0, "half-applied migration rolled back"
        c.execute("SELECT COUNT(*) FROM jobs;")
        c.close()
        r = ops.migrate_safely(d)
        assert r["status"] == "MIGRATED"
        junk = os.path.join(tempfile.mkdtemp(), "junk.db")
        open(junk, "wb").write(b"not sqlite at all" * 50)
        try:
            r = ops.migrate_safely(junk)
            assert r["status"] == "REFUSED"
        except sqlite3.DatabaseError:
            pass  # refusing by raising is also acceptable: nothing was touched
        assert open(junk, "rb").read().startswith(b"not sqlite")
        assert ops.migrate_safely(os.path.join(tempfile.mkdtemp(), "new.db"))["status"] == "CREATED"
    run_test("T66", "Audit hash chain detects edit/delete, secrets never logged; migration backs up, validates and rolls back a crashed migration", t_audit_migrate)

    def t_consent():
        db = _db()
        base = dict(adult=True, explicit_permission=True, live_confirmation=True)
        assert voice_consent.record_consent("me", "voice", adult=False, explicit_permission=True, live_confirmation=True, totp_code="1", db_path=db)["reason"] == "child_voice_or_face_never_allowed"
        assert voice_consent.record_consent("me", "voice", **base, totp_code="123456", db_path=db)["status"] == "REFUSED", "no 2FA enrolled/valid"
        sec = identity.totp_enroll(db)["secret"]
        t = 1_900_000_000.0
        assert voice_consent.record_consent("me", "voice", adult=True, explicit_permission=False, live_confirmation=True, totp_code="1", db_path=db)["status"] == "REFUSED"
        assert voice_consent.record_consent("me", "clone", **base, totp_code="1", db_path=db)["status"] == "REFUSED"
        ok = voice_consent.record_consent("me", "voice", **base, totp_code=identity._code(sec, int(time.time() // 30)), db_path=db)
        assert ok["status"] == "RECORDED" and "no voice/face cloning" in ok["note"]
        assert voice_consent.has_consent("me", "voice", db) and not voice_consent.has_consent("me", "face", db) and not voice_consent.has_consent("someone else", "voice", db)
    run_test("T67", "Voice/face consent: child refused, explicit+live+OTP required, consent record only (no cloning capability)", t_consent)

    def t_bridge_identity():
        from kora.bridge.api import KoraApp
        d = tempfile.mkdtemp()
        s = replace(load_settings({}, dotenv_path="/nonexistent"), auth_token="owner-tok-123", db_path=os.path.join(d, "b.db"), rate_write_per_min=1000,
                    rate_read_per_min=1000, rate_heavy_per_min=1000, cron_enabled=False, worker_poll_seconds=0.05)
        app = KoraApp(s)
        OH = {"Authorization": "Bearer owner-tok-123"}

        def raw(method, path, body=None, headers=OH, peer="203.0.113.9"):
            b = json.dumps(body).encode() if body is not None else b""
            env = {"REQUEST_METHOD": method, "PATH_INFO": path, "REMOTE_ADDR": peer, "HTTP_HOST": "127.0.0.1:8000", "wsgi.input": io.BytesIO(b),
                   "CONTENT_LENGTH": str(len(b)) if b else "", "CONTENT_TYPE": "application/json" if b else ""}
            for k, v in (headers or {}).items():
                env["HTTP_" + k.upper().replace("-", "_")] = v
            out = {}
            data = b"".join(app(env, lambda st, h: out.update(status=int(st.split()[0]), headers=dict(h))))
            return out["status"], data, out["headers"]

        def call(*a, **k):
            st, data, _ = raw(*a, **k)
            return st, json.loads(data)
        # owner creates a user; user sees only what is granted
        st, u = call("POST", "/api/principals", {"name": "alice", "role": "user"})
        assert st == 201 and u["token"]
        UH = {"Authorization": "Bearer " + u["token"]}
        assert call("GET", "/api/rag/stats", headers=UH)[0] == 403, "no grant yet"
        assert call("GET", "/api/principals", headers=UH)[1]["error"] == "owner_only"
        assert call("GET", "/api/active", headers=UH)[0] == 403 and call("POST", "/api/killswitch", {"active": True}, headers=UH)[0] == 403
        g = call("POST", f"/api/principals/{u['id']}/grant", {"permission": "READ_LOCAL_FILE", "ttl_seconds": 1})
        assert g[0] == 201
        assert call("GET", "/api/rag/stats", headers=UH)[0] == 200
        time.sleep(1.3)
        assert call("GET", "/api/rag/stats", headers=UH)[1]["error"] == "permission_not_granted_or_expired", "temporary permission expired"
        g2 = call("POST", f"/api/principals/{u['id']}/grant", {"permission": "READ_LOCAL_FILE"})[1]
        assert call("GET", "/api/rag/stats", headers=UH)[0] == 200
        assert call("POST", f"/api/grants/{g2['grant_id']}/revoke")[0] == 200 and call("GET", "/api/rag/stats", headers=UH)[0] == 403, "instant revoke"
        assert call("POST", f"/api/principals/{u['id']}/grant", {"permission": "CHANGE_SECURITY"})[0] == 400
        assert call("POST", f"/api/principals/{u['id']}/grant", {"permission": "BYPASS_AUTH"})[0] == 400
        # the user can use the Brain but only within its grants (same permission engine)
        assert call("POST", "/api/brain", {"text": "attack cats"}, headers=UH)[1]["status"] == "DENIED"
        assert call("POST", "/api/brain", {"text": "status"}, headers=UH)[1]["status"] == "OK"
        # revoked principal's token stops working at once
        call("POST", f"/api/principals/{u['id']}/grant", {"permission": "READ_LOCAL_FILE"})
        assert call("GET", "/api/rag/stats", headers=UH)[0] == 200
        assert call("POST", f"/api/principals/{u['id']}/revoke")[0] == 200 and call("GET", "/api/rag/stats", headers=UH)[0] == 403
        assert call("GET", "/api/principals", headers={"Authorization": "Bearer nope"})[0] == 403
        # step-up: owner enrols TOTP, then sensitive routes need a fresh code header
        sec = call("POST", "/api/security/totp", {})[1]["secret"]
        assert call("GET", "/api/security")[1]["totp_enrolled"] is True
        assert call("POST", "/api/malak", {"key": "tone", "value": "formal"})[1]["error"] == "step_up_required"
        c1 = identity._code(sec, int(time.time() // 30))
        st, r = call("POST", "/api/malak", {"key": "tone", "value": "formal"}, headers={**OH, "X-Kora-Totp": c1})
        assert st == 200, r
        assert call("POST", "/api/malak", {"key": "tone", "value": "casual"}, headers={**OH, "X-Kora-Totp": c1})[1]["error"] == "step_up_required", "replay refused"
        assert call("POST", "/api/killswitch", {"active": True})[0] == 200, "turning protection ON never needs a code"
        assert call("POST", "/api/killswitch", {"active": False})[1]["error"] == "step_up_required", "lifting it does"
        # DNA time machine over the API: preview is free, applying needs step-up
        assert call("POST", "/api/dna", {"kind": "style", "key": "tone", "value": "a"})[0] == 201
        assert call("POST", "/api/dna", {"kind": "style", "key": "tone", "value": "b"})[0] == 201
        assert call("POST", "/api/dna/restore", {"kind": "style", "version": 1})[1]["status"] == "PREVIEW"
        assert call("POST", "/api/dna/restore", {"kind": "style", "version": 1, "confirm": True})[1]["error"] == "step_up_required"
        assert call("GET", "/api/dna/style")[1]["version"] == 2 and call("GET", "/api/dna/voice_face")[0] == 400
        # export is a real ZIP; audit chain endpoint; providers; ops
        st, data, hdr = raw("GET", "/api/data/export")
        assert st == 200 and hdr["Content-Type"] == "application/zip" and zipfile.ZipFile(io.BytesIO(data)).testzip() is None
        assert call("GET", "/api/audit/verify")[1]["ok"] is True
        assert any(p["provider"] == "local_deterministic_fallback" for p in call("GET", "/api/providers")[1]["items"])
        assert call("GET", "/api/ops")[1]["resources"]["disk_free_mb"] > 0
        assert call("POST", "/api/data/delete", {"confirm": "nope"}, headers={**OH, "X-Kora-Totp": identity._code(sec, int(time.time() // 30) + 1)})[0] == 400
        # every new route needs auth
        for m, p in (("GET", "/api/security"), ("GET", "/api/atma"), ("GET", "/api/skills"), ("POST", "/api/brain"), ("POST", "/api/autopost"), ("GET", "/api/ops")):
            assert call(m, p, {} if m == "POST" else None, headers=None, peer="198.51.100.%d" % len(p))[0] == 403, p
        sk = call("GET", "/api/skills")
        assert sk[0] == 200 and sk[1]["items"], sk
    run_test("T68", "Bridge identity E2E: roles, temporary/revoked grants, owner-only routes, step-up (replay-proof), DNA time machine, export ZIP, auth on all new routes", t_bridge_identity)

    def t_perf():
        db = _db()
        t0 = time.perf_counter()
        brain.handle("ho ja shuru", principal=OWNER, db_path=db)
        t_status = time.perf_counter() - t0
        social.create_social_post("X", "perf post", "GENERAL", db_path=db, auto_approve=False, env={})
        pid = social.list_posts(db)[0]["id"]
        t0 = time.perf_counter()
        shadow.preview_post(pid, db, env={})
        t_shadow = time.perf_counter() - t0
        brain.set_voice(True, "o", db)
        t0 = time.perf_counter()
        brain.handle("status", principal=OWNER, source="voice", db_path=db, voice_verified=True)
        t_voice = time.perf_counter() - t0
        print(f"      measured: brain status {t_status * 1000:.1f} ms, voice command {t_voice * 1000:.1f} ms, shadow preview {t_shadow * 1000:.1f} ms (server-side only; no STT/TTS/network)")
        assert t_status < 2.0 and t_voice < 3.0 and t_shadow < 2.0
    run_test("T69", "Performance (measured, server-side): brain/voice-command/shadow-preview under their targets", t_perf)
