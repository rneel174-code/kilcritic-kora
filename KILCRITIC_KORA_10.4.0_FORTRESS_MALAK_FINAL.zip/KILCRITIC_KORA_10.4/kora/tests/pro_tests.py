"""KORA PRO behavioural tests T23+ (the original T01-T22 live in run_all.py and are unchanged).
Everything runs against real SQLite files in a temp dir. Network calls use an injected fake transport: those tests verify
request/response handling and state machines, NOT live platform/provider behaviour (that stays UNVERIFIED without credentials)."""
import io
import json
import os
import tempfile
import threading
import time
import urllib.request
from dataclasses import replace

from kora.config.settings import Settings, load_settings
from kora.core import scheduler
from kora.core.auth import Authenticator
from kora.core.db import get_connection, init_db
from kora.core.logger import JsonFormatter, redact_text
from kora.core.queue import (DurableQueue, IdempotencyConflictException, KillSwitchActiveException,
                             PermanentJobError, QueueCapacityExceededException)
from kora.core.ratelimit import RateLimiter
from kora.core.worker import HANDLERS, SafeWorker, WorkerPool, register_handler


def _db():
    d = tempfile.mkdtemp(prefix="kora-t-")
    p = os.path.join(d, "t.db")
    init_db(p)
    return p


class Clock:
    def __init__(self, t=1_000_000.0):
        self.t = t

    def __call__(self):
        return self.t


def register(run_test):
    calls = {}

    @register_handler("t_fail")
    def _fail(payload):
        raise RuntimeError("boom")

    @register_handler("t_perm")
    def _perm(payload):
        raise PermanentJobError("bad input")

    @register_handler("t_count")
    def _count(payload):
        calls[payload["n"]] = calls.get(payload["n"], 0) + 1
        return {"ok": True, "n": payload["n"]}

    @register_handler("t_sleep")
    def _sleep(payload):
        time.sleep(payload.get("s", 2))
        return {"ok": True}

    @register_handler("t_badresult")
    def _bad(payload):
        return "not a dict"

    @register_handler("t_okfalse")
    def _okf(payload):
        return {"ok": False, "error": "handler says no"}

    # ---- retry / backoff
    def t_retry_backoff():
        clk = Clock()
        q = DurableQueue(_db(), retry_base=10, retry_max=100, rng=lambda: 1.0, clock=clk)
        q.enqueue("t_fail", {}, max_retries=3)
        w = SafeWorker(q, "w1")
        r = w.process_one()
        assert r["status"] == "QUEUED", r
        assert q.claim_next_job("w1") is None, "must not be claimable before backoff elapses"
        clk.t += 9
        assert q.claim_next_job("w1") is None
        clk.t += 2  # 10s base * 2^0 * jitter(1.0) = 10s
        j = q.claim_next_job("w1")
        assert j and j["attempts"] == 2, j
    run_test("T23", "Retry with Exponential Backoff (job not claimable until due)", t_retry_backoff)

    # ---- DLQ
    def t_dlq():
        q = DurableQueue(_db(), retry_base=0)
        job = q.enqueue("t_fail", {}, max_retries=2)
        w = SafeWorker(q, "w1")
        assert w.process_one()["status"] == "QUEUED"
        assert w.process_one()["status"] == "DEAD_LETTER"
        dl = q.list_dead_letters()
        assert len(dl) == 1 and dl[0]["id"] == job["id"] and "boom" in dl[0]["error"]
        assert q.get_stats()["DEAD_LETTER"] == 1
        assert q.requeue_dead_letter(job["id"]) is True
        assert q.get_job(job["id"])["attempts"] == 0
        assert q.requeue_dead_letter(job["id"]) is False, "only dead letters can be requeued"
    run_test("T24", "Dead-Letter Queue: exhaust -> DLQ -> operator requeue", t_dlq)

    def t_permanent():
        q = DurableQueue(_db(), retry_base=0)
        q.enqueue("t_perm", {}, max_retries=5)
        q.enqueue("never_registered_handler", {}, max_retries=5, priority=-1)
        w = SafeWorker(q, "w1")
        assert w.process_one()["status"] == "DEAD_LETTER", "PermanentJobError must skip retries"
        assert w.process_one()["status"] in ("FAILED", "DEAD_LETTER")
        assert q.get_stats()["DEAD_LETTER"] == 2
        q.enqueue("t_badresult", {}, max_retries=5)
        assert w.process_one()["status"] == "DEAD_LETTER", "non-dict handler result must not count as success"
        q.enqueue("t_okfalse", {}, max_retries=1)
        r = w.process_one()
        assert r["status"] == "DEAD_LETTER" and "handler says no" in r["error"], r
    run_test("T25", "Permanent Errors, Unregistered Handlers & Result Validation -> DLQ", t_permanent)

    def t_lease_recovery():
        clk = Clock()
        q = DurableQueue(_db(), retry_base=0, clock=clk)
        a = q.enqueue("noop", {}, max_retries=3)
        b = q.enqueue("noop", {}, max_retries=1, priority=-1)
        q.claim_next_job("dead-worker", 30)
        q.claim_next_job("dead-worker", 30)
        clk.t += 31
        assert q.recover_stale_leases() == 2
        assert q.get_job(a["id"])["status"] == "QUEUED"
        assert q.get_job(b["id"])["status"] == "DEAD_LETTER", "exhausted attempts + expired lease must dead-letter"
    run_test("T26", "Stale Lease Recovery (requeue vs dead-letter on exhausted attempts)", t_lease_recovery)

    def t_ownership():
        q = DurableQueue(_db(), retry_base=0)
        q.enqueue("noop", {})
        j = q.claim_next_job("owner")
        assert q.fail_job(j["id"], "intruder", "x") == "NOT_OWNER"
        assert q.complete_job(j["id"], "intruder", {"ok": True}) is False
        assert q.complete_job(j["id"], "owner", {"ok": True}, version=j["version"] + 5) is False, "stale fencing version"
        assert q.complete_job(j["id"], "owner", {"ok": True}, version=j["version"]) is True
        assert q.fail_job(j["id"], "owner", "late") == "NOT_OWNER", "completed job cannot be failed"
    run_test("T27", "Job Ownership & Version Fencing (no stale-worker overwrite)", t_ownership)

    def t_competing():
        path = _db()
        q0 = DurableQueue(path)
        n = 60
        for i in range(n):
            q0.enqueue("t_count", {"n": i})
        calls.clear()
        done = []

        def run(idx):
            w = SafeWorker(DurableQueue(path), f"c{idx}")
            while True:
                r = w.process_one()
                if r is None:
                    return
                done.append(r["job_id"])

        ts = [threading.Thread(target=run, args=(i,)) for i in range(4)]
        [t.start() for t in ts]
        [t.join(60) for t in ts]
        assert len(done) == n and len(set(done)) == n, f"{len(done)} processed / {len(set(done))} unique"
        assert all(v == 1 for v in calls.values()) and len(calls) == n, "a job ran more than once"
        assert q0.get_stats()["COMPLETED"] == n
    run_test("T28", "Competing Workers: 4 threads, 60 jobs, exactly-once execution", t_competing)

    def t_timeout_cancel():
        q = DurableQueue(_db(), retry_base=0)
        j = q.enqueue("t_sleep", {"s": 2}, max_retries=1)
        w = SafeWorker(q, "w1", job_timeout=0.4, lease_seconds=3)
        t0 = time.time()
        r = w.process_one()
        assert time.time() - t0 < 1.8, "worker must not wait for the slow handler"
        assert r["status"] == "DEAD_LETTER" and "timeout" in r["error"], r
        # cancellation of a running job
        j2 = q.enqueue("t_sleep", {"s": 2}, max_retries=3)
        w2 = SafeWorker(q, "w2", job_timeout=5, lease_seconds=0.3)
        threading.Timer(0.3, lambda: q.cancel_job(j2["id"])).start()
        r2 = w2.process_one()
        assert r2["status"] == "CANCELLED", r2
        assert q.get_job(j2["id"])["status"] == "CANCELLED"
        time.sleep(2.2)  # abandoned threads finish; their late results must be discarded
        assert q.get_job(j["id"])["status"] == "DEAD_LETTER" and q.get_job(j2["id"])["status"] == "CANCELLED"
    run_test("T29", "Job Timeout & Cancellation (late results discarded)", t_timeout_cancel)

    def t_killswitch_capacity_idem():
        path = _db()
        q = DurableQueue(path, max_capacity=2)
        q.enqueue("noop", {})
        q.enqueue("noop", {})
        try:
            q.enqueue("noop", {})
            assert False, "capacity must be enforced"
        except QueueCapacityExceededException:
            pass
        DurableQueue(path).set_kill_switch(True)
        other = DurableQueue(path)  # a DIFFERENT instance must see the persisted switch
        assert other.is_kill_switch_active() is True
        try:
            other.enqueue("noop", {})
            assert False
        except KillSwitchActiveException:
            pass
        assert other.claim_next_job("w") is None
        DurableQueue(path).set_kill_switch(False)
        assert DurableQueue(path).is_kill_switch_active() is False
        q2 = DurableQueue(_db())
        a = q2.enqueue_once("noop", {}, "same-key")
        b = q2.enqueue_once("noop", {}, "same-key")
        assert a["duplicate"] is False and b["duplicate"] is True and a["id"] == b["id"]
    run_test("T30", "Durable Kill-Switch, Capacity Limit & enqueue_once Dedup", t_killswitch_capacity_idem)

    def t_pool():
        path = _db()
        q = DurableQueue(path)
        for i in range(10):
            q.enqueue("noop", {"i": i})
        pool = WorkerPool(path, size=3, poll_seconds=0.05)
        pool.start()
        end = time.time() + 10
        while time.time() < end and q.get_stats()["COMPLETED"] < 10:
            time.sleep(0.05)
        assert pool.stop(5) is True, "pool must stop cleanly"
        assert q.get_stats()["COMPLETED"] == 10 and pool.status()["running"] is False
        pool.start()  # restartable
        assert pool.status()["running"] is True
        pool.stop(5)
    run_test("T31", "Worker Pool Start / Drain / Clean Stop / Restart", t_pool)

    # ---- cron
    def t_cron():
        assert scheduler.next_run("*/15 * * * *", 0) == 900
        assert scheduler.next_run("30 2 * * *", 0) == 2 * 3600 + 30 * 60
        assert scheduler.next_run("@every 90s", 100) == 190
        for bad in ("* * * *", "61 * * * *", "*/0 * * * *", "a b c d e", "5-1 * * * *"):
            try:
                scheduler.validate_schedule(bad)
                assert False, bad
            except scheduler.CronError:
                pass
        path = _db()
        base = 1_700_000_000.0
        info = scheduler.add_cron_job("nightly", "*/5 * * * *", "noop", {"x": 1}, db_path=path, now=base)
        later = base + 3600  # an hour of missed slots
        f1 = scheduler.tick(path, now=later)
        assert len(f1) == 1 and f1[0]["job_id"], f1
        assert scheduler.tick(path, now=later) == [], "slot already fired; must not fire again"
        q = DurableQueue(path)
        assert q.get_stats()["QUEUED"] == 1, "missed slots must coalesce into ONE run"
        # two competing schedulers on the same slot -> single job
        scheduler.add_cron_job("race", "* * * * *", "noop", db_path=path, now=base)
        res = []
        ts = [threading.Thread(target=lambda: res.append(scheduler.tick(path, now=base + 120))) for _ in range(4)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        assert sum(1 for r in res for f in r if f["name"] == "race" and f["job_id"]) == 1
        try:
            scheduler.add_cron_job("nightly", "* * * * *", "noop", db_path=path)
            assert False
        except scheduler.CronError:
            pass
    run_test("T32", "Cron: parsing, coalesced misfires, multi-scheduler exactly-once", t_cron)

    # ---- auth / ratelimit / logger / settings
    def t_auth():
        a = Authenticator("tok-123456", trust_proxy=False)
        assert a.check("127.0.0.1", {})[0] is True
        assert a.check("203.0.113.9", {})[:2] == (False, 403)
        assert a.check("203.0.113.9", {"authorization": "Bearer tok-123456"})[0] is True
        assert a.check("127.0.0.1", {"authorization": "Bearer wrong"})[:2] == (False, 403), "wrong token rejected even locally"
        assert a.check("203.0.113.9", {"x-forwarded-for": "127.0.0.1"})[:2] == (False, 403), "XFF spoof must be ignored"
        none = Authenticator("")
        assert none.check("203.0.113.9", {"authorization": "Bearer x"})[0] is False
        assert Authenticator("t", require_local=True).check("127.0.0.1", {})[0] is False
        th = Authenticator("tok-123456", max_fail=3)
        for _ in range(3):
            th.check("198.51.100.5", {"authorization": "Bearer bad"})
        assert th.check("198.51.100.5", {"authorization": "Bearer tok-123456"})[1] == 429, "brute force throttled"
    run_test("T33", "Auth: bearer, loopback, XFF-spoof, wrong-token & brute-force throttle", t_auth)

    def t_ratelimit():
        clk = Clock(0.0)
        rl = RateLimiter(max_keys=3, clock=clk)
        assert all(rl.allow("a", 60, burst=3)[0] for _ in range(3))
        ok, retry = rl.allow("a", 60, burst=3)
        assert ok is False and 0 < retry <= 1.0
        clk.t += 1.0
        assert rl.allow("a", 60, burst=3)[0] is True
        for k in "bcdef":
            rl.allow(k, 60)
        assert rl.size() <= 3, "key table must stay bounded"
    run_test("T34", "Rate Limiter token bucket (refill, 429 retry-after, bounded memory)", t_ratelimit)

    def t_logger_settings():
        import logging
        rec = logging.LogRecord("kora.t", logging.INFO, "f", 1, "calling with Bearer abcdef123456 and api_key=sk-secret9999", None, None)
        rec.fields = {"token": "xyz", "ok": 1, "nested": {"password": "p"}}
        line = json.loads(JsonFormatter().format(rec))
        blob = json.dumps(line)
        assert "abcdef123456" not in blob and "sk-secret9999" not in blob and line["token"] == "[REDACTED]" and line["nested"]["password"] == "[REDACTED]"
        assert "abc" not in redact_text("Authorization: Bearer abcdef123456")[15:]
        s = load_settings({"KORA_WORKER_POOL_SIZE": "99", "KORA_RETRY_BASE_SECONDS": "oops", "KORA_AUTH_TOKEN": " t "}, dotenv_path="/nonexistent")
        assert s.worker_pool_size == 8 and s.retry_base_seconds == 2.0 and s.auth_token == "t"
        d = load_settings({}, dotenv_path="/nonexistent")
        assert d.auth_token == "" and d.bind_host == "127.0.0.1" and d.social_auto_approve is False
        env = {}
        p = tempfile.mktemp()
        open(p, "w").write("A_KEY=from_file\n# c\nB='quoted'\nEXISTING=file\n")
        env["EXISTING"] = "real"
        from kora.config.settings import load_dotenv
        load_dotenv(p, env)
        assert env["A_KEY"] == "from_file" and env["B"] == "quoted" and env["EXISTING"] == "real", "real env must win"
    run_test("T35", "Structured Logger Redaction & Env Settings (clamps, no default secret)", t_logger_settings)

    # ---- social
    from kora.services import handlers as H, social
    from kora.services.publishers import PUBLISHERS

    def mk_env(**kw):
        return {"X_OAUTH2_USER_TOKEN": "xtok", **kw}

    def fake(sent, script=None):
        script = list(script or [])

        def tr(method, url, headers, body, timeout):
            sent.append((method, url, headers, body))
            if script:
                return script.pop(0)
            if "twitter.com" in url:
                return 201, {}, json.dumps({"data": {"id": "tweet-1"}}).encode()
            return 200, {}, json.dumps({"id": "fb-1"}).encode()
        return tr

    def t_social_auto():
        path = _db()
        sent = []
        H.SOCIAL_TRANSPORT, H.SOCIAL_ENV = fake(sent), mk_env()
        os.environ["KORA_DB_PATH"] = path
        try:
            q = DurableQueue(path, retry_base=0)
            post = social.create_social_post("X", "hello world", "GENERAL", db_path=path, auto_approve=False, queue=q, env=H.SOCIAL_ENV, auto_publish=True)
            assert post["status"] == "PENDING_APPROVAL"
            w = SafeWorker(q, "w")
            assert w.process_one() is None, "nothing may publish before approval"
            assert not sent
            res = social.approve_and_publish_post(post["post_id"], path, env=H.SOCIAL_ENV, queue=q, auto_publish=True)
            assert res["status"] == "APPROVED_QUEUED", res
            again = social.approve_and_publish_post(post["post_id"], path, env=H.SOCIAL_ENV, queue=q, auto_publish=True)
            assert again["duplicate_job"] is True, "re-approval must not create a second job"
            out = w.process_one()
            assert out["status"] == "COMPLETED", out
            p = social.get_post(post["post_id"], path)
            assert p["status"] == "PUBLISHED" and p["external_id"] == "tweet-1"
            assert len(sent) == 1 and sent[0][2]["Authorization"] == "Bearer xtok"
            assert social.approve_and_publish_post(post["post_id"], path, env=H.SOCIAL_ENV)["status"] == "PUBLISHED"
            assert len(sent) == 1, "no duplicate send"
            # explicit AUTO-APPROVE opt-in goes straight through (and is audited)
            p2 = social.create_social_post("X", "auto one", "GENERAL", db_path=path, auto_approve=True, queue=q, env=H.SOCIAL_ENV, auto_publish=True, asset_meta={"rights": "OWNED", "source": "original"})
            assert p2["status"] == "APPROVED_QUEUED"
            assert w.process_one()["status"] == "COMPLETED" and len(sent) == 2
            assert get_connection(path).execute("SELECT COUNT(*) c FROM audit_events WHERE event_type='social_auto_approve'").fetchone()["c"] == 1
        finally:
            H.SOCIAL_TRANSPORT = H.SOCIAL_ENV = None
            os.environ.pop("KORA_DB_PATH", None)
    run_test("T36", "Social Auto-Publish after Approval (idempotent, audited, no pre-approval send)", t_social_auto)

    def t_social_failures():
        path = _db()
        sent = []
        os.environ["KORA_DB_PATH"] = path
        q = DurableQueue(path, retry_base=0)
        w = SafeWorker(q, "w")
        try:
            # no credentials -> truthful halt, nothing sent
            H.SOCIAL_TRANSPORT, H.SOCIAL_ENV = fake(sent), {}
            a = social.create_social_post("X", "no creds", "GENERAL", db_path=path, auto_approve=False)
            r = social.approve_and_publish_post(a["post_id"], path, env={}, queue=q, auto_publish=True)
            assert r["status"] == "APPROVED_AWAITING_CREDENTIALS" and "X_OAUTH2_USER_TOKEN" in r["message"] and not sent
            # unsupported platform never fakes success
            ig = social.create_social_post("INSTAGRAM", "ig", "GENERAL", db_path=path, auto_approve=False)
            try:
                social.approve_and_publish_post(ig["post_id"], path, env={"INSTAGRAM_ACCESS_TOKEN": "t"}, queue=q, auto_publish=True)
                assert False, "Instagram without a public media URL must not be approved for dispatch (audit S6)"
            except social.SocialPublishError as exc:
                assert "media_required" in str(exc)
            ig = social.create_social_post("INSTAGRAM", "ig", "GENERAL", db_path=path, auto_approve=False, public_media_url="https://cdn.example.com/a.mp4", media_type="REEL")
            r = social.approve_and_publish_post(ig["post_id"], path, env={"INSTAGRAM_ACCESS_TOKEN": "t"}, queue=q, auto_publish=True)
            assert r["status"] == "APPROVED_AWAITING_CREDENTIALS" and "INSTAGRAM_USER_ID" in r["message"] and not sent
            # transient 503 then success -> retried, ONE successful publish
            H.SOCIAL_ENV = mk_env()
            H.SOCIAL_TRANSPORT = fake(sent, [(503, {}, b"down")])
            t = social.create_social_post("X", "retry me", "GENERAL", db_path=path, auto_approve=False)
            social.approve_and_publish_post(t["post_id"], path, env=H.SOCIAL_ENV, queue=q, auto_publish=True)
            assert w.process_one()["status"] == "QUEUED"
            assert social.get_post(t["post_id"], path)["status"] == "APPROVED"
            assert w.process_one()["status"] == "COMPLETED"
            assert social.get_post(t["post_id"], path)["status"] == "PUBLISHED"
            # permanent 403 -> DLQ + post FAILED
            H.SOCIAL_TRANSPORT = fake(sent, [(403, {}, b"forbidden")])
            f = social.create_social_post("X", "denied", "GENERAL", db_path=path, auto_approve=False)
            social.approve_and_publish_post(f["post_id"], path, env=H.SOCIAL_ENV, queue=q, auto_publish=True)
            assert w.process_one()["status"] == "DEAD_LETTER"
            assert social.get_post(f["post_id"], path)["status"] == "FAILED"
            # empty external id = failure, never success
            H.SOCIAL_TRANSPORT = fake(sent, [(201, {}, b'{"data":{}}')])
            e = social.create_social_post("X", "noid", "GENERAL", db_path=path, auto_approve=False)
            social.approve_and_publish_post(e["post_id"], path, env=H.SOCIAL_ENV, queue=q, auto_publish=True)
            assert w.process_one()["status"] == "DEAD_LETTER" and social.get_post(e["post_id"], path)["status"] != "PUBLISHED"
            # crash simulation: row stuck in PUBLISHING must NOT be re-sent
            c = social.create_social_post("X", "crash", "GENERAL", db_path=path, auto_approve=False)
            social.approve_and_publish_post(c["post_id"], path, env=H.SOCIAL_ENV, queue=q, auto_publish=True)
            get_connection(path).execute("UPDATE social_posts SET status='PUBLISHING' WHERE id=?", (c["post_id"],))
            n = len(sent)
            assert w.process_one()["status"] == "DEAD_LETTER" and len(sent) == n, "interrupted publish must not double-post"
            assert social.get_post(c["post_id"], path)["status"] == "FAILED"
            # idempotent create + path traversal
            k1 = social.create_social_post("X", "k", "GENERAL", idempotency_key="k-1", db_path=path, auto_approve=False)
            k2 = social.create_social_post("X", "k", "GENERAL", idempotency_key="k-1", db_path=path, auto_approve=False)
            assert k2["duplicate"] is True and k2["post_id"] == k1["post_id"]
            try:
                social.create_social_post("YOUTUBE", "v", "GENERAL", db_path=path, media_path="/etc/passwd", auto_approve=False)
                assert False
            except social.SocialPublishError:
                pass
        finally:
            H.SOCIAL_TRANSPORT = H.SOCIAL_ENV = None
            os.environ.pop("KORA_DB_PATH", None)
    run_test("T37", "Social Failure Paths: no creds, unsupported, retry, DLQ, no-id, crash-safety, traversal", t_social_failures)

    def t_publishers():
        import kora.services.publishers as P
        d = tempfile.mkdtemp()
        vid = os.path.join(d, "v.mp4")
        open(vid, "wb").write(b"\0" * (600 * 1024))
        old = P.CHUNK
        P.CHUNK = 256 * 1024
        try:
            sent = []

            def tr(method, url, headers, body, timeout):
                sent.append((method, url, headers))
                if method == "POST":
                    return 200, {"location": "https://www.googleapis.com/upload/youtube/v3/videos?upload_id=1"}, b""
                rng = headers["Content-Range"]
                end = int(rng.split("-")[1].split("/")[0])
                total = int(rng.split("/")[1])
                if end + 1 < total:
                    return 308, {"range": f"bytes=0-{end}"}, b""
                return 200, {}, b'{"id":"yt-9"}'
            ext = P.publish_youtube({"media_path": vid, "content": "c", "title": "t", "audience": "KIDS"}, {"YOUTUBE_ACCESS_TOKEN": "y"}, tr)
            assert ext == "yt-9" and sum(1 for s in sent if s[0] == "PUT") == 3, "600KiB in 256KiB chunks = 3 PUTs"
            fb = P.publish_facebook({"content": "hi"}, {"FACEBOOK_PAGE_ID": "12345", "FACEBOOK_PAGE_ACCESS_TOKEN": "f"},
                                    lambda m, u, h, b, t: (200, {}, b'{"id":"123_456"}'))
            assert fb == "123_456"
            try:
                P.publish_x({"content": "x" * 281}, {"X_OAUTH2_USER_TOKEN": "t"}, tr)
                assert False
            except P.PublishError as e:
                assert e.retryable is False
        finally:
            P.CHUNK = old
    run_test("T38", "YouTube Chunked Resumable Upload, Facebook & X Limits (fake transport)", t_publishers)

    # ---- research / rag / ai
    from kora.core.security import validate_public_url
    from kora.services import rag, research

    def t_research():
        pub = lambda h: ["93.184.216.34"]
        for bad in ("http://example.com/", "https://127.0.0.1/", "https://localhost/", "https://169.254.169.254/latest", "https://[::1]/",
                    "https://user:pw@example.com/", "https://example.com:8443/", "https://intranet.internal/"):
            assert validate_public_url(bad, resolver=pub)[0] is False, bad
        assert validate_public_url("https://rebind.example/", resolver=lambda h: ["93.184.216.34", "10.0.0.5"])[0] is False
        assert validate_public_url("https://example.com/", resolver=pub)[0] is True
        assert validate_public_url("https://other.com/", allowed_domains=("example.com",), resolver=pub)[0] is False
        html = b"<html><head><title>Doc</title><script>steal()</script></head><body><p>KORA uses SQLite for the durable queue and leases.</p></body></html>"
        ok = research.fetch_page("https://example.com/a", fetcher=lambda u, t, m: (200, {"content-type": "text/html; charset=utf-8"}, html), resolver=pub)
        assert ok["title"] == "Doc" and "steal" not in ok["text"] and "durable queue" in ok["text"]
        hops = []

        def redirecting(u, t, m):
            hops.append(u)
            return 302, {"location": "https://evil.example/x"}, b""
        resolver = lambda h: ["10.1.1.1"] if h == "evil.example" else ["93.184.216.34"]
        try:
            research.fetch_page("https://example.com/r", fetcher=redirecting, resolver=resolver)
            assert False
        except research.ResearchError as e:
            assert e.code == "url_blocked" and len(hops) == 1, "redirect to private host must be blocked before fetching"
        try:
            research.fetch_page("https://example.com/b", fetcher=lambda u, t, m: (200, {"content-type": "application/zip"}, b"PK"), resolver=pub)
            assert False
        except research.ResearchError as e:
            assert e.code == "content_type_not_allowed"
        assert research.search_web("q", env={})["status"] == "CONFIGURATION_REQUIRED"
        sr = research.search_web("kora", env={"BRAVE_SEARCH_API_KEY": "k"},
                                 transport=lambda m, u, h, b, t: (200, {}, b'{"web":{"results":[{"title":"T","url":"https://e.com","description":"d"}]}}'))
        assert sr["ok"] and sr["results"][0]["url"] == "https://e.com"
    run_test("T39", "Web Research: SSRF guard, redirect re-validation, content-type, search config", t_research)

    def t_rag():
        path = _db()
        a = rag.ingest_text("KORA stores jobs in SQLite. Workers claim jobs atomically using leases and fencing tokens. " * 5, "https://example.com/queue", "Queue", path)
        b = rag.ingest_text("Bananas are yellow fruit rich in potassium and grow in tropical climates around the world today.", "https://example.com/fruit", "Fruit", path)
        assert rag.ingest_text("KORA stores jobs in SQLite. Workers claim jobs atomically using leases and fencing tokens. " * 5, "dup", "", path)["duplicate"] is True
        hits = rag.retrieve("how do workers claim jobs with leases", 3, path)
        assert hits and hits[0]["source"].endswith("/queue"), hits
        assert not rag.retrieve("quantum chromodynamics zebra", 3, path), "no term overlap => no hits"
        ans = rag.answer("how do workers claim jobs", path, ask_ai=lambda p: {"provider": "local_deterministic_fallback", "output": ""})
        assert ans["mode"] == "extractive_no_llm" and ans["citations"] and "leases" in ans["answer"]
        seen = {}
        llm = rag.answer("how do workers claim jobs", path, ask_ai=lambda p: seen.setdefault("p", p) and {"provider": "groq", "output": "By leases [1]."})
        assert llm["mode"] == "llm" and "untrusted" in seen["p"].lower() and "<CONTEXT>" in seen["p"]
        try:
            rag.ingest_text("x" * 100, "s", "", path, max_chunks=1)
            assert False
        except rag.RagError:
            pass
    run_test("T40", "RAG: ingest/dedup, retrieval relevance, extractive vs LLM answer, injection fencing, capacity", t_rag)

    def t_ai():
        from kora.services import ai_failover as AI
        AI.reset_breakers()
        env = {"GEMINI_API_KEY": "g", "OPENAI_API_KEY": "o"}
        seq = []

        def tr(method, url, headers, body, timeout):
            seq.append(url)
            if "googleapis" in url:
                return 429, {}, b"quota"
            return 200, {}, json.dumps({"choices": [{"message": {"content": "hello from openai"}}]}).encode()
        r = AI.query_ai_model("hi", transport=tr, env=env)
        assert r["provider"] == "openai" and r["errors_before_success"][0]["provider"] == "gemini" and "x-goog-api-key" not in seq[0]
        for _ in range(4):
            AI.query_ai_model("hi", transport=tr, env=env)
        assert sum("googleapis" in u for u in seq) == 3, "circuit breaker must stop calling a failing provider"
        AI.reset_breakers()
        allfail = AI.query_ai_model("hi", transport=lambda *a: (500, {}, b""), env=env)
        assert allfail["provider"] == "local_deterministic_fallback" and allfail["errors"]
    run_test("T41", "AI Failover: provider cascade, circuit breaker, labelled local fallback (fake transport)", t_ai)

    # ---- bridge
    def t_bridge():
        from kora.bridge.api import KoraApp
        d = tempfile.mkdtemp()
        s = replace(load_settings({}, dotenv_path="/nonexistent"), auth_token="secret-token-1", db_path=os.path.join(d, "b.db"),
                    worker_poll_seconds=0.05, retry_base_seconds=0, rate_write_per_min=1000, rate_read_per_min=1000, rate_heavy_per_min=2)
        app = KoraApp(s)

        def call(method, path, body=None, peer="127.0.0.1", headers=None, ctype="application/json", host="127.0.0.1:8000"):
            raw = json.dumps(body).encode() if body is not None else b""
            env = {"REQUEST_METHOD": method, "PATH_INFO": path, "REMOTE_ADDR": peer, "HTTP_HOST": host, "wsgi.input": io.BytesIO(raw),
                   "CONTENT_LENGTH": str(len(raw)) if raw else "", "CONTENT_TYPE": ctype if raw else ""}
            for k, v in (headers or {}).items():
                env["HTTP_" + k.upper().replace("-", "_")] = v
            out = {}
            data = b"".join(app(env, lambda st, h: out.update(status=int(st.split()[0]), headers=dict(h))))
            try:
                return out["status"], json.loads(data), out["headers"]
            except ValueError:
                return out["status"], data, out["headers"]
        tok = {"Authorization": "Bearer secret-token-1"}
        assert call("GET", "/api/health")[0] == 200
        assert call("GET", "/api/active", peer="203.0.113.7")[0] == 403, "remote without token"
        assert call("GET", "/api/active", peer="203.0.113.7", headers=tok)[0] == 200
        assert call("GET", "/api/active", host="evil.example")[0] == 403, "Host allow-list (DNS rebinding)"
        assert call("POST", "/api/queue/enqueue", {"handler": "noop"}, headers={"Origin": "http://evil.example"})[0] == 403, "foreign Origin (CSRF)"
        assert call("POST", "/api/queue/enqueue", {"handler": "noop"}, ctype="text/plain")[0] == 415, "non-JSON body (simple-form CSRF)"
        assert call("POST", "/api/queue/enqueue", {"handler": "social_publish", "payload": {"post_id": "x"}})[0] == 400, "publish handler is not enqueueable directly"
        assert call("POST", "/api/queue/enqueue", {"handler": "os.system"})[0] == 400, "closed handler registry"
        big = {"handler": "noop", "payload": {"x": "a" * (s.max_body_bytes + 10)}}
        assert call("POST", "/api/queue/enqueue", big)[0] == 413
        st, body, hdr = call("GET", "/api/health")
        assert hdr["X-Content-Type-Options"] == "nosniff" and "frame-ancestors 'none'" in hdr["Content-Security-Policy"]
        assert call("GET", "/")[0] == 200 and call("GET", "/hud.js")[0] == 200
        # end-to-end: enqueue -> worker -> completed; failing job -> DLQ -> requeue via API
        app.pool.start()
        try:
            st, j, _ = call("POST", "/api/queue/enqueue", {"handler": "math_compute", "payload": {"a": 2, "b": 3, "op": "add"}})
            assert st == 201
            end = time.time() + 10
            while time.time() < end and call("GET", "/api/jobs/" + j["id"])[1]["job"]["status"] != "COMPLETED":
                time.sleep(0.05)
            assert call("GET", "/api/jobs/" + j["id"])[1]["job"]["result"]["result"] == 5
            st, bad, _ = call("POST", "/api/queue/enqueue", {"handler": "math_compute", "payload": {"op": "nope"}})
            end = time.time() + 10
            while time.time() < end and not call("GET", "/api/queue/dlq")[1]["items"]:
                time.sleep(0.05)
            dl = call("GET", "/api/queue/dlq")[1]["items"]
            assert dl and dl[0]["id"] == bad["id"]
            assert call("POST", f"/api/queue/dlq/{bad['id']}/requeue")[0] == 200
        finally:
            app.pool.stop(5)
        act = call("GET", "/api/active")[1]
        assert set(["running", "queued", "needs_approval", "failed", "idle"]) <= set(act)
        # kill switch via API
        assert call("POST", "/api/killswitch", {"active": True})[0] == 200
        assert call("POST", "/api/queue/enqueue", {"handler": "noop"})[0] == 503
        assert call("POST", "/api/killswitch", {"active": False})[0] == 200
        # heavy endpoint rate limit (2/min configured)
        codes = [call("GET", "/api/doctor/probes")[0] for _ in range(6)]
        assert 429 in codes, codes
        # social over HTTP: approval gate present
        st, p, _ = call("POST", "/api/social/posts", {"platform": "X", "content": "via api"})
        assert st == 201 and p["status"] == "PENDING_APPROVAL"
        # research endpoint refuses internal targets
        st, r, _ = call("POST", "/api/research/fetch", {"url": "https://169.254.169.254/latest/meta-data"})
        assert st in (422, 429), (st, r)
    run_test("T42", "Bridge E2E: auth, Host/Origin/CSRF, closed registry, size cap, worker E2E, DLQ API, kill-switch, rate-limit", t_bridge)

    def t_real_http():
        from kora.bridge.server import _Threaded, _QuietHandler
        from wsgiref.simple_server import make_server
        from kora.bridge.api import KoraApp
        d = tempfile.mkdtemp()
        s = replace(load_settings({}, dotenv_path="/nonexistent"), db_path=os.path.join(d, "h.db"), cron_tick_seconds=0.1,
                    worker_poll_seconds=0.05, allowed_hosts=("127.0.0.1", "localhost"))
        app = KoraApp(s)
        app.start_services()
        srv = make_server("127.0.0.1", 0, app, server_class=_Threaded, handler_class=_QuietHandler)
        port = srv.server_address[1]
        th = threading.Thread(target=srv.serve_forever, daemon=True)
        th.start()
        try:
            def get(path):
                return json.loads(urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=5).read())
            assert get("/api/health")["status"] == "ONLINE"
            req = urllib.request.Request(f"http://127.0.0.1:{port}/api/queue/enqueue", data=json.dumps({"handler": "noop", "payload": {"a": 1}}).encode(),
                                         headers={"Content-Type": "application/json"}, method="POST")
            jid = json.loads(urllib.request.urlopen(req, timeout=5).read())["id"]
            end = time.time() + 10
            while time.time() < end and get("/api/jobs/" + jid)["job"]["status"] != "COMPLETED":
                time.sleep(0.05)
            assert get("/api/jobs/" + jid)["job"]["status"] == "COMPLETED"
            assert any(c["name"] == "maintenance" for c in get("/api/cron")["items"]), "default cron job registered"
            assert get("/api/queue/stats")["worker"]["running"] is True
        finally:
            srv.shutdown()
            app.stop_services()
            assert app.pool.status()["running"] is False
    run_test("T43", "Real HTTP Server: threaded bridge + live worker pool + cron + graceful shutdown", t_real_http)
