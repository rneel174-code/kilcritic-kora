# 10.5.0 (2026-10-09): FREEZE PHASE - real integrations + verification + resources + growth loop (additive)
- **OPS ASSESSMENT (additive, same version, no bump)**: (1) router telemetry in `ai_failover` - per-provider calls/successes/failures, avg+last latency, last model, error-kind counts, circuit-open skips and local-fallback count; errors are sanitised to categories (`http_NNN`, `timeout`, `malformed_response`, ...) so no key/URL/provider text is stored or returned; `provider_states` gains a `telemetry` key (unmeasured = None/UNKNOWN). (2) capability registry: each `discover_capabilities` entry gains `verification` {state, evidence, limitations, checked_at, verified:false}; the function never auto-assigns VERIFIED. (3) new `kora/services/assessment.py`: read-only `run_assessment` (overlap-locked, deadline-bounded, safe-mode/freeze aware, persistent history, proposals listed but never created), `metrics` (queue depth/age, saturation, UNKNOWN instead of 0) and explicit owner-triggered `egress_probe` (TCP connect, no data sent). Routes: `GET /api/metrics`, `GET /api/assessment/history`, `POST /api/assessment/run`, `POST /api/egress/probe`. New worker handler `readonly_assessment` (trust-registered, LOW risk) that the owner may schedule with the EXISTING cron; nothing is scheduled automatically. Tests T200-T205. See docs/OPS_ASSESSMENT.md and docs/TRACEABILITY_MATRIX.md.
- **PROVIDER GAP (additive, same version, no bump)**: `GAP_NO_AI_PROVIDER` is raised by the existing gap radar only when `ai_failover.provider_states` shows no usable external AI provider (the local rule engine is reported as available but is NOT an AI provider; a key for a provider with no adapter is not usable). New `ai_failover.usable_ai_providers / provider_comparison / provider_owner_actions` (availability, adapter support, cost category, privacy/retention = UNKNOWN unless owner reviews attached evidence, dependencies, required credential NAMES). The discovery cycle (`run_cycle`) now ends with ONE provider-specific, de-duplicated `CONNECT_AI_PROVIDER` proposal carrying structured `owner_actions` (Malak vs SYSTEM, env-var names, restart/retest, approvals) and a `guarantees` block (no install, no code change, no account connection, no spend, no external service, no secret requested). Research only via owner-supplied URLs or configured Brave search; otherwise `NOT_CONFIGURED`. New read-only `GET /api/evolution/3/providers`; `GET /api/governance/proposals/<id>` exposes owner_actions/comparison; approving a `CONNECT_AI_PROVIDER` proposal records the decision only (`executed:false`). `self_evolution.prepare` adds `owner_actions` when a patch could not be drafted because no provider is usable. Approval gates, evidence gate, audit ledger, rollback and freeze are untouched. Tests T192-T199 (`kora/tests/provider_gap_tests.py`). See docs/PROVIDER_GAP.md.
- Malak Assist: authenticated Telegram (secret-token header) and WhatsApp (HMAC-SHA256 + verify challenge) inbound webhooks, NOT_CONFIGURED => 503, number normalisation, timeout/escalation (spaced, capped, never claims SENT unless a channel returned SENT), wired into the existing watchdog cron.
- Social: external read-back verification (X/Facebook/YouTube/Instagram/TikTok) after publish; verification_state VERIFIED / NOT_FOUND / UNVERIFIED; delayed 30s job on the existing queue; tokens scrubbed.
- Resources: runtime_limits current RSS + env limits + pressure; worker pool yields under pressure; HTTP request threads bounded (503 when full).
- Trust gate: scheduled_autopilot / fortress_watchdog / social_verify added to SKILL_META (previously refused live); test asserts every handler is trust-visible.
- New growth_loop.py: campaign attribution, ROI_TARGET/ESTIMATE/MEASURED/VERIFIED, Marketing DNA from evidenced outcomes, 10-shop pilot EVIDENCE framework (Rs500 rule only on tool-verified before/after, never charges), competitor gap radar, festival plan templates. Backup 3-2-1 truth report. scripts/REAL-system_check.sh.
- New moat_store.py: consent-gated (OFF by default), AES-256-GCM (reuses secure_vault) monthly sealed store, atomic writes, checksum index, tamper/wrong-key detection, anonymised export needing separate export consent. Library-level; not wired to a UI.
- Post-audit growth-loop security patch (same version, no bump): caller text ("pos:x") no longer counts as tool evidence (max level 2, UNRECONCILED); level 4 only via a single-use, amount- and currency-exact dhanda ledger link; idempotency keys (required for SALE/PAYMENT); pilot observations unique per shop/phase/date, real non-future dates, window/order/contiguity checks, owner-only attestation (level 3, audited); every growth mutation audited with actor; redaction limited to real secret shapes; finite-number validation (NaN/Infinity rejected). Canonical runner now includes infinite_core and supreme_runtime (T163/T164); T114 no longer depends on wall-clock ratios and the slowdown gate has a deterministic test (T166).
- server.ts hardened against Python module shadowing: both Python spawns go through scripts/safe_launch.py (python3 -I, project root appended not prepended, module allowlist kora.cli / kora.tests.run_all, kora-origin check). Regression test T167.
- T100 (self-benchmark lab) made deterministic: decision logic runs on a fixed injected clock; one real-measurement assertion stays. It failed ~5-10% of runs before (identical functions compared on noisy wall-clock); 400 consecutive runs pass, also under CPU load.
- kora/bridge/api.py `run_tests` now launches through scripts/safe_launch.py (-I) instead of `-m` + PYTHONPATH (same shadowing class as server.ts); covered by T167.
- PATCH3 (found by the PATCH2 final audit): `POST /api/tests/run` runs the suite with cwd = a temp dir and returned `ok:false` (166/167) because T110's generated test read a repo-relative path. Fixed in the test harness only (`run_generated_from_root`, restores cwd); no product, auth or approval code touched. Regression: T168 (helper, foreign cwd) and T169 (the route's own launcher run with cwd=temp restricted to T110 via the `KORA_TEST_ONLY` test hook in run_all; unknown ids/recursion can never pass). The route now shares one launcher (`_run_suite_subprocess`); behaviour, auth, timeout (503) and exit-code handling unchanged.
- **HUD + Hollywood Studio repair (mounted `/`)**: root cause was three UIs with repairs landing on non-default ones (see docs/HUD_STUDIO_AUDIT_AND_MAPPING.md). Repaired in place: `kora/hud/creator_index.html|creator.js|creator.css` (+ new `intent.js`): truthful state badge (IDLE/LISTENING/THINKING/WORKING/NEEDS APPROVAL/ERROR/COMPLETE), always-visible command bar, task panel from `/api/active`, floating glass tool ring, safe-area/mobile CSS, task checkpoint + "return to last task", one `dispatch()` for voice/text/touch -> `/api/brain`, Advanced/System panel (Doctor, Discovery, Backup, Improve Me, Resources, Events, Audit, Tests, Voice, token, full console). Legacy `/advanced` console untouched.
- **Studio (one media engine)**: `media_pipeline.py` gains chunked import, library, inline preview, ffmpeg edits (trim/crop/aspect/rotate/resize/color/filter/text/audio/export presets) verified with ffprobe; `hollywood_studio.py` gains local draft projects; `api.py` gains 9 owner-only `/api/studio/*` routes (edit = heavy/rate-limited, import/edit audited), `studio_asset` on `/api/social/posts`, `/intent.js` static route and CSP `media-src 'self' blob:` + `img-src blob:`. Publishing remains approval-gated; the UI has no publish call.
- Not implemented (reported, not faked): 3D/4D/5D rendering, generative video, multi-track timeline, Amazon posting, live trends, 4K export. React `src/` untouched (cannot be built: npm registry blocked).
- Optional browser check: `scripts/ui_mounted_check.py` (Playwright; NOT RUN when unavailable).
- Tests: 169 -> 178 (T170-T178).
- **Phase 2 - offline command library (additive, same version)**: new `kora/services/command_library.py` holds 100 deterministic command templates (Learning, Decision, Professional writing, Business/creative, Productivity; 20 each) with English, Roman Punjabi, Roman Hindi and a few Gurmukhi/Devanagari aliases. It is NOT a new engine: `brain.handle()` consults it only when no original intent matched; same permissions, voice gates and audit. Output is a fill-in scaffold labelled "local template - no AI model used"; nothing is sent/published/executed. Ties return NEEDS_CLARIFICATION with candidates (`cmd <ID>` picks one); unknown input keeps the original examples and adds closest-command suggestions. No LLM, network or paid API is used or required (`ai_failover` is untouched and not called). The owner's original 100-command file was not available, so the set is a designed one (`PROVENANCE = DESIGNED_SET`) kept as data. Known limit: original intents win (e.g. phrases containing `resume`, or `create/make ... video|story|reel`), so such phrasing reaches the original intent, not the library. See docs/COMMAND_LIBRARY.md.
- Tests: 178 -> 184 (T179-T184).
- **CTO-audit bug fixes (same version, additive)**: Doctor Heal no longer reports `healed:true` when nothing was repaired (`state` NOTHING_TO_REPAIR / REPAIRED / PARTIAL_FAILURE, `repaired_total`, `message`); `doctor heal` / `system heal` now work as commands through the one brain dispatcher (permission-gated, audited); `health` lists owner setup per flagged domain; identical open MODIFY_CODE proposals are not queued twice; `/api/active` gains an `approvals` summary (posts + proposals, high-risk, approved-not-executed) used by the HUD; new read-only `GET /api/governance/proposals/<id>` shows that APPROVED is not EXECUTED (patch/restore-point presence, audit trail); suite timeout is owner-adjustable (`KORA_TEST_TIMEOUT_SECONDS`, 60-1800, default 180) and a timeout is reported as UNKNOWN, never a pass; HUD Enter/Go/Send key handled explicitly through the same form submit as GO and `enterkeyhint="send"`. See docs/CTO_BUGFIX_AUDIT.md.
- Tests: 184 -> 191 (T185-T191).

# 10.4.0 (2026-10-07): FIX + HARDEN + LOCK-11 (additive)
- 9 audit fixes (rights gate, touch workflows, truthful schedule states + recovery, Instagram media/account readiness, state guards, mobile UI, capability truth, real media.convert). See HARDENING_10_4_REPORT.md.
- LOCK-11 MALAK-ASSIST hardened: redaction, task-bound one-time code (never returned to requester), expiry, lockout, duplicate-reply rejection, consume-once checkpoint, sender-authenticated inbound, restart recovery.
- New fortress.py: immutable permission boundary, independent watchdog + halt, delegation limits, evolution proof, dead-file audit (archive-only), learning firewall + drift, independence report, complexity gate, recovery proof.
- Security fixes: token echo in platform errors scrubbed; SSRF numeric-host bypass closed; malformed 2xx JSON handled.
- Tests: 121 -> 151 (T122-T151). T19/T36/T37/T48/T49/T53/T59 now assert undeclared/unknown rights => HUMAN_REVIEW/BLOCKED.

# Changelog

## 10.3.0 — FINAL MERGE (2026-10-06): one ZIP, nothing removed
- **Merged**: 10.2 base + SE2 + 5.0 Godfather/Supreme Runtime/Infinite Core + Next-Gen + FIXED_AUDITED + Creator OS (scheduled autopilot, Instagram/TikTok adapters, vault, regional lock, creator HUD) + Owner KB + Self-Evolution 3.0 spec.
- **Self-Evolution 3.0 Good Father** (`services/self_evolution_3.py`, upgrade of SE1/SE2, no second engine): evidence-hash-chained memory, capability discovery + FIND-before-BUILD, dependency intel, benchmark lab, evolution score (reuses Godfather), regression guards, impact graph + levels 0-6, adversarial scan, gap radar, performance profile, failure prediction (9 classes), resource-aware checkpointed cycle, offline queue (durable jobs), self-test generator, canary in isolated copy, promotion gate, verified rollback, chaos check, owner freeze. Legacy approve/apply can no longer patch code without the gate.
- **20 intelligence additions** merged into existing modules: priority tiers P0-P4 + pressure control, pause/resume, dependency-aware jobs, injection shield, human-readable errors, health domains, failure prediction, dry-run, social account routing, ffprobe quality verification, DNA learning + rollback, trust score/least-privilege routing, command confidence.
- **Duplicates fixed**: `offline_queue` is now an adapter over the single durable queue; one `_NoRedirect`.
- **Tests**: 121/121 (twice) + Godfather, Supreme Runtime, Infinite Core runners. Creator-suite assertions made strict (a False result now fails).

## 2026-10-05 — Creator-First Dashboard UI Lock
- Added a single **MEDIA + SOCIAL + STUDIO** folder/icon as the creator dashboard front door.
- Grouped YouTube, Facebook, Instagram, TikTok, X, Hollywood Studio, Editing, Cartoon/Animation, Funny Baby, Funny Videos, Videos, Photos, Stories, Wallpapers, Voice+Text, POST, 30-Day Autopilot, Comments, Growth, Research and Dhanda inside the hub.
- Removed technical navigation tabs from the main dashboard.
- Moved System Health, Discovery/System Overview, Events/Event Bus, Backup, Voice/STT, Media Dedup, Offline Queue, Tests and KORA HUD into an explicit **Advanced** area.
- Advanced/system controls are hidden by default and do not clutter the creator workflow.
- No backend capability was removed; this is a presentation/navigation change only.

# Changelog

## 10.2.0-KILCRITIC-SUPREME (on KORA 8.10.0)
Identity/roles/TOTP, One Brain (text+voice), DNA Time Machine, ATMA/Phoenix, Shadow Publish, trust+skill gate, deep research, ledger verifier, anti-loop, audit hash-chain, export/delete, safe migration, new HUD. Tests 53 -> 69, all PASS. Details: docs/CHANGELOG_AND_NOTES.md.

## 8.10.0
Governance layer (policy, proposals, Malak, legal preflight, cost caps, SENA, emergency). Tests 43 -> 53.

## 8.9.0-KORA-PRO
Restructure into kora/{core,services,bridge,config,hud}; queue retry+DLQ; auth/rate-limit/logger/env; cron; social auto-publish; research+RAG.

## 10.2.1 — Governed Self-Evolution + Holographic HUD
- Added `kora/services/self_evolution.py`: real repository scan, source research, governed patch proposal, path validation, owner approval, canary/dry-run, compile + full-test verification, rollback and audit trail.
- Added `/api/evolution/scan`, `/api/evolution/prepare`, `/api/evolution/{id}/apply`, `/api/evolution/{id}/rollback`.
- Approved `MODIFY_CODE` proposals now automatically enter the governed apply/test/verify path; failed verification rolls back.
- Added adaptive environment profile API: EARTH/OCEAN/SKY/SPACE/REGION.
- Added 72-test gate including self-evolution and environment tests.
- Reworked the native HUD into a desktop/mobile fullscreen holographic command center with current-task focus, approvals, self-evolution, resources, providers, environment, voice, backup and doctor controls.
- Added bundled KORA avatar asset to the native HUD.
- No fake physical power, no silent production modification, no credential bypass, and no automatic payment.

## Supreme Runtime Next-Gen Integration
- Added Horizon Reduction, Trajectory Assurance, Formal Agent Contracts and Dynamic Autonomy Budget primitives.
- Added runtime watchdog, tamper-evident execution proof, execution-state memory tree and delegation provenance.
- Added zero-trust supply-chain records, evidence freshness, objective-drift detection, blast-radius analysis and recovery proof.
- Added complexity-debt accounting and architecture-compression/reuse-first guidance.
- Integrated planning-only Supreme Runtime assurance into the existing Godfather planner.
- Added research-gap audit and regression tests; existing 75-test suite remains green.

## 2026-10-05 — Gap Closure Pass
- Added official Instagram Graph publishing flow with public-media requirement.
- Added official TikTok Content Posting API Direct Post flow with bounded upload/status verification.
- Added social media URL/type/AI metadata migration.
- Added runtime resource enforcement, encrypted local vault, notification outbox and capability truth matrix.
- Added 9 gap-closure regression tests.

## 2026-10-05 — CA/US/IN Regional Lock
- Added explicit Canada, United States and India regional profiles.
- Added region-aware localization/currency/Amazon marketplace defaults.
- Added UI region selector with India default.
- Added region safety rules: no permission/legal/platform bypass and no automatic affiliate account creation.
- Added regional regression tests.
