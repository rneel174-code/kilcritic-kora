# Traceability matrix (generated from the real test registry and the files supplied in this chat)

## Important limitation
The owner's *numbered list of 100 prompts* is **NOT RECOVERABLE**: no single file or message in the available uploads/context contains a numbered 100-prompt list. Nothing below is invented to fill that gap. Part A lists the real source documents that WERE found; Part B maps the master-task requirements to existing tests.

## Part A - recovered source documents (unique by SHA-256)

| # | Title (first line) | Bytes | SHA-256 (12) | Uploaded as |
|---|---|---|---|---|
| 1 | Changelog | 1643 | 64ac1ef10515 | 0b752fd8-KILCRITIC_KORA_SUPREME_5_0_FULL_SYSTEM_OWNER_PACK.z |
| 2 | KILCRITIC + KORA + PARMANU — MASTER INTEGRATION BLUEPRINT | 34347 | 63f38150e088 | ef02fc17-KILCRITIC_KORA_PARMANU_GOD_MODE_LOCKED_BLUEPRINT.zi (+1 duplicate copies) |
| 3 | KILCRITIC + KORA + PARMANU — MASTER INTEGRATION BLUEPRINT | 22372 | a74ed71a7147 | 83e7ee7f-KILCRITIC_KORA_PARMANU_MASTER_BLUEPRINT.zip |
| 4 | KILCRITIC / KORA — FINAL MASTER CTO AUDIT + IMPLEMENTATION TASK | 24161 | 6524d4bcc460 | 307a1fc2-attachment.txt |
| 5 | KILCRITIC / KORA — SELF-EVOLUTION 3.0 | 16825 | e008879269f3 | 4fd2b0c1-KILCRITIC_KORA_SELF_EVOLUTION_3.0_GOOD_FATHER_MASTE (+1 duplicate copies) |
| 6 | KILCRITIC / KORA — SELF-EVOLVING BRAIN + CAPABILITY FACTORY | 39770 | 031d35ff40fe | 4c846752-KILCRITIC_KORA_SELF_EVOLVING_BRAIN_MASTER_CLAUDE_CO (+1 duplicate copies) |
| 7 | KILCRITIC 6.5 CTO HARDENED CHANGELOG | 2028 | cebd5b8bbc9c | a2d30178-KILCRITIC_SUPREM_AUTOPILOT_V8_8_0_KORA_DURABLE_WORK |
| 8 | KILCRITIC Additive Upgrade Contract | 1055 | ba3ecd9f6e3c | a2d30178-KILCRITIC_SUPREM_AUTOPILOT_V8_8_0_KORA_DURABLE_WORK |
| 9 | KILCRITIC INFINITE / SUPREME ENGINE | 32479 | c5adb0a8a242 | a32a3d82-KILCRITIC_INFINITE_MASTER_CTO_BLUEPRINT__1_.txt |
| 10 | KILCRITIC INFINITE — Coding Kit | 460 | 94a3a02b760e | b9c4d69c-KILCRITIC_INFINITE_CODING_KIT.zip |
| 11 | KILCRITIC KORA 10.5.0 — MASTER HUD + HOLLYWOOD STUDIO RESTORE SPEC CTO | 14488 | 5716e30196f0 | 6113b5be-KILCRITIC_KORA_HUD_HOLLYWOOD_STUDIO_MASTER_SPEC.txt |
| 12 | KILCRITIC KORA 8.7.0 — UNIVERSAL CTO HARDENED | 1384 | e23dd00ca5aa | a2d30178-KILCRITIC_SUPREM_AUTOPILOT_V8_8_0_KORA_DURABLE_WORK |
| 13 | KILCRITIC KORA 8.7.2 — Universal Test Matrix | 2316 | 94b7c0aa8649 | a2d30178-KILCRITIC_SUPREM_AUTOPILOT_V8_8_0_KORA_DURABLE_WORK |
| 14 | KILCRITIC KORA SUPREME — OWNER CONTROL (SAFE KB) | 1320 | c18a618cc342 | 0b752fd8-KILCRITIC_KORA_SUPREME_5_0_FULL_SYSTEM_OWNER_PACK.z |
| 15 | KILCRITIC KORA — REAL COMPETITIVE CAPABILITY UPGRADE COMMAND | 8747 | aa90a5ba46a2 | 98d5df91-KILCRITIC_KORA_REAL_COMPETITIVE_CAPABILITY_UPGRADE. |
| 16 | KILCRITIC SUPREME 10.2 — audit report | 3347 | add0b84f254f | 0b752fd8-KILCRITIC_KORA_SUPREME_5_0_FULL_SYSTEM_OWNER_PACK.z |
| 17 | KILCRITIC SUPREME 10.2.1 (KORA governed self-evolution release) | 4118 | 42316ded9d56 | 0b752fd8-KILCRITIC_KORA_SUPREME_5_0_FULL_SYSTEM_OWNER_PACK.z |
| 18 | KILCRITIC SUPREME ENGINE 8.6.3 — KORA CONTINUOUS FACE OS | 11327 | cd8ab598a0e0 | a2d30178-KILCRITIC_SUPREM_AUTOPILOT_V8_8_0_KORA_DURABLE_WORK |
| 19 | KILCRITIC SUPREME — FINAL MASTER BUILD COMMAND | 19060 | 6365f743ac40 | 88611c5f-KILCRITIC_SUPREME_FINAL_MASTER_CLAUDE_COMMAND.txt (+1 duplicate copies) |
| 20 | KILCRITIC SUPREME — FINAL MASTER COMMAND FOR KORA 8.10.0 | 10984 | b7211c9ead4b | 4cfa5ea0-KILCRITIC_SUPREME_KORA_8.10.0_FINAL_MASTER_COMMAND_ |
| 21 | KILCRITIC/KORA/PARMANU GOD MODE LOCKED BLUEPRINT | 198 | 119af6fabdd8 | ef02fc17-KILCRITIC_KORA_PARMANU_GOD_MODE_LOCKED_BLUEPRINT.zi (+1 duplicate copies) |
| 22 | KORA / KILCRITIC SUPREME | 17435 | 96e2817d9cc0 | a403fcb7-KORA_KILCRITIC_ALL_20_INTELLIGENCE_ADDITIONS_COMPLE |
| 23 | KORA / KILCRITIC — FINAL PRACTICAL UPGRADE & FREEZE COMMAND | 12764 | f5606efb6ccd | caa89f9d-KORA_KILCRITIC_FINAL_PRACTICAL_FREEZE_COMMAND.zip (+2 duplicate copies) |
| 24 | KORA / KILCRITIC — ULTIMATE MASTER CTO ENGINEERING CONSTITUTION | 12603 | 491fb35c4a35 | 85e5ef7d-KORA_KILCRITIC_ULTIMATE_MASTER_CTO_CONSTITUTION.zip (+2 duplicate copies) |
| 25 | KORA 8.7.1 — CLEAN EXECUTIVE RELEASE | 563 | ea2e5fecaad3 | a2d30178-KILCRITIC_SUPREM_AUTOPILOT_V8_8_0_KORA_DURABLE_WORK |
| 26 | KORA 8.7.2 — BRAHMA SAFE IMPROVEMENT + RATE LIMIT HARDENING | 1039 | 4d65a3aaccbf | a2d30178-KILCRITIC_SUPREM_AUTOPILOT_V8_8_0_KORA_DURABLE_WORK |
| 27 | KORA/KILCRITIC — CLAUDE CONTINUE PROMPT | 1688 | 0a44f9970231 | 5215bc11-KORA_CLAUDE_LOCK11_SHORT_CONTINUE_PROMPT.zip |
| 28 | PARMANU SOVEREIGN EXECUTIVE MASTER COMMAND | 12393 | d7ded8aacf03 | a1794a9a-PARMANU_SOVEREIGN_EXECUTIVE_MASTER_COMMAND.txt (+1 duplicate copies) |
| 29 | Store persistent state here only after applying encryption/access controls appro | 148 | 7e51b1f152bd | b9c4d69c-KILCRITIC_INFINITE_CODING_KIT.zip |
| 30 | V8.6.0 — KORA UNIVERSAL HUD | 1684 | 31a1c1bd610b | a2d30178-KILCRITIC_SUPREM_AUTOPILOT_V8_8_0_KORA_DURABLE_WORK |
| 31 | V8.6.2 — KORA Universal HUD hotfix | 481 | d13a94668340 | a2d30178-KILCRITIC_SUPREM_AUTOPILOT_V8_8_0_KORA_DURABLE_WORK |
| 32 | V8.8.0 — KORA Durable Worker / Disk Queue | 466 | e9d0c3ddc487 | a2d30178-KILCRITIC_SUPREM_AUTOPILOT_V8_8_0_KORA_DURABLE_WORK |
| 33 | fastapi>=0.115 | 254 | 04729b3a1121 | a2d30178-KILCRITIC_SUPREM_AUTOPILOT_V8_8_0_KORA_DURABLE_WORK |

_The documents were read as sources for constraints and scope; each was not re-audited line by line in this release. Several are blueprints/commands, not implemented-feature lists._

## Part B - requirement -> tests (a matching test proves the behaviour in a mocked/unit setting only; it is NOT a real-world integration result)

_Matching is by keyword in test names, so a few listed tests are only loosely related; a requirement with no listed test is a real gap._

| Req | Requirement | Matching tests in the registry | Evidence class | Gap / limitation |
|---|---|---|---|---|
| C1 | Test runner timeout / progress / never PASS on timeout | T190, T157, T29 | unit/mock tests (PASS in suite run) |  |
| C2 | AI providers: truthful state, NOT_IMPLEMENTED, fallback is not an LLM | T98, T107, T88, T201, T202, T41, T192, T193, T194, T195, T197, T199, T06, T21 ...(+1) | unit/mock tests (PASS in suite run) | No real provider call made; HEALTHY needs one real success |
| C3 | Single version source; stale UI version caught | T46, T85, T27, T57 | unit/mock tests (PASS in suite run) | HUD string re-check is covered only if a matching test exists |
| C4 | Autopilot job outcome / durable record / no duplicate external action | T152, T50, T200, T23, T24, T26, T34, T37, T143, T146, T135, T151 | unit/mock tests (PASS in suite run) |  |
| C5 | Health probes, events, audit-chain detail | T186, T189, T180, T181, T113, T114, T156, T165, T172, T178, T92, T94, T204, T36 ...(+9) | unit/mock tests (PASS in suite run) |  |
| C6 | Safe-mode consistency (API/UI/worker/publish) | T181, T97, T116, T44, T49, T53, T87, T200, T56 | unit/mock tests (PASS in suite run) |  |
| C7 | Improve Me / self-scan evidence-backed | T187, T98, T105, T172, T202, T141, T145, T148, T70, T67, T128 | unit/mock tests (PASS in suite run) |  |
| C8 | Growth / Dhanda truthfulness, ROI levels | T120, T117, T158, T160, T165, T64 | unit/mock tests (PASS in suite run) | No real revenue/leads exist; estimates only |
| C9 | Backup checksum + isolated restore | T189, T113, T161, T168, T172, T86, T09, T10, T57, T58 | unit/mock tests (PASS in suite run) | Restore verified in temp DBs only; owner's real backup file not available here |
| C10 | Resources / workers / back-pressure | T119, T107, T108, T110, T116, T154, T155, T172, T87, T200, T27, T28, T31, T42 ...(+4) | unit/mock tests (PASS in suite run) |  |
| C11 | Scheduling + publishing states, verification, mock adapters | T99, T113, T114, T152, T156, T158, T159, T45, T47, T52, T173, T177, T84, T202 ...(+11) | unit/mock tests (PASS in suite run) | Real platform publish: NOT_RUN (needs credentials + owner authorisation); mocks only |
| C12 | Hollywood Studio / ffmpeg / export / quality | T120, T162, T170, T174, T175, T176, T178, T13, T14, T65, T68, T128, T129, T136 | unit/mock tests (PASS in suite run) | H.264 decode and 4K/AI-video claims not verified here; ffmpeg edits tested with fixtures |
| C13 | Voice: consent, STT, command routing (live mic NOT tested) | T180, T181, T171, T172, T78, T06, T07, T08, T56, T67, T69, T130 | unit/mock tests (PASS in suite run) | Live microphone, real STT/TTS, Punjabi recognition: NOT_RUN (needs a real device) |
| C14 | Owner security: auth, approval, 2FA boundary | T186, T188, T189, T190, T97, T101, T112, T118, T152, T160, T161, T165, T45, T53 ...(+32) | unit/mock tests (PASS in suite run) | 2FA setup flow not exercised; loopback = owner is existing design |
| E | Command routing / command library (Phase 2) | T186, T191, T179, T180, T181, T171, T94, T56, T69 | unit/mock tests (PASS in suite run) |  |
| F | Governed self-improvement (prepare/gate/canary/rollback/freeze) | T96, T97, T101, T102, T104, T106, T108, T109, T111, T112, T113, T114, T166, T115 ...(+14) | unit/mock tests (PASS in suite run) |  |
| G | Research / SSRF / injection guard | T109, T81, T39, T40, T195, T17, T144, T147, T148, T62, T136 | unit/mock tests (PASS in suite run) |  |
| NEW | GAP_NO_AI_PROVIDER, provider comparison, owner_actions | T192, T193, T194, T195, T196, T197 | unit/mock tests (PASS in suite run) | See CHANGELOG; no real-device or live-provider evidence |
| NEW | Router telemetry, capability evidence, assessment, metrics, egress | T102, T106, T110, T165, T53, T95, T200, T201, T202, T203, T204, T205, T68 | unit/mock tests (PASS in suite run) | See CHANGELOG; no real-device or live-provider evidence |

Registry size: 205 tests discovered by scanning run_test() calls.
