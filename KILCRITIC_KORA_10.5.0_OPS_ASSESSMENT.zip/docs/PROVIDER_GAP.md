# Provider gap: what was added and what is NOT claimed

## Behaviour
1. `GET /api/evolution/3/gaps` lists `GAP_NO_AI_PROVIDER` (HIGH) only when no external provider is usable (adapter exists AND key present AND breaker not open).
   The deterministic local rule engine is reported in the evidence as "AVAILABLE (not an AI provider)".
2. `POST /api/evolution/3/cycle` creates (once, de-duplicated) a `CONNECT_AI_PROVIDER` proposal with `owner_actions` and a provider comparison.
3. `GET /api/evolution/3/providers` returns the comparison and owner actions without any network call. Only environment-variable NAMES are returned.
4. `GET /api/governance/proposals/<id>` shows `owner_actions`, `comparison`, `guarantees`.
5. Approving that proposal is a recorded decision only. Nothing is installed, connected, enabled or charged.

## Owner steps (Malak)
Choose a provider -> create the account/key yourself -> put the key in your own `.env` (never in chat or logs) -> restart KORA -> re-run discovery -> approve one small real test call.

## Research
Owner-supplied official URLs (`urls` in the cycle body) or Brave search if `BRAVE_SEARCH_API_KEY` is configured. Otherwise `NOT_CONFIGURED`. Pages/links are attached as evidence; privacy and retention terms stay `UNKNOWN` until Malak reads them.

## Not verified / not claimed
No real provider call was made; a provider is never reported HEALTHY without one real success. No end-to-end provider integration is claimed. An open provider proposal is not auto-closed when a key later appears (re-run discovery; reject or ignore it).
