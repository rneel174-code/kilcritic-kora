# Ops assessment, metrics, router telemetry, egress probe

## What is real
- Router telemetry is measured in-process from real calls since start (resets on restart). With no calls the values are `null` (UNKNOWN), never 0.
- Capability `verification.state` comes from observation (PRESENT / IMPLEMENTED / CONFIGURED / OPERATIONAL / NOT_CONFIGURED / NOT_IMPLEMENTED / DEGRADED / UNKNOWN). `VERIFIED` is never assigned automatically.
- `POST /api/assessment/run` is read-only: it does not run tests, touch the network, create proposals/jobs or change code, cron, models or credentials. It refuses when safe mode is ON or evolution is frozen.
- `POST /api/egress/probe` is the only network-touching function: a TCP connect (no data sent) to 1.1.1.1:443 and 8.8.8.8:53. REACHABLE proves outbound access exists (the runtime is NOT offline). Failure cannot distinguish a firewall from no network and is not an air-gap proof.

## Not claimed
No cost/token figures (none are recorded), no model benchmark, no live provider call, no Docker/Ollama/agent framework, no speed-up.

## Optional scheduling (owner action)
Create a cron entry through the existing scheduler API for handler `readonly_assessment` (e.g. `0 */6 * * *`). Nothing is scheduled by default.

## Launch
`python3 run.py` (set `KORA_AUTH_TOKEN`; keys only in your own `.env`). Check: `GET /api/health`, `GET /api/metrics`, `POST /api/assessment/run`.

## Rollback
This release only adds files/functions. Roll back by restoring the previous ZIP (`KILCRITIC_KORA_10.5.0_PHASE2_PROVIDER_GAP.zip`, SHA-256 39d926b7...) into a new folder; the database schema is unchanged (new data is only `assess.*` settings keys, safe to ignore).
