(()=>{
'use strict';
// KORA mounted HUD ('/'). Voice, text and touch all go through dispatch() -> KoraIntent -> real actions or the single backend dispatcher /api/brain.
const KEY='kora.creator.desktop.v2', TASK_KEY='kora.task.v1';
const I=window.KoraIntent;
const categories=[
 {id:'social',icon:'🌐',name:'Social Publishing',desc:'YouTube • Facebook • Instagram • TikTok • X',go:'publish'},
 {id:'studio',icon:'🎬',name:'Hollywood Studio',desc:'Import • edit • preview • export',go:'studio'},
 {id:'editing',icon:'✂️',name:'Editing',desc:'Trim • crop • rotate • text • color • audio',go:'studio'},
 {id:'animation',icon:'🎨',name:'3D • 4D • 5D',desc:'OPTIONAL HEAVY — not implemented in this build',go:'future'},
 {id:'fun',icon:'😂',name:'Funny + Baby',desc:'Edit your own clips (audience mode applies)',go:'studio'},
 {id:'media',icon:'🖼️',name:'Media',desc:'Library • photos • videos • audio',go:'studio'},
 {id:'convert',icon:'🔄',name:'Convert + Quality',desc:'Presets • compress • quality check',go:'studio'},
 {id:'storymovie',icon:'📖',name:'Story → Movie',desc:'Planning only — generation NOT implemented',go:'brain'},
 {id:'voice',icon:'🎙️',name:'Voice + Text',desc:'Speak, type or touch — same command brain',go:'voice'},
 {id:'publish',icon:'🚀',name:'Post + Autopilot',desc:'Draft • approval • schedule',go:'publish'},
 {id:'research',icon:'🔎',name:'Research + Search',desc:'Needs a configured source; no fake trends',go:'brain'},
 {id:'growth',icon:'📈',name:'Growth + Dhanda',desc:'Evidence-gated analytics',go:'brain'},
];
const defaults=[{id:'master',icon:'📁',name:'MEDIA + SOCIAL + STUDIO',x:window.innerWidth/2-45,y:window.innerHeight*.64,hidden:false,type:'folder',locked:true}];
let items=null; try{items=JSON.parse(localStorage.getItem(KEY)||'null');}catch(e){}
if(!Array.isArray(items)||!items.length) items=defaults;
const $=id=>document.getElementById(id);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function save(){try{localStorage.setItem(KEY,JSON.stringify(items));}catch(e){}}

// ---------------------------------------------------------------- API (never turns a failure into success)
let token='',lang='pa-IN';
try{token=sessionStorage.getItem('kora_token')||'';lang=sessionStorage.getItem('kora_lang')||lang;}catch(e){}
let inflight=null;
async function api(method,url,body,opts){
  const h={'Content-Type':'application/json'}; if(token)h.Authorization='Bearer '+token;
  const ctl=new AbortController(); if(!opts||!opts.background)inflight=ctl;
  try{
    const r=await fetch(url,{method,headers:h,body:body?JSON.stringify(body):undefined,signal:ctl.signal});
    let j={}; try{j=await r.json();}catch(e){}
    return {status:r.status,ok:r.ok&&j.ok!==false,json:j};
  }catch(e){
    return {status:0,ok:false,json:{error:e&&e.name==='AbortError'?'cancelled':'unreachable'}};
  }finally{ if(inflight===ctl)inflight=null; }
}
const errText=r=>r.status===429?('Too many heavy jobs right now ('+(r.json.detail||'rate limited')+'). Wait a few seconds and try again.'):r.status===401||r.status===403?'Access needs the owner token (Advanced → Owner token).':(r.json.detail||r.json.error||r.json.message||('HTTP '+r.status));

// ---------------------------------------------------------------- truthful state + task checkpoint
const task={id:null,label:'No active task',state:'IDLE',result:'KORA is ready. Type, speak or tap.',view:'home',source:null,text:null,asset:null,project:null};
function persist(){try{localStorage.setItem(TASK_KEY,JSON.stringify({label:task.label,state:task.state,result:task.result,view:task.view,text:task.text,asset:task.asset,project:task.project,ts:Date.now()}));}catch(e){}}
function setState(s,label,result,extra){
  if(I.STATES.indexOf(s)<0)s='ERROR';
  task.state=s; if(label!=null)task.label=label; if(result!=null)task.result=result; if(extra)Object.assign(task,extra);
  $('faceState').textContent=s;$('workState').textContent=s;$('taskState').textContent=s;$('taskState').dataset.state=s;
  $('taskLabel').textContent=task.label;$('taskResult').textContent=task.result;
  $('taskCancel').classList.toggle('hidden',!(s==='THINKING'||s==='WORKING'));
  persist();
}
function loadCheckpoint(){
  let c=null; try{c=JSON.parse(localStorage.getItem(TASK_KEY)||'null');}catch(e){}
  if(c&&c.label&&c.label!=='No active task'){
    task.view=c.view||'home';task.asset=c.asset||null;task.project=c.project||null;task.text=c.text||null;
    $('taskLabel').textContent='Last task: '+c.label;
    $('taskResult').textContent='Not running now. '+(c.result||'');
    $('taskResume').classList.remove('hidden');
  }
}

// ---------------------------------------------------------------- views
function show(view){
  $('home').classList.toggle('hidden',view!=='home');
  $('workspace').classList.toggle('hidden',view==='home');
  ['studio','publishPanel'].forEach(id=>$(id).classList.add('hidden'));
  $('categoryGrid').classList.toggle('hidden',view==='studio'||view==='publish');
  task.view=view; persist();
}
function goHome(){show('home');$('result').textContent='';}
function openWorkspace(title){show('workspace');$('workspaceTitle').textContent=title;renderCategories();}
function openStudio(){show('studio');$('workspaceTitle').textContent='🎬 Hollywood Studio';$('studio').classList.remove('hidden');studioInit();}
function openPublish(platform){show('publish');$('workspaceTitle').textContent='🚀 Post + Autopilot';$('publishPanel').classList.remove('hidden');if(platform)selectPlatform(platform);publishInit();}
function openSys(){$('sysPanel').classList.remove('hidden');}
function render(){const root=$('desktopIcons');root.innerHTML='';items.filter(i=>!i.hidden&&i.id!=='master').forEach(item=>{const e=document.createElement('div');e.className='icon';e.dataset.id=item.id;item.x=Math.max(4,Math.min(window.innerWidth-96,item.x));item.y=Math.max(62,Math.min(window.innerHeight-145,item.y));e.style.left=item.x+'px';e.style.top=item.y+'px';e.innerHTML=`<span class="icon-symbol">${esc(item.icon||'📁')}</span><span class="icon-label">${esc(item.name)}</span>`;root.appendChild(e);drag(e,item);e.addEventListener('dblclick',()=>openItem(item));e.addEventListener('click',()=>{if(item.id==='master')openItem(item)});e.oncontextmenu=ev=>{ev.preventDefault();if(!item.locked)hide(item.id)};let timer; e.addEventListener('touchstart',()=>{timer=setTimeout(()=>{if(!item.locked)hide(item.id)},850)},{passive:true});e.addEventListener('touchend',()=>clearTimeout(timer));});save()}
function drag(el,item){let sx=0,sy=0,ox=0,oy=0,m=false;el.addEventListener('pointerdown',e=>{m=true;sx=e.clientX;sy=e.clientY;ox=item.x;oy=item.y;el.setPointerCapture?.(e.pointerId)});el.addEventListener('pointermove',e=>{if(!m)return;item.x=Math.max(4,Math.min(window.innerWidth-96,ox+e.clientX-sx));item.y=Math.max(62,Math.min(window.innerHeight-145,oy+e.clientY-sy));el.style.left=item.x+'px';el.style.top=item.y+'px'});el.addEventListener('pointerup',()=>{m=false;save()});el.addEventListener('pointercancel',()=>{m=false;save()})}
function openItem(item){ if(item.id==='master'||item.type==='folder'){openWorkspace(item.icon+' '+item.name);} else {setState('COMPLETE',item.name,'This custom item is a shortcut label only; no action is attached.');} }
function renderCategories(){const g=$('categoryGrid');g.innerHTML=categories.map(c=>`<button class="category" data-cat="${c.id}"><b>${c.icon} ${esc(c.name)}</b><small>${esc(c.desc)}</small></button>`).join('');g.querySelectorAll('[data-cat]').forEach(b=>b.onclick=()=>runCategory(b.dataset.cat))}
function runCategory(id){
  const c=categories.find(x=>x.id===id); if(!c)return;
  if(c.go==='studio')return openStudio();
  if(c.go==='publish')return openPublish();
  if(c.go==='voice')return voice();
  if(c.go==='future'){setState('COMPLETE',c.name,'3D/4D/5D rendering is an OPTIONAL HEAVY feature and is NOT implemented in this build (no rendering engine installed). Nothing was generated.');$('result').textContent=task.result;return;}
  return dispatch('Open '+c.name+' workflow','touch');
}
function hide(id){const i=items.find(x=>x.id===id);if(i&&!i.locked){i.hidden=true;save();render()}}
function drawer(){const d=$('drawer');d.classList.remove('hidden');const l=$('drawerList');l.innerHTML=items.map(i=>`<div class="drawer-row"><span>${esc(i.icon)} ${esc(i.name)}</span><button data-id="${esc(i.id)}" data-a="${i.hidden?'show':'hide'}">${i.hidden?'Show':'Hide'}</button></div>`).join('')+`<div class="drawer-row"><span>📁 MEDIA + SOCIAL + STUDIO</span><small>Master folder is always available</small></div>`;l.querySelectorAll('button').forEach(b=>b.onclick=()=>{const i=items.find(x=>x.id===b.dataset.id);if(i&&!i.locked){i.hidden=b.dataset.a==='hide';save();drawer()}})}
function add(){$('modal').classList.remove('hidden');$('newName').focus()}
function saveAdd(){const n=$('newName').value.trim();if(!n)return;const type=$('newType').value;items.push({id:'custom-'+Date.now(),icon:type==='folder'?'📁':type==='file'?'📄':'⚡',name:n,x:20+(items.length%6)*110,y:80+Math.floor(items.length/6)*88,hidden:false,type});save();$('modal').classList.add('hidden');$('newName').value='';render()}

// ---------------------------------------------------------------- the ONE dispatcher (voice + text + touch)
async function dispatch(text,source){
  const intent=I.resolve(I.parse(text),{mediaLoaded:!!player.el,studioOpen:!$('studio').classList.contains('hidden')});
  if(intent.act==='empty')return;
  task.text=text; task.source=source||'text';
  switch(intent.act){
    case 'open_studio': setState('COMPLETE','Studio','Studio opened.'); return openStudio();
    case 'open_advanced': setState('COMPLETE','Advanced / System','Advanced panel opened.'); return openSys();
    case 'back': setState('COMPLETE','Back','Returned to the desktop.'); return goHome();
    case 'play': return player.play();
    case 'pause': return player.pause();
    case 'stop': return player.stop();
    case 'save_draft': return saveDraft();
  }
  // everything else: the single backend dispatcher. High-impact words are never executed locally; the backend permission/approval engine decides.
  setState('THINKING',text.slice(0,60),'Waiting for KORA…');
  const r=await api('POST','/api/brain',{text,source:source||'text',voice_verified:false});
  const j=r.json;
  if(r.status===0){return setState('ERROR',text.slice(0,60),j.error==='cancelled'?'Stopped. The request was abandoned; the server may still have processed it.':'KORA is unreachable. Nothing was executed.');}
  if(!r.ok&&r.status!==200){return setState('ERROR',text.slice(0,60),errText(r)+'. Nothing was claimed as done.');}
  const msg=j.message||j.detail||j.error||'';
  if(j.status==='NEEDS_CLARIFICATION'){return setState('IDLE',text.slice(0,60),(msg||'I did not understand that.')+(j.examples?' Try: '+j.examples.slice(0,6).join(' • '):''));}
  if(j.status==='STEP_UP_REQUIRED'||j.status==='NEEDS_APPROVAL'||j.status==='APPROVAL_REQUIRED'){return setState('NEEDS APPROVAL',text.slice(0,60),msg||'Owner approval is required.');}
  if(j.ok===false||j.status==='DENIED'||j.status==='REFUSED'||j.status==='ERROR'||j.status==='INVALID'){return setState('ERROR',text.slice(0,60),(j.status?'['+j.status+'] ':'')+(msg||'Request was not completed.'));}
  setState('COMPLETE',text.slice(0,60),(j.status?'['+j.status+'] ':'')+(msg||'Accepted; nothing executed yet.'));
  $('result').textContent=task.result;
}

// ---------------------------------------------------------------- voice (same dispatcher; text and touch stay functional without it)
function voice(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){setState('ERROR','Voice','Voice input is not available in this browser. Text and touch still work.');return;}
  const r=new SR(); r.lang=lang; r.interimResults=false;
  setState('LISTENING','Voice','Listening… speak now ('+lang+').');
  r.onresult=e=>{const t=e.results[0][0].transcript.trim();$('homeCommand').value=t;$('command').value=t;
    const it=I.parse(t); if(it.high_impact&&!window.confirm('Heard: “'+t+'”. This looks high-impact (publish/pay/delete). KORA will still ask for owner approval. Send it?')){setState('IDLE','Voice','Cancelled: '+t);return;}
    dispatch(t,'voice');};
  r.onerror=ev=>setState('ERROR','Voice',ev&&ev.error==='not-allowed'?'Microphone permission was denied. Text and touch still work.':'Voice recognition error ('+(ev&&ev.error||'unknown')+'). Text and touch still work.');
  r.onend=()=>{if(task.state==='LISTENING')setState('IDLE','Voice','No speech recognised.');};
  try{r.start();}catch(e){setState('ERROR','Voice','Could not start the microphone.');}
}

// ---------------------------------------------------------------- activity (real /api/active)
async function refreshActive(){
  if($('home').classList.contains('hidden'))return;
  const r=await api('GET','/api/active',null,{background:true}); const box=$('activity'); box.textContent='';
  if(!r.ok){const d=document.createElement('div');d.textContent=r.status===0?'Backend unreachable.':errText(r);box.appendChild(d);return;}
  const j=r.json,run=j.running||[],q=j.queued||[],ap=j.approvals||null,na=ap?ap.total:(j.needs_approval||[]).length+(j.proposals||[]).length;
  const chips=[['Running',run.length],['Queued',q.length],['Needs approval',na]];
  if(ap&&ap.approved_not_executed)chips.push(['Approved, not executed',ap.approved_not_executed]);
  chips.forEach(x=>{const d=document.createElement('span');d.className='chip';d.textContent=x[0]+': '+x[1];box.appendChild(d);});
  if(j.safe_mode||j.kill_switch){const d=document.createElement('span');d.className='chip bad';d.textContent=j.kill_switch?'FROZEN (kill switch)':'SAFE MODE';box.appendChild(d);}
  if(['IDLE','COMPLETE','NEEDS APPROVAL'].indexOf(task.state)>=0&&!inflight){
    if(run.length)setState('WORKING','Background work',(run[0].handler_name||'job')+' running');
    else if(na)setState('NEEDS APPROVAL','Decisions waiting',na+' item(s) need the owner'+(ap?' ('+ap.posts+' post, '+ap.proposals+' proposal, '+ap.high_risk+' high-risk).':'.'));
    else if(task.state==='NEEDS APPROVAL'||task.state==='WORKING')setState('IDLE','No active task','KORA is ready.');
  }
}

// ---------------------------------------------------------------- Studio
const player={el:null,url:null,
  load(blob,mime){this.clear();const k=mime.split('/')[0];const el=document.createElement(k==='image'?'img':k);if(k!=='image'){el.controls=false;el.preload='metadata';el.playsInline=true;}
    this.url=URL.createObjectURL(blob);el.className='stage-media';el.addEventListener('error',()=>{$('stageMsg').textContent='This file cannot be decoded by the browser (unsupported or corrupt codec).';});
    if(k!=='image'){el.addEventListener('timeupdate',()=>tick());el.addEventListener('loadedmetadata',()=>tick());el.addEventListener('ended',()=>setState('COMPLETE','Preview','Playback finished.'));}
    el.src=this.url;$('stageEmpty').classList.add('hidden');$('stage').appendChild(el);this.el=k==='image'?null:el;this.img=k==='image';this.node=el;},
  clear(){if(this.node){this.node.remove();}if(this.url){URL.revokeObjectURL(this.url);}this.el=null;this.node=null;this.url=null;$('stageEmpty').classList.remove('hidden');$('pSeek').value=0;$('pTime').textContent='0:00 / 0:00';},
  play(){if(!this.el){setState('ERROR','Preview',this.img?'Images have no playback; they are displayed.':'Nothing is loaded. Select a file first.');return;}
    this.el.play().then(()=>setState('WORKING','Preview','Playing '+(task.asset||'')+' (preview only, not published).')).catch(e=>setState('ERROR','Preview','Playback blocked or failed: '+(e&&e.message||'unknown')));},
  pause(){if(this.el){this.el.pause();setState('IDLE','Preview','Paused.');}},
  stop(){if(this.el){this.el.pause();this.el.currentTime=0;setState('IDLE','Preview','Stopped.');tick();}},
  seek(f){if(this.el&&isFinite(this.el.duration))this.el.currentTime=f*this.el.duration;}
};
function fmt(s){s=Math.max(0,s||0);return Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0');}
function tick(){const e=player.el;if(!e)return;const d=e.duration||0;$('pSeek').value=d?Math.round(1000*e.currentTime/d):0;$('pTime').textContent=fmt(e.currentTime)+' / '+fmt(d);}
let caps=null,hist=[],hidx=-1,assets=[],studioReady=false;
async function studioInit(){
  if(!studioReady){
    const r=await api('GET','/api/studio/capabilities',null,{background:true});
    if(r.ok){caps=r.json;$('studioCaps').textContent=(caps.ffmpeg?'ffmpeg ready':'ffmpeg NOT installed — edits unavailable')+(caps.drawtext_text_overlay?'':' • text overlay unavailable');
      $('exPreset').innerHTML=(caps.export_presets||[]).map(p=>`<option>${esc(p)}</option>`).join('');
      $('futureList').textContent='Not implemented / optional heavy: '+(caps.not_implemented||[]).join(', ')+'. 4K export: '+(caps.uhd_4k_export||'');
      studioReady=true;}
    else $('studioCaps').textContent='Studio backend unavailable: '+errText(r);
  }
  await refreshAssets(); await refreshProjects();
}
async function refreshAssets(){
  const r=await api('GET','/api/studio/assets',null,{background:true}); const box=$('assetList'); box.textContent='';
  if(!r.ok){box.textContent='Library unavailable: '+errText(r);return;}
  assets=r.json.items||[];
  if(!assets.length){box.textContent='Library is empty. Use Import to add a video, audio or image.';return;}
  assets.forEach(a=>{const b=document.createElement('button');b.className='asset'+(a.id===task.asset?' sel':'');b.setAttribute('role','option');b.textContent=({video:'🎞 ',audio:'🎵 ',image:'🖼 '}[a.kind]||'')+a.id+' ('+(a.bytes/1048576).toFixed(1)+' MB)';b.onclick=()=>selectAsset(a.id,true);box.appendChild(b);});
}
async function selectAsset(id,reset){
  task.asset=id; if(reset){hist=[id];hidx=0;} persist();
  $('stageMsg').textContent='Loading preview…';
  const r=await api('POST','/api/studio/preview',{id});
  if(!r.ok){player.clear();$('stageMsg').textContent=r.status===413?'Too large for inline preview — export “preview_480p” first.':'Preview failed: '+errText(r);return false;}
  const bin=atob(r.json.data_b64),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);
  player.load(new Blob([u],{type:r.json.mime}),r.json.mime);$('stageMsg').textContent=id+' loaded ('+r.json.mime+'). Preview only — nothing is published.';
  document.querySelectorAll('#assetList .asset').forEach(b=>b.classList.toggle('sel',b.textContent.indexOf(id+' (')>=0));
  return true;
}
async function importFile(file){
  if(!file)return; const max=(caps&&caps.max_upload_mb)||200;
  if(file.size>max*1048576){$('importStatus').textContent='Too large (limit '+max+' MB).';return;}
  setState('WORKING','Import',file.name);
  const CH=512*1024,total=Math.max(1,Math.ceil(file.size/CH)); let last=null;
  for(let i=0;i<total;i++){
    const part=file.slice(i*CH,(i+1)*CH);
    const b64=await new Promise((ok,no)=>{const fr=new FileReader();fr.onload=()=>ok(String(fr.result).split(',')[1]||'');fr.onerror=()=>no();fr.readAsDataURL(part);});
    $('importStatus').textContent='Uploading '+(i+1)+'/'+total+'…';
    last=await api('POST','/api/studio/upload',{name:file.name.replace(/[^A-Za-z0-9._-]/g,'_').slice(0,80),index:i,total,data_b64:b64});
    if(!last.ok){$('importStatus').textContent='Import failed: '+errText(last);return setState('ERROR','Import',errText(last));}
  }
  const j=last.json; $('importStatus').textContent=(j.state||'IMPORTED')+': '+j.id;
  setState('COMPLETE','Import',(j.state==='IMPORTED_VERIFIED'?'Imported and verified by ffprobe: ':'Imported but NOT verified (ffprobe unavailable): ')+j.id);
  await refreshAssets(); await selectAsset(j.id,true);
}
function opsFor(kind){
  const n=id=>{const v=$(id).value;return v===''?null:Number(v);};
  if(kind==='trim'){const s=n('trStart'),e=n('trEnd');return {trim:Object.assign({start:s==null?0:s},e==null?{}:{end:e})};}
  if(kind==='crop')return {crop:{aspect:$('cropAspect').value}};
  if(kind==='rotate')return {rotate:Number($('rotDeg').value)};
  if(kind==='resize'){const w=n('rsW'),h=n('rsH');if(!w||!h)return null;return {resize:{width:w,height:h}};}
  if(kind==='color'){const o={},b=Number($('clBr').value),c=Number($('clCo').value);if(b!==0)o.brightness=b;if(c!==1)o.contrast=c;if($('clFilter').value)o.filter=$('clFilter').value;return Object.keys(o).length?o:null;}
  if(kind==='text'){const t=$('txText').value.trim();return t?{text:{text:t,position:$('txPos').value}}:null;}
  if(kind==='audio'){if($('auMute').checked)return {audio:{mute:true}};const a={},v=Number($('auVol').value),fi=n('auFi'),fo=n('auFo');if(v!==1)a.volume=v;if(fi)a.fade_in=fi;if(fo)a.fade_out=fo;return Object.keys(a).length?{audio:a}:null;}
  if(kind==='export')return {export_preset:$('exPreset').value};
  return null;
}
async function applyEdit(kind){
  if(!task.asset){$('stageMsg').textContent='Select or import a file first.';return setState('ERROR','Edit','No asset selected.');}
  const ops=opsFor(kind); if(!ops){$('stageMsg').textContent='Nothing to apply: enter a value for this tool.';return;}
  setState('WORKING','Edit: '+kind,'Running ffmpeg on '+task.asset+'…'); $('stageMsg').textContent='Editing… (a new file is created; the original is kept)';
  const r=await api('POST','/api/studio/edit',{id:task.asset,ops});
  const j=r.json;
  if(!r.ok){const why=j.state?(j.state+': '+(j.reason||'')+(j.detail?' — '+j.detail:'')):errText(r);$('stageMsg').textContent='Edit not done — '+why;return setState('ERROR','Edit: '+kind,'Not done: '+why);}
  hist=hist.slice(0,hidx+1);hist.push(j.output);hidx=hist.length-1;
  const m=j.measured||{};
  setState('COMPLETE','Edit: '+kind,'Created '+j.output+' (verified by ffprobe: '+(m.width?m.width+'×'+m.height+', ':'')+(m.duration_s!=null?Number(m.duration_s).toFixed(1)+' s':'')+').');
  await refreshAssets(); await selectAsset(j.output,false);
}
async function undoRedo(d){const ni=hidx+d;if(ni<0||ni>=hist.length){$('stageMsg').textContent=d<0?'Nothing to undo.':'Nothing to redo.';return;}hidx=ni;await selectAsset(hist[hidx],false);}
async function qualityCheck(){
  if(!task.asset)return;const r=await api('POST','/api/studio/quality',{id:task.asset});const j=r.json;
  if(!r.status){return setState('ERROR','Quality','Unreachable.');}
  const c=j.checks||{};const t=(j.decision||'UNVERIFIED')+' — '+(c.aspect_ratio!=null?'aspect '+c.aspect_ratio+', ':'')+(c.file_size_mb!=null?c.file_size_mb+' MB, ':'')+(c.audio_present==null?'':'audio '+(c.audio_present?'yes':'NO')+', ')+'destination policy not evaluated.';
  $('stageMsg').textContent=t;setState(j.ok?'COMPLETE':'ERROR','Quality check',t);
}
async function refreshProjects(){const r=await api('GET','/api/studio/projects',null,{background:true});const s=$('projList');s.innerHTML='';if(!r.ok)return;(r.json.items||[]).forEach(p=>{const o=document.createElement('option');o.textContent=p.name;s.appendChild(o);});if(!s.options.length){const o=document.createElement('option');o.textContent='(no drafts yet)';o.disabled=true;s.appendChild(o);}}
async function saveDraft(){
  const name=($('projName').value.trim()||('draft-'+new Date().toISOString().slice(0,10)));
  if(!task.asset){return setState('ERROR','Save draft','Nothing to save: no asset selected.');}
  const r=await api('POST','/api/studio/projects/save',{name,data:{asset:task.asset,history:hist,idx:hidx}});
  if(!r.ok)return setState('ERROR','Save draft',errText(r));
  setState('COMPLETE','Draft saved','Saved locally as “'+name+'” (revision '+r.json.revision+'). Not published.',{project:name});await refreshProjects();
}
async function loadDraft(){
  const name=$('projList').value;if(!name||name.indexOf('(no')===0)return;const r=await api('POST','/api/studio/projects/load',{name});
  if(!r.ok)return setState('ERROR','Open draft',errText(r));
  const d=(r.json.data||{});hist=Array.isArray(d.history)?d.history.slice(0,200):[d.asset];hidx=Math.min(Number(d.idx)||0,hist.length-1);
  const ok=await selectAsset(hist[hidx]||d.asset,false);setState(ok?'COMPLETE':'ERROR','Draft opened',ok?'Opened “'+name+'”.':'Draft opened but its media file is missing.',{project:name});
}
async function approvalFromStudio(){
  if(!task.asset)return setState('ERROR','Approval','Select an asset first.');
  openPublish(); $('pubText').value=$('pubText').value||''; $('pubResult').textContent='Asset '+task.asset+' will be attached as a pending item. Write the caption, then “Save for approval”.';
}

// ---------------------------------------------------------------- Post panel (draft / approval only; no direct publish)
async function publishInit(){
  const r=await api('GET','/api/platforms/readiness',null,{background:true});
  if(r.ok){const p=r.json.platforms||{};$('platformStatus').textContent=Object.keys(p).map(k=>k+': '+p[k].status).join(' • ')+' • Amazon: NOT IMPLEMENTED';}
  else $('platformStatus').textContent='Platform status unavailable: '+errText(r);
}
function selectPlatform(p){const m={YouTube:'YOUTUBE',Facebook:'FACEBOOK',Instagram:'INSTAGRAM',TikTok:'TIKTOK',X:'X'};if(m[p])$('pubPlatform').value=m[p];}
async function pubDraft(){
  const content=$('pubText').value.trim(); if(!content)return ($('pubResult').textContent='Write the caption/text first.');
  const body={platform:$('pubPlatform').value,content,audience:$('pubAudience').value,idempotency_key:'ui-'+Date.now()};
  if(task.asset){body.studio_asset=task.asset;}
  setState('WORKING','Save for approval','Creating a pending item…');
  const r=await api('POST','/api/social/posts',body); const j=r.json;
  if(!r.ok){const t='Not saved: '+(j.detail||j.error||errText(r));$('pubResult').textContent=t;return setState('ERROR','Save for approval',t);}
  const t='Saved as '+(j.status||'pending')+' (id '+(j.id||j.post_id||'?')+'). NOT published; the owner must approve and platform credentials must be configured.';
  $('pubResult').textContent=t;setState('NEEDS APPROVAL','Waiting for owner approval',t);
}

// ---------------------------------------------------------------- Advanced / System (same real endpoints as the legacy console)
async function sys(kind){
  const out=$('sysOut');out.textContent='Working…';
  const show=(r,pick)=>{out.textContent=r.ok?JSON.stringify(pick?pick(r.json):r.json,null,1).slice(0,3500):('Failed: '+errText(r));};
  if(kind==='doctor'){return show(await api('POST','/api/doctor/heal'));}
  if(kind==='discovery'){return show(await api('GET','/api/providers'),j=>j.items);}
  if(kind==='backup'){return show(await api('POST','/api/backup/create'));}
  if(kind==='improve'){return show(await api('GET','/api/evolution/scan'));}
  if(kind==='resources'){return show(await api('GET','/api/ops'));}
  if(kind==='events'){return show(await api('GET','/api/active'));}
  if(kind==='audit'){return show(await api('GET','/api/audit/verify'));}
  if(kind==='tests'){if(!window.confirm('Run the full test suite now? It takes about a minute and does not touch live data.')){out.textContent='Cancelled.';return;}return show(await api('POST','/api/tests/run'),j=>({ok:j.ok,passed:j.passed,failed:j.failed,total:j.total}));}
  if(kind==='voice'){const l=window.prompt('Voice language (pa-IN, hi-IN, en-IN)',lang);if(l){lang=l.trim();try{sessionStorage.setItem('kora_lang',lang);}catch(e){}}out.textContent='Voice language: '+lang+'. Browser speech recognition support varies; text and touch always work.';return;}
  if(kind==='token'){const t=window.prompt('KORA owner access token (kept for this browser session only)');if(t!=null){token=t.trim();try{sessionStorage.setItem('kora_token',token);}catch(e){}out.textContent=token?'Token set for this session.':'Token cleared.';}return;}
}

// ---------------------------------------------------------------- schedule (existing)
async function loadSchedules(){const r=await api('GET','/api/autopilot/schedules');if(!r.ok){$('result').textContent='Schedule data unavailable: '+errText(r)+'. Nothing claimed.';return;}const rows=(r.json.items||[]).slice(0,20).map(x=>`${x.id} • ${x.post_id} • ${x.status} • ${new Date(x.scheduled_for_utc*1000).toLocaleString()}`).join('\n')||'No schedules yet.';$('result').textContent=rows}
function openSchedule(){ $('scheduleModal').classList.remove('hidden'); $('scheduleTz').value=Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC'; const d=new Date(Date.now()+3600000); d.setSeconds(0,0); $('scheduleWhen').value=new Date(d-d.getTimezoneOffset()*60000).toISOString().slice(0,16)}
async function saveSchedule(){const post_id=$('schedulePostId').value.trim(),when=$('scheduleWhen').value,tz=$('scheduleTz').value.trim()||'UTC',frequency=$('scheduleFreq').value;if(!post_id||!when){$('scheduleMsg').textContent='Post ID and time are required.';return} $('scheduleMsg').textContent='Scheduling…';const r=await api('POST','/api/autopilot/schedules',{post_id,scheduled_for:when,timezone:tz,frequency});$('scheduleMsg').textContent=r.ok?`Scheduled: ${r.json.id}`:('Not scheduled: '+errText(r));if(r.ok)setTimeout(()=>{$('scheduleModal').classList.add('hidden');loadSchedules()},500)}

// ---------------------------------------------------------------- touch targets -> same dispatcher
function go(target){
  const [k,v]=target.split(':');
  if(k==='platform'){ if(v==='Amazon'){setState('COMPLETE','Amazon','Amazon posting is NOT IMPLEMENTED (no official posting integration). Nothing was sent.');return;} return openPublish(v); }
  if(k==='search'){openWorkspace('🔎 Discover');$('command').focus();setState('IDLE','Discover','Type what to research. Live trends need a configured source; none is claimed otherwise.');return;}
  if(k==='growth')return dispatch('Open Growth + Dhanda workflow','touch');
  if(k==='calendar'){openPublish();openSchedule();return;}
  if(k==='projects'){openStudio();return;}
}
$('advanced').onclick=openSys;$('workspaceAdvanced').onclick=openSys;$('closeSys').onclick=()=>$('sysPanel').classList.add('hidden');
document.querySelectorAll('[data-sys]').forEach(b=>b.onclick=()=>sys(b.dataset.sys));
document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>go(b.dataset.go));
document.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>applyEdit(b.dataset.edit));
$('scheduleBtn').onclick=openSchedule;$('scheduleListBtn').onclick=loadSchedules;$('scheduleCancel').onclick=()=>$('scheduleModal').classList.add('hidden');$('scheduleSave').onclick=saveSchedule;
$('back').onclick=goHome;$('masterFolder').onclick=()=>openItem(items.find(i=>i.id==='master')||defaults[0]);
$('add').onclick=add;$('hidden').onclick=drawer;$('start').onclick=drawer;$('closeDrawer').onclick=()=>$('drawer').classList.add('hidden');$('cancelAdd').onclick=()=>$('modal').classList.add('hidden');$('saveAdd').onclick=saveAdd;
$('commandForm').onsubmit=e=>{e.preventDefault();const t=$('command').value;$('command').value='';dispatch(t,'text')};
$('homeCommandForm').onsubmit=e=>{e.preventDefault();const t=$('homeCommand').value;$('homeCommand').value='';dispatch(t,'text')};
// Enter / Go / Send key: some mobile keyboards deliver it in a way that skips the browser's implicit form submit, so it is handled explicitly and goes
// through the SAME form submit as GO (text is read at send time, so pasted text counts at once; the input is cleared after the first send).
[['command','commandForm'],['homeCommand','homeCommandForm']].forEach(([i,f])=>$(i).addEventListener('keydown',e=>{
  if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();const fm=$(f);if(fm.requestSubmit)fm.requestSubmit();else fm.dispatchEvent(new Event('submit',{cancelable:true}));}}));
$('voiceTop').onclick=voice;$('workVoice').onclick=voice;$('homeVoice').onclick=voice;
$('searchBtn').onclick=()=>go('search:');
document.querySelectorAll('[data-tool]').forEach(b=>b.onclick=()=>{const t=b.dataset.tool;if(t==='voice')voice();else if(t==='text'){$('homeCommand').focus();}else{openWorkspace('👆 Touch');}});
$('importFile').onchange=e=>{importFile(e.target.files[0]);e.target.value='';};
$('refreshAssets').onclick=refreshAssets;$('pPlay').onclick=()=>player.play();$('pPause').onclick=()=>player.pause();$('pStop').onclick=()=>player.stop();
$('pSeek').oninput=e=>player.seek(Number(e.target.value)/1000);$('pMute').onclick=()=>{if(player.el){player.el.muted=!player.el.muted;$('pMute').textContent=player.el.muted?'🔇':'🔊';}};
$('undoBtn').onclick=()=>undoRedo(-1);$('redoBtn').onclick=()=>undoRedo(1);$('qualityBtn').onclick=qualityCheck;$('saveDraft').onclick=saveDraft;$('loadDraft').onclick=loadDraft;$('approvalBtn').onclick=approvalFromStudio;
$('pubDraft').onclick=pubDraft;
$('taskCancel').onclick=()=>{if(inflight)inflight.abort();setState('IDLE','Stopped','Stopped by you. A server-side step may still finish.');};
$('taskResume').onclick=()=>{$('taskResume').classList.add('hidden');if(task.view==='studio'){openStudio();if(task.asset)selectAsset(task.asset,true);}else if(task.view==='publish')openPublish();else if(task.view==='workspace')openWorkspace('📁 MEDIA + SOCIAL + STUDIO');else goHome();setState('IDLE',task.label,'Returned to your last view. Nothing was re-executed.');};
document.addEventListener('keydown',e=>{if(e.key==='Escape'){$('sysPanel').classList.add('hidden');$('drawer').classList.add('hidden');}});
window.addEventListener('resize',()=>{render()});
window.KoraUI={dispatch,setState,task,player,go};
render();loadCheckpoint();['faceState','workState','taskState'].forEach(i=>{$(i).textContent='IDLE';});$('taskState').dataset.state='IDLE';refreshActive();setInterval(refreshActive,5000);
})();
