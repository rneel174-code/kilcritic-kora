"""
KORA PRO bridge - WSGI JSON API + minimal HUD host.

Per-request pipeline (fail closed):
  Host allow-list (DNS-rebinding) -> Origin check (CSRF) -> auth (Bearer / local) -> rate limit (token bucket)
  -> JSON-only bodies with a hard size cap (CSRF + memory bound) -> handler -> structured, secret-free log line.
Only registered job handlers can be enqueued; `social_publish` can only be created through the approval flow.
"""
import json
import logging
import os
import re
import subprocess
import sys
import tempfile
import time
from dataclasses import replace
from typing import Any, Callable, Dict, List, Optional, Tuple

from kora import VERSION
from kora.config.settings import Settings, get_settings
import threading
from kora.core import anti_loop, identity, policy, scheduler
from kora.core.auth import Authenticator, client_ip, extract_token
from kora.core.security import Reveal, constant_time_compare
from kora.core.db import DEFAULT_DB_PATH, get_connection, init_db, record_audit, verify_audit_chain
from kora.core.logger import get_logger, log_event
from kora.core.queue import (DurableQueue, IdempotencyConflictException, KillSwitchActiveException,
                             PayloadOversizedException, QueueCapacityExceededException)
from kora.core.ratelimit import RateLimiter
from kora.core.security import sanitize_recursive
from kora.core.worker import HANDLERS, WorkerPool
import kora.services.handlers  # noqa: F401  (registers production handlers)
from kora.services import self_evolution_3 as se3
from kora.services import growth_loop
from kora.services import (atma, asset_compiler, auto_post_legal, brain, cost, dhanda, dharma, dna, emergency, fusion, godfather, governance, hollywood_studio, legal_guard, ops, rag,
                           research, scheduled_autopilot, sena, self_evolution, self_evolution_2, shadow, social, trust, voice_consent, supreme_guardian, malak_assist, fortress)
from kora.services.ai_failover import provider_states

log = get_logger("bridge")
HUD_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "hud")
ROOT_DIR = os.path.dirname(os.path.dirname(HUD_DIR))

# handlers an API caller may enqueue directly (social_publish is deliberately NOT here: it needs approval)
ENQUEUE_ALLOWED = {"noop", "math_compute", "research_ingest", "backup", "maintenance"}

# Non-owner principals (assigned users/devices) may only call these, and only with an active grant. Everything else is owner-only.
ROUTE_PERMS = {"research_search": "WEB_SEARCH", "research_fetch": "WEB_SEARCH", "research_deep": "WEB_SEARCH", "rag_query": "READ_LOCAL_FILE",
               "rag_stats": "READ_LOCAL_FILE", "social_create": "PUBLISH_SOCIAL", "autopost": "PUBLISH_SOCIAL", "shadow_post": "READ_LOCAL_FILE"}
SELF_AUTHORIZING = {"brain"}  # the Brain applies the same permission engine itself
# Owner actions that need a one-time TOTP code once the owner has enrolled one (step-up). Sensitive = protected by design.
STEP_UP = {"proposal_decide", "evolution_apply", "malak_set", "emergency", "emergency_resume", "principal_create", "principal_grant", "atma_restore",
           "skill_approve", "data_delete", "flag_set", "totp_enroll", "voice_consent",
           "evolution_apply", "evolution_rollback", "evo3_unfreeze", "evo3_legal_review",
           "fortress_resume", "fortress_delegate", "guardian_vault_put", "guardian_vault_get", "guardian_vault_revoke", "guardian_vault_rotate"}

STATIC = {
    "/": ("creator_index.html", "text/html; charset=utf-8"),
    "/advanced": ("index.html", "text/html; charset=utf-8"),
    "/legacy-hud": ("index.html", "text/html; charset=utf-8"),
    "/intent.js": ("intent.js", "application/javascript; charset=utf-8"),
    "/creator.js": ("creator.js", "application/javascript; charset=utf-8"),
    "/creator.css": ("creator.css", "text/css; charset=utf-8"),
    "/hud.js": ("hud.js", "application/javascript; charset=utf-8"),
    "/hud.css": ("hud.css", "text/css; charset=utf-8"),
    "/kora_avatar.jpg": ("kora_avatar.jpg", "image/jpeg"),
    "/manifest.json": ("../../public/manifest.json", "application/manifest+json"),
    "/sw.js": ("../../public/sw.js", "application/javascript; charset=utf-8"),
}


class ApiError(Exception):
    def __init__(self, status: int, code: str, detail: str = ""):
        super().__init__(code)
        self.status, self.code, self.detail = status, code, detail


def _status_line(code: int) -> str:
    return f"{code} " + {200: "OK", 201: "Created", 400: "Bad Request", 403: "Forbidden", 404: "Not Found", 405: "Method Not Allowed",
                         409: "Conflict", 411: "Length Required", 413: "Payload Too Large", 415: "Unsupported Media Type",
                         422: "Unprocessable Entity", 429: "Too Many Requests", 500: "Internal Server Error", 503: "Service Unavailable"}.get(code, "OK")


def _suite_timeout() -> float:
    try:
        return float(min(1800, max(60, int(os.environ.get("KORA_TEST_TIMEOUT_SECONDS", "180")))))
    except ValueError:
        return 180.0


def _run_suite_subprocess(only=None):
    """Single launch path for the isolated suite (cwd = temp dir). `only` (test id) restricts the child to that test; it exists so the
    route's own launch path can be regression-tested without running the whole suite inside itself."""
    with tempfile.TemporaryDirectory(prefix="kora-tests-") as tmp:
        env = {k: v for k, v in os.environ.items() if not k.endswith(("_KEY", "_TOKEN")) and k != "KORA_TEST_ONLY"}
        if only:
            env["KORA_TEST_ONLY"] = str(only)
        try:   # isolated launch (-I, project root appended): a planted json.py/os.py in the project folder cannot shadow the stdlib
            return subprocess.run([sys.executable, "-I", os.path.join(ROOT_DIR, "scripts", "safe_launch.py"), "kora.tests.run_all"], cwd=tmp, env=env, capture_output=True, text=True, timeout=_suite_timeout())
        except subprocess.TimeoutExpired:
            raise ApiError(503, "test_suite_timeout", f"the suite did not finish within {_suite_timeout():.0f}s (slow device or heavy load); the result is UNKNOWN, not a pass. Raise KORA_TEST_TIMEOUT_SECONDS (60-1800) or run `python3 -m kora.tests.run_all` in a terminal.")


class KoraApp:
    def __init__(self, settings: Optional[Settings] = None, db_path: Optional[str] = None, init: bool = True):
        self.s = settings or get_settings()
        self.db_path = os.path.abspath(db_path or self.s.db_path or DEFAULT_DB_PATH)
        if init:
            os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
            init_db(self.db_path)
        self.auth = Authenticator(self.s.auth_token, self.s.require_auth_local, self.s.trust_proxy)
        self.limiter = RateLimiter()
        self.queue = DurableQueue(self.db_path, self.s.max_queue_capacity, self.s.retry_base_seconds, self.s.retry_max_seconds)
        self._tl = threading.local()
        self.pool = WorkerPool(self.db_path, self.s.worker_pool_size, self.s.worker_poll_seconds, self.s.job_timeout_seconds,
                               skill_gate=lambda name: trust.skill_runnable(name, self.db_path), loop_threshold=3)
        from kora.services import runtime_limits as _rl
        self.pool.pressure_check = lambda: _rl.pressure(_rl.env_limits(), os.path.dirname(os.path.abspath(self.db_path)) or ".")["under_pressure"]
        self.cron = scheduler.CronRunner(self.db_path, self.s.cron_tick_seconds)
        self.started = time.time()
        self.routes: List[Tuple[str, "re.Pattern", Callable, str]] = []
        self._register_routes()

    # ---------------------------------------------------------------- lifecycle
    def start_services(self) -> None:
        self.queue.recover_stale_leases()
        trust.sync_skills(HANDLERS, self.db_path)
        atma.heartbeat(self.db_path)
        scheduler.ensure_cron_job("maintenance", "*/10 * * * *", "maintenance", db_path=self.db_path)
        # 15-second durable autopilot dispatcher; it only claims due schedules and reuses social approval/publish.
        scheduler.ensure_cron_job("scheduled-social-autopilot", "@every 15s", "scheduled_autopilot", db_path=self.db_path)
        scheduler.ensure_cron_job("fortress-watchdog", "@every 60s", "fortress_watchdog", db_path=self.db_path)
        if self.s.cron_backup_daily:
            scheduler.ensure_cron_job("backup-daily", "15 3 * * *", "backup", db_path=self.db_path)
        self.pool.start()
        if self.s.cron_enabled:
            self.cron.start()

    def stop_services(self) -> None:
        self.cron.stop()
        self.pool.stop()

    # ---------------------------------------------------------------- routing table
    def _r(self, method: str, pattern: str, fn: Callable, klass: str) -> None:
        self.routes.append((method, re.compile("^" + pattern + "$"), fn, klass))

    def _register_routes(self) -> None:
        r = self._r
        r("GET", r"/api/health", self.health, "public")
        r("GET", r"/api/active", self.active, "read")
        r("GET", r"/api/queue/stats", self.queue_stats, "read")
        r("POST", r"/api/queue/enqueue", self.queue_enqueue, "write")
        r("GET", r"/api/queue/dlq", self.dlq_list, "read")
        r("POST", r"/api/queue/dlq/(?P<id>[\w\-]+)/requeue", self.dlq_requeue, "write")
        r("POST", r"/api/jobs/(?P<id>[\w\-]+)/cancel", self.job_cancel, "write")
        r("GET", r"/api/jobs/(?P<id>[\w\-]+)", self.job_get, "read")
        r("GET", r"/api/social/posts", self.social_list, "read")
        r("POST", r"/api/social/posts", self.social_create, "write")
        r("POST", r"/api/social/posts/(?P<id>[\w\-]+)/approve", self.social_approve, "write")
        r("POST", r"/api/social/posts/(?P<id>[\w\-]+)/reject", self.social_reject, "write")
        r("GET", r"/api/autopilot/schedules", self.autopilot_list, "read")
        r("POST", r"/api/autopilot/schedules", self.autopilot_create, "write")
        r("POST", r"/api/autopilot/schedules/(?P<id>[\w\-]+)/pause", self.autopilot_pause, "write")
        r("POST", r"/api/autopilot/schedules/(?P<id>[\w\-]+)/resume", self.autopilot_resume, "write")
        r("POST", r"/api/autopilot/schedules/(?P<id>[\w\-]+)/cancel", self.autopilot_cancel, "write")
        r("POST", r"/api/autopilot/schedules/(?P<id>[\w\-]+)/edit", self.autopilot_edit, "write")
        r("POST", r"/api/autopilot/schedules/(?P<id>[\w\-]+)/retry", self.autopilot_retry, "write")
        r("POST", r"/api/autopilot/calendar", self.autopilot_calendar, "write")
        r("GET", r"/api/platforms/readiness", self.platforms_readiness, "read")
        r("GET", r"/api/capabilities", self.capabilities_audit, "read")
        r("POST", r"/api/media/convert", self.media_convert, "write")
        r("GET", r"/api/fortress/status", self.fortress_status, "read")
        r("POST", r"/api/fortress/watchdog", self.fortress_watchdog, "write")
        r("POST", r"/api/fortress/resume", self.fortress_resume, "write")
        r("POST", r"/api/fortress/delegations", self.fortress_delegate, "write")
        r("POST", r"/api/fortress/delegations/(?P<id>[\w\-]+)/revoke", self.fortress_revoke, "write")
        r("GET", r"/api/fortress/dead-files", self.fortress_dead, "read")
        r("POST", r"/api/fortress/complexity", self.fortress_complexity, "write")
        r("GET", r"/api/fortress/recovery-proof", self.fortress_recovery, "read")
        r("GET", r"/api/fortress/independence", self.fortress_independence, "read")
        r("GET", r"/api/fortress/evolution-proof/(?P<id>[\w\-]+)", self.fortress_evo_proof, "read")
        r("POST", r"/api/research/search", self.research_search, "heavy")
        r("POST", r"/api/research/fetch", self.research_fetch, "heavy")
        r("POST", r"/api/rag/ingest", self.rag_ingest, "write")
        r("POST", r"/api/rag/query", self.rag_query, "write")
        r("GET", r"/api/rag/stats", self.rag_stats, "read")
        r("GET", r"/api/cron", self.cron_list, "read")
        r("POST", r"/api/cron", self.cron_create, "write")
        r("POST", r"/api/cron/(?P<id>[\w\-]+)/toggle", self.cron_toggle, "write")
        r("POST", r"/api/cron/(?P<id>[\w\-]+)/delete", self.cron_delete, "write")
        r("GET", r"/api/doctor/probes", self.doctor, "heavy")
        r("POST", r"/api/doctor/heal", self.heal, "heavy")
        r("POST", r"/api/backup/create", self.backup, "heavy")
        r("POST", r"/api/tests/run", self.run_tests, "heavy")
        r("POST", r"/api/killswitch", self.killswitch, "write")
        r("GET", r"/api/security", self.security_status, "read")
        r("POST", r"/api/security/totp", self.totp_enroll, "write")
        r("GET", r"/api/principals", self.principals_list, "read")
        r("POST", r"/api/principals", self.principal_create, "write")
        r("POST", r"/api/principals/(?P<id>[\w\-]+)/revoke", self.principal_revoke, "write")
        r("POST", r"/api/principals/(?P<id>[\w\-]+)/grant", self.principal_grant, "write")
        r("POST", r"/api/grants/(?P<id>[\w\-]+)/revoke", self.grant_revoke, "write")
        r("POST", r"/api/brain", self.brain, "write")
        r("POST", r"/api/studio/plan", self.studio_plan, "read")
        r("GET", r"/api/studio/capabilities", self.studio_capabilities, "read")
        r("GET", r"/api/studio/assets", self.studio_assets, "read")
        r("POST", r"/api/studio/upload", self.studio_upload, "write")
        r("POST", r"/api/studio/preview", self.studio_preview, "read")
        r("POST", r"/api/studio/edit", self.studio_edit, "heavy")
        r("POST", r"/api/studio/quality", self.studio_quality, "read")
        r("GET", r"/api/studio/projects", self.studio_projects, "read")
        r("POST", r"/api/studio/projects/save", self.studio_project_save, "write")
        r("POST", r"/api/studio/projects/load", self.studio_project_load, "read")
        r("POST", r"/api/assets/variants", self.asset_variants, "read")
        r("POST", r"/api/workflow/plan", self.workflow_plan, "read")
        r("POST", r"/api/voice", self.voice_set, "write")
        r("POST", r"/api/voice/consent", self.voice_consent, "write")
        r("GET", r"/api/dna/(?P<kind>[a-z_]+)", self.dna_get, "read")
        r("GET", r"/api/dna/(?P<kind>[a-z_]+)/history", self.dna_history, "read")
        r("POST", r"/api/dna", self.dna_set, "write")
        r("POST", r"/api/dna/diff", self.dna_diff, "read")
        r("POST", r"/api/dna/restore", self.dna_restore, "write")
        r("GET", r"/api/shadow/posts/(?P<id>[\w\-]+)", self.shadow_post, "read")
        r("POST", r"/api/autopost", self.autopost, "write")
        r("POST", r"/api/research/deep", self.research_deep, "heavy")
        r("POST", r"/api/backup/321", self.backup_321, "heavy")
        r("POST", r"/api/growth/campaigns", self.growth_campaign, "write")
        r("POST", r"/api/growth/campaigns/(?P<id>[\w\-]+)/events", self.growth_event, "write")
        r("GET", r"/api/growth/campaigns/(?P<id>[\w\-]+)/roi", self.growth_roi, "read")
        r("POST", r"/api/growth/link", self.growth_link, "write")
        r("POST", r"/api/growth/dna", self.growth_dna, "read")
        r("POST", r"/api/growth/pilot/shops", self.growth_pilot_shop, "write")
        r("POST", r"/api/growth/pilot/(?P<id>[\w\-]+)/observations", self.growth_pilot_obs, "write")
        r("POST", r"/api/growth/pilot/observations/(?P<id>\d+)/attest", self.growth_pilot_attest, "write")
        r("GET", r"/api/growth/pilot/(?P<id>[\w\-]+)", self.growth_pilot_eval, "read")
        r("GET", r"/api/growth/pilot", self.growth_pilot_summary, "read")
        r("POST", r"/api/growth/competitor", self.growth_competitor_add, "write")
        r("GET", r"/api/growth/competitor", self.growth_competitor_rank, "read")
        r("POST", r"/api/growth/festival", self.growth_festival, "write")
        r("POST", r"/api/dhanda/ledger", self.ledger_add, "write")
        r("GET", r"/api/dhanda/summary", self.ledger_summary, "read")
        r("POST", r"/api/dhanda/score", self.dhanda_score, "read")
        r("GET", r"/api/atma", self.atma_status, "read")
        r("POST", r"/api/atma/restore", self.atma_restore, "heavy")
        r("POST", r"/api/mission", self.mission_create, "write")
        r("POST", r"/api/mission/(?P<id>[\w\-]+)/progress", self.mission_progress, "write")
        r("GET", r"/api/skills", self.skills_list, "read")
        r("POST", r"/api/skills/(?P<name>[\w\-]+)/approve", self.skill_approve, "write")
        r("GET", r"/api/ops", self.ops_status, "read")
        r("GET", r"/api/environment", self.environment_get, "read")
        r("POST", r"/api/environment", self.environment_set, "write")
        r("GET", r"/api/health/deep", self.health_deep, "read")
        r("POST", r"/api/pressure/apply", self.pressure_apply, "write")
        r("GET", r"/api/accounts", self.accounts_get, "read")
        r("POST", r"/api/accounts", self.accounts_set, "write")
        r("POST", r"/api/posting/route", self.posting_route, "read")
        r("POST", r"/api/predict", self.predict, "read")
        r("POST", r"/api/dry-run", self.dry_run, "read")
        r("POST", r"/api/quality/verify", self.quality_verify, "read")
        r("POST", r"/api/trust/score", self.trust_score, "read")
        r("POST", r"/api/dna/observe", self.dna_observe, "write")
        r("POST", r"/api/dna/rollback-learned", self.dna_rollback_learned, "write")
        r("POST", r"/api/errors/explain", self.error_explain, "read")
        r("POST", r"/api/brain/choose", self.brain_choose, "read")
        r("GET", r"/api/tasks/blocked", self.tasks_blocked, "read")
        r("POST", r"/api/flags", self.flag_set, "write")
        r("GET", r"/api/providers", self.providers, "read")
        r("GET", r"/api/data/export", self.data_export, "heavy")
        r("POST", r"/api/data/delete", self.data_delete, "heavy")
        r("GET", r"/api/audit/verify", self.audit_verify, "read")
        r("POST", r"/api/operations/(?P<op>[\w\-]+)/unfreeze", self.op_unfreeze, "write")
        r("GET", r"/api/governance/proposals", self.proposals_list, "read")
        r("GET", r"/api/governance/proposals/(?P<id>[\w\-]+)", self.proposal_detail, "read")
        r("POST", r"/api/governance/proposals/(?P<id>[\w\-]+)/(?P<verb>approve|reject|postpone)", self.proposal_decide, "write")
        r("GET", r"/api/godfather/health", self.godfather_health, "read")
        r("POST", r"/api/godfather/plan", self.godfather_plan, "read")
        r("GET", r"/api/evolution/3/dashboard", self.evo3_dashboard, "read")
        r("GET", r"/api/evolution/3/capabilities", self.evo3_capabilities, "read")
        r("GET", r"/api/evolution/3/gaps", self.evo3_gaps, "read")
        r("GET", r"/api/evolution/3/providers", self.evo3_providers, "read")
        r("GET", r"/api/metrics", self.metrics_get, "read")
        r("GET", r"/api/assessment/history", self.assessment_history, "read")
        r("POST", r"/api/assessment/run", self.assessment_run, "heavy")
        r("POST", r"/api/egress/probe", self.egress_probe_run, "heavy")
        r("GET", r"/api/evolution/3/dependencies", self.evo3_dependencies, "read")
        r("GET", r"/api/evolution/3/performance", self.evo3_performance, "read")
        r("POST", r"/api/evolution/3/cycle", self.evo3_cycle, "heavy")
        r("POST", r"/api/evolution/3/resume", self.evo3_resume, "heavy")
        r("POST", r"/api/evolution/3/memory", self.evo3_memory, "read")
        r("POST", r"/api/evolution/3/score", self.evo3_score, "read")
        r("POST", r"/api/evolution/3/predict", self.evo3_predict, "read")
        r("POST", r"/api/evolution/3/baseline", self.evo3_baseline, "heavy")
        r("POST", r"/api/evolution/3/canary", self.evo3_canary, "heavy")
        r("GET", r"/api/evolution/3/gate/(?P<id>[\w\-]+)", self.evo3_gate, "read")
        r("GET", r"/api/evolution/3/rollback-points", self.evo3_rollback_points, "read")
        r("POST", r"/api/evolution/3/freeze", self.evo3_freeze, "write")
        r("POST", r"/api/evolution/3/unfreeze", self.evo3_unfreeze, "write")
        r("POST", r"/api/evolution/3/legal-review/(?P<id>[\w\-]+)", self.evo3_legal_review, "write")
        r("POST", r"/api/evolution/3/tests", self.evo3_generate_test, "write")
        r("POST", r"/api/evolution/3/chaos", self.evo3_chaos, "heavy")
        r("POST", r"/api/evolution/3/guards", self.evo3_guard_add, "write")
        r("GET", r"/api/evolution/scan", self.evolution_scan, "read")
        r("GET", r"/api/evolution/2/audit", self.evolution_2_audit, "read")
        r("POST", r"/api/evolution/2/plan", self.evolution_2_plan, "heavy")
        r("POST", r"/api/evolution/prepare", self.evolution_prepare, "heavy")
        r("POST", r"/api/evolution/(?P<id>[\w\-]+)/apply", self.evolution_apply, "write")
        r("POST", r"/api/evolution/(?P<id>[\w\-]+)/rollback", self.evolution_rollback, "write")
        r("GET", r"/api/malak", self.malak_get, "read")
        r("POST", r"/api/malak", self.malak_set, "write")
        r("GET", r"/api/cost", self.cost_get, "read")
        r("POST", r"/api/legal/preflight", self.legal_preflight, "read")
        r("POST", r"/api/safe-mode", self.safe_mode, "write")
        r("POST", r"/api/emergency", self.emergency, "heavy")
        r("POST", r"/api/emergency/resume", self.emergency_resume, "heavy")
        r("POST", r"/api/sena/attack", self.sena_attack, "read")
        r("POST", r"/api/sena/team", self.sena_team, "read")
        r("GET", r"/api/guardian/status", self.guardian_status, "read")
        r("POST", r"/api/guardian/inspect-tool", self.guardian_inspect_tool, "write")
        r("POST", r"/api/guardian/resolve", self.guardian_resolve, "write")
        r("POST", r"/api/guardian/predict", self.guardian_predict, "read")
        r("POST", r"/api/guardian/memory-screen", self.guardian_memory_screen, "write")
        r("POST", r"/api/guardian/meta-tool", self.guardian_meta_tool, "write")
        r("GET", r"/api/guardian/malak-profile", self.guardian_malak_profile, "read")
        r("POST", r"/api/guardian/recycle-scan", self.guardian_recycle_scan, "heavy")
        r("POST", r"/api/guardian/refuse", self.guardian_refuse, "write")
        r("GET", r"/api/guardian/watchdog", self.guardian_watchdog, "read")
        r("POST", r"/api/guardian/supervisor-tick", self.guardian_supervisor_tick, "heavy")
        r("POST", r"/api/guardian/vault/put", self.guardian_vault_put, "heavy")
        r("POST", r"/api/guardian/vault/get", self.guardian_vault_get, "heavy")
        r("POST", r"/api/guardian/vault/revoke", self.guardian_vault_revoke, "heavy")
        r("POST", r"/api/guardian/vault/rotate", self.guardian_vault_rotate, "heavy")
        r("POST", r"/api/malak-assist/pause", self.malak_assist_pause, "write")
        r("POST", r"/api/malak-assist/inbound", self.malak_assist_inbound, "write")
        r("POST", r"/api/malak-assist/webhook/telegram", self.malak_webhook_telegram, "public")
        r("GET", r"/api/malak-assist/webhook/whatsapp", self.malak_webhook_whatsapp_verify, "public")
        r("POST", r"/api/malak-assist/webhook/whatsapp", self.malak_webhook_whatsapp, "public")
        r("POST", r"/api/malak-assist/escalate", self.malak_assist_escalate, "write")
        r("GET", r"/api/malak-assist/recover", self.malak_assist_recover, "read")
        r("POST", r"/api/malak-assist/(?P<id>[\w\-]+)/cancel", self.malak_assist_cancel, "write")
        r("GET", r"/api/malak-assist/(?P<id>[\w\-]+)", self.malak_assist_get, "read")
        r("GET", r"/api/malak-assist", self.malak_assist_list, "read")
        r("POST", r"/api/malak-assist/(?P<id>[\w\-]+)/resume", self.malak_assist_resume, "write")

    # ---------------------------------------------------------------- WSGI entry
    def __call__(self, environ, start_response):
        t0 = time.perf_counter()
        method = environ.get("REQUEST_METHOD", "GET").upper()
        path = environ.get("PATH_INFO", "/") or "/"
        peer = environ.get("REMOTE_ADDR", "")
        headers = {k[5:].replace("_", "-").lower(): v for k, v in environ.items() if k.startswith("HTTP_")}
        for k in ("CONTENT_TYPE", "CONTENT_LENGTH"):
            if environ.get(k):
                headers[k.replace("_", "-").lower()] = environ[k]
        ip = client_ip(peer, headers, self.s.trust_proxy)
        status, body, extra, ctype = 500, b"{}", [], "application/json"
        try:
            status, payload, extra, ctype = self._handle(method, path, ip, peer, headers, environ)
            body = payload if isinstance(payload, (bytes, bytearray)) else json.dumps(sanitize_recursive(payload), default=str).encode()
        except ApiError as e:
            status, body = e.status, json.dumps({"ok": False, "error": e.code, **({"detail": e.detail} if e.detail else {})}).encode()
            if e.status == 429 and e.detail.startswith("retry_after="):
                extra = [("Retry-After", str(max(1, int(float(e.detail.split("=")[1])) + 1)))]
        except Exception:  # never leak internals
            log.exception("unhandled error on %s %s", method, path)
            status, body = 500, json.dumps({"ok": False, "error": "internal_error"}).encode()
        hdrs = [("Content-Type", ctype), ("Content-Length", str(len(body))), ("X-Content-Type-Options", "nosniff"),
                ("X-Frame-Options", "DENY"), ("Referrer-Policy", "no-referrer"), ("Cache-Control", "no-store"),
                ("X-Kora-Version", VERSION),
                ("Content-Security-Policy", "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")] + extra
        start_response(_status_line(status), hdrs)
        log_event(log, logging.INFO, "request", method=method, path=path, status=status, ip=ip, ms=round((time.perf_counter() - t0) * 1000, 2))
        return [body]

    def _host_ok(self, host_header: str) -> bool:
        h = host_header.strip().lower()
        h = h.rsplit(":", 1)[0] if (":" in h and not h.endswith("]")) else h
        return h in {x.lower() for x in self.s.allowed_hosts}

    def _origin_ok(self, origin: str, host_header: str) -> bool:
        if not origin or origin == "null":
            return origin == ""  # 'null' origin (sandboxed/file) is rejected
        o = origin.lower().rstrip("/")
        return o in {x.lower().rstrip("/") for x in self.s.allowed_origins} or o in (f"http://{host_header.lower()}", f"https://{host_header.lower()}")

    def _handle(self, method, path, ip, peer, headers, environ):
        if not self._host_ok(headers.get("host", "")):
            raise ApiError(403, "host_not_allowed")
        if "origin" in headers and not self._origin_ok(headers["origin"], headers.get("host", "")):
            raise ApiError(403, "origin_not_allowed")

        if method == "GET" and path in STATIC:  # static HUD shell: no data, safe to serve; data calls need auth
            fname, ctype = STATIC[path]
            try:
                with open(os.path.join(HUD_DIR, fname), "rb") as fh:
                    return 200, fh.read(), [], ctype
            except OSError:
                raise ApiError(404, "not_found")

        route = None
        path_matched = False
        for m, rx, fn, klass in self.routes:
            mt = rx.match(path)
            if mt:
                path_matched = True
                if m == method:
                    route = (fn, klass, mt.groupdict())
                    break
        if not route:
            raise ApiError(405 if path_matched else 404, "method_not_allowed" if path_matched else "not_found")
        fn, klass, params = route

        principal = {"id": "owner", "role": "owner"}
        if klass != "public":
            supplied = extract_token(headers)
            other = None
            if supplied and not (self.s.auth_token and constant_time_compare(supplied, self.s.auth_token)):
                other = identity.authenticate_token(supplied, self.db_path)  # assigned user/device (hashed token, expiry, revocation)
            if other is None:
                ok, code, why = self.auth.check(peer, headers)
                if not ok:
                    record_audit("auth_denied", ip, {"path": path, "reason": why}, self.db_path)
                    raise ApiError(code, why)
            else:
                principal = other
                fname = fn.__name__
                if fname not in SELF_AUTHORIZING:
                    perm = ROUTE_PERMS.get(fname)
                    if not perm:
                        raise ApiError(403, "owner_only")
                    if not identity.has_permission(other["id"], perm, self.db_path):
                        record_audit("permission_denied", f"principal:{other['id']}", {"path": path, "permission": perm}, self.db_path)
                        raise ApiError(403, "permission_not_granted_or_expired", perm)
            if self.s.rate_limit_enabled:
                limit = {"read": self.s.rate_read_per_min, "write": self.s.rate_write_per_min, "heavy": self.s.rate_heavy_per_min}[klass]
                allowed, retry = self.limiter.allow(f"{ip}:{klass}:{principal['id']}", limit, burst=max(1, limit // 2 if klass == "heavy" else limit))
                if not allowed:
                    raise ApiError(429, "rate_limited", f"retry_after={retry:.1f}")
        self._tl.principal = principal
        self._tl.headers = headers
        self._tl.query = environ.get("QUERY_STRING", "")

        body: Dict[str, Any] = {}
        self._tl.raw_body = b""
        if method in ("POST", "PUT", "PATCH", "DELETE"):
            ctype = headers.get("content-type", "").split(";")[0].strip().lower()
            raw_len = headers.get("content-length")
            if raw_len is None or raw_len == "":
                if headers.get("transfer-encoding"):
                    raise ApiError(411, "content_length_required")
                raw_len = "0"
            try:
                n = int(raw_len)
            except ValueError:
                raise ApiError(400, "invalid_content_length")
            if n < 0 or n > self.s.max_body_bytes:
                raise ApiError(413, "request_too_large", f"limit={self.s.max_body_bytes}")
            if n > 0:
                if ctype != "application/json":  # forces a CORS preflight for browsers -> blocks simple-form CSRF
                    raise ApiError(415, "json_content_type_required")
                try:
                    _raw = environ["wsgi.input"].read(n)
                    self._tl.raw_body = _raw
                    body = json.loads(_raw.decode("utf-8"))
                except (ValueError, UnicodeDecodeError):
                    raise ApiError(400, "invalid_json")
                if not isinstance(body, dict):
                    raise ApiError(400, "json_object_required")
            elif ctype and ctype != "application/json":
                raise ApiError(415, "json_content_type_required")
        if principal["role"] == "owner" and fn.__name__ in STEP_UP:
            self._require_step_up(headers)
        try:
            out = fn(body, ip=ip, **params)
        except ApiError:
            raise
        except KillSwitchActiveException:
            raise ApiError(503, "kill_switch_active")
        except QueueCapacityExceededException:
            raise ApiError(429, "queue_full")
        except IdempotencyConflictException as e:
            raise ApiError(409, "duplicate_idempotency_key", str(e)[:200])
        except PayloadOversizedException:
            raise ApiError(413, "payload_too_large")
        except (social.SocialPublishError, scheduler.CronError, rag.RagError) as e:
            raise ApiError(400, "invalid_request", str(e)[:300])
        except research.ResearchError as e:
            raise ApiError(422, e.code, str(e)[:300])
        except cost.BudgetExceeded as e:
            raise ApiError(429, "budget_exceeded", str(e)[:200])
        except (dharma.MalakViolation, dna.DnaError, identity.IdentityError, KeyError, ValueError) as e:
            raise ApiError(400, "invalid_request", str(e)[:300])
        except policy.PolicyDenied as e:
            raise ApiError(403, "policy_denied", e.reason)
        if isinstance(out, tuple) and len(out) == 3:  # (status, bytes, content-type) raw download
            return out[0], out[1], [("Content-Disposition", 'attachment; filename="kora-export.zip"')], out[2]
        return (200 if not isinstance(out, tuple) else out[0]), (out if not isinstance(out, tuple) else out[1]), [], "application/json"

    # ---------------------------------------------------------------- helpers
    @staticmethod
    def _req(body: Dict[str, Any], key: str, typ=str, default=None, maxlen: int = 20000):
        v = body.get(key, default)
        if v is None or not isinstance(v, typ) or (typ is str and (not v.strip() or len(v) > maxlen)):
            raise ApiError(400, "invalid_field", key)
        return v

    # ---------------------------------------------------------------- handlers
    def health(self, body, ip):
        return {"status": "ONLINE", "version": VERSION, "uptime_seconds": round(time.time() - self.started, 1)}

    def active(self, body, ip):
        """Only what is happening NOW: running + queued jobs, items needing a human, failures to look at, next cron."""
        jobs = self.queue.get_active(50)
        stats = self.queue.get_stats()
        pending = social.list_posts(self.db_path, "PENDING_APPROVAL", 20) + social.list_posts(self.db_path, "APPROVED_AWAITING_CREDENTIALS", 20)
        props = governance.list_proposals(self.db_path, "PENDING", 20)
        approvals = {"posts": len(pending), "proposals": len(props), "total": len(pending) + len(props),
                     "high_risk": sum(1 for p in props if str(p.get("risk")).upper() in ("HIGH", "CRITICAL")),
                     "approved_not_executed": len(governance.list_proposals(self.db_path, "APPROVED", 20)),
                     "note": "needs_approval lists social posts only; code/self-improvement proposals are in `proposals`. `total` counts both."}
        return {
            "ok": True, "version": VERSION, "kill_switch": stats["kill_switch"], "approvals": approvals,
            "running": [j for j in jobs if j["status"] == "RUNNING"],
            "queued": [j for j in jobs if j["status"] == "QUEUED"],
            "needs_approval": pending,
            "proposals": props, "safe_mode": policy.is_safe_mode(self.db_path),
            "failed": self.queue.list_dead_letters(10),
            "workers": self.pool.status(),
            "idle": not jobs and not pending and not props and stats["DEAD_LETTER"] == 0,
        }

    def queue_stats(self, body, ip):
        return {"ok": True, **self.queue.get_stats(), "worker": self.pool.status(), "cron": self.cron.status()}

    def queue_enqueue(self, body, ip):
        handler = self._req(body, "handler")
        if handler not in ENQUEUE_ALLOWED or handler not in HANDLERS:
            raise ApiError(400, "handler_not_allowed", f"allowed: {sorted(ENQUEUE_ALLOWED)}")
        payload = body.get("payload", {})
        if not isinstance(payload, dict):
            raise ApiError(400, "invalid_field", "payload")
        pr = int(body.get("priority", 0))
        mr = int(body.get("max_retries", 3))
        key = body.get("idempotency_key")
        if key is not None and (not isinstance(key, str) or not 1 <= len(key) <= 200):
            raise ApiError(400, "invalid_field", "idempotency_key")
        deps = body.get("depends_on", "")
        if not isinstance(deps, str) or len(deps) > 80:
            raise ApiError(400, "invalid_field", "depends_on")
        job = self.queue.enqueue(handler, payload, priority=max(-100, min(100, pr)), idempotency_key=key, max_retries=max(1, min(10, mr)),
                                 owner=brain.owner_key(self._tl.principal), label=str(body.get("label", ""))[:120], depends_on=deps)
        record_audit("job_enqueued", ip, {"id": job["id"], "handler": handler}, self.db_path)
        return (201, {"ok": True, **job})

    def dlq_list(self, body, ip):
        return {"ok": True, "items": self.queue.list_dead_letters(100)}

    def dlq_requeue(self, body, ip, id):
        ok = self.queue.requeue_dead_letter(id)
        if not ok:
            raise ApiError(404, "not_in_dead_letter_queue")
        record_audit("dlq_requeue", ip, {"id": id}, self.db_path)
        return {"ok": True, "id": id, "status": "QUEUED"}

    def job_cancel(self, body, ip, id):
        if not self.queue.cancel_job(id):
            raise ApiError(409, "job_not_cancellable")
        record_audit("job_cancel", ip, {"id": id}, self.db_path)
        return {"ok": True, "id": id, "status": "CANCELLED"}

    def job_get(self, body, ip, id):
        j = self.queue.get_job(id)
        if not j:
            raise ApiError(404, "not_found")
        return {"ok": True, "job": {k: j[k] for k in ("id", "handler_name", "status", "attempts", "max_retries", "error", "result", "created_at", "updated_at", "next_attempt_at") if k in j}}

    def social_list(self, body, ip):
        return {"ok": True, "items": social.list_posts(self.db_path, None, 100)}

    def social_create(self, body, ip):
        if isinstance(body.get("studio_asset"), str):   # Studio library asset id -> server-side path inside the media root (the browser never supplies a path)
            from kora.services import media_pipeline
            try:
                body = dict(body, media_path=media_pipeline.resolve_asset(os.path.abspath(os.environ.get("KORA_MEDIA_DIR", "data/media")), body["studio_asset"]))
            except media_pipeline.MediaPipelineError as e:
                raise ApiError(400, "invalid_request", str(e)[:120])
        out = social.create_social_post(
            self._req(body, "platform"), self._req(body, "content", maxlen=10000), body.get("audience") or dharma.get_rule("default_audience", "GENERAL", self.db_path),
            idempotency_key=body.get("idempotency_key"), db_path=self.db_path, media_path=body.get("media_path"),
            title=body.get("title"), queue=self.queue, asset_meta=self._asset_meta(body),
            public_media_url=body.get("public_media_url"), media_type=body.get("media_type"),
            ai_generated=bool(body.get("ai_generated", False)), owner=brain.owner_key(self._tl.principal),
            auto_publish=self.s.social_auto_publish, auto_approve=self.s.social_auto_approve,
            env=os.environ, media_root=os.path.abspath(os.environ.get("KORA_MEDIA_DIR", "data/media")))
        return (201, {"ok": True, **out})

    @staticmethod
    def _asset_meta(body):
        m = {k: body[k] for k in ("rights", "source", "adult_content", "ai_generated", "disclosure", "duplicate_risk", "platform_risk") if k in body}
        return m

    def social_approve(self, body, ip, id):
        out = social.approve_and_publish_post(id, self.db_path, actor=f"operator@{ip}", queue=self.queue, auto_publish=self.s.social_auto_publish)
        return {"ok": True, **out}

    def social_reject(self, body, ip, id):
        return {"ok": True, **social.reject_post(id, self.db_path, actor=f"operator@{ip}")}

    def autopilot_list(self, body, ip):
        return {"ok": True, "items": scheduled_autopilot.list_schedules(self.db_path)}

    def autopilot_create(self, body, ip):
        out = scheduled_autopilot.create_schedule(
            self._req(body, "post_id"), self._req(body, "scheduled_for"),
            str(body.get("timezone") or "UTC"), str(body.get("frequency") or "ONCE"), self.db_path)
        return (201, {"ok": True, **out})

    def autopilot_pause(self, body, ip, id):
        try: ok = scheduled_autopilot.pause(id, self.db_path)
        except scheduled_autopilot.ScheduleStateError as e: raise ApiError(409, "invalid_state_transition", str(e)[:200])
        if not ok: raise ApiError(404, "schedule_not_found")
        return {"ok": True, "id": id, "status": "PAUSED"}

    def autopilot_resume(self, body, ip, id):
        try: ok = scheduled_autopilot.resume(id, self.db_path)
        except scheduled_autopilot.ScheduleStateError as e: raise ApiError(409, "invalid_state_transition", str(e)[:200])
        if not ok: raise ApiError(404, "schedule_not_found")
        return {"ok": True, "id": id, "status": "SCHEDULED"}

    def autopilot_cancel(self, body, ip, id):
        try: ok = scheduled_autopilot.cancel(id, self.db_path)
        except scheduled_autopilot.ScheduleStateError as e: raise ApiError(409, "invalid_state_transition", str(e)[:200])
        if not ok: raise ApiError(404, "schedule_not_found")
        return {"ok": True, "id": id, "status": "CANCELLED"}

    def autopilot_edit(self, body, ip, id):
        try:
            out = scheduled_autopilot.edit_schedule(id, body.get("scheduled_for"), body.get("timezone"), body.get("frequency"), body.get("retry_policy"), self.db_path)
        except scheduled_autopilot.ScheduleStateError as e: raise ApiError(409, "invalid_state_transition", str(e)[:200])
        except KeyError: raise ApiError(404, "schedule_not_found")
        return {"ok": True, **(out if isinstance(out, dict) else {"id": id})}

    def autopilot_retry(self, body, ip, id):
        try: out = scheduled_autopilot.retry(id, self.db_path)
        except scheduled_autopilot.ScheduleStateError as e: raise ApiError(409, "invalid_state_transition", str(e)[:200])
        except KeyError: raise ApiError(404, "schedule_not_found")
        return {"ok": True, **(out if isinstance(out, dict) else {"id": id})}

    def autopilot_calendar(self, body, ip):
        try: out = scheduled_autopilot.create_calendar(body.get("items"), self.db_path)
        except ValueError as e: raise ApiError(400, "invalid_calendar", str(e)[:200])
        return (201, {"ok": True, **out})

    def platforms_readiness(self, body, ip):
        from kora.services import platform_readiness
        return {"ok": True, "platforms": platform_readiness.matrix(dict(os.environ) | dict(self.s.keys))}

    def capabilities_audit(self, body, ip):
        from kora.services import capability_audit
        return {"ok": True, **capability_audit.audit()}

    def media_convert(self, body, ip):
        from kora.services import media_pipeline
        try:
            out = media_pipeline.convert_variant(self._req(body, "source_path"), self._req(body, "target", maxlen=40),
                                                 media_root=os.path.abspath(os.environ.get("KORA_MEDIA_DIR", "data/media")))
        except media_pipeline.MediaPipelineError as e:
            raise ApiError(400, "convert_failed", str(e)[:200])
        return {"ok": out.get("state") == "EXPORTED_VERIFIED", **out}

    def fortress_status(self, body, ip):
        return {"ok": True, "halted": fortress.halted(self.db_path), "boundary": fortress.verify_boundary()["ok"], "forbidden_actions": sorted(fortress.BOUNDARY)}

    def fortress_watchdog(self, body, ip):
        return {"ok": True, **fortress.watchdog_scan(self.db_path, self._envmap())}

    def fortress_resume(self, body, ip):
        out = fortress.resume_from_halt(self._actor(ip), str(body.get("reason", ""))[:300], self.db_path, owner_verified=True)
        if out["status"] != "RESUMED": raise ApiError(409, out["reason"])
        return {"ok": True, **out}

    def fortress_delegate(self, body, ip):
        try:
            out = fortress.issue_delegation(self._req(body, "parent"), self._req(body, "child"), self._req(body, "capability", maxlen=40),
                                            ttl_seconds=float(body.get("ttl_seconds", 3600)), max_uses=int(body.get("max_uses", 10)),
                                            parent_delegation=body.get("parent_delegation"), db_path=self.db_path)
        except fortress.DelegationError as e:
            raise ApiError(403, "delegation_refused", str(e)[:120])
        return (201, {"ok": True, **out})

    def fortress_revoke(self, body, ip, id):
        return {"ok": True, **fortress.revoke_delegation(id, self._actor(ip), self.db_path)}

    def fortress_dead(self, body, ip):
        return {"ok": True, **fortress.dead_file_audit(ROOT_DIR)}

    def fortress_complexity(self, body, ip):
        return {"ok": True, **fortress.complexity_gate(body if isinstance(body, dict) else {}, ROOT_DIR)}

    def fortress_recovery(self, body, ip):
        return {"ok": True, **fortress.recovery_proof(self.db_path, self.queue)}

    def fortress_independence(self, body, ip):
        return {"ok": True, **fortress.independence_report(self._envmap(), self.db_path)}

    def fortress_evo_proof(self, body, ip, id):
        return self._evo(fortress.evolution_proof, id, self.db_path)

    def _caps(self):
        return cost.parse_caps(self.s.budget_daily), cost.parse_caps(self.s.budget_monthly)

    def _charge(self, resource: str) -> None:
        cost.charge(resource, *self._caps(), db_path=self.db_path)

    def research_search(self, body, ip):
        self._charge("net_calls")
        res = research.search_web(self._req(body, "query", maxlen=300))
        return (200 if res["ok"] else 503 if res["status"] == "CONFIGURATION_REQUIRED" else 502), res

    def research_fetch(self, body, ip):
        url = self._req(body, "url", maxlen=2000)
        self._charge("net_calls")
        if body.get("async"):
            job = self.queue.enqueue("research_ingest", {"url": url}, priority=5, max_retries=3)
            return (201, {"ok": True, "queued": True, **job})
        page = research.fetch_page(url, self.s.research_max_bytes, self.s.research_timeout_seconds, self.s.research_allowed_domains)
        out = {"ok": True, "url": page["url"], "title": page["title"], "bytes": page["bytes"], "preview": page["text"][:500]}
        if body.get("ingest", True):
            out["rag"] = rag.ingest_text(page["text"], page["url"], page["title"], self.db_path, self.s.rag_max_chunks)
        return out

    def rag_ingest(self, body, ip):
        r = rag.ingest_text(self._req(body, "text", maxlen=2_000_000), str(body.get("source", "manual"))[:500], str(body.get("title", ""))[:300], self.db_path, self.s.rag_max_chunks)
        return (201, r)

    def rag_query(self, body, ip):
        q = self._req(body, "question", maxlen=1000)
        k = max(1, min(10, int(body.get("k", 4))))
        if body.get("answer", True):
            if any(self.s.credential_present(k) for k in ("GEMINI_API_KEY", "OPENAI_API_KEY", "GROQ_API_KEY")):
                self._charge("ai_calls")
            return rag.answer(q, self.db_path, k, max_chunks=self.s.rag_max_chunks)
        return {"ok": True, "hits": rag.retrieve(q, k, self.db_path, self.s.rag_max_chunks)}

    def rag_stats(self, body, ip):
        return {"ok": True, **rag.stats(self.db_path)}

    def cron_list(self, body, ip):
        return {"ok": True, "items": scheduler.list_cron_jobs(self.db_path), "runner": self.cron.status()}

    def cron_create(self, body, ip):
        handler = self._req(body, "handler")
        if handler not in ENQUEUE_ALLOWED or handler not in HANDLERS:
            raise ApiError(400, "handler_not_allowed", f"allowed: {sorted(ENQUEUE_ALLOWED)}")
        payload = body.get("payload", {})
        if not isinstance(payload, dict):
            raise ApiError(400, "invalid_field", "payload")
        out = scheduler.add_cron_job(self._req(body, "name", maxlen=64), self._req(body, "schedule", maxlen=100), handler, payload, db_path=self.db_path)
        record_audit("cron_created", ip, out, self.db_path)
        return (201, {"ok": True, **out})

    def cron_toggle(self, body, ip, id):
        if not scheduler.set_cron_enabled(id, bool(body.get("enabled", True)), self.db_path):
            raise ApiError(404, "not_found")
        return {"ok": True, "id": id, "enabled": bool(body.get("enabled", True))}

    def cron_delete(self, body, ip, id):
        if not scheduler.delete_cron_job(id, self.db_path):
            raise ApiError(404, "not_found")
        return {"ok": True, "id": id, "deleted": True}

    def doctor(self, body, ip):
        from kora.services.system_doctor import run_system_doctor_inspection
        return {"ok": True, **run_system_doctor_inspection(self.db_path)}

    def heal(self, body, ip):
        from kora.services.system_doctor import execute_safe_self_healing
        out = execute_safe_self_healing(self.db_path)
        record_audit("self_heal", ip, {"healed": out["healed"], "state": out["state"], "repaired_total": out["repaired_total"]}, self.db_path)
        return {"ok": True, **out}

    def backup(self, body, ip):
        from kora.services.backup import create_verified_backup
        out = create_verified_backup(self.db_path)
        record_audit("backup_created", ip, {"backup_id": out["backup_id"]}, self.db_path)
        return {"ok": True, **{k: v for k, v in out.items() if k != "path"}}

    def run_tests(self, body, ip):
        """Runs the behavioural suite in an isolated temp dir (never touches the live DB)."""
        p = _run_suite_subprocess()
        lines = [ln for ln in p.stdout.splitlines() if ln.strip()]
        passed = sum("[PASS]" in ln for ln in lines)
        failed = sum("[FAIL]" in ln for ln in lines)
        return {"ok": p.returncode == 0, "passed": passed, "failed": failed, "total": passed + failed, "output": lines[-60:]}

    def killswitch(self, body, ip):
        active = body.get("active")
        if not isinstance(active, bool):
            raise ApiError(400, "invalid_field", "active")
        if not active:
            self._require_step_up(self._tl.headers)  # lifting the kill switch is sensitive; turning it ON never needs a code
        self.queue.set_kill_switch(active)
        record_audit("kill_switch", ip, {"active": active}, self.db_path)
        return {"ok": True, "kill_switch": active}


    # ---------------------------------------------------------------- governance
    def proposals_list(self, body, ip):
        return {"ok": True, "items": governance.list_proposals(self.db_path, None, 100)}

    def proposal_detail(self, body, ip, id):
        """Read-only truth about one proposal: decision, recorded result, whether a patch / restore point exists on disk, and its audit trail.
        APPROVED never means EXECUTED: a code proposal runs only through the evidence gate (promote)."""
        rec = governance.get_proposal(id, self.db_path)
        if not rec:
            raise ApiError(404, "proposal_not_found")
        base = os.path.join(ROOT_DIR, "data", "evolution")
        patch_present = os.path.isfile(os.path.join(base, "proposals", f"{id}.patch"))
        rp = os.path.join(base, "restore_points", id)
        rp_files = sum(len(fs) for _d, _s, fs in os.walk(rp)) if os.path.isdir(rp) else 0
        conn = get_connection(self.db_path)
        try:
            ev = [{"event": r["event_type"], "actor": r["actor"], "at": r["created_at"]} for r in
                  conn.execute("SELECT event_type, actor, created_at FROM audit_events WHERE details LIKE ? ORDER BY id DESC LIMIT 20;", (f'%"{id}"%',)).fetchall()]
        finally:
            conn.close()
        try:
            result = json.loads(rec["result"]) if rec.get("result") else None
        except ValueError:
            result = None
        st = rec["status"]
        why = {"PENDING": "Waiting for the owner's decision. Nothing has changed.",
               "REJECTED": "Rejected. Nothing was applied.",
               "EXECUTED": "Executed and verified (see result and restore point).",
               "FAILED": "Attempted and failed; see result (a failed apply is rolled back).",
               "EXECUTING": "Running now."}.get(st)
        if st == "APPROVED":
            why = ("Approved but NOT executed: " + ("no patch exists for this proposal (none was generated, e.g. no AI provider configured), so there is nothing to apply."
                                                    if not patch_present else "the evidence gate (baseline, canary, tests) must pass and promote must run; check /api/evolution/3/gate/<id>."))
        try:
            chg = json.loads(rec.get("changes") or "[]")
        except ValueError:
            chg = []
        c0 = chg[0] if chg and isinstance(chg[0], dict) else {}
        extra = {k: c0[k] for k in ("owner_actions", "comparison", "guarantees") if k in c0}
        return {"ok": True, "proposal": {k: v for k, v in rec.items() if k not in ("result", "tests", "changes")}, **extra, "result": result,
                "executed": st == "EXECUTED", "patch_present": patch_present, "restore_point_present": rp_files > 0, "restore_point_files": rp_files,
                "audit_trail": ev, "explanation": why}

    def proposal_decide(self, body, ip, id, verb):
        conn = get_connection(self.db_path)
        try:
            rec = conn.execute("SELECT action, status FROM proposals WHERE id=?;", (id,)).fetchone()
        finally:
            conn.close()
        category = str(body.get("category", "uncategorized"))[:40]
        if verb == "postpone":  # keeps the proposal PENDING; only the owner's preference signal is recorded
            if not rec or rec["status"] != "PENDING":
                raise ApiError(409, "proposal_not_pending")
            se3.learn_decision(id, "postpone", category, self.db_path)
            return {"ok": True, "id": id, "status": "PENDING", "note": "postponed; still waiting for your decision"}
        approved = verb == "approve"
        if not governance.decide(id, approved, f"operator@{ip}", self.db_path):
            raise ApiError(409, "proposal_not_pending")
        se3.learn_decision(id, "approve" if approved else "reject", category, self.db_path)
        if approved and rec and rec["action"] == se3.PROVIDER_ACTION:  # owner decision only: nothing is installed, connected, enabled or charged
            return {"ok": True, "id": id, "status": "APPROVED", "executed": False,
                    "note": "Approved. The system did nothing: it cannot obtain a real API key or authorise an external account. Follow owner_actions "
                            "(set the variable in your own .env, restart, then re-run discovery). Never paste the key into chat or logs."}
        if approved and rec and rec["action"] == "MODIFY_CODE":
            gate = se3.promotion_gate(id, self.db_path, ROOT_DIR)
            if not gate["can_promote"]:
                return {"ok": True, "id": id, "status": "APPROVED", "evolution": {"status": "AWAITING_EVIDENCE", "blocked_by": gate["blocked_by"]},
                        "note": "Approved. Nothing was applied: the evidence gate still needs the listed items (baseline, canary, ...)."}
            result = se3.promote(id, self.db_path, ROOT_DIR, actor=f"operator@{ip}")
            return {"ok": result["status"] == "PROMOTED_VERIFIED", "id": id, "status": result["status"], "evolution": result,
                    "note": "Owner approval + full evidence gate passed; promoted and verified."}
        return {"ok": True, "id": id, "status": "APPROVED" if approved else "REJECTED",
                "note": "Approval authorises only the governed in-process action; external side effects remain separately gated."}

    def environment_get(self, body, ip):
        return {"ok": True, **ops.environment_get(self.db_path)}

    def environment_set(self, body, ip):
        return {"ok": True, **ops.environment_set(self._req(body, "profile", maxlen=20), self._actor(ip), self.db_path)}

    # ---------------------------------------------------------------- self-evolution / owner-approved improvement
    def godfather_health(self, body, ip):
        return {"ok": True, **godfather.capability_health(self.db_path)}

    def godfather_plan(self, body, ip):
        return {"ok": True, **godfather.plan_goal(self._req(body, "task", maxlen=2000), db_path=self.db_path)}

    def evolution_scan(self, body, ip):
        return {"ok": True, **self_evolution.scan(ROOT_DIR, self.db_path)}

    def evolution_2_audit(self, body, ip):
        return {"ok": True, **self_evolution_2.audit(ROOT_DIR, self.db_path, os.environ)}

    def evolution_2_plan(self, body, ip):
        goal = self._req(body, "goal", maxlen=500)
        self._charge("ai_calls") if body.get("research", False) else None
        return {"ok": True, **self_evolution_2.evolution_plan(goal, ROOT_DIR, self.db_path, os.environ)}

    def evolution_prepare(self, body, ip):
        urls = body.get("urls")
        if urls is not None and (not isinstance(urls, list) or len(urls) > 8 or not all(isinstance(u, str) for u in urls)):
            raise ApiError(400, "invalid_field", "urls")
        files = body.get("files")
        if files is not None and (not isinstance(files, list) or len(files) > 12 or not all(isinstance(x, str) for x in files)):
            raise ApiError(400, "invalid_field", "files")
        out = self._req(body, "goal", maxlen=500)
        if body.get("generate_patch", True):
            self._charge("ai_calls")
        if urls:
            self._charge("net_calls")
        try:
            return {"ok": True, **se3.propose(out, self.db_path, ROOT_DIR, urls=urls, files=files, generate_patch=body.get("generate_patch", True), env=os.environ,
                                              category=str(body.get("category", "uncategorized"))[:40])}
        except se3.EvolutionFrozen as exc:
            raise ApiError(409, "evolution_frozen", str(exc))

    def evolution_apply(self, body, ip, id):
        try:
            r = se3.promote(id, self.db_path, ROOT_DIR, actor=self._actor(ip))
        except se3.EvolutionFrozen as exc:
            raise ApiError(409, "evolution_frozen", str(exc))
        return {"ok": r["status"] == "PROMOTED_VERIFIED", **r}

    def evolution_rollback(self, body, ip, id):
        return {"ok": True, **se3.verified_rollback(id, self.db_path, ROOT_DIR, actor=self._actor(ip))}

    # ---------------------------------------------------------------- Self-Evolution 3.0 (GOOD FATHER): observe / learn / verify, owner-gated
    def _evo(self, fn, *a, **k):
        try:
            return {"ok": True, **fn(*a, **k)}
        except se3.EvolutionFrozen as exc:
            raise ApiError(409, "evolution_frozen", str(exc))
        except ValueError as exc:
            raise ApiError(400, "invalid_request", str(exc)[:120])

    def _envmap(self):
        return dict(os.environ) | dict(self.s.keys)

    def evo3_dashboard(self, body, ip):
        return self._evo(se3.dashboard, self.db_path)

    def evo3_capabilities(self, body, ip):
        return self._evo(se3.discover_capabilities, self.db_path, self._envmap())

    def evo3_gaps(self, body, ip):
        return self._evo(se3.detect_gaps, self.db_path, ROOT_DIR, None, self._envmap())

    def metrics_get(self, body, ip):
        from kora.services import assessment
        return {"ok": True, **assessment.metrics(self.db_path, pool_size=getattr(self.s, "worker_pool_size", None))}

    def assessment_history(self, body, ip):
        from kora.services import assessment
        return {"ok": True, "items": assessment.history(self.db_path)}

    def assessment_run(self, body, ip):
        """Owner-triggered READ-ONLY assessment: no edits, no network, no tests run."""
        from kora.services import assessment
        r = assessment.run_assessment(self.db_path, ROOT_DIR, env=self._envmap(), pool_size=getattr(self.s, "worker_pool_size", None))
        return {"ok": r["status"] in ("COMPLETED", "PARTIAL_DEADLINE", "PARTIAL_ERRORS"), **r}

    def egress_probe_run(self, body, ip):
        """Owner-triggered, explicit: TCP connect (no data sent) to two fixed public IPs. Evidence for/against 'offline' claims; not an air-gap proof."""
        from kora.services import assessment
        return {"ok": True, **assessment.egress_probe(db_path=self.db_path, actor=self._actor(ip))}

    def evo3_providers(self, body, ip):
        """Read-only: truthful provider comparison + exact owner actions. No network call, no key value is ever returned (only variable names)."""
        from kora.services import ai_failover
        env = self._envmap()
        return {"ok": True, "comparison": ai_failover.provider_comparison(env), "owner_actions": ai_failover.provider_owner_actions(env),
                "note": "research is NOT_RUN here; run POST /api/evolution/3/cycle (optionally with official policy URLs) to attach evidence"}

    def evo3_dependencies(self, body, ip):
        return self._evo(se3.dependency_intel, ROOT_DIR, self.db_path)

    def evo3_performance(self, body, ip):
        return self._evo(se3.performance_profile, self.db_path)

    def evo3_cycle(self, body, ip):
        urls = body.get("urls")
        if urls is not None and (not isinstance(urls, list) or len(urls) > 6 or not all(isinstance(u, str) for u in urls)):
            raise ApiError(400, "invalid_field", "urls")
        return self._evo(se3.run_cycle, self.db_path, ROOT_DIR, self._envmap(), str(body.get("goal", ""))[:300], urls)

    def evo3_resume(self, body, ip):
        return self._evo(se3.resume, self._req(body, "run_id", maxlen=60), self.db_path, ROOT_DIR, self._envmap())

    def evo3_memory(self, body, ip):
        return {"ok": True, "items": se3.memory(str(body.get("proposal_id", ""))[:80], str(body.get("stage", ""))[:40], self.db_path, 200), "chain": se3.verify_ledger(self.db_path)}

    def evo3_score(self, body, ip):
        f = body.get("factors")
        if not isinstance(f, dict):
            raise ApiError(400, "invalid_field", "factors")
        cat = str(body.get("category", "uncategorized"))[:40]
        return self._evo(se3.score, f, body.get("damaged") if isinstance(body.get("damaged"), list) else None, se3.preference_weight(cat, self.db_path))

    def evo3_predict(self, body, ip):
        return self._evo(se3.predict, str(body.get("proposal_id", ""))[:80], self.db_path, ROOT_DIR, self._envmap())

    def evo3_baseline(self, body, ip):
        return self._evo(se3.capture_baseline, self._req(body, "proposal_id", maxlen=80), self.db_path, ROOT_DIR)

    def evo3_canary(self, body, ip):
        return self._evo(se3.canary, self._req(body, "proposal_id", maxlen=80), self.db_path, ROOT_DIR)

    def evo3_gate(self, body, ip, id):
        return self._evo(se3.promotion_gate, id, self.db_path, ROOT_DIR)

    def evo3_rollback_points(self, body, ip):
        return {"ok": True, "items": se3.rollback_points(self.db_path, ROOT_DIR)}

    def evo3_freeze(self, body, ip):
        return self._evo(se3.freeze, self._actor(ip), self.db_path, str(body.get("reason", ""))[:200])

    def evo3_unfreeze(self, body, ip):
        return self._evo(se3.unfreeze, self._actor(ip), self.db_path)

    def evo3_legal_review(self, body, ip, id):
        return self._evo(se3.attest_legal_review, id, self._actor(ip), str(body.get("note", ""))[:300], self.db_path)

    def evo3_generate_test(self, body, ip):
        params = {k: str(v) for k, v in (body.get("params") or {}).items()} if isinstance(body.get("params"), dict) else {}
        return self._evo(se3.generate_test, self._req(body, "kind", maxlen=20), self.db_path, ROOT_DIR, **params)

    def evo3_chaos(self, body, ip):
        return self._evo(se3.chaos_check)

    def evo3_guard_add(self, body, ip):
        return self._evo(se3.add_guard, self._req(body, "pattern", maxlen=200), self._req(body, "reason", maxlen=300), body.get("files") if isinstance(body.get("files"), list) else None, "", self.db_path)

    def malak_get(self, body, ip):
        return {"ok": True, **dharma.get_rules(self.db_path)}

    def malak_set(self, body, ip):
        if "rollback_to" in body:
            return {"ok": True, **dharma.rollback(body["rollback_to"], f"operator@{ip}", self.db_path)}
        return {"ok": True, **dharma.set_rule(self._req(body, "key", maxlen=60), body.get("value"), f"operator@{ip}", self.db_path)}

    def guardian_status(self, body, ip):
        return {"ok": True, **supreme_guardian.status(self.db_path)}

    def guardian_inspect_tool(self, body, ip):
        return {"ok": True, **supreme_guardian.inspect_tool(self._req(body, "tool_id", maxlen=120), int(body.get("failure_count", 0)), str(body.get("payload", ""))[:10000], self.db_path)}

    def guardian_resolve(self, body, ip):
        return {"ok": True, **supreme_guardian.resolve_incident(self._req(body, "incident_id", maxlen=120), self._req(body, "resolution", maxlen=2000), verified=bool(body.get("verified", False)), actor=f"operator@{ip}", db_path=self.db_path)}

    def guardian_predict(self, body, ip):
        return {"ok": True, **supreme_guardian.future_predictor(self.db_path, window=int(body.get("window", 30)))}

    def guardian_memory_screen(self, body, ip):
        return {"ok": True, **supreme_guardian.inspect_memory(self._req(body, "text", maxlen=10000), str(body.get("source", "unknown"))[:300], float(body.get("confidence", 0.5)), self.db_path)}

    def guardian_meta_tool(self, body, ip):
        return {"ok": True, **supreme_guardian.register_meta_tool(self._req(body, "name", maxlen=80), body.get("steps") or [], benchmark=body.get("benchmark") or {}, db_path=self.db_path)}

    def guardian_malak_profile(self, body, ip):
        return {"ok": True, **supreme_guardian.malak_profile(self.db_path)}

    def guardian_recycle_scan(self, body, ip):
        return {"ok": True, **supreme_guardian.recycle_scan(self._req(body, "root", maxlen=500), self.db_path)}

    def guardian_refuse(self, body, ip):
        return {"ok": True, **supreme_guardian.refusal(self._req(body, "action", maxlen=100), str(body.get("context", ""))[:5000], self.db_path)}

    def guardian_watchdog(self, body, ip):
        return {"ok": True, **supreme_guardian.watchdog(self.db_path)}

    def guardian_supervisor_tick(self, body, ip):
        return {"ok": True, **supreme_guardian.supervisor_tick(self.db_path)}

    def guardian_vault_put(self, body, ip):
        return {"ok": True, **supreme_guardian.vault_put(self._req(body, "name", maxlen=120), self._req(body, "value", maxlen=10000), ttl_seconds=body.get("ttl_seconds"), db_path=self.db_path)}

    def guardian_vault_get(self, body, ip):
        return {"ok": True, **supreme_guardian.vault_get(self._req(body, "name", maxlen=120), self.db_path)}

    def guardian_vault_revoke(self, body, ip):
        return {"ok": True, **supreme_guardian.vault_revoke(self._req(body, "name", maxlen=120), self.db_path)}

    def guardian_vault_rotate(self, body, ip):
        return {"ok": True, **supreme_guardian.rotate_master_key(self._req(body, "old_key", maxlen=200), self._req(body, "new_key", maxlen=200), self.db_path)}

    def malak_assist_pause(self, body, ip):
        out = malak_assist.pause_for_malak(self._req(body, "reason", maxlen=40), body.get("checkpoint") or {}, task_id=body.get("task_id"), db_path=self.db_path, ttl_seconds=int(body.get("ttl_seconds", 3600)), channels=body.get("channels"))
        out.pop("resume_token", None)  # the one-time code goes ONLY to the Malak channel, never back to the requester
        return {"ok": True, **out}

    def malak_assist_inbound(self, body, ip):
        out = malak_assist.handle_inbound(self._req(body, "channel", maxlen=20), str(body.get("sender", ""))[:100], str(body.get("text", ""))[:500], db_path=self.db_path)
        return {"ok": out.get("status") == "RESUMABLE", **{k: v for k, v in out.items() if k != "checkpoint"}}

    def _webhook_gate(self, ip):
        allowed, _ = self.limiter.allow(f"{ip}:malak-webhook", 60, burst=30)
        if not allowed:
            raise ApiError(429, "rate_limited", "retry_after=5")

    def malak_webhook_telegram(self, body, ip):
        """Public route that authenticates ITSELF: Telegram's secret-token header must match. Unset secret => NOT_CONFIGURED (503)."""
        self._webhook_gate(ip)
        want = os.getenv("KORA_MALAK_TELEGRAM_WEBHOOK_SECRET", "")
        if not want:
            raise ApiError(503, "not_configured", "KORA_MALAK_TELEGRAM_WEBHOOK_SECRET")
        got = self._tl.headers.get("x-telegram-bot-api-secret-token", "")
        if not constant_time_compare(got, want):
            record_audit("malak_assist_rejected", ip, {"reason": "bad_webhook_secret", "channel": "telegram"}, self.db_path)
            raise ApiError(401, "bad_webhook_secret")
        msg = body.get("message") or body.get("edited_message") or {}
        sender = str((msg.get("chat") or {}).get("id", ""))
        out = malak_assist.handle_inbound("telegram", sender, str(msg.get("text", ""))[:500], db_path=self.db_path)
        return {"ok": True, "status": out.get("status")}  # never echo checkpoint/code

    def malak_webhook_whatsapp_verify(self, body, ip):
        self._webhook_gate(ip)
        want = os.getenv("KORA_WHATSAPP_VERIFY_TOKEN", "")
        if not want:
            raise ApiError(503, "not_configured", "KORA_WHATSAPP_VERIFY_TOKEN")
        import urllib.parse as _up
        q = {k: v[0] for k, v in _up.parse_qs(getattr(self._tl, "query", "") or "").items()}
        if q.get("hub.mode") != "subscribe" or not constant_time_compare(q.get("hub.verify_token", ""), want):
            raise ApiError(403, "verify_failed")
        return (200, str(q.get("hub.challenge", ""))[:200].encode(), "text/plain")

    def malak_webhook_whatsapp(self, body, ip):
        """X-Hub-Signature-256 = HMAC-SHA256(app secret, raw body). No app secret => NOT_CONFIGURED; bad signature => 401."""
        self._webhook_gate(ip)
        secret = os.getenv("KORA_WHATSAPP_APP_SECRET", "")
        if not secret:
            raise ApiError(503, "not_configured", "KORA_WHATSAPP_APP_SECRET")
        import hmac as _h, hashlib as _hl
        raw = getattr(self._tl, "raw_body", b"") or b""
        expect = "sha256=" + _h.new(secret.encode(), raw, _hl.sha256).hexdigest()
        if not constant_time_compare(self._tl.headers.get("x-hub-signature-256", ""), expect):
            record_audit("malak_assist_rejected", ip, {"reason": "bad_signature", "channel": "whatsapp"}, self.db_path)
            raise ApiError(401, "bad_signature")
        results = []
        for entry in body.get("entry", []) or []:
            for ch in entry.get("changes", []) or []:
                for m in (ch.get("value") or {}).get("messages", []) or []:
                    if m.get("type") == "text":
                        o = malak_assist.handle_inbound("whatsapp", str(m.get("from", "")), str((m.get("text") or {}).get("body", ""))[:500], db_path=self.db_path)
                        results.append(o.get("status"))
        return {"ok": True, "processed": len(results), "statuses": results}

    def malak_assist_escalate(self, body, ip):
        return {"ok": True, **malak_assist.tick(self.db_path)}

    def malak_assist_recover(self, body, ip):
        return {"ok": True, **malak_assist.recover(self.db_path)}

    def malak_assist_cancel(self, body, ip, id):
        out = malak_assist.cancel(id, db_path=self.db_path)
        if out.get("status") != "CANCELLED": raise ApiError(409, "not_cancellable")
        return {"ok": True, **out}

    def malak_assist_get(self, body, ip, id):
        return {"ok": True, **malak_assist.get_task(id, self.db_path)}

    def malak_assist_list(self, body, ip):
        return {"ok": True, **malak_assist.list_waiting(self.db_path)}

    def malak_assist_resume(self, body, ip, id):
        out = malak_assist.resume(id, self._req(body, "resume_token", maxlen=200) if body.get("resume_token") else self._req(body, "code", maxlen=100), note=str(body.get("note", "Malak approved")), db_path=self.db_path)
        return {"ok": out.get("status") == "RESUMABLE", **out}

    def cost_get(self, body, ip):
        return {"ok": True, **cost.snapshot(*self._caps(), db_path=self.db_path)}

    def legal_preflight(self, body, ip):
        return {"ok": True, **legal_guard.preflight(body)}

    def safe_mode(self, body, ip):
        active = body.get("active")
        if not isinstance(active, bool):
            raise ApiError(400, "invalid_field", "active")
        if not active:
            self._require_step_up(self._tl.headers)
        return {"ok": True, **emergency.set_safe_mode(active, f"operator@{ip}", self.db_path)}

    def emergency(self, body, ip):
        return {"ok": True, **emergency.emergency_recovery(f"operator@{ip}", self.db_path)}

    def emergency_resume(self, body, ip):
        out = emergency.resume(f"operator@{ip}", self.db_path)
        return (200 if out["status"] == "RESUMED" else 409), {"ok": out["status"] == "RESUMED", **out}

    def sena_attack(self, body, ip):
        return {"ok": True, **sena.attack_plan(self._req(body, "topic", maxlen=300))}

    def sena_team(self, body, ip):
        roles = body.get("roles")
        if not isinstance(roles, list):
            raise ApiError(400, "invalid_field", "roles")
        return {"ok": True, **sena.clone_team(roles)}


    # ---------------------------------------------------------------- identity / step-up
    def _require_step_up(self, headers) -> None:
        """Once the owner has enrolled TOTP, sensitive owner actions need a fresh one-time code (X-Kora-Totp)."""
        if identity.totp_enrolled(self.db_path) and identity.step_up(headers.get("x-kora-totp", ""), self.db_path) != "OK":
            record_audit("step_up_failed", "owner", {}, self.db_path)
            raise ApiError(403, "step_up_required", "send a valid one-time code in X-Kora-Totp")

    def _actor(self, ip) -> str:
        p = getattr(self._tl, "principal", {"id": "owner", "role": "owner"})
        return f"{p['role']}:{p['id']}@{ip}"

    def security_status(self, body, ip):
        chain = verify_audit_chain(self.db_path)
        return {"ok": True, "totp_enrolled": identity.totp_enrolled(self.db_path),
                "recommendation": None if identity.totp_enrolled(self.db_path) else "enrol TOTP (POST /api/security/totp) to protect sensitive actions",
                "principals": len(identity.list_principals(self.db_path)), "audit_chain": chain, "safe_mode": policy.is_safe_mode(self.db_path),
                "voice_enabled": brain.voice_enabled(self.db_path), "frozen_note": "see /api/ops"}

    def totp_enroll(self, body, ip):
        return Reveal({"ok": True, **identity.totp_enroll(self.db_path, str(body.get("current_code", "")))}, ("secret",))

    def principals_list(self, body, ip):
        return {"ok": True, "items": identity.list_principals(self.db_path)}

    def principal_create(self, body, ip):
        ttl = body.get("ttl_seconds")
        return (201, Reveal({"ok": True, **identity.create_principal(self._req(body, "name", maxlen=80), self._req(body, "role", maxlen=10), self._actor(ip), self.db_path,
                                                                     ttl_seconds=ttl if isinstance(ttl, (int, float)) and ttl > 0 else None)}, ("token",)))

    def principal_revoke(self, body, ip, id):
        if not identity.revoke_principal(id, self._actor(ip), self.db_path):
            raise ApiError(404, "principal_not_found_or_revoked")
        return {"ok": True, "id": id, "revoked": True}

    def principal_grant(self, body, ip, id):
        ttl = body.get("ttl_seconds")
        return (201, {"ok": True, **identity.grant(id, self._req(body, "permission", maxlen=40), ttl if isinstance(ttl, (int, float)) else None, self._actor(ip), self.db_path)})

    def grant_revoke(self, body, ip, id):
        if not identity.revoke_grant(id, self._actor(ip), self.db_path):
            raise ApiError(404, "grant_not_found_or_revoked")
        return {"ok": True, "id": id, "revoked": True}

    # ---------------------------------------------------------------- brain / voice
    def brain(self, body, ip):
        p = self._tl.principal
        res = brain.handle(self._req(body, "text", maxlen=500), principal=p, source=str(body.get("source", "text")), db_path=self.db_path,
                           voice_verified=bool(body.get("voice_verified", False)) and ops.flag_get("voice_session_trust", self.db_path),
                           totp_code=str(body.get("totp", "") or self._tl.headers.get("x-kora-totp", "")))
        return {"ok": res["status"] in ("OK", "PLANNED"), **res}

    def studio_plan(self, body, ip):
        category = self._req(body, "category", maxlen=80)
        return {"ok": True, **hollywood_studio.studio_plan(category, original=bool(body.get("original", True)), manual=bool(body.get("manual", True)), automatic=bool(body.get("automatic", True)))}

    # ---------------------------------------------------------------- Studio (import / library / preview / edit / drafts) — one media engine (media_pipeline)
    @staticmethod
    def _media_root() -> str:
        return os.path.abspath(os.environ.get("KORA_MEDIA_DIR", "data/media"))

    def studio_capabilities(self, body, ip):
        from kora.services import media_pipeline
        return {"ok": True, **media_pipeline.studio_capabilities()}

    def studio_assets(self, body, ip):
        from kora.services import media_pipeline
        return {"ok": True, "items": media_pipeline.list_assets(self._media_root())}

    def studio_upload(self, body, ip):
        import base64
        import binascii
        from kora.services import media_pipeline
        name = self._req(body, "name", maxlen=80)
        index, total = body.get("index"), body.get("total")
        if not isinstance(index, int) or isinstance(index, bool) or not isinstance(total, int) or isinstance(total, bool):
            raise ApiError(400, "invalid_field", "index/total")
        try:
            data = base64.b64decode(self._req(body, "data_b64", maxlen=1100000), validate=True)
        except (binascii.Error, ValueError):
            raise ApiError(400, "invalid_field", "data_b64")
        try:
            out = media_pipeline.upload_chunk(self._media_root(), name, index, total, data)
        except media_pipeline.MediaPipelineError as e:
            raise ApiError(400, "upload_failed", str(e)[:200])
        if out.get("state", "").startswith("IMPORTED"):
            record_audit("studio_import", self._actor(ip), {"asset": out["id"], "bytes": out["bytes"], "state": out["state"]}, self.db_path)
        return {"ok": True, **out}

    def studio_preview(self, body, ip):
        from kora.services import media_pipeline
        try:
            return {"ok": True, **media_pipeline.read_preview(self._media_root(), self._req(body, "id", maxlen=80))}
        except media_pipeline.MediaPipelineError as e:
            code = str(e)
            raise ApiError(413 if code.startswith("too_large") else 404 if code == "asset_not_found" else 400, "preview_failed", code[:200])

    def studio_edit(self, body, ip):
        from kora.services import media_pipeline
        ops = body.get("ops")
        if not isinstance(ops, dict):
            raise ApiError(400, "invalid_field", "ops")
        try:
            out = media_pipeline.edit_media(self._media_root(), self._req(body, "id", maxlen=80), ops, out_name=body.get("output_name") if isinstance(body.get("output_name"), str) else None)
        except media_pipeline.MediaPipelineError as e:
            raise ApiError(400, "edit_failed", str(e)[:200])
        record_audit("studio_edit", self._actor(ip), {"asset": body.get("id"), "ops": sorted(ops), "state": out.get("state")}, self.db_path)
        return {"ok": out.get("state") == "EDITED_VERIFIED", **out}

    def studio_quality(self, body, ip):
        """Measured quality gate for one library asset. Destination policy is NOT evaluated (no live platform-policy source)."""
        from kora.services import media_pipeline
        mid = self._req(body, "id", maxlen=80)
        try:
            rec = media_pipeline.asset_record(self._media_root(), mid)
        except media_pipeline.MediaPipelineError as e:
            raise ApiError(404, "asset_not_found", str(e)[:120])
        m = rec.get("measured")
        if not m:
            return {"ok": False, "decision": "UNVERIFIED", "reason": "ffprobe_unavailable_or_unreadable", "asset": rec}
        w, h = m.get("width"), m.get("height")
        checks = {"resolution_known": bool(w and h) or rec["kind"] == "audio", "duration_known": rec["kind"] == "image" or bool(m.get("duration_s")),
                  "audio_present": m.get("has_audio") if rec["kind"] == "video" else None, "file_size_mb": round(rec["bytes"] / 1048576, 2),
                  "aspect_ratio": round(w / h, 4) if w and h else None}
        ok = checks["resolution_known"] and checks["duration_known"]
        return {"ok": ok, "decision": "PASS" if ok else "REVIEW", "checks": checks, "measured": m,
                "captions": "NOT_EVALUATED (use subtitles service)", "destination_policy": "NOT_EVALUATED (no live platform-policy source)"}

    def studio_projects(self, body, ip):
        return {"ok": True, "items": hollywood_studio.list_projects(self._media_root())}

    def studio_project_save(self, body, ip):
        try:
            out = hollywood_studio.save_project(self._media_root(), self._req(body, "name", maxlen=60), body.get("data") if isinstance(body.get("data"), dict) else {})
        except ValueError as e:
            raise ApiError(400, "project_failed", str(e)[:120])
        return {"ok": True, **out}

    def studio_project_load(self, body, ip):
        try:
            return {"ok": True, **hollywood_studio.load_project(self._media_root(), self._req(body, "name", maxlen=60))}
        except ValueError as e:
            raise ApiError(404 if str(e) == "project_not_found" else 400, "project_failed", str(e)[:120])

    def asset_variants(self, body, ip):
        master_asset = self._req(body, "master_asset", maxlen=2000)
        platforms = body.get("platforms")
        if platforms is not None and (not isinstance(platforms, list) or any(not isinstance(x, str) for x in platforms)):
            raise ApiError(400, "invalid_field", "platforms")
        return {"ok": True, **asset_compiler.compile_variants(master_asset, platforms)}

    def workflow_plan(self, body, ip):
        goal = self._req(body, "goal", maxlen=3000)
        return {"ok": True, "state": "PLANNED_NOT_EXECUTED", "goal": goal,
                "pipeline": ["UNDERSTAND", "RIGHTS", "PLAN", "CREATE_OR_EDIT", "QUALITY", "PLATFORM_VARIANTS", "PREVIEW", "APPROVAL_IF_REQUIRED", "PUBLISH_IF_AUTHORIZED", "VERIFY", "LEARN"],
                "truth": "Planning only; no media export, social post, revenue or viral result is claimed."}

    def voice_set(self, body, ip):
        en = body.get("enabled")
        if not isinstance(en, bool):
            raise ApiError(400, "invalid_field", "enabled")
        return {"ok": True, **brain.set_voice(en, self._actor(ip), self.db_path)}

    def voice_consent(self, body, ip):
        r = voice_consent.record_consent(self._req(body, "subject", maxlen=80), str(body.get("scope", "")), adult=body.get("adult") is True,
                                         explicit_permission=body.get("explicit_permission") is True, live_confirmation=body.get("live_confirmation") is True,
                                         totp_code=str(body.get("totp", "")), db_path=self.db_path)
        return (200 if r["status"] == "RECORDED" else 403), {"ok": r["status"] == "RECORDED", **r}

    # ---------------------------------------------------------------- DNA / time machine
    def dna_get(self, body, ip, kind):
        return {"ok": True, **dna.get(kind, self.db_path), "stale": dna.stale(kind, self.db_path)}

    def dna_history(self, body, ip, kind):
        return {"ok": True, "items": dna.history(kind, self.db_path)}

    def dna_set(self, body, ip):
        return (201, {"ok": True, **dna.set_pref(self._req(body, "kind", maxlen=30), self._req(body, "key", maxlen=60), body.get("value"),
                                                 source=str(body.get("source", "explicit")), confidence=float(body.get("confidence", 1.0)),
                                                 actor=self._actor(ip), db_path=self.db_path)})

    def dna_diff(self, body, ip):
        return {"ok": True, **dna.diff(self._req(body, "kind", maxlen=30), int(body.get("a", 0)), int(body.get("b", 0)), self.db_path)}

    def dna_restore(self, body, ip):
        confirm = body.get("confirm") is True
        if confirm:
            self._require_step_up(self._tl.headers)  # applying a restore is sensitive; a preview is not
        return {"ok": True, **dna.restore(self._req(body, "kind", maxlen=30), int(body.get("version", 0)), self._actor(ip), self.db_path, confirm=confirm)}

    # ---------------------------------------------------------------- shadow / auto-post / research / dhanda
    def shadow_post(self, body, ip, id):
        r = shadow.preview_post(id, self.db_path)
        if r["status"] == "NOT_FOUND":
            raise ApiError(404, "not_found")
        return {"ok": True, **r}

    def autopost(self, body, ip):
        r = auto_post_legal.prepare(self._req(body, "platform"), self._req(body, "content", maxlen=10000),
                                    body.get("audience") or dharma.get_rule("default_audience", "GENERAL", self.db_path), self.db_path,
                                    rights=str(body.get("rights", "")), source=str(body.get("source", "")), media_path=body.get("media_path"),
                                    ai_generated=bool(body.get("ai_generated", False)), title=body.get("title"), idempotency_key=body.get("idempotency_key"),
                                    queue=self.queue, media_root=os.path.abspath(os.environ.get("KORA_MEDIA_DIR", "data/media")))
        return (201, {"ok": True, **r})

    def research_deep(self, body, ip):
        urls = body.get("urls")
        if urls is not None and (not isinstance(urls, list) or len(urls) > 10 or not all(isinstance(u, str) for u in urls)):
            raise ApiError(400, "invalid_field", "urls")
        cost.charge("net_calls", *self._caps(), db_path=self.db_path, amount=float(min(6, len(urls)) if urls else 7))
        fetch = lambda u: research.fetch_page(u, self.s.research_max_bytes, self.s.research_timeout_seconds, self.s.research_allowed_domains)
        r = fusion.deep_research(self._req(body, "question", maxlen=500), urls, fetch=fetch)
        if body.get("science"):
            r["science_lab"] = fusion.science_report(str(body["science"])[:300], r, body.get("calculation"))
        return {"ok": r["status"] != "UNAVAILABLE", **r}

    def ledger_add(self, body, ip):
        return (201, {"ok": True, **dhanda.add_entry(self._req(body, "kind", maxlen=10), body.get("amount"), self._req(body, "note", maxlen=300),
                                                     str(body.get("currency", "USD")), bool(body.get("estimated", False)), str(body.get("evidence", "")), self.db_path,
                                                     source=str(body.get("source", "")), fees=body.get("fees", 0.0), payout_ref=str(body.get("payout_ref", "")))})

    def backup_321(self, body, ip):
        from kora.services import backup as _bk
        root = os.path.realpath(os.path.dirname(os.path.abspath(self.db_path)))
        def inside(p):
            rp = os.path.realpath(str(p))
            return rp.startswith(root + os.sep) or rp.startswith(os.path.realpath(str(body.get("offsite_dir") or "/nonexistent")) + os.sep)
        src, copies = str(body.get("source", "")), [str(x) for x in (body.get("copies") or [])][:6]
        if not src or not all(inside(p) for p in [src] + copies):
            raise ApiError(400, "path_outside_data_dir")
        return {"ok": True, **_bk.backup_321_report(src, copies, str(body.get("offsite_dir", "")), bool(body.get("offsite_attested", False)))}

    # ---- growth loop (additive; every number is evidence-classed, nothing is charged/paid/published here)
    def growth_campaign(self, body, ip):
        keys = ("platform", "language", "hook", "cta", "post_hour", "asset_id", "roi_target", "cost", "currency")
        return (201, {"ok": True, **growth_loop.create_campaign(self._req(body, "merchant", maxlen=100), self._req(body, "offer", maxlen=200), db_path=self.db_path,
                                                                actor=self._actor(ip), **{k: body[k] for k in keys if k in body})})

    def growth_event(self, body, ip, id):
        return (201, {"ok": True, **growth_loop.record_event(id, self._req(body, "kind", maxlen=20), count=body.get("count", 1), amount=body.get("amount", 0.0), source=str(body.get("source", "")),
                                                              evidence_ref=str(body.get("evidence_ref", "")), ledger_id=body.get("ledger_id"), idempotency_key=str(body.get("idempotency_key", "")),
                                                              db_path=self.db_path, actor=self._actor(ip))})

    def growth_roi(self, body, ip, id):
        return {"ok": True, **growth_loop.roi(id, self.db_path)}

    def growth_link(self, body, ip):
        return {"ok": True, **growth_loop.attribution_link(self._req(body, "base_url", maxlen=500), self._req(body, "campaign_id", maxlen=60), str(body.get("asset_id", ""))[:60])}

    def growth_dna(self, body, ip):
        return {"ok": True, **growth_loop.marketing_dna(str(body.get("group_by", "hook")), self.db_path)}

    def growth_pilot_shop(self, body, ip):
        return (201, {"ok": True, **growth_loop.pilot_add_shop(self._req(body, "name", maxlen=100), str(body.get("category", "")), body.get("window_days", 7), self.db_path, actor=self._actor(ip))})

    def growth_pilot_obs(self, body, ip, id):
        return (201, {"ok": True, **growth_loop.pilot_record(id, str(body.get("phase", "")), str(body.get("date", "")), body.get("sales"), photo_ref=str(body.get("photo_ref", "")),
                                                              source=str(body.get("source", "")), evidence_ref=str(body.get("evidence_ref", "")), db_path=self.db_path, actor=self._actor(ip))})

    def growth_pilot_attest(self, body, ip, id):
        return {"ok": True, **growth_loop.pilot_attest(int(id), actor=self._actor(ip), db_path=self.db_path)}

    def growth_pilot_eval(self, body, ip, id):
        return {"ok": True, **growth_loop.pilot_evaluate(id, self.db_path)}

    def growth_pilot_summary(self, body, ip):
        return {"ok": True, **growth_loop.pilot_summary(self.db_path)}

    def growth_competitor_add(self, body, ip):
        keys = ("source", "public_evidence", "kilcritic_status", "gap", "cost", "risk", "legal_constraint", "impact", "feasibility", "test_plan", "next_action")
        return (201, {"ok": True, **growth_loop.competitor_add(self._req(body, "capability", maxlen=120), db_path=self.db_path, actor=self._actor(ip), **{k: body[k] for k in keys if k in body})})

    def growth_competitor_rank(self, body, ip):
        return {"ok": True, "radar": growth_loop.competitor_rank(self.db_path)}

    def growth_festival(self, body, ip):
        return {"ok": True, **growth_loop.festival_plan(self._req(body, "festival", maxlen=60), str(body.get("date", "")), str(body.get("category", "")), str(body.get("language", "pa")), body.get("count", 5))}

    def ledger_summary(self, body, ip):
        return {"ok": True, "ledger": dhanda.summary(self.db_path)}

    def dhanda_score(self, body, ip):
        return {"ok": True, **dhanda.score(body)}

    # ---------------------------------------------------------------- ATMA / skills / ops
    def atma_status(self, body, ip):
        return {"ok": True, **atma.identity(self.db_path), "guardian": atma.guardian_status(self.db_path), "restore_points": atma.list_restore_points(self.db_path, 10)}

    def atma_restore(self, body, ip):
        r = atma.phoenix_restore(self._req(body, "backup_id", maxlen=80), self._actor(ip), self.db_path)
        return (200 if r["status"].startswith("RESTORED") else 409), {"ok": r["status"].startswith("RESTORED"), **r}

    def mission_create(self, body, ip):
        ms = body.get("milestones", [])
        if not isinstance(ms, list):
            raise ApiError(400, "invalid_field", "milestones")
        return (201, {"ok": True, **atma.mission_set(self._req(body, "goal", maxlen=500), ms, self.db_path)})

    def mission_progress(self, body, ip, id):
        return {"ok": True, **atma.mission_progress(id, body.get("index"), str(body.get("evidence", "")), self.db_path)}

    def skills_list(self, body, ip):
        return {"ok": True, "items": trust.list_skills(HANDLERS, self.db_path)}

    def skill_approve(self, body, ip, name):
        try:
            return {"ok": True, "trust": trust.approve_skill(name, HANDLERS, self._actor(ip), self.db_path)}
        except KeyError:
            raise ApiError(404, "skill_not_registered")

    def health_deep(self, body, ip):
        return {"ok": True, **ops.health(self.db_path)}

    def pressure_apply(self, body, ip):
        return {"ok": True, **ops.apply_pressure(self.db_path)}

    def accounts_get(self, body, ip):
        return {"ok": True, "items": social.accounts_for(brain.owner_key(self._tl.principal), self.db_path),
                "note": "status metadata only; platform tokens are not stored here"}

    def accounts_set(self, body, ip):
        try:
            r = social.account_set(brain.owner_key(self._tl.principal), self._req(body, "platform", maxlen=20), self._req(body, "status", maxlen=20),
                                   str(body.get("handle", "")), self.db_path)
        except social.SocialPublishError as exc:
            raise ApiError(400, "invalid_account", str(exc))
        return {"ok": True, **r}

    def posting_route(self, body, ip):
        pl = body.get("platforms")
        if not isinstance(pl, list) or not 1 <= len(pl) <= 5 or not all(isinstance(x, str) for x in pl):
            raise ApiError(400, "invalid_field", "platforms")
        return {"ok": True, **social.route_posting(brain.owner_key(self._tl.principal), pl, self.db_path, dict(os.environ) | dict(self.s.keys))}

    def predict(self, body, ip):
        kind = self._req(body, "kind", maxlen=20)
        if kind not in ("render", "media", "quality", "ai", "research", "publish", "generic"):
            raise ApiError(400, "invalid_field", "kind")
        params = body.get("params", {}) if isinstance(body.get("params", {}), dict) else {}
        params.setdefault("owner", brain.owner_key(self._tl.principal))
        return {"ok": True, **ops.predict_failure(kind, params, self.db_path, dict(os.environ) | dict(self.s.keys))}

    def dry_run(self, body, ip):
        try:
            return {"ok": True, **ops.dry_run(self._req(body, "action", maxlen=40), body.get("params") if isinstance(body.get("params"), dict) else {}, self.db_path)}
        except (ValueError, KeyError, dna.DnaError) as exc:
            raise ApiError(400, "invalid_dry_run", str(exc)[:100])

    def quality_verify(self, body, ip):
        from kora.services import media_pipeline
        try:
            path = social._safe_media_path(self._req(body, "path", maxlen=500), social.MEDIA_ROOT)
        except Exception:
            raise ApiError(400, "invalid_path", "must be inside the media directory")
        return {"ok": True, **media_pipeline.verify_quality(path, body.get("claimed") if isinstance(body.get("claimed"), dict) else {})}

    def trust_score(self, body, ip):
        return {"ok": True, **trust.score(self._req(body, "subject_type", maxlen=30), self._req(body, "subject_id", maxlen=120), self.db_path)}

    def dna_observe(self, body, ip):
        try:
            return {"ok": True, **dna.observe(self._req(body, "kind", maxlen=30), self._req(body, "key", maxlen=60), body.get("value"), self.db_path)}
        except dna.DnaError as exc:
            raise ApiError(400, "invalid_dna", str(exc))

    def dna_rollback_learned(self, body, ip):
        try:
            return {"ok": True, **dna.rollback_learned(self._req(body, "kind", maxlen=30), self.db_path, confirm=body.get("confirm") is True, actor=self._actor(ip))}
        except dna.DnaError as exc:
            raise ApiError(400, "invalid_dna", str(exc))

    def error_explain(self, body, ip):
        from kora.core.contracts import explain_error
        return {"ok": True, **explain_error(self._req(body, "category", maxlen=30), str(body.get("detail", ""))[:200], str(body.get("tried", ""))[:200])}

    def brain_choose(self, body, ip):
        opts = body.get("options")
        if not isinstance(opts, list) or not 1 <= len(opts) <= 10 or not all(isinstance(o, dict) and isinstance(o.get("name"), str) for o in opts):
            raise ApiError(400, "invalid_field", "options")
        return {"ok": True, **brain.choose_option(opts)}

    def tasks_blocked(self, body, ip):
        return {"ok": True, "items": self.queue.blocked_by_dependency()}

    def ops_status(self, body, ip):
        return {"ok": True, "resources": ops.resources(self.db_path), "flags": ops.flags(self.db_path), "notifications": ops.notifications(self.db_path),
                "frozen_operations": [h for h in HANDLERS if anti_loop.is_frozen(h, self.db_path)],
                "pressure": ops.pressure_level(self.db_path)}

    def flag_set(self, body, ip):
        try:
            ops.flag_set(self._req(body, "name", maxlen=60), body.get("value") is True, self._actor(ip), self.db_path)
        except KeyError:
            raise ApiError(404, "unknown_flag")
        return {"ok": True, "flags": ops.flags(self.db_path)}

    def providers(self, body, ip):
        return {"ok": True, "items": provider_states(dict(os.environ) | dict(self.s.keys))}

    def data_export(self, body, ip):
        fd, path = tempfile.mkstemp(suffix=".zip")
        os.close(fd)
        try:
            ops.export_zip(self.db_path, path)
            with open(path, "rb") as fh:
                return 200, fh.read(), "application/zip"
        finally:
            os.remove(path)

    def data_delete(self, body, ip):
        r = ops.delete_user_data(self.db_path, str(body.get("confirm", "")), self._actor(ip))
        return (200 if r["status"] == "DELETED_FROM_LIVE_DB" else 400), {"ok": r["status"] == "DELETED_FROM_LIVE_DB", **r}

    def audit_verify(self, body, ip):
        return {"ok": True, **verify_audit_chain(self.db_path)}

    def op_unfreeze(self, body, ip, op):
        anti_loop.unfreeze(op, self._actor(ip), self.db_path)
        return {"ok": True, "op": op, "frozen": False}


def create_app(settings: Optional[Settings] = None, db_path: Optional[str] = None, init: bool = True) -> KoraApp:
    return KoraApp(settings, db_path, init)


# Module-level WSGI callable for `python -m wsgiref`-style servers / the legacy `app.main:app` import path.
# Built lazily so importing this module has no filesystem side effects until a request arrives.
class _LazyApp:
    _inst: Optional[KoraApp] = None

    def __call__(self, environ, start_response):
        if _LazyApp._inst is None:
            _LazyApp._inst = KoraApp()
        return _LazyApp._inst(environ, start_response)


app = _LazyApp()


# KORA_INFINITE_CORE_INTEGRATION: measured, bounded execution profile.
try:
    from kora.bridge.infinite_core_integration import resource_execution_profile
except Exception:
    resource_execution_profile = None
