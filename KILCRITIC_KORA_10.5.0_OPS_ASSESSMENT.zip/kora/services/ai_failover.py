"""
KORA PRO - AI routing with circuit-breaker failover.

Order: Gemini -> OpenAI -> Groq -> deterministic local fallback (clearly labelled `local_deterministic_fallback`).
A provider with no key is skipped. A provider that errors (timeout / 429 / 5xx / bad body) is recorded as failed and
the next one is tried; after `breaker_threshold` consecutive failures it is skipped for `breaker_cooldown` seconds.
The local fallback never pretends to be an LLM. Real provider calls are UNVERIFIED in this build (no credentials
were available); the request/response handling is exercised against an injected transport in the test suite.
"""
import json
import os
import threading
import re
import time
from typing import Any, Callable, Dict, List, Optional

from kora.core.http import TransportError, https_request

_lock = threading.Lock()
_breaker: Dict[str, Dict[str, float]] = {}
BREAKER_THRESHOLD = 3
BREAKER_COOLDOWN = 60.0

OPENAI_URL = "https://api.openai.com/v1/chat/completions"
GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"


def reset_breakers() -> None:
    with _lock:
        _breaker.clear()


def _open(provider: str, now: float) -> bool:
    with _lock:
        b = _breaker.get(provider)
        return bool(b and b.get("until", 0) > now)


def _record(provider: str, ok: bool, now: float, err: str = "") -> None:
    with _lock:
        b = _breaker.setdefault(provider, {"fails": 0, "until": 0})
        if ok:
            b["fails"], b["until"], b["ok"] = 0, 0, 1
        else:
            b["fails"] += 1
            b["last_429"] = 1 if "429" in err else 0
            if b["fails"] >= BREAKER_THRESHOLD:
                b["until"] = now + BREAKER_COOLDOWN


_telemetry: Dict[str, Dict[str, Any]] = {}   # in-process, since start; resets on restart (reported as such)
_TELE_SINCE = time.time()


def error_kind(exc: BaseException) -> str:
    """Sanitised category for an upstream failure. Never returns raw provider text, URLs, headers or keys."""
    msg = str(exc).lower()
    m = re.search(r"http_(\d{3})", msg)
    if m:
        return "http_" + m.group(1)
    if isinstance(exc, TimeoutError) or "timed out" in msg or "timeout" in msg:
        return "timeout"
    if "empty_output" in msg:
        return "empty_output"
    if isinstance(exc, (KeyError, IndexError, ValueError, TypeError)):
        return "malformed_response"
    return "transport_error"


def _tele(provider: str, ok: Optional[bool], latency_ms: Optional[float], kind: str = "", model: str = "", event: str = "") -> None:
    with _lock:
        t = _telemetry.setdefault(provider, {"calls": 0, "successes": 0, "failures": 0, "skipped_circuit_open": 0, "latency_total_ms": 0.0, "latency_samples": 0,
                                             "last_latency_ms": None, "last_error_kind": None, "last_model": None, "last_at": None, "errors_by_kind": {}})
        if event == "circuit_open":
            t["skipped_circuit_open"] += 1
        else:
            t["calls"] += 1
            t["successes" if ok else "failures"] += 1
            if latency_ms is not None:
                t["latency_total_ms"] += latency_ms
                t["latency_samples"] += 1
                t["last_latency_ms"] = round(latency_ms, 1)
            if not ok:
                t["last_error_kind"] = kind or "transport_error"
                t["errors_by_kind"][t["last_error_kind"]] = t["errors_by_kind"].get(t["last_error_kind"], 0) + 1
            if model:
                t["last_model"] = model
        t["last_at"] = time.time()


def telemetry_snapshot() -> Dict[str, Dict[str, Any]]:
    """Measured since process start. Averages are None (UNKNOWN) when nothing was measured - never 0."""
    with _lock:
        out = {}
        for k, t in _telemetry.items():
            out[k] = {"calls": t["calls"], "successes": t["successes"], "failures": t["failures"], "skipped_circuit_open": t["skipped_circuit_open"],
                      "avg_latency_ms": round(t["latency_total_ms"] / t["latency_samples"], 1) if t["latency_samples"] else None,
                      "last_latency_ms": t["last_latency_ms"], "last_error_kind": t["last_error_kind"], "errors_by_kind": dict(t["errors_by_kind"]),
                      "last_model": t["last_model"], "last_at": t["last_at"], "success_rate": round(t["successes"] / t["calls"], 3) if t["calls"] else None,
                      "since": _TELE_SINCE, "scope": "this process only (resets on restart)"}
        return out


def reset_telemetry() -> None:
    with _lock:
        _telemetry.clear()


def _call_openai_compat(url: str, key: str, model: str, prompt: str, transport, timeout: float) -> str:
    body = json.dumps({"model": model, "messages": [{"role": "user", "content": prompt}], "temperature": 0.2, "max_tokens": 1200}).encode()
    status, _h, data = transport("POST", url, {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}, body, timeout)
    if status != 200:
        raise TransportError(f"http_{status}")
    return json.loads(data)["choices"][0]["message"]["content"]


def _call_gemini(key: str, model: str, prompt: str, transport, timeout: float) -> str:
    body = json.dumps({"contents": [{"role": "user", "parts": [{"text": prompt}]}], "generationConfig": {"temperature": 0.2, "maxOutputTokens": 1200}}).encode()
    status, _h, data = transport("POST", GEMINI_URL.format(model=model), {"x-goog-api-key": key, "Content-Type": "application/json"}, body, timeout)
    if status != 200:
        raise TransportError(f"http_{status}")
    parts = json.loads(data)["candidates"][0]["content"]["parts"]
    return "".join(p.get("text", "") for p in parts)


def query_ai_model(prompt: str, preferred_provider: Optional[str] = None, transport: Callable = https_request,
                   env: Optional[Dict[str, str]] = None, timeout: float = 30.0, clock: Callable[[], float] = time.time) -> Dict[str, Any]:
    env = os.environ if env is None else env
    plan: List[tuple] = [
        ("gemini", env.get("GEMINI_API_KEY"), env.get("GEMINI_MODEL", "gemini-1.5-flash")),
        ("openai", env.get("OPENAI_API_KEY"), env.get("OPENAI_MODEL", "gpt-4o-mini")),
        ("groq", env.get("GROQ_API_KEY"), env.get("GROQ_MODEL", "llama-3.3-70b-versatile")),
    ]
    errors: List[Dict[str, str]] = []
    for name, key, model in plan:
        if not key or (preferred_provider and preferred_provider != name):
            continue
        now = clock()
        if _open(name, now):
            errors.append({"provider": name, "error": "circuit_open"})
            _tele(name, None, None, event="circuit_open")
            continue
        t0 = time.monotonic()
        try:
            if name == "gemini":
                text = _call_gemini(key, model, prompt, transport, timeout)
            else:
                text = _call_openai_compat(OPENAI_URL if name == "openai" else GROQ_URL, key, model, prompt, transport, timeout)
            if not text or not text.strip():
                raise TransportError("empty_output")
            _record(name, True, now)
            _tele(name, True, (time.monotonic() - t0) * 1000, model=model)
            return {"ok": True, "provider": name, "model": model, "output": text, "errors_before_success": errors}
        except (TransportError, KeyError, IndexError, ValueError, TypeError) as exc:
            _record(name, False, now, str(exc))
            _tele(name, False, (time.monotonic() - t0) * 1000, error_kind(exc), model)
            errors.append({"provider": name, "error": error_kind(exc)})  # sanitised category only (raw upstream text may carry URLs/keys)

    _tele("local_deterministic_fallback", True, 0.0, model="kora-rule-engine")
    return {
        "ok": True,
        "provider": "local_deterministic_fallback",
        "model": "kora-rule-engine-v8.10.0",
        "output": f"KORA [Deterministic Analysis]: Evaluated prompt of {len(prompt)} characters. Telemetry nominal.",
        "fallback_reason": "External API keys unconfigured or all providers failed / circuit-breaker open. Local fallback executed safely.",
        "errors": errors,
    }


_NO_TELE = {"calls": 0, "successes": 0, "failures": 0, "avg_latency_ms": None, "last_latency_ms": None, "last_error_kind": None, "success_rate": None, "note": "no calls measured yet (UNKNOWN, not zero latency)"}


def provider_states(env: Optional[Dict[str, str]] = None, clock: Callable[[], float] = time.time) -> List[Dict[str, Any]]:
    """Truthful per-provider state: UNAVAILABLE (no key) / CONFIGURED / HEALTHY (>=1 real success, breaker closed) /
    FAILED (recent failures) / RATE_LIMITED is reported only when a 429 was seen. Capability/cost hints are static metadata."""
    env = os.environ if env is None else env
    now = clock()
    meta = {"gemini": ("GEMINI_API_KEY", "low", "text,vision"), "openai": ("OPENAI_API_KEY", "paid", "text,vision"), "groq": ("GROQ_API_KEY", "low", "text,fast"),
            "openrouter": ("OPENROUTER_API_KEY", "varies", "text"), "cerebras": ("CEREBRAS_API_KEY", "low", "text,fast")}
    out = []
    tele = telemetry_snapshot()
    for name, (key, cost, caps) in meta.items():
        implemented = name in ("gemini", "openai", "groq")
        with _lock:
            b = dict(_breaker.get(name, {}))
        if not env.get(key):
            state = "UNAVAILABLE"
        elif not implemented:
            state = "CONFIGURED_NOT_IMPLEMENTED"
        elif b.get("until", 0) > now:
            state = "RATE_LIMITED" if b.get("last_429") else "FAILED"
        elif b.get("ok"):
            state = "HEALTHY"
        else:
            state = "CONFIGURED"
        out.append({"provider": name, "state": state, "implemented": implemented, "cost_hint": cost, "capabilities": caps,
                    "credentials": [key], "privacy": "UNKNOWN", "data_retention": "UNKNOWN", "telemetry": tele.get(name) or _NO_TELE})
    out.append({"provider": "local_deterministic_fallback", "state": "AVAILABLE", "implemented": True, "cost_hint": "free", "capabilities": "rule engine, not an LLM",
                "credentials": [], "privacy": "LOCAL_ONLY (no data leaves the machine)", "data_retention": "NONE (not an external service)",
                "telemetry": tele.get("local_deterministic_fallback") or _NO_TELE})
    return out


# --------------------------------------------------------------------------------------------- provider gap support (read-only; never installs, connects or pays)
USABLE_STATES = ("HEALTHY", "CONFIGURED")   # CONFIGURED_NOT_IMPLEMENTED has a key but no adapter, so it cannot be used
LOCAL_FALLBACK = "local_deterministic_fallback"
# Official sites per provider: used ONLY to attach fetched pages as evidence for the owner to read. Terms are never inferred from page text.
_PROVIDER_HOSTS = {"gemini": ("ai.google.dev", "googleapis.com", "google.com"), "openai": ("openai.com",), "groq": ("groq.com",),
                   "openrouter": ("openrouter.ai",), "cerebras": ("cerebras.ai",)}
_PROVIDER_DEPS = "none: Python standard library HTTPS client (kora.core.http); no package is installed"
RESTART_NOTE = "restart KORA so it re-reads the environment"


def usable_ai_providers(env: Optional[Dict[str, str]] = None, clock: Callable[[], float] = time.time) -> List[str]:
    """Names of REAL external AI providers that can be used now (adapter exists and a key is present, breaker not open). The local rule engine is not one."""
    return [p["provider"] for p in provider_states(env, clock) if p["provider"] != LOCAL_FALLBACK and p["implemented"] and p["state"] in USABLE_STATES]


def provider_comparison(env: Optional[Dict[str, str]] = None, research: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Truthful side-by-side of the supported providers. Cost is a static category (not a quote). Privacy/retention are UNKNOWN unless the owner
    reviews the attached evidence pages: this function never infers terms. `research` = {"status", "sources":[{"url",...}], ...} or None (not run)."""
    research = research or {"status": "NOT_RUN", "sources": [], "note": "no owner URLs supplied and no research performed"}
    srcs = [s for s in (research.get("sources") or []) if isinstance(s, dict) and s.get("url")]
    rows = []
    import urllib.parse as _up
    for p in provider_states(env):
        name = p["provider"]
        hosts = _PROVIDER_HOSTS.get(name, ())
        ev = [s["url"] for s in srcs if any((_up.urlparse(s["url"]).hostname or "").endswith(h) for h in hosts)]
        local = name == LOCAL_FALLBACK
        rows.append({"provider": name, "kind": "LOCAL_RULE_ENGINE (not an AI provider)" if local else "EXTERNAL_AI_PROVIDER", "state": p["state"],
                     "available_now": bool(p["state"] in USABLE_STATES and p["implemented"]) if not local else True, "adapter_supported": p["implemented"],
                     "cost_category": p["cost_hint"], "cost_evidence": "static category hint, not a price quote; check the provider's pricing page" if not local else "free",
                     "capabilities": p["capabilities"], "dependencies": "none (local)" if local else _PROVIDER_DEPS, "credentials_required": p["credentials"],
                     "privacy": p["privacy"], "data_retention": p["data_retention"],
                     "privacy_status": "LOCAL" if local else ("UNKNOWN_EVIDENCE_ATTACHED_NEEDS_OWNER_REVIEW" if ev else "UNKNOWN"), "evidence_sources": ev})
    return {"providers": rows, "ai_provider_available": bool(usable_ai_providers(env)), "local_rules_available": True,
            "local_rules_note": "the local deterministic rule engine is available but it is NOT an AI provider",
            "research": {k: research.get(k) for k in ("status", "note", "sources", "failed") if research.get(k) is not None}}


def provider_owner_actions(env: Optional[Dict[str, str]] = None) -> List[Dict[str, Any]]:
    """Exact actions to connect an AI provider, split into what only Malak can do and what the system can do by itself (read-only).
    Secrets are entered only in the owner's own environment/.env file - never in chat, tickets or logs."""
    keys = [k for p in provider_states(env) if p["provider"] != LOCAL_FALLBACK and p["implemented"] for k in p["credentials"]]
    secret = "Put the key only in your own .env file / OS environment. Never paste it into chat, tickets or logs."
    return [
        {"id": "CHOOSE_PROVIDER", "who": "MALAK", "system_can_do_alone": False, "requires_approval": False,
         "action": "Choose one supported provider after reading the comparison and the provider's own privacy/retention terms.",
         "detail": "Privacy and data-retention terms are UNKNOWN to the system; read the provider's official pages (attached as evidence when research was configured).", "env_vars": []},
        {"id": "OBTAIN_KEY", "who": "MALAK", "system_can_do_alone": False, "requires_approval": True,
         "action": "Create/authorise an account at the chosen provider and generate an API key yourself (an external account only you can authorise).",
         "detail": "The system cannot create accounts, accept terms, or obtain keys. Any paid plan or usage charge needs your explicit decision.", "env_vars": keys, "secret_handling": secret},
        {"id": "SET_ENV", "who": "MALAK", "system_can_do_alone": False, "requires_approval": False,
         "action": "Set exactly one of these environment variables in .env, then " + RESTART_NOTE + ".", "detail": "Variable names only; values are never requested here.",
         "env_vars": keys, "secret_handling": secret},
        {"id": "RERUN_DISCOVERY", "who": "SYSTEM", "system_can_do_alone": True, "requires_approval": False,
         "action": "Re-run read-only capability discovery (GET /api/evolution/3/capabilities) and gap detection (GET /api/evolution/3/gaps).",
         "detail": "Expected: the provider shows CONFIGURED and GAP_NO_AI_PROVIDER disappears. HEALTHY appears only after one real successful call.", "env_vars": []},
        {"id": "FIRST_REAL_CALL", "who": "MALAK", "system_can_do_alone": False, "requires_approval": True,
         "action": "Approve one small real test call (it may incur a charge) so the provider can be verified HEALTHY.",
         "detail": "Not performed automatically; nothing is spent without your approval.", "env_vars": []},
        {"id": "RECORD_RESULT", "who": "SYSTEM", "system_can_do_alone": True, "requires_approval": False,
         "action": "Record the verified outcome in the evidence ledger; if verification fails, nothing was changed so there is nothing to roll back (remove the variable and restart).",
         "detail": "The system installs no package, edits no code and connects no account for this proposal.", "env_vars": []},
    ]
