"""Registers the production job handlers into the worker's CLOSED registry. Import this module once at startup."""
import os
from typing import Any, Dict

from kora.core.db import DEFAULT_DB_PATH
from kora.core.queue import DurableQueue, PermanentJobError
from kora.core.worker import current_db, register_dead_letter_hook, register_handler
from kora.services import social, scheduled_autopilot


def _db(payload: Dict[str, Any] = None) -> str:
    return current_db() or DEFAULT_DB_PATH


# Test seams (production values): the transport used for platform calls and the credential environment.
SOCIAL_TRANSPORT = None   # None => kora.core.http.https_request
SOCIAL_ENV = None         # None => os.environ


@register_handler("social_publish")
def h_social_publish(payload: Dict[str, Any]) -> Dict[str, Any]:
    pid = str(payload.get("post_id", ""))
    if not pid:
        raise PermanentJobError("post_id_required")
    kw = {}
    if SOCIAL_TRANSPORT is not None:
        kw["transport"] = SOCIAL_TRANSPORT
    return social.run_publish(pid, _db(payload), env=SOCIAL_ENV, **kw)


@register_dead_letter_hook("social_publish")
def hook_social_dead(job: Dict[str, Any], error: str) -> None:
    pid = str((job.get("payload") or {}).get("post_id", ""))
    if pid:
        social.mark_dead_lettered(pid, error, job.get("db_path") or _db())


@register_handler("research_ingest")
def h_research_ingest(payload: Dict[str, Any]) -> Dict[str, Any]:
    from kora.config.settings import get_settings
    from kora.services import rag, research
    s = get_settings()
    url = str(payload.get("url", ""))
    from kora.services import cost
    try:
        cost.charge("net_calls", cost.parse_caps(s.budget_daily), cost.parse_caps(s.budget_monthly), _db(payload))
    except cost.BudgetExceeded as exc:
        raise RuntimeError(str(exc))  # transient: retried with backoff; visible in DLQ if the cap persists
    try:
        page = research.fetch_page(url, s.research_max_bytes, s.research_timeout_seconds, s.research_allowed_domains)
    except research.ResearchError as exc:
        if exc.code in ("url_blocked", "content_type_not_allowed", "response_too_large", "no_extractable_text", "http_status") and not str(exc).endswith(("429", "500", "502", "503", "504")):
            raise PermanentJobError(str(exc))
        raise RuntimeError(str(exc))  # network-ish: retry with backoff
    r = rag.ingest_text(page["text"], page["url"], page["title"], _db(payload), s.rag_max_chunks)
    return {"ok": True, "url": page["url"], **{k: r[k] for k in ("doc_id", "chunks", "duplicate")}}


@register_handler("scheduled_autopilot")
def h_scheduled_autopilot(payload: Dict[str, Any]) -> Dict[str, Any]:
    from kora.config.settings import get_settings
    s = get_settings()
    return {"ok": True, "processed": scheduled_autopilot.process_due(_db(payload), DurableQueue(_db(payload)),
        auto_approve=s.social_auto_approve, auto_publish=s.social_auto_publish)}


@register_handler("social_verify")
def h_social_verify(payload: Dict[str, Any]) -> Dict[str, Any]:
    pid = str(payload.get("post_id", ""))
    if not pid:
        raise PermanentJobError("post_id_required")
    kw = {}
    if SOCIAL_TRANSPORT is not None:
        kw["transport"] = SOCIAL_TRANSPORT
    return social.run_verify(pid, _db(payload), env=SOCIAL_ENV, **kw)


@register_handler("fortress_watchdog")
def h_fortress_watchdog(payload: Dict[str, Any]) -> Dict[str, Any]:
    from kora.services import fortress
    out = fortress.watchdog_scan(_db(payload))
    try:
        from kora.services import malak_assist
        malak_assist.tick(_db(payload))
    except Exception:
        pass
    return {"ok": True, "status": out["status"], "critical": len(out["critical"]), "warnings": len(out["warnings"])}


@register_handler("readonly_assessment")
def h_readonly_assessment(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Scheduled READ-ONLY assessment (overlap-locked, deadline-bounded). It never edits code, cron, models or credentials."""
    from kora.services import assessment
    out = assessment.run_assessment(_db(payload))
    return {"ok": out["status"] in ("COMPLETED", "PARTIAL_DEADLINE", "PARTIAL_ERRORS", "SKIPPED_OVERLAP", "REFUSED"), "status": out["status"], "run_id": out.get("run_id"),
            "production_mutation": False}


@register_handler("maintenance")
def h_maintenance(payload: Dict[str, Any]) -> Dict[str, Any]:
    from kora.core.db import verify_audit_chain
    from kora.services import atma, ops, supreme_guardian
    db = _db(payload)
    supreme_guardian.init(db)
    q = DurableQueue(db)
    atma.heartbeat(db)
    chain = verify_audit_chain(db)
    if not chain["ok"]:
        ops.notify("CRITICAL", "audit_chain_broken", f"audit log tamper/corruption detected at row {chain.get('broken_at')}", db)
    guardian = supreme_guardian.supervisor_tick(db)
    return {"ok": True, "leases_recovered": q.recover_stale_leases(), "finished_purged": q.cleanup(),
            "dlq_purged": q.purge_dead_letters(), "social_interrupted_flagged": social.recover_interrupted(db),
            "lifecycle": ops.lifecycle(db), "audit_chain_ok": chain["ok"], "guardian": guardian}


@register_handler("backup")
def h_backup(payload: Dict[str, Any]) -> Dict[str, Any]:
    from kora.services.backup import create_verified_backup
    res = create_verified_backup(_db(payload))
    if not res.get("integrity_verified", res.get("verified", True)):
        raise RuntimeError("backup_not_verified")
    return {"ok": True, **{k: res[k] for k in res if k in ("filename", "sha256", "size_bytes")}}


@register_handler("evolution_resume")
def h_evolution_resume(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Durable resume of a paused evolution run (resource pressure cleared). Read-only: the cycle never patches code."""
    from kora.services import self_evolution_3 as se3
    run_id = str(payload.get("run_id", ""))
    if not run_id:
        raise PermanentJobError("run_id_required")
    try:
        r = se3.resume(run_id, _db(payload))
    except se3.EvolutionFrozen as exc:
        raise PermanentJobError(f"frozen:{exc}")
    if r.get("status") == "PAUSED":
        raise RuntimeError("still constrained: " + ",".join(r.get("reasons", [])))  # transient -> backoff, bounded retries
    return {"ok": r.get("status") in ("COMPLETED", "NOT_FOUND"), "status": r.get("status")}


@register_handler("evolution_net_check")
def h_evolution_net_check(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Network research queued while offline. Raises (retry with backoff) while still offline; never fabricates results."""
    from kora.services import ops, self_evolution_3 as se3
    if ops.network_state()["state"] == "OFFLINE":
        raise RuntimeError("offline: will retry")
    urls = [u for u in payload.get("urls", []) if isinstance(u, str)][:6]
    if not urls:
        raise PermanentJobError("urls_required")
    out = se3._research_now(urls, str(payload.get("run_id", "")), _db(payload))
    return {"ok": True, "status": out["status"], "fetched": len(out["sources"])}
