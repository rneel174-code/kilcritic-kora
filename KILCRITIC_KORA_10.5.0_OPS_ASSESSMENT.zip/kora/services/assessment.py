"""Read-only operational assessment, metrics and egress probe (additive; reuses ops.health, queue stats, se3.detect_gaps, ai_failover telemetry).

* metrics(): measured numbers only. Anything that cannot be measured is None (UNKNOWN), never 0.
* run_assessment(): read-only. Overlap-locked, deadline-bounded, respects safe mode and the evolution freeze, keeps persistent run history.
  It proposes nothing automatically and changes no code, schedule, model, credential or external service.
* egress_probe(): the ONLY function here that touches the network, and only when called explicitly (owner route). A TCP connect with no data sent.
"""
from __future__ import annotations

import json
import socket
import time
import uuid
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from kora.core import policy
from kora.core.db import DEFAULT_DB_PATH, get_connection, get_setting, record_audit, set_setting

HISTORY_KEY = "assess.history"
LOCK_KEY = "assess.lock"
HISTORY_MAX = 20
DEFAULT_DEADLINE_SECONDS = 60.0
EGRESS_TARGETS: Tuple[Tuple[str, int], ...] = (("1.1.1.1", 443), ("8.8.8.8", 53))


# ------------------------------------------------------------------------------------------------ metrics
def metrics(db_path: str = DEFAULT_DB_PATH, now: Optional[float] = None, pool_size: Optional[int] = None) -> Dict[str, Any]:
    from kora.core.queue import DurableQueue
    from kora.services import ai_failover, ops
    now = time.time() if now is None else now
    st = DurableQueue(db_path).get_stats()
    conn = get_connection(db_path)
    try:
        oldest = conn.execute("SELECT MIN(created_at) m FROM jobs WHERE status='QUEUED';").fetchone()["m"]
        durs = [r["d"] for r in conn.execute("SELECT updated_at-created_at d FROM jobs WHERE status='COMPLETED' ORDER BY updated_at DESC LIMIT 50;").fetchall()]
        oldest_running = conn.execute("SELECT MIN(updated_at) m FROM jobs WHERE status='RUNNING';").fetchone()["m"]
    finally:
        conn.close()
    try:
        res = ops.resources(db_path)
    except Exception as exc:  # noqa: BLE001
        res = {"error": f"resources unavailable: {str(exc)[:80]}"}
    queue = {"queued": st["QUEUED"], "running": st["RUNNING"], "dead_letter": st["DEAD_LETTER"], "failed": st["FAILED"], "cancelled": st["CANCELLED"],
             "completed": st["COMPLETED"], "capacity": st["capacity"], "capacity_used_ratio": round((st["QUEUED"] + st["RUNNING"]) / st["capacity"], 4) if st["capacity"] else None,
             "oldest_queued_age_seconds": round(now - oldest, 1) if oldest else (0.0 if st["QUEUED"] == 0 else None),
             "longest_running_since_update_seconds": round(now - oldest_running, 1) if oldest_running else None,
             "avg_completed_duration_seconds_last50": round(sum(durs) / len(durs), 2) if durs else None, "kill_switch": st["kill_switch"]}
    sat = None
    if pool_size and pool_size > 0:
        sat = round(min(1.0, st["RUNNING"] / pool_size), 3)
    return {"measured_at": now, "queue": queue, "worker_saturation": sat,
            "worker_saturation_note": None if sat is not None else "UNKNOWN: worker pool size not supplied to this call",
            "providers": {p["provider"]: p["telemetry"] for p in ai_failover.provider_states()},
            "resources": res, "safe_mode": policy.is_safe_mode(db_path),
            "notes": "None means not measured (UNKNOWN). Provider telemetry is per process since start. No cost or token figures are claimed: none are recorded."}


# ------------------------------------------------------------------------------------------------ egress probe
def egress_probe(targets: Optional[Sequence[Tuple[str, int]]] = None, timeout: float = 2.0, connect: Callable = socket.create_connection,
                 db_path: Optional[str] = None, actor: str = "owner") -> Dict[str, Any]:
    """Empirical outbound-connectivity test from THIS process. REACHABLE proves outbound TCP exists to that target.
    A failure cannot distinguish a firewall from a missing network, and a pass/fail on two targets is not proof about any other host or port."""
    results: List[Dict[str, Any]] = []
    for host, port in (targets or EGRESS_TARGETS):
        t0 = time.monotonic()
        try:
            c = connect((host, int(port)), timeout=timeout)
            try:
                c.close()
            except Exception:  # noqa: BLE001
                pass
            results.append({"host": host, "port": int(port), "result": "REACHABLE", "ms": round((time.monotonic() - t0) * 1000, 1)})
        except socket.timeout:
            results.append({"host": host, "port": int(port), "result": "BLOCKED_OR_UNREACHABLE", "error_kind": "timeout"})
        except OSError as exc:
            results.append({"host": host, "port": int(port), "result": "BLOCKED_OR_UNREACHABLE", "error_kind": type(exc).__name__})
    ok = [r for r in results if r["result"] == "REACHABLE"]
    overall = "EGRESS_OPEN" if ok else "NO_OUTBOUND_OBSERVED"
    out = {"status": overall, "targets": results, "measured_at": time.time(), "data_sent": False,
           "interpretation": ("outbound TCP works to at least one target: this runtime is NOT offline/air-gapped" if ok else
                              "no outbound connection observed to the tested targets; cannot tell firewall from no network, and other hosts/ports were not tested"),
           "declared_offline_is_not_proof": True}
    if db_path:
        record_audit("egress_probe", actor, {"status": overall, "reachable": len(ok), "tested": len(results)}, db_path)
    return out


# ------------------------------------------------------------------------------------------------ read-only scheduled assessment
def history(db_path: str = DEFAULT_DB_PATH) -> List[Dict[str, Any]]:
    try:
        h = json.loads(get_setting(HISTORY_KEY, "[]", db_path) or "[]")
    except ValueError:
        h = []
    return h if isinstance(h, list) else []


def _acquire(db_path: str, run_id: str, now: float, deadline: float) -> bool:
    conn = get_connection(db_path)
    try:
        conn.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES (?,?,?);", (LOCK_KEY, json.dumps({"run_id": run_id, "until": now + deadline * 2}), now))
        row = conn.execute("SELECT value FROM settings WHERE key=?;", (LOCK_KEY,)).fetchone()
        cur = json.loads(row["value"])
        if cur.get("run_id") == run_id:
            return True
        if cur.get("until", 0) < now:  # stale lock from a crashed run: take it over atomically
            n = conn.execute("UPDATE settings SET value=?, updated_at=? WHERE key=? AND value=?;",
                             (json.dumps({"run_id": run_id, "until": now + deadline * 2}), now, LOCK_KEY, row["value"])).rowcount
            return n == 1
        return False
    finally:
        conn.close()


def _release(db_path: str, run_id: str) -> None:
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT value FROM settings WHERE key=?;", (LOCK_KEY,)).fetchone()
        if row and json.loads(row["value"]).get("run_id") == run_id:
            conn.execute("DELETE FROM settings WHERE key=?;", (LOCK_KEY,))
    finally:
        conn.close()


def _push_history(db_path: str, entry: Dict[str, Any]) -> None:
    h = history(db_path)
    h.append(entry)
    set_setting(HISTORY_KEY, json.dumps(h[-HISTORY_MAX:]), db_path)


def run_assessment(db_path: str = DEFAULT_DB_PATH, root: Optional[str] = None, deadline_seconds: float = DEFAULT_DEADLINE_SECONDS,
                   env: Optional[Dict[str, str]] = None, now: Optional[float] = None, pool_size: Optional[int] = None,
                   clock: Callable[[], float] = time.time) -> Dict[str, Any]:
    """OBSERVE-only. Never edits code, cron, models, credentials or external services; proposals are listed, not created."""
    from kora.services import ai_failover, ops
    from kora.services import self_evolution_3 as se3
    started = clock() if now is None else now
    if se3.frozen(db_path):
        return {"status": "REFUSED", "reason": "evolution is frozen by the owner", "production_mutation": False}
    if policy.is_safe_mode(db_path):
        return {"status": "REFUSED", "reason": "safe mode is ON", "production_mutation": False}
    run_id = f"assess-{uuid.uuid4().hex[:10]}"
    if not _acquire(db_path, run_id, started, deadline_seconds):
        return {"status": "SKIPPED_OVERLAP", "reason": "another assessment is running", "production_mutation": False}
    steps: Dict[str, Any] = {}
    status = "COMPLETED"
    try:
        def over() -> bool:
            return (clock() - started) > deadline_seconds
        plan: List[Tuple[str, Callable[[], Any]]] = [
            ("health", lambda: ops.health(db_path)),
            ("metrics", lambda: metrics(db_path, pool_size=pool_size)),
            ("provider_gap", lambda: {"usable_ai_providers": ai_failover.usable_ai_providers(env), "local_rules_available": True}),
            ("gaps", lambda: [{"id": g["id"], "severity": g["severity"], "evidence": g["evidence"]} for g in se3.detect_gaps(db_path, root, None, env)["gaps"][:15]]),
        ]
        for name, fn in plan:
            if over():
                steps[name] = {"status": "NOT_RUN", "reason": "deadline reached"}
                status = "PARTIAL_DEADLINE"
                continue
            try:
                steps[name] = {"status": "OK", "data": fn()}
            except Exception as exc:  # noqa: BLE001
                steps[name] = {"status": "ERROR", "error_kind": type(exc).__name__}
                status = "PARTIAL_ERRORS" if status == "COMPLETED" else status
        steps["tests"] = {"status": "NOT_RUN", "reason": "the assessment never runs the test suite; use POST /api/tests/run or the CLI"}
        health = (steps.get("health") or {}).get("data") or {}
        bad = [k for k, v in (health.get("domains") or health.get("domain") or {}).items() if isinstance(v, dict) and v.get("state") in ("BLOCKED", "ATTENTION", "UNKNOWN", "OFFLINE")]
        gaps = (steps.get("gaps") or {}).get("data") or []
        proposals = [{"gap": g["id"], "severity": g["severity"], "action": "PROPOSAL ONLY - nothing applied; use the governed flow (POST /api/evolution/prepare)",
                      "rollback": "none needed: no change is made by this assessment"} for g in gaps if g["severity"] in ("CRITICAL", "HIGH")][:5]
        finished = clock()
        entry = {"run_id": run_id, "started_at": started, "finished_at": finished, "duration_seconds": round(finished - started, 3), "status": status,
                 "domains_needing_attention": bad, "gap_count": len(gaps), "high_gaps": [p["gap"] for p in proposals]}
        _push_history(db_path, entry)
        record_audit("assessment_run", "system", {"run_id": run_id, "status": status, "gaps": len(gaps)}, db_path)
        return {"status": status, "run_id": run_id, "steps": steps, "proposals": proposals, "history_entry": entry, "production_mutation": False,
                "network_used": False}
    finally:
        _release(db_path, run_id)
