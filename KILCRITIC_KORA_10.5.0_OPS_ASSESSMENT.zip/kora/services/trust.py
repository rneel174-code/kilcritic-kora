"""Trust levels, provenance records and the Dynamic Skill Registry.

* Unknown is never trusted: the default level is UNKNOWN and only TRUSTED/VERIFIED count as trusted.
* Skills (worker handlers) carry metadata (permission, risk, input schema, provider, tests, rollback) and a SHA-256 of
  their code. First sight of a built-in skill records VERIFIED; if the code later differs it becomes SUSPICIOUS and will
  not run until the owner re-approves it. A handler with no metadata stays UNKNOWN and is refused by a gated worker.
"""
import hashlib
import inspect
import json
import time
from typing import Any, Callable, Dict, List, Optional

from kora.core.db import DEFAULT_DB_PATH, get_connection, record_audit

LEVELS = ("TRUSTED", "VERIFIED", "UNKNOWN", "SUSPICIOUS", "BLOCKED")
TRUSTED_LEVELS = ("TRUSTED", "VERIFIED")

# Dynamic skill registry metadata: permission / risk / input schema / provider / tests / rollback
SKILL_META: Dict[str, Dict[str, Any]] = {
    "noop": {"permission": "READ_LOCAL_FILE", "risk": "LOW", "schema": {}, "provider": "local", "tests": ["T23"], "rollback": "none needed"},
    "math_compute": {"permission": "READ_LOCAL_FILE", "risk": "LOW", "schema": {"a": "number", "b": "number", "op": "add|multiply"}, "provider": "local", "tests": ["T25"], "rollback": "none needed"},
    "research_ingest": {"permission": "WEB_SEARCH", "risk": "MEDIUM", "schema": {"url": "https url"}, "provider": "web", "tests": ["T39", "T40"], "rollback": "delete rag doc"},
    "maintenance": {"permission": "WRITE_LOCAL_FILE", "risk": "MEDIUM", "schema": {}, "provider": "local", "tests": ["T43"], "rollback": "none needed"},
    "backup": {"permission": "WRITE_LOCAL_FILE", "risk": "MEDIUM", "schema": {}, "provider": "local", "tests": ["T43"], "rollback": "delete snapshot"},
    "evolution_resume": {"permission": "READ_LOCAL_FILE", "risk": "LOW", "schema": {"run_id": "str"}, "provider": "local", "tests": ["T108"], "rollback": "none needed (read-only; never patches code)"},
    "evolution_net_check": {"permission": "WEB_SEARCH", "risk": "LOW", "schema": {"run_id": "str", "urls": "list of https urls"}, "provider": "web", "tests": ["T109"], "rollback": "none needed"},
    "scheduled_autopilot": {"permission": "PUBLISH_SOCIAL", "risk": "HIGH", "schema": {}, "provider": "local (hands due schedules to the approval/publish engine)", "tests": ["T131", "T134"], "rollback": "pause/cancel schedule"},
    "fortress_watchdog": {"permission": "READ_LOCAL_FILE", "risk": "LOW", "schema": {}, "provider": "local", "tests": ["T139", "T140"], "rollback": "none needed (read-only; may only HALT)"},
    "social_verify": {"permission": "WEB_SEARCH", "risk": "LOW", "schema": {"post_id": "str"}, "provider": "platform APIs (read-only GET)", "tests": ["T152"], "rollback": "none needed (read-only)"},
    "readonly_assessment": {"permission": "READ_LOCAL_FILE", "risk": "LOW", "schema": {}, "provider": "local (read-only; no network, no edits)", "tests": ["T200", "T203"], "rollback": "none needed (read-only; writes only its own run history)"},
    "social_publish": {"permission": "PUBLISH_SOCIAL", "risk": "HIGH", "schema": {"post_id": "str"}, "provider": "platform APIs", "tests": ["T36", "T37"], "rollback": "platform-side delete (manual)"},
}


def code_hash(fn: Callable) -> str:
    try:
        src = inspect.getsource(fn).encode()
    except (OSError, TypeError):
        src = fn.__code__.co_code
    return hashlib.sha256(src).hexdigest()


def set_trust(subject_type: str, subject_id: str, level: str, sha256: str = "", evidence: str = "", actor: str = "system",
              db_path: str = DEFAULT_DB_PATH) -> None:
    if level not in LEVELS:
        raise ValueError("bad level")
    conn = get_connection(db_path)
    try:
        conn.execute("INSERT INTO trust(subject_type,subject_id,level,sha256,evidence,updated_at) VALUES (?,?,?,?,?,?) "
                     "ON CONFLICT(subject_type,subject_id) DO UPDATE SET level=excluded.level, sha256=excluded.sha256, evidence=excluded.evidence, updated_at=excluded.updated_at;",
                     (subject_type, subject_id, level, sha256, evidence[:500], time.time()))
    finally:
        conn.close()
    record_audit("trust_set", actor, {"type": subject_type, "id": subject_id, "level": level}, db_path)


def get_trust(subject_type: str, subject_id: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    conn = get_connection(db_path)
    try:
        r = conn.execute("SELECT level,sha256,evidence FROM trust WHERE subject_type=? AND subject_id=?;", (subject_type, subject_id)).fetchone()
        return dict(r) if r else {"level": "UNKNOWN", "sha256": "", "evidence": ""}
    finally:
        conn.close()


def is_trusted(subject_type: str, subject_id: str, db_path: str = DEFAULT_DB_PATH) -> bool:
    return get_trust(subject_type, subject_id, db_path)["level"] in TRUSTED_LEVELS


def sync_skills(handlers: Dict[str, Callable], db_path: str = DEFAULT_DB_PATH) -> Dict[str, str]:
    """Compare every registered handler with its recorded hash. Returns {skill: level}."""
    out: Dict[str, str] = {}
    for name, fn in handlers.items():
        if name not in SKILL_META:
            out[name] = get_trust("skill", name, db_path)["level"]  # unknown stays whatever it is (default UNKNOWN)
            continue
        h, cur = code_hash(fn), get_trust("skill", name, db_path)
        if cur["level"] == "UNKNOWN" and not cur["sha256"]:
            set_trust("skill", name, "VERIFIED", h, "first-seen built-in baseline", "system", db_path)
            out[name] = "VERIFIED"
        elif cur["sha256"] and cur["sha256"] != h and cur["level"] in TRUSTED_LEVELS:
            set_trust("skill", name, "SUSPICIOUS", cur["sha256"], f"code hash changed (now {h[:12]})", "system", db_path)
            out[name] = "SUSPICIOUS"
        else:
            out[name] = cur["level"]
    return out


def approve_skill(name: str, handlers: Dict[str, Callable], actor: str, db_path: str = DEFAULT_DB_PATH) -> str:
    """Owner action: accept the CURRENT code of a registered skill as the new baseline."""
    if name not in handlers:
        raise KeyError("skill not registered")
    set_trust("skill", name, "TRUSTED", code_hash(handlers[name]), "approved by owner", actor, db_path)
    return "TRUSTED"


def skill_runnable(name: str, db_path: str = DEFAULT_DB_PATH) -> bool:
    return is_trusted("skill", name, db_path)


def list_skills(handlers: Dict[str, Callable], db_path: str = DEFAULT_DB_PATH) -> List[Dict[str, Any]]:
    return [{"name": n, "trust": get_trust("skill", n, db_path)["level"], **{k: v for k, v in SKILL_META.get(n, {}).items()}} for n in sorted(handlers)]


def record_provenance(subject_type: str, subject_id: str, *, source: str = "", tool: str = "", license: str = "", rights: str = "",
                      transformations: str = "", verification: str = "", version: str = "", db_path: str = DEFAULT_DB_PATH) -> None:
    conn = get_connection(db_path)
    try:
        conn.execute("INSERT INTO provenance(subject_type,subject_id,source,tool,license,rights,transformations,verification,version,created_at) VALUES (?,?,?,?,?,?,?,?,?,?);",
                     (subject_type, subject_id, source[:300], tool[:100], license[:100], rights[:100], transformations[:300], verification[:300], version[:40], time.time()))
    finally:
        conn.close()


def provenance_for(subject_type: str, subject_id: str, db_path: str = DEFAULT_DB_PATH) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        return [dict(r) for r in conn.execute("SELECT * FROM provenance WHERE subject_type=? AND subject_id=? ORDER BY id;", (subject_type, subject_id)).fetchall()]
    finally:
        conn.close()


_BASE = {"TRUSTED": 90, "VERIFIED": 75, "UNKNOWN": 30, "SUSPICIOUS": 10, "BLOCKED": 0}


def score(subject_type: str, subject_id: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """0-100 trust score from the EXISTING trust level (+ provenance evidence). Explainable: every adjustment is listed.
    Unknown stays low; the score can never lift a SUSPICIOUS/BLOCKED subject into the trusted range."""
    t = get_trust(subject_type, subject_id, db_path)
    sc, factors = _BASE.get(t["level"], 30), [f"level {t['level']} = {_BASE.get(t['level'], 30)}"]
    prov = provenance_for(subject_type, subject_id, db_path)
    if t["level"] not in ("SUSPICIOUS", "BLOCKED"):
        if prov:
            sc += 5
            factors.append("provenance recorded +5")
            if any((p.get("rights") or "UNDECLARED") == "UNDECLARED" for p in prov):
                sc -= 5
                factors.append("rights undeclared -5")
        if t.get("evidence"):
            sc += 3
            factors.append("evidence on file +3")
    return {"subject": f"{subject_type}:{subject_id}", "level": t["level"], "score": max(0, min(100, sc)), "factors": factors}


_RISK_RANK = {"LOW": 0, "MEDIUM": 1, "HIGH": 2, "CRITICAL": 3}


def route_skills(needs: List[str], db_path: str = DEFAULT_DB_PATH, max_risk: str = "HIGH") -> Dict[str, Any]:
    """Smart skill routing on the EXISTING registry: for each needed permission pick the single lowest-risk TRUSTED skill that provides it
    (minimum capability). Untrusted/suspicious skills and anything above `max_risk` are never chosen; an unmet need is reported, not guessed."""
    chosen: Dict[str, str] = {}
    unmet: List[str] = []
    skipped: List[Dict[str, str]] = []
    for need in needs:
        cands = []
        for name, meta in SKILL_META.items():
            if meta["permission"] != need:
                continue
            if not skill_runnable(name, db_path):
                skipped.append({"skill": name, "why": "not trusted/approved"})
            elif _RISK_RANK.get(meta["risk"], 3) > _RISK_RANK.get(max_risk, 2):
                skipped.append({"skill": name, "why": f"risk {meta['risk']} above allowed {max_risk}"})
            else:
                cands.append((_RISK_RANK.get(meta["risk"], 3), name))
        if cands:
            chosen[need] = sorted(cands)[0][1]
        else:
            unmet.append(need)
    return {"skills": chosen, "unmet": unmet, "skipped": skipped,
            "note": "least-privilege selection; sensitive skills still pass the permission engine and approvals at run time"}
