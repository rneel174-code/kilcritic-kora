"""T185-T191: CTO-audit fixes (truthful Doctor Heal, 'doctor heal' command, duplicate proposals, approval summary, proposal detail, suite timeout, HUD send path)."""
import json
import os
import re
import tempfile

OWNER = {"id": "owner", "role": "owner"}
HUD = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "hud")


def _db():
    from kora.core.db import init_db
    p = os.path.join(tempfile.mkdtemp(prefix="kora-bf-"), "b.db")
    init_db(p)
    return p


def register(run_test):
    from kora.services import brain, governance, system_doctor

    def heal_truthful():
        db = _db()
        r = system_doctor.execute_safe_self_healing(db)
        assert r["state"] == "NOTHING_TO_REPAIR" and r["healed"] is False and r["repaired_total"] == 0 and "nothing needed repair" in r["message"], r
        assert all(a["status"] == "DONE" and a["count"] == 0 for a in r["actions"]) and "setup items" in r["message"]
        from kora.core.queue import DurableQueue
        real = DurableQueue.recover_stale_leases
        try:
            DurableQueue.recover_stale_leases = lambda self: 2
            r2 = system_doctor.execute_safe_self_healing(db)
            assert r2["state"] == "REPAIRED" and r2["healed"] is True and r2["repaired_total"] == 2, r2

            def boom(self): raise RuntimeError("lease table locked")
            DurableQueue.recover_stale_leases = boom
            r3 = system_doctor.execute_safe_self_healing(db)
            assert r3["state"] == "PARTIAL_FAILURE" and r3["healed"] is False and any(a["status"] == "FAILED" for a in r3["actions"]), r3
        finally:
            DurableQueue.recover_stale_leases = real
        from kora.tests.hud_studio_tests import _app, H
        app, call, root, db2 = _app()
        s, b, _h = call("POST", "/api/doctor/heal", {}, headers=H)
        assert s == 200 and b["state"] == "NOTHING_TO_REPAIR" and b["healed"] is False and b["repaired_total"] == 0, (s, b)
    run_test("T185", "Doctor Heal is truthful: NOTHING_TO_REPAIR / REPAIRED / PARTIAL_FAILURE with measured totals (no healed:true on count 0)", heal_truthful)

    def heal_command():
        db = _db()
        for t in ("Doctor Heal", "doctor heal", "system heal", "self-healing"):
            r = brain.handle(t, principal=OWNER, db_path=db)
            assert r["status"] == "OK" and r["intent"] == "heal" and r["data"]["state"] == "NOTHING_TO_REPAIR", (t, r)
        assert brain.handle("system doctor", principal=OWNER, db_path=db)["intent"] == "doctor"
        assert brain.handle("health check karo", principal=OWNER, db_path=db)["intent"] == "health"
        assert brain.handle("doctor heal", principal={"id": "g", "role": "guest"}, db_path=db)["status"] == "DENIED"
        assert brain.handle("doctor heal", principal={"id": "u", "role": "user"}, db_path=db)["status"] == "DENIED", "needs an explicit permission"
        h = brain.handle("health", principal=OWNER, db_path=db)["message"]
        assert "Owner setup:" in h and "GEMINI_API_KEY" in h, h
        assert len(brain.HELP) == 15
    run_test("T186", "'doctor heal' / 'system heal' recognised through the one dispatcher (same safe repairs, permission-gated, audited); health message lists owner setup", heal_command)

    def duplicates():
        from kora.services import self_evolution as se
        db = _db()
        a = se.prepare("tidy the status panel wording", db, generate_patch=False)
        b = se.prepare("tidy the status panel wording", db, generate_patch=False)
        assert a["status"] == "PENDING_APPROVAL" and b.get("duplicate") is True and b["proposal_id"] == a["proposal_id"] == b["duplicate_of"], (a.get("status"), b)
        c = se.prepare("a different goal entirely", db, generate_patch=False)
        assert c["proposal_id"] != a["proposal_id"]
        assert len(governance.list_proposals(db, None, 50)) == 2
        governance.decide(a["proposal_id"], False, "t", db)       # once rejected, the same request may be raised again
        d = se.prepare("tidy the status panel wording", db, generate_patch=False)
        assert not d.get("duplicate") and d["proposal_id"] != a["proposal_id"]
    run_test("T187", "Identical open MODIFY_CODE proposal is not queued twice (before any scan/AI call); reject re-opens", duplicates)

    def approvals_consistent():
        from kora.tests.hud_studio_tests import _app, H
        app, call, root, db = _app()
        p1 = governance.create_proposal("MODIFY_CODE", "same reason", "HIGH", [], [], "", db)
        governance.create_proposal("MODIFY_CODE", "other reason", "HIGH", [], [], "", db)
        s, a, _h = call("GET", "/api/active", headers=H)
        assert s == 200 and a["needs_approval"] == [] and len(a["proposals"]) == 2, a
        ap = a["approvals"]
        assert ap["posts"] == 0 and ap["proposals"] == 2 and ap["total"] == 2 and ap["high_risk"] == 2 and ap["approved_not_executed"] == 0, ap
        assert a["idle"] is False
        assert governance.decide(p1, True, "t", db)
        ap2 = call("GET", "/api/active", headers=H)[1]["approvals"]
        assert ap2["proposals"] == 1 and ap2["approved_not_executed"] == 1 and ap2["total"] == 1, ap2
        js = open(os.path.join(HUD, "creator.js"), encoding="utf-8").read()
        assert "ap.total" in js and "approved_not_executed" in js
    run_test("T188", "/api/active exposes one approvals summary (posts + proposals, high-risk, approved-not-executed); HUD uses it; legacy keys unchanged", approvals_consistent)

    def proposal_detail():
        from kora.tests.hud_studio_tests import _app, H
        app, call, root, db = _app()
        pid = governance.create_proposal("MODIFY_CODE", "Self-improvement proposal: x", "HIGH", [{"goal": "x"}], [], "restore", db)
        s, d, _h = call("GET", f"/api/governance/proposals/{pid}", headers=H)
        assert s == 200 and d["executed"] is False and d["proposal"]["status"] == "PENDING" and "Waiting" in d["explanation"] and d["patch_present"] is False
        assert any(e["event"] == "proposal_created" for e in d["audit_trail"]), d["audit_trail"]
        governance.decide(pid, True, "t", db)
        d2 = call("GET", f"/api/governance/proposals/{pid}", headers=H)[1]
        assert d2["executed"] is False and d2["proposal"]["status"] == "APPROVED" and "NOT executed" in d2["explanation"] and d2["restore_point_present"] is False, d2
        assert call("GET", "/api/governance/proposals/prop_nope", headers=H)[0] == 404
        assert call("GET", f"/api/governance/proposals/{pid}")[0] in (401, 403)
        assert call("GET", "/api/governance/proposals", headers=H)[1]["items"][0].keys() >= {"result", "decided_at"}
    run_test("T189", "Read-only proposal detail: APPROVED is never reported as executed; patch/restore-point presence and audit trail shown; auth required", proposal_detail)

    def suite_timeout():
        import subprocess
        from kora.bridge import api
        old = os.environ.pop("KORA_TEST_TIMEOUT_SECONDS", None)
        try:
            assert api._suite_timeout() == 180
            for raw, want in (("5", 60), ("99999", 1800), ("abc", 180), ("240", 240)):
                os.environ["KORA_TEST_TIMEOUT_SECONDS"] = raw
                assert api._suite_timeout() == want, (raw, api._suite_timeout())
            real = subprocess.run
            subprocess.run = lambda *a, **k: (_ for _ in ()).throw(subprocess.TimeoutExpired("x", 1))
            try:
                api._run_suite_subprocess()
                raise AssertionError("timeout must raise")
            except api.ApiError as e:
                assert e.status == 503 and e.code == "test_suite_timeout" and "UNKNOWN" in e.detail and "not a pass" in e.detail
            finally:
                subprocess.run = real
        finally:
            os.environ.pop("KORA_TEST_TIMEOUT_SECONDS", None)
            if old is not None: os.environ["KORA_TEST_TIMEOUT_SECONDS"] = old
    run_test("T190", "Suite timeout: default 180 s unchanged, owner-adjustable (60-1800), a timeout is reported as UNKNOWN/503 - never as a pass", suite_timeout)

    def hud_send_path():
        js = open(os.path.join(HUD, "creator.js"), encoding="utf-8").read()
        html = open(os.path.join(HUD, "creator_index.html"), encoding="utf-8").read()
        assert "['homeCommand','homeCommandForm']" in js and "e.key==='Enter'" in js and "requestSubmit" in js and "$('homeCommandForm').onsubmit" in js
        assert js.count("'/api/brain'") == 1, "still exactly one dispatcher call site"
        assert html.count('enterkeyhint="send"') == 2 and re.search(r'type="submit"[^>]*>GO<', html), "GO button preserved"
    run_test("T191", "HUD send path: GO preserved, Enter/Go/Send handled explicitly through the same form submit, still one /api/brain call site", hud_send_path)
