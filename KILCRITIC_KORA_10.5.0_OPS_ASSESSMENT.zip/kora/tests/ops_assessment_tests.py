"""T200-T205: read-only assessment, router telemetry (sanitised), capability evidence, metrics (UNKNOWN != 0), egress probe, API routes."""
import json
import os
import socket
import tempfile

SECRET = "sk-TESTSECRETVALUE-1234567890"


def _db():
    from kora.core.db import init_db
    p = os.path.join(tempfile.mkdtemp(prefix="kora-oa-"), "o.db")
    init_db(p)
    return p


def _count(db, sql):
    from kora.core.db import get_connection
    c = get_connection(db)
    try:
        return c.execute(sql).fetchone()[0]
    finally:
        c.close()


def register(run_test):
    from kora.services import ai_failover as F
    from kora.services import assessment as A

    def assessment_readonly():
        from kora.core import policy
        from kora.core.worker import HANDLERS
        from kora.services import handlers  # noqa: F401  (registers handlers)
        from kora.services import trust
        db = _db()
        props0 = _count(db, "SELECT COUNT(*) FROM proposals;")
        jobs0 = _count(db, "SELECT COUNT(*) FROM jobs;")
        real = socket.socket

        def boom(*a, **k):
            raise AssertionError("network used by read-only assessment")
        socket.socket = boom
        try:
            r = A.run_assessment(db, ".", env={})
        finally:
            socket.socket = real
        assert r["status"] == "COMPLETED" and r["production_mutation"] is False and r["network_used"] is False, r["status"]
        assert set(r["steps"]) >= {"health", "metrics", "provider_gap", "gaps", "tests"} and r["steps"]["tests"]["status"] == "NOT_RUN"
        assert any(g["id"] == "GAP_NO_AI_PROVIDER" for g in r["steps"]["gaps"]["data"])
        assert all("PROPOSAL ONLY" in p["action"] and "no change" in p["rollback"] for p in r["proposals"])
        assert _count(db, "SELECT COUNT(*) FROM proposals;") == props0 and _count(db, "SELECT COUNT(*) FROM jobs;") == jobs0, "assessment must not create proposals or jobs"
        h = A.history(db)
        assert len(h) == 1 and h[0]["run_id"] == r["run_id"] and h[0]["status"] == "COMPLETED"
        assert _count(db, f"SELECT COUNT(*) FROM settings WHERE key='{A.LOCK_KEY}';") == 0, "lock released"
        # overlap: a live lock makes a second run skip (never run twice at once)
        import time as _t
        from kora.core.db import set_setting
        set_setting(A.LOCK_KEY, json.dumps({"run_id": "other", "until": _t.time() + 100}), db)
        assert A.run_assessment(db, ".", env={})["status"] == "SKIPPED_OVERLAP"
        set_setting(A.LOCK_KEY, json.dumps({"run_id": "dead", "until": _t.time() - 5}), db)
        assert A.run_assessment(db, ".", env={})["status"] == "COMPLETED", "stale lock from a crashed run is taken over"
        # deadline: fake clock jumps past the deadline => remaining steps NOT_RUN, status PARTIAL_DEADLINE (never COMPLETED)
        ticks = iter([0.0, 0.0] + [999.0] * 50)
        p = A.run_assessment(db, ".", env={}, deadline_seconds=5, clock=lambda: next(ticks))
        assert p["status"] == "PARTIAL_DEADLINE" and any(s["status"] == "NOT_RUN" for s in p["steps"].values())
        # safe mode and freeze are respected
        policy.set_safe_mode(True, "t", db) if hasattr(policy, "set_safe_mode") else __import__("kora.services.emergency", fromlist=["x"]).set_safe_mode(True, "t", db)
        assert A.run_assessment(db, ".", env={})["status"] == "REFUSED"
        # scheduled handler is registered on the existing worker registry and visible to the trust gate
        assert "readonly_assessment" in HANDLERS and "readonly_assessment" in trust.SKILL_META
    run_test("T200", "Read-only assessment: no network/proposals/jobs, history persisted, overlap lock + stale takeover, deadline => PARTIAL, safe mode refuses, registered on existing worker/trust", assessment_readonly)

    def router_telemetry():
        F.reset_telemetry()
        F._breaker.clear()
        env = {"GROQ_API_KEY": SECRET}
        leak = f"https://api.example/v1?key={SECRET}"
        r = F.query_ai_model("hello", env=env, transport=lambda *a, **k: (500, {}, leak.encode()))
        assert r["provider"] == F.LOCAL_FALLBACK and r["errors"] == [{"provider": "groq", "error": "http_500"}]
        snap = F.telemetry_snapshot()
        g = snap["groq"]
        assert g["calls"] == 1 and g["failures"] == 1 and g["successes"] == 0 and g["last_error_kind"] == "http_500" and g["errors_by_kind"] == {"http_500": 1}
        assert g["avg_latency_ms"] is not None and g["success_rate"] == 0.0
        assert snap[F.LOCAL_FALLBACK]["calls"] == 1, "fallback usage is counted"
        # a good call records latency + model
        import kora.services.ai_failover as m
        ok = {"choices": [{"message": {"content": "hi there"}}]}
        r2 = F.query_ai_model("hello", env={"OPENAI_API_KEY": SECRET}, transport=lambda *a, **k: (200, {}, json.dumps(ok).encode()))
        assert r2["provider"] == "openai" and F.telemetry_snapshot()["openai"]["successes"] == 1 and F.telemetry_snapshot()["openai"]["last_model"]
        # circuit open is counted, not a call
        for _ in range(m.BREAKER_THRESHOLD):
            F.query_ai_model("x", env=env, transport=lambda *a, **k: (500, {}, b""))
        F.query_ai_model("x", env=env, transport=lambda *a, **k: (500, {}, b""))
        assert F.telemetry_snapshot()["groq"]["skipped_circuit_open"] >= 1
        # malformed + timeout categories
        F.reset_telemetry(); F._breaker.clear()
        F.query_ai_model("x", env=env, transport=lambda *a, **k: (200, {}, b"not json"))
        assert F.telemetry_snapshot()["groq"]["last_error_kind"] == "malformed_response"

        def to(*a, **k):
            raise F.TransportError("timed out after 30s " + leak)
        F.query_ai_model("x", env={"OPENAI_API_KEY": SECRET}, transport=to)
        assert F.telemetry_snapshot()["openai"]["last_error_kind"] == "timeout"
        blob = json.dumps(F.telemetry_snapshot()) + json.dumps(F.provider_states(env))
        assert SECRET not in blob and "api.example" not in blob
        # nothing measured => UNKNOWN (None), never zero latency
        F.reset_telemetry()
        st = {p["provider"]: p["telemetry"] for p in F.provider_states({})}
        assert st["gemini"]["avg_latency_ms"] is None and st["gemini"]["calls"] == 0 and "UNKNOWN" in st["gemini"]["note"]
        assert {"provider", "state", "implemented", "cost_hint", "capabilities", "credentials", "privacy", "data_retention"} <= set(F.provider_states({})[0])
        F.reset_telemetry(); F._breaker.clear()
    run_test("T201", "Router telemetry: per-provider latency/outcome/fallback/circuit counts, sanitised error kinds (no key/URL leak), UNKNOWN when unmeasured, state shape unchanged", router_telemetry)

    def capability_evidence():
        from kora.services import self_evolution_3 as se3
        F._breaker.clear()
        db = _db()
        d = se3.discover_capabilities(db, {"OPENROUTER_API_KEY": SECRET, "GROQ_API_KEY": SECRET})
        states = set()
        for k, v in d["capabilities"].items():
            ver = v["verification"]
            assert ver["verified"] is False and ver["state"] != "VERIFIED" and ver["evidence"] and ver["limitations"] and ver["checked_at"], k
            states.add(ver["state"])
        c = d["capabilities"]
        assert c["provider:groq"]["verification"]["state"] == "CONFIGURED" and "no real call" in c["provider:groq"]["verification"]["limitations"]
        assert c["provider:openrouter"]["verification"]["state"] == "NOT_IMPLEMENTED"
        assert c["provider:gemini"]["verification"]["state"] == "NOT_CONFIGURED"
        assert c["provider:local_deterministic_fallback"]["verification"]["state"] == "IMPLEMENTED" and "not an LLM" in c["provider:local_deterministic_fallback"]["verification"]["limitations"]
        assert any(k.startswith("tool:") and v["verification"]["state"] in ("PRESENT", "NOT_CONFIGURED") and "not run functionally" in v["verification"]["limitations"] for k, v in c.items())
        assert SECRET not in json.dumps(d)
        # one source of truth: the API route returns the same enriched structure
        from kora.tests.hud_studio_tests import _app, H
        app, call, root, db2 = _app()
        s, body, _ = call("GET", "/api/evolution/3/capabilities", headers=H)
        assert s == 200 and all("verification" in v for v in body["capabilities"].values())
    run_test("T202", "Capability registry evidence: every capability has state/evidence/limitations/checked_at; never auto-VERIFIED; provider states honest; same data via API", capability_evidence)

    def metrics_unknown():
        from kora.core.queue import DurableQueue
        db = _db()
        m = A.metrics(db)
        assert m["queue"]["queued"] == 0 and m["queue"]["oldest_queued_age_seconds"] == 0.0
        assert m["queue"]["avg_completed_duration_seconds_last50"] is None, "no completed jobs => UNKNOWN, not 0"
        assert m["worker_saturation"] is None and "UNKNOWN" in m["worker_saturation_note"]
        assert m["queue"]["longest_running_since_update_seconds"] is None
        q = DurableQueue(db)
        q.enqueue("noop", {}, idempotency_key="m1")
        q.enqueue("noop", {}, idempotency_key="m2")
        import time as _t
        m2 = A.metrics(db, now=_t.time() + 30, pool_size=2)
        assert m2["queue"]["queued"] == 2 and 29 <= m2["queue"]["oldest_queued_age_seconds"] <= 40 and m2["worker_saturation"] == 0.0
        assert m2["queue"]["capacity_used_ratio"] == round(2 / m2["queue"]["capacity"], 4)
        assert "gemini" in m2["providers"] and "cost" in m2["notes"].lower() and m2["safe_mode"] is False
    run_test("T203", "Metrics: queue depth/age/saturation measured; unmeasured values are None (UNKNOWN), never 0; no invented cost/token figures", metrics_unknown)

    def egress():
        db = _db()
        calls = []

        class C:
            def close(self): calls.append("closed")

        def ok_conn(addr, timeout=None):
            calls.append(addr)
            return C()
        r = A.egress_probe(connect=ok_conn, db_path=db)
        assert r["status"] == "EGRESS_OPEN" and all(t["result"] == "REACHABLE" for t in r["targets"]) and r["data_sent"] is False and "NOT offline" in r["interpretation"]

        def deny(addr, timeout=None):
            raise ConnectionRefusedError("x")

        def slow(addr, timeout=None):
            raise socket.timeout()
        r2 = A.egress_probe(connect=deny, db_path=db)
        assert r2["status"] == "NO_OUTBOUND_OBSERVED" and r2["targets"][0]["error_kind"] == "ConnectionRefusedError" and "cannot tell firewall" in r2["interpretation"]
        r3 = A.egress_probe(connect=slow, targets=[("203.0.113.1", 9)])
        assert r3["targets"][0]["error_kind"] == "timeout" and r3["declared_offline_is_not_proof"] is True
        from kora.core.db import get_connection
        c = get_connection(db)
        try:
            ev = [x[0] for x in c.execute("SELECT event_type FROM audit_events;").fetchall()]
        finally:
            c.close()
        assert ev.count("egress_probe") == 2
    run_test("T204", "Egress probe: REACHABLE => runtime not offline; failures reported as unobserved (no firewall/air-gap claim); no data sent; audited; injected connector only (no real network in test)", egress)

    def api_routes():
        from kora.tests.hud_studio_tests import _app, H
        app, call, root, db = _app()
        # unauthenticated non-loopback caller is denied on every new route
        for m, p in (("GET", "/api/metrics"), ("GET", "/api/assessment/history"), ("POST", "/api/assessment/run"), ("POST", "/api/egress/probe")):
            assert call(m, p, {} if m == "POST" else None)[0] in (401, 403), (m, p)
        s, mt, _ = call("GET", "/api/metrics", headers=H)
        assert s == 200 and mt["queue"]["queued"] == 0 and mt["worker_saturation"] is not None, (s, mt)
        s, r, _ = call("POST", "/api/assessment/run", {}, headers=H)
        assert s == 200 and r["ok"] is True and r["production_mutation"] is False, (s, r)
        s, h, _ = call("GET", "/api/assessment/history", headers=H)
        assert s == 200 and len(h["items"]) == 1 and h["items"][0]["run_id"] == r["run_id"]
        # egress route against a closed LOOPBACK port only (no external traffic from the test)
        A.EGRESS_TARGETS, old = (("127.0.0.1", 1),), A.EGRESS_TARGETS
        try:
            s, e, _ = call("POST", "/api/egress/probe", {}, headers=H)
        finally:
            A.EGRESS_TARGETS = old
        assert s == 200 and e["status"] in ("NO_OUTBOUND_OBSERVED", "EGRESS_OPEN") and e["data_sent"] is False
    run_test("T205", "New routes (metrics, assessment run/history, egress probe): auth required, owner-only, read-only results, loopback-only egress target in test", api_routes)
