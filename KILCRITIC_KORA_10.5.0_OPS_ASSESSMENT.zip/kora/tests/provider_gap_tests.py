"""T192-T199: GAP_NO_AI_PROVIDER, truthful provider comparison, structured owner_actions (no provider / local rules only / provider available /
missing research configuration / unknown privacy terms / owner approval / deduplication / backward compatibility)."""
import json
import os
import socket
import tempfile

SECRET = "sk-TESTSECRETVALUE-1234567890"


def _db():
    from kora.core.db import init_db
    p = os.path.join(tempfile.mkdtemp(prefix="kora-pg-"), "p.db")
    init_db(p)
    return p


def _count(db, action):
    from kora.core.db import get_connection
    c = get_connection(db)
    try:
        return c.execute("SELECT COUNT(*) FROM proposals WHERE action=?;", (action,)).fetchone()[0]
    finally:
        c.close()


class _NoNet:
    """Any socket use fails: provider-gap detection, comparison and proposal drafting must be offline."""
    def __enter__(self):
        self.old = socket.socket

        def boom(*a, **k):
            raise AssertionError("network used")
        socket.socket = boom
        return self

    def __exit__(self, *a):
        socket.socket = self.old


def register(run_test):
    from kora.services import ai_failover as F
    from kora.services import governance
    from kora.services import self_evolution_3 as se3
    from kora.tests.evolution3_tests import _calm, _mini_repo

    def gap(db, env):
        return [g for g in se3.detect_gaps(db, None, None, env)["gaps"] if g["id"] == se3.PROVIDER_GAP]

    def no_provider():
        F._breaker.clear()
        db = _db()
        g = gap(db, {})
        assert len(g) == 1 and g[0]["severity"] == "HIGH" and g[0]["evidence"]["usable_ai_providers"] == 0, g
        assert "not an AI provider" in g[0]["evidence"]["local_rule_engine"]
        assert F.usable_ai_providers({}) == []
        cmp_ = F.provider_comparison({})
        assert cmp_["ai_provider_available"] is False and cmp_["local_rules_available"] is True and "NOT an AI provider" in cmp_["local_rules_note"]
        assert len(cmp_["providers"]) == 6
    run_test("T192", "No provider: GAP_NO_AI_PROVIDER raised (HIGH) from ai_failover.provider_states; comparison says no AI provider available", no_provider)

    def local_rules_only():
        F._breaker.clear()
        db = _db()
        rows = {r["provider"]: r for r in F.provider_comparison({})["providers"]}
        loc = rows[F.LOCAL_FALLBACK]
        assert loc["state"] == "AVAILABLE" and loc["available_now"] is True and loc["kind"].startswith("LOCAL_RULE_ENGINE") and "not an AI provider" in loc["kind"]
        assert F.LOCAL_FALLBACK not in F.usable_ai_providers({})
        # a key for a provider that has NO adapter is not a usable provider either: gap stays and the state is reported accurately
        env = {"OPENROUTER_API_KEY": SECRET}
        st = {p["provider"]: p["state"] for p in F.provider_states(env)}
        assert st["openrouter"] == "CONFIGURED_NOT_IMPLEMENTED" and F.usable_ai_providers(env) == []
        assert len(gap(db, env)) == 1
        assert rows["openrouter"]["adapter_supported"] is False and rows["openrouter"]["available_now"] is False
    run_test("T193", "Local rules only: rule engine reported as available but never counted as an AI provider; key without adapter is not usable", local_rules_only)

    def provider_available():
        F._breaker.clear()
        db = _db()
        env = {"GROQ_API_KEY": SECRET}
        assert F.usable_ai_providers(env) == ["groq"] and gap(db, env) == []
        assert F.provider_comparison(env)["ai_provider_available"] is True
        repo = _mini_repo()
        with _calm():
            r = se3.run_cycle(db, str(repo), env, goal="improve calc module")
        assert r["status"] == "COMPLETED" and "provider_proposal_id" not in r["result"] and _count(db, se3.PROVIDER_ACTION) == 0
        assert all(x["gap"] != se3.PROVIDER_GAP for x in r["result"]["drafts"])
        assert all(a["env_vars"] == [] or "GROQ_API_KEY" in a["env_vars"] or "OPENAI_API_KEY" in a["env_vars"] for a in F.provider_owner_actions(env))
    run_test("T194", "Provider available: no gap, no provider proposal; existing cycle behaviour unchanged", provider_available)

    def missing_research():
        F._breaker.clear()
        db = _db()
        repo = _mini_repo()
        with _calm(), _NoNet():
            r = se3.run_cycle(db, str(repo), {}, goal="")
        assert r["status"] == "COMPLETED"
        d = r["result"]
        pr = d["provider_research"]
        assert pr["status"] == "NOT_CONFIGURED" and pr["sources"] == [] and "BRAVE_SEARCH_API_KEY" in pr["note"], pr
        pid = d["provider_proposal_id"]
        p = governance.get_proposal(pid, db)
        assert p["action"] == se3.PROVIDER_ACTION and p["status"] == "PENDING" and p["risk"] == "MEDIUM"
        c = json.loads(p["changes"])[0]
        assert c["comparison"]["research"]["status"] == "NOT_CONFIGURED"
        # the provider draft is first and is provider-specific (not a Whisper / unused-module draft)
        assert d["drafts"][0]["gap"] == se3.PROVIDER_GAP and d["drafts"][0]["proposal_id"] == pid
        # Brave search configured but the call fails: reported as failed, never invented
        calls = []

        def failing(q, env=None, count=5):
            calls.append(q)
            return {"ok": False, "status": "PROVIDER_ERROR", "error": "http_401", "results": []}
        r2 = se3._provider_research({}, {"BRAVE_SEARCH_API_KEY": SECRET}, search=failing)
        assert r2["status"] == "NO_SOURCES" and r2["failed"] and len(calls) == 3 and SECRET not in json.dumps(r2)
    run_test("T195", "Missing research configuration: NOT_CONFIGURED reported, provider-specific proposal still created offline, search failures not invented", missing_research)

    def unknown_privacy():
        F._breaker.clear()
        owner_src = {"status": "OWNER_URLS", "sources": [{"url": "https://groq.com/privacy-policy", "title": "Groq privacy"}, {"url": "https://evil.example/openai", "title": "x"}]}
        rows = {r["provider"]: r for r in F.provider_comparison({}, owner_src)["providers"]}
        assert rows["groq"]["privacy"] == "UNKNOWN" and rows["groq"]["data_retention"] == "UNKNOWN"
        assert rows["groq"]["privacy_status"] == "UNKNOWN_EVIDENCE_ATTACHED_NEEDS_OWNER_REVIEW" and rows["groq"]["evidence_sources"] == ["https://groq.com/privacy-policy"]
        assert rows["openai"]["privacy_status"] == "UNKNOWN" and rows["openai"]["evidence_sources"] == [], "off-site URL is never attached as evidence"
        for n in ("gemini", "openai", "groq", "openrouter", "cerebras"):
            assert rows[n]["privacy"] == "UNKNOWN" and rows[n]["data_retention"] == "UNKNOWN", n
            assert rows[n]["dependencies"] and rows[n]["credentials_required"] and rows[n]["cost_category"] and "adapter_supported" in rows[n]
        # Brave search: only same-provider https hosts are kept, as links; nothing is interpreted
        def fake(q, env=None, count=5):
            n = q.split()[0]
            return {"ok": True, "status": "OK", "results": [{"title": "t", "url": "https://spam.example/" + n, "snippet": "we never retain data"},
                                                            {"title": "official", "url": {"gemini": "https://ai.google.dev/gemini-api/terms", "openai": "https://openai.com/policies", "groq": "https://groq.com/privacy-policy"}[n], "snippet": ""}]}
        r = se3._provider_research({}, {"BRAVE_SEARCH_API_KEY": SECRET}, search=fake)
        assert r["status"] == "SEARCH_RESULTS_ONLY" and len(r["sources"]) == 3 and all(s["url"].startswith("https://") and "spam.example" not in s["url"] for s in r["sources"]), r
        rows2 = {x["provider"]: x for x in F.provider_comparison({}, r)["providers"]}
        assert all(rows2[n]["privacy"] == "UNKNOWN" for n in rows2 if n != F.LOCAL_FALLBACK)
    run_test("T196", "Unknown privacy/retention stay UNKNOWN (never guessed); evidence links only from official hosts via owner URLs or configured Brave search", unknown_privacy)

    def owner_actions_and_dedup():
        F._breaker.clear()
        db = _db()
        repo = _mini_repo()
        env = {"BRAVE_SEARCH_API_KEY": ""}
        with _calm():
            a = se3.run_cycle(db, str(repo), env, goal="")
            b = se3.run_cycle(db, str(repo), env, goal="")
        pid = a["result"]["provider_proposal_id"]
        assert b["result"]["provider_proposal_id"] == pid and _count(db, se3.PROVIDER_ACTION) == 1, "duplicate open proposal must not be created"
        assert b["result"]["drafts"][0]["duplicate"] is True
        p = governance.get_proposal(pid, db)
        c = json.loads(p["changes"])[0]
        acts = {x["id"]: x for x in c["owner_actions"]}
        assert [x["id"] for x in c["owner_actions"]] == ["CHOOSE_PROVIDER", "OBTAIN_KEY", "SET_ENV", "RERUN_DISCOVERY", "FIRST_REAL_CALL", "RECORD_RESULT"]
        for k in ("OBTAIN_KEY", "SET_ENV", "CHOOSE_PROVIDER", "FIRST_REAL_CALL"):
            assert acts[k]["who"] == "MALAK" and acts[k]["system_can_do_alone"] is False
        for k in ("RERUN_DISCOVERY", "RECORD_RESULT"):
            assert acts[k]["who"] == "SYSTEM" and acts[k]["system_can_do_alone"] is True
        assert set(acts["SET_ENV"]["env_vars"]) == {"GEMINI_API_KEY", "OPENAI_API_KEY", "GROQ_API_KEY"} and "restart" in acts["SET_ENV"]["action"].lower()
        assert acts["OBTAIN_KEY"]["requires_approval"] is True and "Never paste" in acts["OBTAIN_KEY"]["secret_handling"]
        assert c["guarantees"] == {"installs_packages": False, "modifies_code": False, "connects_accounts": False, "spends_money": False,
                                   "enables_external_services": False, "secrets_requested_in_chat": False}
        blob = json.dumps(c)
        assert "whisper" not in blob.lower() and "unused" not in blob.lower()
        # a real key in the environment is never copied into the proposal or the ledger
        F._breaker.clear()
        db2 = _db()
        with _calm():
            se3.run_cycle(db2, str(repo), {"OPENROUTER_API_KEY": SECRET}, goal="")
        from kora.core.db import get_connection
        cn = get_connection(db2)
        try:
            dump = json.dumps([dict(r) for r in cn.execute("SELECT * FROM proposals;").fetchall()]) + json.dumps([dict(r) for r in cn.execute("SELECT * FROM audit_events;").fetchall()])
        finally:
            cn.close()
        assert SECRET not in dump
        # goal about an AI provider => provider draft only (not unrelated drafts)
        db3 = _db()
        with _calm():
            r3 = se3.run_cycle(db3, str(repo), {}, goal="connect an AI provider")
        assert [x["gap"] for x in r3["result"]["drafts"]] == [se3.PROVIDER_GAP]
    run_test("T197", "Owner actions: exact steps/env-var NAMES/restart/retest, Malak vs SYSTEM split, guarantees, one deduplicated proposal, no secret value stored, provider-specific draft", owner_actions_and_dedup)

    def approval_and_api():
        from kora.tests.hud_studio_tests import _app, H
        app, call, root, db = _app()
        repo = _mini_repo()
        old = {k: os.environ.pop(k, None) for k in ("GEMINI_API_KEY", "OPENAI_API_KEY", "GROQ_API_KEY")}
        try:
            F._breaker.clear()
            with _calm():
                se3.run_cycle(db, str(repo), {}, goal="")
            pid = governance.find_open_duplicate(se3.PROVIDER_ACTION, se3.PROVIDER_REASON, db)
            assert pid
            assert call("GET", "/api/evolution/3/providers")[0] in (401, 403)
            s, body, _ = call("GET", "/api/evolution/3/providers", headers=H)
            assert s == 200 and body["comparison"]["ai_provider_available"] is False and body["owner_actions"][0]["who"] == "MALAK", (s, body)
            s, gp, _ = call("GET", "/api/evolution/3/gaps", headers=H)
            assert s == 200 and any(g["id"] == se3.PROVIDER_GAP for g in gp["gaps"])
            s, d, _ = call("GET", f"/api/governance/proposals/{pid}", headers=H)
            assert s == 200 and d["owner_actions"] and d["comparison"]["providers"] and "changes" not in d["proposal"] and d["proposal"]["status"] == "PENDING" and d["executed"] is False
            assert call("POST", f"/api/governance/proposals/{pid}/approve", {})[0] in (401, 403)
            assert governance.get_proposal(pid, db)["status"] == "PENDING"
            s, ap, _ = call("POST", f"/api/governance/proposals/{pid}/approve", {}, headers=H)
            assert s == 200 and ap["status"] == "APPROVED" and ap["executed"] is False and "cannot obtain a real API key" in ap["note"], ap
            s, d2, _ = call("GET", f"/api/governance/proposals/{pid}", headers=H)
            assert d2["proposal"]["status"] == "APPROVED" and d2["executed"] is False and d2["patch_present"] is False
            assert not os.path.isdir(os.path.join(root, "data", "evolution", "restore_points", pid))
            assert call("POST", f"/api/governance/proposals/{pid}/approve", {}, headers=H)[0] == 409, "cannot be decided twice"
            # freeze control still stops the cycle (existing control intact)
            se3.freeze("t", db, "t")
            try:
                se3.run_cycle(db, str(repo), {}, goal="")
                raise AssertionError("frozen cycle ran")
            except se3.EvolutionFrozen:
                pass
            se3.unfreeze("t", db) if hasattr(se3, "unfreeze") else None
        finally:
            for k, v in old.items():
                if v is not None:
                    os.environ[k] = v
    run_test("T198", "Owner approval over HTTP: auth required, approval is a decision only (executed=false, nothing applied), detail exposes owner_actions, freeze intact", approval_and_api)

    def backward_compat():
        F._breaker.clear()
        db = _db()
        g = se3.detect_gaps(db)  # old signature still works
        assert "gaps" in g and "count" in g
        from kora.services import self_evolution as se
        r = se.prepare("tighten the calc module", db, str(_mini_repo()), generate_patch=False, env={})
        assert r["status"] == "PENDING_APPROVAL" and r["owner_actions"] == [] and r["patch_ready"] is False
        d = se.prepare("tighten the calc module", db, str(_mini_repo()), generate_patch=False, env={})
        assert d["status"] == "DUPLICATE_OPEN" and d["proposal_id"] == r["proposal_id"]
        r2 = se.prepare("another goal entirely", db, str(_mini_repo()), generate_patch=True, env={})
        assert r2["patch_ready"] is False and [x["id"] for x in r2["owner_actions"]][:3] == ["CHOOSE_PROVIDER", "OBTAIN_KEY", "SET_ENV"]
        assert F.provider_states({})[-1]["provider"] == F.LOCAL_FALLBACK and {"provider", "state", "implemented", "cost_hint", "capabilities", "credentials", "privacy", "data_retention"} <= set(F.provider_states({})[0])
    run_test("T199", "Backward compatibility: detect_gaps old signature, prepare duplicate guard, prepare owner_actions only when a patch needed an AI provider that is absent, provider_states shape", backward_compat)
