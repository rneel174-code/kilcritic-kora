# 10.4.0 (2026-10-07): FIX + HARDEN + LOCK-11 (additive)
- 9 audit fixes (rights gate, touch workflows, truthful schedule states + recovery, Instagram media/account readiness, state guards, mobile UI, capability truth, real media.convert). See HARDENING_10_4_REPORT.md.
- LOCK-11 MALAK-ASSIST hardened: redaction, task-bound one-time code (never returned to requester), expiry, lockout, duplicate-reply rejection, consume-once checkpoint, sender-authenticated inbound, restart recovery.
- New fortress.py: immutable permission boundary, independent watchdog + halt, delegation limits, evolution proof, dead-file audit (archive-only), learning firewall + drift, independence report, complexity gate, recovery proof.
- Security fixes: token echo in platform errors scrubbed; SSRF numeric-host bypass closed; malformed 2xx JSON handled.
- Tests: 121 -> 151 (T122-T151). T19/T36/T37/T48/T49/T53/T59 now assert undeclared/unknown rights => HUMAN_REVIEW/BLOCKED.

# Changelog

## 10.3.0 — FINAL MERGE (2026-10-06): one ZIP, nothing removed
- **Merged**: 10.2 base + SE2 + 5.0 Godfather/Supreme Runtime/Infinite Core + Next-Gen + FIXED_AUDITED + Creator OS (scheduled autopilot, Instagram/TikTok adapters, vault, regional lock, creator HUD) + Owner KB + Self-Evolution 3.0 spec.
- **Self-Evolution 3.0 Good Father** (`services/self_evolution_3.py`, upgrade of SE1/SE2, no second engine): evidence-hash-chained memory, capability discovery + FIND-before-BUILD, dependency intel, benchmark lab, evolution score (reuses Godfather), regression guards, impact graph + levels 0-6, adversarial scan, gap radar, performance profile, failure prediction (9 classes), resource-aware checkpointed cycle, offline queue (durable jobs), self-test generator, canary in isolated copy, promotion gate, verified rollback, chaos check, owner freeze. Legacy approve/apply can no longer patch code without the gate.
- **20 intelligence additions** merged into existing modules: priority tiers P0-P4 + pressure control, pause/resume, dependency-aware jobs, injection shield, human-readable errors, health domains, failure prediction, dry-run, social account routing, ffprobe quality verification, DNA learning + rollback, trust score/least-privilege routing, command confidence.
- **Duplicates fixed**: `offline_queue` is now an adapter over the single durable queue; one `_NoRedirect`.
- **Tests**: 121/121 (twice) + Godfather, Supreme Runtime, Infinite Core runners. Creator-suite assertions made strict (a False result now fails).

## 2026-10-05 — Creator-First Dashboard UI Lock
- Added a single **MEDIA + SOCIAL + STUDIO** folder/icon as the creator dashboard front door.
- Grouped YouTube, Facebook, Instagram, TikTok, X, Hollywood Studio, Editing, Cartoon/Animation, Funny Baby, Funny Videos, Videos, Photos, Stories, Wallpapers, Voice+Text, POST, 30-Day Autopilot, Comments, Growth, Research and Dhanda inside the hub.
- Removed technical navigation tabs from the main dashboard.
- Moved System Health, Discovery/System Overview, Events/Event Bus, Backup, Voice/STT, Media Dedup, Offline Queue, Tests and KORA HUD into an explicit **Advanced** area.
- Advanced/system controls are hidden by default and do not clutter the creator workflow.
- No backend capability was removed; this is a presentation/navigation change only.

# Changelog

## 10.2.0-KILCRITIC-SUPREME (on KORA 8.10.0)
Identity/roles/TOTP, One Brain (text+voice), DNA Time Machine, ATMA/Phoenix, Shadow Publish, trust+skill gate, deep research, ledger verifier, anti-loop, audit hash-chain, export/delete, safe migration, new HUD. Tests 53 -> 69, all PASS. Details: docs/CHANGELOG_AND_NOTES.md.

## 8.10.0
Governance layer (policy, proposals, Malak, legal preflight, cost caps, SENA, emergency). Tests 43 -> 53.

## 8.9.0-KORA-PRO
Restructure into kora/{core,services,bridge,config,hud}; queue retry+DLQ; auth/rate-limit/logger/env; cron; social auto-publish; research+RAG.

## 10.2.1 — Governed Self-Evolution + Holographic HUD
- Added `kora/services/self_evolution.py`: real repository scan, source research, governed patch proposal, path validation, owner approval, canary/dry-run, compile + full-test verification, rollback and audit trail.
- Added `/api/evolution/scan`, `/api/evolution/prepare`, `/api/evolution/{id}/apply`, `/api/evolution/{id}/rollback`.
- Approved `MODIFY_CODE` proposals now automatically enter the governed apply/test/verify path; failed verification rolls back.
- Added adaptive environment profile API: EARTH/OCEAN/SKY/SPACE/REGION.
- Added 72-test gate including self-evolution and environment tests.
- Reworked the native HUD into a desktop/mobile fullscreen holographic command center with current-task focus, approvals, self-evolution, resources, providers, environment, voice, backup and doctor controls.
- Added bundled KORA avatar asset to the native HUD.
- No fake physical power, no silent production modification, no credential bypass, and no automatic payment.

## Supreme Runtime Next-Gen Integration
- Added Horizon Reduction, Trajectory Assurance, Formal Agent Contracts and Dynamic Autonomy Budget primitives.
- Added runtime watchdog, tamper-evident execution proof, execution-state memory tree and delegation provenance.
- Added zero-trust supply-chain records, evidence freshness, objective-drift detection, blast-radius analysis and recovery proof.
- Added complexity-debt accounting and architecture-compression/reuse-first guidance.
- Integrated planning-only Supreme Runtime assurance into the existing Godfather planner.
- Added research-gap audit and regression tests; existing 75-test suite remains green.

## 2026-10-05 — Gap Closure Pass
- Added official Instagram Graph publishing flow with public-media requirement.
- Added official TikTok Content Posting API Direct Post flow with bounded upload/status verification.
- Added social media URL/type/AI metadata migration.
- Added runtime resource enforcement, encrypted local vault, notification outbox and capability truth matrix.
- Added 9 gap-closure regression tests.

## 2026-10-05 — CA/US/IN Regional Lock
- Added explicit Canada, United States and India regional profiles.
- Added region-aware localization/currency/Amazon marketplace defaults.
- Added UI region selector with India default.
- Added region safety rules: no permission/legal/platform bypass and no automatic affiliate account creation.
- Added regional regression tests.
