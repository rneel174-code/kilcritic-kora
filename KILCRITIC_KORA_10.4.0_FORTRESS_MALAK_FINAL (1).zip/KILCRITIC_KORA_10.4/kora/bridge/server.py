"""Threaded WSGI server + service lifecycle (worker pool, cron). Binds 127.0.0.1 unless KORA_BIND_HOST says otherwise."""
import signal
import threading
from socketserver import ThreadingMixIn
from wsgiref.simple_server import WSGIRequestHandler, WSGIServer, make_server

from kora import VERSION
from kora.bridge.api import KoraApp
from kora.config.settings import get_settings
from kora.core.logger import configure_logging, get_logger


class _Threaded(ThreadingMixIn, WSGIServer):
    daemon_threads = True
    request_queue_size = 64


class _QuietHandler(WSGIRequestHandler):
    def log_message(self, *a):  # structured logging happens in the app
        pass


def serve(settings=None) -> None:
    s = settings or get_settings()
    configure_logging(s.log_level, s.log_file)
    log = get_logger("server")
    app = KoraApp(s)
    app.start_services()
    httpd = make_server(s.bind_host, s.port, app, server_class=_Threaded, handler_class=_QuietHandler)
    if s.bind_host not in ("127.0.0.1", "::1", "localhost") and not s.auth_token:
        log.warning("bound to %s with NO KORA_AUTH_TOKEN: remote clients will be denied (403)", s.bind_host)
    log.info("KORA %s listening on http://%s:%s (workers=%s cron=%s)", VERSION, s.bind_host, s.port, s.worker_pool_size, s.cron_enabled)

    def _stop(*_):
        threading.Thread(target=httpd.shutdown, daemon=True).start()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, _stop)
        except ValueError:
            pass
    try:
        httpd.serve_forever()
    finally:
        log.info("shutting down: stopping cron + workers")
        app.stop_services()
        httpd.server_close()


if __name__ == "__main__":
    serve()
