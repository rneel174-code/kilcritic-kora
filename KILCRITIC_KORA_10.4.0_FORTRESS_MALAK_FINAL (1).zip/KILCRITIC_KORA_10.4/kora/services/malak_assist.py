"""MALAK-ASSIST: governed human-in-the-loop pause/notify/resume bridge.

Never bypasses OTP/CAPTCHA/payment/approval. It checkpoints the task, puts it
into WAITING_FOR_MALAK, attempts configured Telegram/WhatsApp notification,
and resumes only after an authenticated Malak response. External messaging is
truthful: NOT_CONFIGURED is returned when credentials/connectors are absent.
"""
from __future__ import annotations
import hashlib, json, os, re, secrets, time, urllib.parse, urllib.request
from typing import Any, Dict, Optional
from kora.core.db import DEFAULT_DB_PATH, get_connection, record_audit

HUMAN_REASONS = {"OTP", "CAPTCHA", "PAYMENT", "APPROVAL", "OAUTH", "HUMAN_INPUT"}

def _now(): return time.time()
def _hash(v: str) -> str: return hashlib.sha256(v.encode()).hexdigest()
def _j(v, n=20000): return json.dumps(v, sort_keys=True, default=str)[:n]

MAX_ATTEMPTS = 5
_SECRET_KEYS = ("otp", "code", "password", "passwd", "secret", "token", "cvv", "cvc", "card", "pin", "api_key", "apikey", "authorization", "captcha")
_SECRET_RX = [re.compile(p, re.I) for p in (
    r"(otp|one[- ]?time (?:code|password)|verification code|pin|cvv|password|passwd|secret|token)\s*[:=]?\s*\S+",
    r"bearer\s+[A-Za-z0-9._\-]{8,}", r"\bsk-[A-Za-z0-9_\-]{10,}", r"\b\d{13,19}\b", r"\b[a-f0-9]{32,}\b")]


def redact(value):
    """Secrets/OTP must never be stored or logged: scrub keys and secret-looking text recursively."""
    if isinstance(value, dict):
        return {k: ("[REDACTED]" if (set(re.split(r"[^a-z0-9]+", str(k).lower())) & set(_SECRET_KEYS)) or str(k).lower().replace("_","") in {x.replace("_","") for x in _SECRET_KEYS} else redact(v)) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [redact(v) for v in value]
    if isinstance(value, str):
        for rx in _SECRET_RX:
            value = rx.sub("[REDACTED]", value)
        return value
    return value


def init(db_path=DEFAULT_DB_PATH):
    c=get_connection(db_path)
    try:
        c.execute("""CREATE TABLE IF NOT EXISTS malak_assist_tasks(
            id TEXT PRIMARY KEY, reason TEXT NOT NULL, message TEXT NOT NULL,
            state TEXT NOT NULL, checkpoint TEXT NOT NULL, token_hash TEXT NOT NULL,
            created_at REAL NOT NULL, updated_at REAL NOT NULL, expires_at REAL,
            resume_note TEXT NOT NULL DEFAULT '', notifier_status TEXT NOT NULL DEFAULT 'NOT_CONFIGURED')""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_malak_assist_state ON malak_assist_tasks(state)")
        cols={r[1] for r in c.execute("PRAGMA table_info(malak_assist_tasks)").fetchall()}
        for col, ddl in (("attempts","INTEGER NOT NULL DEFAULT 0"),("consumed_at","REAL"),("completed_at","REAL"),("outcome","TEXT NOT NULL DEFAULT ''")):
            if col not in cols: c.execute(f"ALTER TABLE malak_assist_tasks ADD COLUMN {col} {ddl}")
    finally: c.close()

def _telegram(message: str):
    token=os.getenv("KORA_MALAK_TELEGRAM_BOT_TOKEN", "")
    chat=os.getenv("KORA_MALAK_TELEGRAM_CHAT_ID", "")
    if not token or not chat: return {"channel":"telegram","status":"NOT_CONFIGURED"}
    url=f"https://api.telegram.org/bot{token}/sendMessage"
    data=urllib.parse.urlencode({"chat_id":chat,"text":message}).encode()
    try:
        req=urllib.request.Request(url,data=data,method="POST")
        with urllib.request.urlopen(req,timeout=10) as r:
            ok=200 <= r.status < 300
        return {"channel":"telegram","status":"SENT" if ok else "FAILED"}
    except Exception as e:
        return {"channel":"telegram","status":"FAILED","error":type(e).__name__}

def _whatsapp(message: str):
    token=os.getenv("KORA_WHATSAPP_CLOUD_TOKEN", "")
    phone=os.getenv("KORA_WHATSAPP_PHONE_NUMBER_ID", "")
    to=os.getenv("KORA_MALAK_WHATSAPP_TO", "")
    if not token or not phone or not to: return {"channel":"whatsapp","status":"NOT_CONFIGURED"}
    url=f"https://graph.facebook.com/v20.0/{phone}/messages"
    payload=json.dumps({"messaging_product":"whatsapp","to":to,"type":"text","text":{"body":message}}).encode()
    try:
        req=urllib.request.Request(url,data=payload,headers={"Authorization":"Bearer "+token,"Content-Type":"application/json"},method="POST")
        with urllib.request.urlopen(req,timeout=10) as r:
            ok=200 <= r.status < 300
        return {"channel":"whatsapp","status":"SENT" if ok else "FAILED"}
    except Exception as e:
        return {"channel":"whatsapp","status":"FAILED","error":type(e).__name__}

def pause_for_malak(reason: str, checkpoint: Dict[str,Any], *, task_id: Optional[str]=None, db_path=DEFAULT_DB_PATH, ttl_seconds: int=3600, channels=None):
    reason=(reason or "HUMAN_INPUT").upper()
    if reason not in HUMAN_REASONS: raise ValueError("unsupported human-assist reason")
    init(db_path); tid=task_id or "malak-"+secrets.token_hex(8); token=secrets.token_hex(4).upper(); now=_now(); exp=now+max(60,min(ttl_seconds,7*86400))
    checkpoint=redact(checkpoint if isinstance(checkpoint, dict) else {"value": checkpoint})
    message=f"Malak need 2 min help: {reason}. Task {tid}. Baki main kar lu. Reply with code {token} to resume."
    stored_message=f"Malak need 2 min help: {reason}. Task {tid}. (one-time code sent only to the Malak channel)"
    results=[]
    for ch in (channels or ["telegram","whatsapp"]):
        results.append(_telegram(message) if ch=="telegram" else _whatsapp(message) if ch=="whatsapp" else {"channel":ch,"status":"UNSUPPORTED"})
    if any(x.get("status")=="SENT" for x in results): pass
    status="SENT" if any(x.get("status")=="SENT" for x in results) else ("FAILED" if any(x.get("status")=="FAILED" for x in results) else "NOT_CONFIGURED")
    c=get_connection(db_path)
    try:
        c.execute("INSERT OR REPLACE INTO malak_assist_tasks(id,reason,message,state,checkpoint,token_hash,created_at,updated_at,expires_at,resume_note,notifier_status) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                  (tid,reason,stored_message,"WAITING_FOR_MALAK",_j(checkpoint),_hash(token),now,now,exp,"",status))
    finally: c.close()
    record_audit("malak_assist_paused","system",{"task_id":tid,"reason":reason,"notifier_status":status},db_path)
    return {"status":"WAITING_FOR_MALAK","task_id":tid,"message":f"Malak need 2 min help: {reason}. Task {tid}. Check your configured Malak channel for the one-time resume code.","notifiers":results,"resume_token":token,"expires_at":exp,"checkpoint_saved":True}

def get_task(task_id: str, db_path=DEFAULT_DB_PATH):
    init(db_path); c=get_connection(db_path)
    try: r=c.execute("SELECT id,reason,state,checkpoint,created_at,updated_at,expires_at,resume_note,notifier_status,outcome,attempts FROM malak_assist_tasks WHERE id=?",(task_id,)).fetchone()
    finally: c.close()
    if not r: return {"status":"NOT_FOUND"}
    return {"status":"OK","task":dict(r)}

def _policy(reason: str) -> Dict[str, Any]:
    """What a resume does NOT authorise. OTP/CAPTCHA are completed by the human, never by KORA; payment is never automatic."""
    return {"auto_pay": False, "payment_executed": False, "otp_value_stored": False, "captcha_bypassed": False,
            "payment_requires_separate_explicit_approval": reason == "PAYMENT"}


def _expire_if_due(c, r, db_path) -> bool:
    if r["state"] == "WAITING_FOR_MALAK" and r["expires_at"] and r["expires_at"] <= _now():
        c.execute("UPDATE malak_assist_tasks SET state='EXPIRED',updated_at=? WHERE id=? AND state='WAITING_FOR_MALAK'", (_now(), r["id"]))
        record_audit("malak_assist_expired", "system", {"task_id": r["id"]}, db_path)
        return True
    return False


def resume(task_id: str, resume_token: str, *, note: str="Malak approved", db_path=DEFAULT_DB_PATH, authenticated_sender: bool = False):
    init(db_path); c=get_connection(db_path)
    try:
        r=c.execute("SELECT * FROM malak_assist_tasks WHERE id=?",(task_id,)).fetchone()
        if not r: return {"status":"NOT_FOUND"}
        if r["state"] != "WAITING_FOR_MALAK":
            record_audit("malak_assist_rejected","system",{"task_id":task_id,"reason":"task_not_waiting","state":r["state"]},db_path)
            return {"status":"REJECTED","reason":"task_not_waiting","state":r["state"]}
        if _expire_if_due(c, r, db_path): return {"status":"EXPIRED"}
        if (r["attempts"] or 0) >= MAX_ATTEMPTS:
            c.execute("UPDATE malak_assist_tasks SET state='LOCKED',updated_at=? WHERE id=? AND state='WAITING_FOR_MALAK'",(_now(),task_id))
            record_audit("malak_assist_locked","system",{"task_id":task_id},db_path)
            return {"status":"LOCKED","reason":"too_many_wrong_attempts"}
        if not secrets.compare_digest(r["token_hash"],_hash(str(resume_token or "").strip().upper())):
            c.execute("UPDATE malak_assist_tasks SET attempts=attempts+1,updated_at=? WHERE id=?",(_now(),task_id))
            record_audit("malak_assist_rejected","system",{"task_id":task_id,"reason":"invalid_resume_token","attempts":(r["attempts"] or 0)+1},db_path)
            return {"status":"REJECTED","reason":"invalid_resume_token"}
        cur=c.execute("UPDATE malak_assist_tasks SET state='RESUMABLE',updated_at=?,resume_note=? WHERE id=? AND state='WAITING_FOR_MALAK'",(_now(),redact(str(note))[:2000],task_id))
        if cur.rowcount != 1: return {"status":"REJECTED","reason":"duplicate_reply"}
    finally: c.close()
    record_audit("malak_assist_resumed","malak",{"task_id":task_id,"authenticated_sender":bool(authenticated_sender)},db_path)
    return {"status":"RESUMABLE","task_id":task_id,"checkpoint":json.loads(r["checkpoint"]),"note":redact(str(note)),"policy":_policy(r["reason"])}


def consume(task_id: str, *, db_path=DEFAULT_DB_PATH):
    """Atomically take the checkpoint exactly once (RESUMABLE -> RESUMED). A second caller gets REJECTED: no double execution."""
    init(db_path); c=get_connection(db_path)
    try:
        r=c.execute("SELECT * FROM malak_assist_tasks WHERE id=?",(task_id,)).fetchone()
        if not r: return {"status":"NOT_FOUND"}
        cur=c.execute("UPDATE malak_assist_tasks SET state='RESUMED',consumed_at=?,updated_at=? WHERE id=? AND state='RESUMABLE'",(_now(),_now(),task_id))
        if cur.rowcount != 1: return {"status":"REJECTED","reason":"not_resumable","state":r["state"]}
    finally: c.close()
    record_audit("malak_assist_consumed","system",{"task_id":task_id},db_path)
    return {"status":"RESUMED","task_id":task_id,"checkpoint":json.loads(r["checkpoint"]),"policy":_policy(r["reason"])}


def complete(task_id: str, *, verified: bool, outcome: str = "", db_path=DEFAULT_DB_PATH):
    """RESUMED -> COMPLETED only when the work was verified; otherwise FAILED. Never a fake success."""
    init(db_path); c=get_connection(db_path)
    try:
        cur=c.execute("UPDATE malak_assist_tasks SET state=?,completed_at=?,updated_at=?,outcome=? WHERE id=? AND state='RESUMED'",
                      ("COMPLETED" if verified else "FAILED",_now(),_now(),redact(str(outcome))[:500],task_id))
        if cur.rowcount != 1: return {"status":"REJECTED","reason":"not_resumed"}
    finally: c.close()
    record_audit("malak_assist_completed" if verified else "malak_assist_failed","system",{"task_id":task_id},db_path)
    return {"status":"COMPLETED" if verified else "FAILED","task_id":task_id}


def cancel(task_id: str, *, db_path=DEFAULT_DB_PATH):
    init(db_path); c=get_connection(db_path)
    try:
        cur=c.execute("UPDATE malak_assist_tasks SET state='CANCELLED',updated_at=? WHERE id=? AND state IN ('WAITING_FOR_MALAK','RESUMABLE')",(_now(),task_id))
        if cur.rowcount != 1: return {"status":"REJECTED","reason":"not_cancellable"}
    finally: c.close()
    record_audit("malak_assist_cancelled","system",{"task_id":task_id},db_path)
    return {"status":"CANCELLED","task_id":task_id}


def expire_stale(db_path=DEFAULT_DB_PATH):
    init(db_path); c=get_connection(db_path)
    try:
        rows=c.execute("SELECT id FROM malak_assist_tasks WHERE state='WAITING_FOR_MALAK' AND expires_at<=?",(_now(),)).fetchall()
        for r in rows: c.execute("UPDATE malak_assist_tasks SET state='EXPIRED',updated_at=? WHERE id=?",(_now(),r["id"]))
    finally: c.close()
    for r in rows: record_audit("malak_assist_expired","system",{"task_id":r["id"]},db_path)
    return {"status":"OK","expired":[r["id"] for r in rows]}


def recover(db_path=DEFAULT_DB_PATH):
    """After restart/SIGKILL: checkpoints live in SQLite, so waiting tasks survive. Expire overdue ones and report what is still waiting.
    A task caught in RESUMED (crash mid-execution) is reported, never silently re-run."""
    exp=expire_stale(db_path); init(db_path); c=get_connection(db_path)
    try:
        waiting=[dict(x) for x in c.execute("SELECT id,reason,expires_at,notifier_status FROM malak_assist_tasks WHERE state='WAITING_FOR_MALAK'").fetchall()]
        resumable=[x["id"] for x in c.execute("SELECT id FROM malak_assist_tasks WHERE state='RESUMABLE'").fetchall()]
        interrupted=[x["id"] for x in c.execute("SELECT id FROM malak_assist_tasks WHERE state='RESUMED'").fetchall()]
    finally: c.close()
    return {"status":"OK","waiting":waiting,"resumable":resumable,"interrupted_needs_review":interrupted,"expired":exp["expired"]}


def _authorized_sender(channel: str, sender: str) -> str:
    """'' when the channel is NOT_CONFIGURED, 'yes'/'no' otherwise. Sender must equal the configured Malak identity."""
    want = os.getenv("KORA_MALAK_TELEGRAM_CHAT_ID","") if channel == "telegram" else os.getenv("KORA_MALAK_WHATSAPP_TO","") if channel == "whatsapp" else None
    if want is None: return "no"
    if not want: return ""
    return "yes" if secrets.compare_digest(str(want), str(sender or "")) else "no"


def handle_inbound(channel: str, sender: str, text: str, *, db_path=DEFAULT_DB_PATH):
    """A reply from a messaging channel. Must come from the configured Malak identity AND name the task AND carry its one-time code."""
    channel = (channel or "").lower(); auth = _authorized_sender(channel, sender)
    if auth == "":
        return {"status":"NOT_CONFIGURED","channel":channel}
    if auth != "yes":
        record_audit("malak_assist_rejected","system",{"reason":"unauthorized_sender","channel":channel},db_path)
        return {"status":"REJECTED","reason":"unauthorized_sender"}
    init(db_path); words = re.findall(r"[A-Za-z0-9_\-]+", str(text or ""))
    for t in list_waiting(db_path)["waiting"]:
        if t["id"] in words:
            code = next((w for w in words if w != t["id"] and len(w) == 8), "")
            return resume(t["id"], code, note="Malak replied via " + channel, db_path=db_path, authenticated_sender=True)
    return {"status":"REJECTED","reason":"no_matching_task_id"}


def list_waiting(db_path=DEFAULT_DB_PATH):
    init(db_path); c=get_connection(db_path)
    try: rows=c.execute("SELECT id,reason,state,created_at,expires_at,notifier_status FROM malak_assist_tasks WHERE state='WAITING_FOR_MALAK' ORDER BY created_at").fetchall()
    finally: c.close()
    return {"status":"OK","waiting":[dict(x) for x in rows]}
