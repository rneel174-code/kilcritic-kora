"""Hard runtime resource guards used by long-running jobs.

Limits are measured and enforced; they never pretend to create extra hardware.
"""
from __future__ import annotations
import os, shutil, time
from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class ResourceLimits:
    max_rss_mb: int = 1024
    min_free_disk_mb: int = 512
    max_wall_seconds: float = 3600.0

class ResourceLimitError(RuntimeError):
    pass

def rss_mb() -> Optional[float]:
    try:
        import resource
        raw = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        # Linux reports KiB; macOS reports bytes.
        return raw / 1024.0 if raw < 10_000_000 else raw / (1024.0 * 1024.0)
    except Exception:
        return None

def free_disk_mb(path: str = ".") -> float:
    return shutil.disk_usage(path).free / (1024.0 * 1024.0)

def enforce(limits: ResourceLimits = ResourceLimits(), disk_path: str = ".") -> dict:
    mem = rss_mb()
    disk = free_disk_mb(disk_path)
    if mem is not None and mem > limits.max_rss_mb:
        raise ResourceLimitError(f"rss_limit_exceeded:{mem:.1f}MB>{limits.max_rss_mb}MB")
    if disk < limits.min_free_disk_mb:
        raise ResourceLimitError(f"disk_floor_exceeded:{disk:.1f}MB<{limits.min_free_disk_mb}MB")
    return {"rss_mb": mem, "free_disk_mb": disk, "limits": limits.__dict__.copy()}

def bounded_sleep_until(deadline: float, seconds: float) -> bool:
    """Sleep without ever crossing a caller-owned deadline. Returns False at deadline."""
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        return False
    time.sleep(min(max(0.0, seconds), remaining))
    return time.monotonic() < deadline
