"""
KORA 8.8.5 - Database Backup & Integrity Engine
Performs safe online SQLite backups with:
- Disk headroom check (>100MB required)
- PRAGMA integrity_check verification on the snapshot
- Critical schema table presence validation
- Cryptographic SHA-256 digest
- Non-zero file size check
- Bounded retention enforcement (keeps latest N backups)
- Restore readability testing from actual snapshot
"""
import os
import shutil
import sqlite3
import hashlib
import time
import uuid
from typing import Dict, Any, List, Optional
from kora.core.db import get_connection, DEFAULT_DB_PATH

BACKUPS_DIR = os.path.abspath("data/backups")
os.makedirs(BACKUPS_DIR, exist_ok=True)
MIN_DISK_HEADROOM_BYTES = 50 * 1024 * 1024  # 50 MB required headroom
MAX_BACKUP_RETENTION = 5

class BackupVerificationError(Exception):
    pass

def check_disk_headroom(target_dir: str = BACKUPS_DIR) -> int:
    stat = shutil.disk_usage(target_dir)
    if stat.free < MIN_DISK_HEADROOM_BYTES:
        raise BackupVerificationError(
            f"Insufficient disk headroom: {stat.free} bytes free, required {MIN_DISK_HEADROOM_BYTES} bytes."
        )
    return stat.free

def create_verified_backup(source_db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    check_disk_headroom(BACKUPS_DIR)

    backup_id = f"backup-{int(time.time())}-{uuid.uuid4().hex[:6]}"
    backup_filename = f"{backup_id}.db"
    backup_path = os.path.join(BACKUPS_DIR, backup_filename)

    # 1. Perform online SQLite backup via sqlite3.backup API
    source_conn = get_connection(source_db_path)
    dest_conn = sqlite3.connect(backup_path)
    try:
        source_conn.backup(dest_conn)
    finally:
        dest_conn.close()
        source_conn.close()

    # 2. Check non-zero file size
    size_bytes = os.path.getsize(backup_path)
    if size_bytes == 0:
        if os.path.exists(backup_path):
            os.remove(backup_path)
        raise BackupVerificationError("Generated backup snapshot is empty (0 bytes).")

    # 3. Calculate SHA-256 digest of the snapshot
    hasher = hashlib.sha256()
    with open(backup_path, "rb") as f:
        while chunk := f.read(65536):
            hasher.update(chunk)
    sha256_hex = hasher.hexdigest()

    # 4. Verify PRAGMA integrity_check on the snapshot
    verify_conn = sqlite3.connect(backup_path)
    try:
        cur = verify_conn.execute("PRAGMA integrity_check;")
        res = cur.fetchone()[0]
        if res != "ok":
            raise BackupVerificationError(f"Snapshot integrity_check failed: {res}")

        # 5. Verify critical schema tables exist in the snapshot
        schema_cur = verify_conn.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = {row[0] for row in schema_cur.fetchall()}
        required_tables = {"jobs", "media_assets", "backups", "transcripts"}
        missing = required_tables - tables
        if missing:
            raise BackupVerificationError(f"Snapshot missing critical schema tables: {missing}")
    finally:
        verify_conn.close()

    # 6. Record in Authoritative Ledger
    now = time.time()
    conn = get_connection(source_db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        conn.execute("""
        INSERT INTO backups (id, filename, filepath, sha256, size_bytes, integrity_verified, created_at)
        VALUES (?, ?, ?, ?, ?, 1, ?);
        """, (backup_id, backup_filename, backup_path, sha256_hex, size_bytes, now))
        conn.execute("COMMIT;")
    finally:
        conn.close()

    # 7. Enforce Bounded Retention
    prune_old_backups(max_keep=MAX_BACKUP_RETENTION)

    return {
        "backup_id": backup_id,
        "filename": backup_filename,
        "path": backup_path,
        "sha256": sha256_hex,
        "size_bytes": size_bytes,
        "integrity_verified": True,
        "timestamp": now
    }

def prune_old_backups(max_keep: int = MAX_BACKUP_RETENTION) -> int:
    """Retains the newest N backups on disk and purges older entries."""
    files = [
        os.path.join(BACKUPS_DIR, f)
        for f in os.listdir(BACKUPS_DIR)
        if f.endswith(".db") and os.path.isfile(os.path.join(BACKUPS_DIR, f))
    ]
    files.sort(key=lambda x: os.path.getmtime(x), reverse=True)

    pruned = 0
    if len(files) > max_keep:
        for old_file in files[max_keep:]:
            try:
                os.remove(old_file)
                pruned += 1
            except Exception:
                pass
    return pruned

def verify_and_test_restore(snapshot_path: str) -> Dict[str, Any]:
    """Tests restore readability by executing sample queries against the snapshot."""
    if not os.path.exists(snapshot_path):
        raise BackupVerificationError(f"Snapshot not found: {snapshot_path}")

    conn = sqlite3.connect(snapshot_path)
    try:
        cur = conn.execute("PRAGMA integrity_check;")
        check = cur.fetchone()[0]
        if check != "ok":
            return {"readable": False, "error": f"Integrity check failed: {check}"}

        cur = conn.execute("SELECT COUNT(*) FROM jobs;")
        job_count = cur.fetchone()[0]

        cur = conn.execute("SELECT COUNT(*) FROM media_assets;")
        media_count = cur.fetchone()[0]

        return {
            "readable": True,
            "jobs_count": job_count,
            "media_count": media_count,
            "status": "RESTORE_VERIFIED_CLEAN"
        }
    finally:
        conn.close()
