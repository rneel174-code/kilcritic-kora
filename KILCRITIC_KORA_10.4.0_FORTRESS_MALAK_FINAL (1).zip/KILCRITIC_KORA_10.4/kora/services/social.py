"""
KORA PRO - Social publishing: mandatory approval, optional AUTO publish after approval, crash-safe state machine.

Lifecycle:  PENDING_APPROVAL -> (approve) -> APPROVED_AWAITING_CREDENTIALS | APPROVED -> PUBLISHING -> PUBLISHED | FAILED
* "Auto publish" = once a post is approved, the worker publishes it (no second click). Approval itself is still a human
  action unless KORA_SOCIAL_AUTO_APPROVE=true is set explicitly (off by default; every auto-approval is audit-logged).
* Duplicate protection: queue idempotency key per post + compare-and-swap status transitions + external_id check.
* Crash safety: if the process dies after the platform accepted the post but before we recorded it, the post is left in
  PUBLISHING; recovery marks it FAILED("verify on platform") instead of retrying - it will NOT double-post.
* No fake success: PUBLISHED requires a non-empty external id returned by the platform.
"""
import os
import re
import sqlite3
import time
import uuid
from typing import Any, Callable, Dict, Mapping, Optional

from kora.core import policy
from kora.core.db import DEFAULT_DB_PATH, get_connection, record_audit
from kora.core.http import https_request
from kora.core.queue import DurableQueue, PermanentJobError
from kora.services import legal_guard, shadow, trust
from kora.services.publishers import PUBLISHERS, PublishError, credential_requirements, missing_credentials

ALLOWED_PLATFORMS = {"YOUTUBE", "FACEBOOK", "INSTAGRAM", "TIKTOK", "X"}
AUDIENCES = {"KIDS", "GENERAL", "ADULT"}
MEDIA_ROOT = os.path.abspath(os.environ.get("KORA_MEDIA_DIR", "data/media"))


class SocialPublishError(Exception):
    pass


def _safe_media_path(path: Optional[str], root: str) -> Optional[str]:
    if not path:
        return None
    real = os.path.realpath(path)
    root_real = os.path.realpath(root)
    if not (real == root_real or real.startswith(root_real + os.sep)):
        raise SocialPublishError("media_path_outside_media_root")
    if not os.path.isfile(real):
        raise SocialPublishError("media_file_not_found")
    return real


def _get(conn, post_id):
    return conn.execute("SELECT * FROM social_posts WHERE id = ?;", (post_id,)).fetchone()


def get_post(post_id: str, db_path: str = DEFAULT_DB_PATH) -> Optional[Dict[str, Any]]:
    conn = get_connection(db_path)
    try:
        r = _get(conn, post_id)
        return dict(r) if r else None
    finally:
        conn.close()


def list_posts(db_path: str = DEFAULT_DB_PATH, status: Optional[str] = None, limit: int = 50):
    conn = get_connection(db_path)
    try:
        sql, args = "SELECT id,platform,status,audience,external_id,attempts,last_error,created_at,published_at,preflight FROM social_posts", []
        if status:
            sql += " WHERE status = ?"
            args.append(status)
        return [dict(r) for r in conn.execute(sql + " ORDER BY created_at DESC LIMIT ?;", (*args, max(1, min(200, limit)))).fetchall()]
    finally:
        conn.close()


# ----------------------------------------------------------------------------- per-user account registry + posting router
# Metadata only (owner, platform, handle, ON/OFF/NEEDS_RECONNECT). Tokens are NEVER stored here: platform credentials still
# come from the environment / secret store, so true per-user token vaulting is NOT_IMPLEMENTED (documented limitation).
ACCOUNT_STATES = ("ON", "OFF", "NEEDS_RECONNECT")


def account_set(owner: str, platform: str, status: str, handle: str = "", db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    platform = platform.upper()
    if platform not in ALLOWED_PLATFORMS or status not in ACCOUNT_STATES or not owner:
        raise SocialPublishError("owner, a supported platform and status ON|OFF|NEEDS_RECONNECT are required")
    conn = get_connection(db_path)
    try:
        conn.execute("INSERT INTO accounts(owner,platform,handle,status,updated_at) VALUES (?,?,?,?,?) "
                     "ON CONFLICT(owner,platform) DO UPDATE SET status=excluded.status, handle=excluded.handle, updated_at=excluded.updated_at;",
                     (owner, platform, handle[:80], status, time.time()))
    finally:
        conn.close()
    record_audit("account_set", owner, {"platform": platform, "status": status}, db_path)
    return {"owner": owner, "platform": platform, "status": status, "handle": handle[:80]}


def accounts_for(owner: str, db_path: str = DEFAULT_DB_PATH) -> list:
    conn = get_connection(db_path)
    try:
        return [dict(r) for r in conn.execute("SELECT platform, handle, status, updated_at FROM accounts WHERE owner=? ORDER BY platform;", (owner,)).fetchall()]
    finally:
        conn.close()


def posting_preflight(owner: str, platform: str, db_path: str = DEFAULT_DB_PATH, env: Optional[Mapping[str, str]] = None) -> Dict[str, Any]:
    """Is this user's account for this platform usable right now? OFF/unregistered/needs-reconnect => skip, and say exactly what to fix."""
    env = os.environ if env is None else env
    platform = platform.upper()
    if platform not in ALLOWED_PLATFORMS:
        return {"platform": platform, "ready": False, "reason": "unsupported_platform", "fix": "Pick one of " + ", ".join(sorted(ALLOWED_PLATFORMS))}
    req = credential_requirements(platform)
    if not req["implemented"]:
        return {"platform": platform, "ready": False, "reason": "adapter_not_implemented", "fix": f"{platform} publishing is not built yet"}
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT status, handle FROM accounts WHERE owner=? AND platform=?;", (owner, platform)).fetchone()
    finally:
        conn.close()
    if not row:
        return {"platform": platform, "ready": False, "reason": "account_not_connected", "fix": f"Connect your {platform} account (set it ON in Accounts)"}
    if row["status"] == "OFF":
        return {"platform": platform, "ready": False, "reason": "account_off", "fix": f"{platform} is OFF; turn it ON to post there"}
    if row["status"] == "NEEDS_RECONNECT":
        return {"platform": platform, "ready": False, "reason": "needs_reconnect", "fix": f"Reconnect {platform} (login expired or revoked)"}
    miss = missing_credentials(platform, env)
    if miss:
        return {"platform": platform, "ready": False, "reason": "credentials_missing", "fix": "Set: " + ", ".join(miss)}
    return {"platform": platform, "ready": True, "reason": "ok", "fix": "", "handle": row["handle"]}


def route_posting(owner: str, platforms, db_path: str = DEFAULT_DB_PATH, env: Optional[Mapping[str, str]] = None) -> Dict[str, Any]:
    """Posting router: ready platforms proceed; OFF/broken ones are skipped (never attempted) with an exact reconnect instruction."""
    res = [posting_preflight(owner, p, db_path, env) for p in platforms]
    return {"ready": [r["platform"] for r in res if r["ready"]],
            "skipped": [{"platform": r["platform"], "reason": r["reason"], "fix": r["fix"]} for r in res if not r["ready"]]}



def _validate_public_media_url(url: Optional[str]) -> Optional[str]:
    """Instagram/TikTok pull media from a public HTTPS URL. Reject anything that is not plainly that (no credentials in URL, no local/private literals)."""
    if not url:
        return None
    import ipaddress
    import urllib.parse
    u = str(url).strip()
    if len(u) > 2000:
        raise SocialPublishError("public_media_url too long")
    p = urllib.parse.urlparse(u)
    host = (p.hostname or "").lower()
    if p.scheme != "https" or not host or p.username or p.password:
        raise SocialPublishError("public_media_url must be a plain https URL without credentials")
    if host == "localhost" or host.endswith((".local", ".internal", ".localhost")):
        raise SocialPublishError("public_media_url must be a public host")
    try:
        ip = ipaddress.ip_address(host)
        if not ip.is_global:
            raise SocialPublishError("public_media_url must be a public host")
    except ValueError:
        # Not a canonical IP literal. Reject numeric-looking hosts (decimal 2130706433, hex 0x7f.1, short 127.1, octal) that
        # resolvers still map to private addresses, and require a real dotted name whose last label has a letter.
        labels = host.split(".")
        if re.fullmatch(r"[0-9a-fx.]+", host) and not re.search(r"[g-wyz]", labels[-1]) or "." not in host or not re.search(r"[a-z]", labels[-1]) or re.fullmatch(r"0x[0-9a-f]+", labels[-1]):
            raise SocialPublishError("public_media_url must be a public DNS host name")
    return u


def _scrub_secrets(text: str, env: Optional[Mapping[str, str]] = None) -> str:
    """Remove every configured credential value and secret-looking token from text before it is stored, audited or raised."""
    out = str(text)
    for k, v in (env or {}).items():
        v = str(v or "")
        if len(v) >= 6 and any(w in k.upper() for w in ("TOKEN", "SECRET", "KEY", "PASSWORD", "AUTH")):
            out = out.replace(v, "[REDACTED]")
    out = re.sub(r"(?i)bearer\s+[A-Za-z0-9._\-]{8,}", "Bearer [REDACTED]", out)
    out = re.sub(r"(?i)(access_token|token|api_key|client_secret)=[^&\s\"']+", r"\1=[REDACTED]", out)
    return out


def missing_credentials_for(platform: str, env: Optional[Mapping[str, str]] = None) -> list:
    return missing_credentials(platform, os.environ if env is None else env)


def recheck_credentials(post_id: str, db_path: str = DEFAULT_DB_PATH, env: Optional[Mapping[str, str]] = None) -> Dict[str, Any]:
    """APPROVED_AWAITING_CREDENTIALS -> APPROVED once the credentials really exist (re-checked from the environment, never assumed)."""
    env = os.environ if env is None else env
    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        post = _get(conn, post_id)
        if not post:
            conn.execute("ROLLBACK;")
            return {"post_id": post_id, "status": "NOT_FOUND"}
        if post["status"] != "APPROVED_AWAITING_CREDENTIALS":
            conn.execute("COMMIT;")
            return {"post_id": post_id, "status": post["status"], "changed": False}
        missing = missing_credentials(post["platform"], env)
        if missing:
            conn.execute("COMMIT;")
            return {"post_id": post_id, "status": "APPROVED_AWAITING_CREDENTIALS", "changed": False, "missing": missing}
        conn.execute("UPDATE social_posts SET status='APPROVED' WHERE id=? AND status='APPROVED_AWAITING_CREDENTIALS';", (post_id,))
        conn.execute("COMMIT;")
    except Exception:
        try:
            conn.execute("ROLLBACK;")
        except Exception:
            pass
        raise
    finally:
        conn.close()
    record_audit("social_credentials_recheck", "system", {"post_id": post_id, "result": "approved_ready"}, db_path)
    return {"post_id": post_id, "status": "APPROVED", "changed": True}


def missing_media_requirement(post: Dict[str, Any]) -> Optional[str]:
    """Platform media prerequisites that can be known without calling the platform."""
    plat = post["platform"]
    if plat == "INSTAGRAM" and not (post["media_url"] if "media_url" in post.keys() else None):
        return "instagram_requires_public_https_media_url"
    if plat == "TIKTOK" and not post["media_path"]:
        return "tiktok_requires_video_media_path"
    return None


def create_social_post(platform: str, content: str, audience: str, idempotency_key: Optional[str] = None,
                       db_path: str = DEFAULT_DB_PATH, media_path: Optional[str] = None, title: Optional[str] = None,
                       auto_approve: Optional[bool] = None, media_root: str = MEDIA_ROOT, env: Optional[Mapping[str, str]] = None,
                       queue: Optional[DurableQueue] = None, auto_publish: Optional[bool] = None,
                       asset_meta: Optional[Dict[str, Any]] = None, public_media_url: Optional[str] = None,
                       media_type: Optional[str] = None, ai_generated: bool = False, owner: str = "") -> Dict[str, Any]:
    platform_norm = platform.upper()
    if platform_norm not in ALLOWED_PLATFORMS:
        raise SocialPublishError(f"Platform '{platform}' not supported. Allowed: {ALLOWED_PLATFORMS}")
    if not content or not content.strip():
        raise SocialPublishError("Post content cannot be empty.")
    if len(content) > 10000:
        raise SocialPublishError("Post content too long.")
    audience = (audience or "GENERAL").upper()
    if audience not in AUDIENCES:
        raise SocialPublishError("Audience must be KIDS, GENERAL or ADULT")
    media_path = _safe_media_path(media_path, media_root)
    public_media_url = _validate_public_media_url(public_media_url)
    media_type = (str(media_type).upper() if media_type else None)
    if media_type and media_type not in ("REEL", "VIDEO", "IMAGE", "PHOTO", "FEED"):
        raise SocialPublishError("media_type must be REEL, VIDEO, IMAGE, PHOTO or FEED")
    if owner:  # per-user account gate; an explicit OFF / NEEDS_RECONNECT is always honoured
        apf = posting_preflight(owner, platform_norm, db_path, env)
        blocking = ("account_off", "needs_reconnect") + (("account_not_connected",) if os.environ.get("KORA_REQUIRE_ACCOUNT_REGISTRY") == "1" else ())
        if not apf["ready"] and apf["reason"] in blocking:
            raise SocialPublishError(f"account_unavailable:{apf['reason']}: {apf['fix']}")
    try:
        policy.require_enabled("PUBLISH_SOCIAL", db_path)
    except policy.PolicyDenied as exc:
        raise SocialPublishError(f"policy_denied:{exc.reason}")
    dups = shadow.duplicate_of(content, db_path) if os.path.exists(db_path) else []
    pf = legal_guard.preflight({**(asset_meta or {}), **({"duplicate_risk": True} if dups else {}), "platform": platform_norm, "content": content, "audience": audience, "media": bool(media_path or public_media_url)})
    if pf["status"] == "BLOCKED":
        record_audit("social_preflight_blocked", "system", {"platform": platform_norm, "issues": pf["issues"]}, db_path)
        raise SocialPublishError("legal_preflight_blocked: " + ", ".join(pf["issues"]))
    content = pf["asset"]["content"]  # AUTO_FIXED content (trimmed hashtags / AI disclosure)
    # (YouTube media presence is validated at publish time so drafts can be created first.)
    post_id = f"post-{uuid.uuid4().hex[:8]}"
    now = time.time()
    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        conn.execute(
            """INSERT INTO social_posts (id, platform, content, audience, status, external_id, idempotency_key, created_at, media_path, title, preflight, media_url, media_type, ai_generated, owner)
               VALUES (?, ?, ?, ?, 'PENDING_APPROVAL', NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?);""",
            (post_id, platform_norm, content, audience, idempotency_key, now, media_path, title, pf["status"], public_media_url, media_type, int(bool(ai_generated)), owner or None))
        conn.execute("COMMIT;")
    except sqlite3.IntegrityError:
        conn.execute("ROLLBACK;")
        existing = conn.execute("SELECT id, status FROM social_posts WHERE idempotency_key = ?;", (idempotency_key,)).fetchone()
        if existing:
            return {"post_id": existing["id"], "platform": platform_norm, "status": existing["status"], "duplicate": True,
                    "message": "Duplicate idempotency key: existing post returned, nothing new created."}
        raise
    except Exception:
        conn.execute("ROLLBACK;")
        raise
    finally:
        conn.close()

    try:
        trust.record_provenance("post", post_id, source=str((asset_meta or {}).get("source", "operator-supplied")), tool="kora.social", rights=str((asset_meta or {}).get("rights", "UNDECLARED")),
                                transformations=";".join(pf["fixes"]), verification=f"preflight:{pf['status']}", db_path=db_path)
    except Exception:  # provenance must never block drafting; absence is visible in Shadow Publish
        pass
    out = {"post_id": post_id, "platform": platform_norm, "status": "PENDING_APPROVAL", "preflight": pf["status"],
           "preflight_issues": pf["issues"], "preflight_fixes": pf["fixes"],
           "message": "Post drafted and locked in PENDING_APPROVAL. Explicit operator authorization required before dispatch."}
    if auto_approve is None:
        from kora.config.settings import get_settings
        auto_approve = get_settings().social_auto_approve
    if auto_approve and pf["status"] in ("PASS", "AUTO_FIXED"):  # HUMAN_REVIEW is never auto-approved
        record_audit("social_auto_approve", "system", {"post_id": post_id, "platform": platform_norm}, db_path)
        out.update(approve_and_publish_post(post_id, db_path, actor="auto", env=env, queue=queue, auto_publish=auto_publish))
    return out


def reject_post(post_id: str, db_path: str = DEFAULT_DB_PATH, actor: str = "operator") -> Dict[str, Any]:
    conn = get_connection(db_path)
    try:
        n = conn.execute("UPDATE social_posts SET status='REJECTED' WHERE id=? AND status IN ('PENDING_APPROVAL','APPROVED_AWAITING_CREDENTIALS');", (post_id,)).rowcount
    finally:
        conn.close()
    if n != 1:
        raise SocialPublishError("post_not_rejectable")
    record_audit("social_reject", actor, {"post_id": post_id}, db_path)
    return {"post_id": post_id, "status": "REJECTED"}


def approve_and_publish_post(post_id: str, db_path: str = DEFAULT_DB_PATH, actor: str = "operator",
                             env: Optional[Mapping[str, str]] = None, queue: Optional[DurableQueue] = None,
                             auto_publish: Optional[bool] = None) -> Dict[str, Any]:
    """Approve a post and (auto publish) hand it to the worker. Never reports fake external success."""
    env = os.environ if env is None else env
    try:
        policy.require_enabled("PUBLISH_SOCIAL", db_path)
    except policy.PolicyDenied as exc:
        raise SocialPublishError(f"policy_denied:{exc.reason}")
    if auto_publish is None:
        from kora.config.settings import get_settings
        auto_publish = get_settings().social_auto_publish
    now = time.time()
    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        post = _get(conn, post_id)
        if not post:
            conn.execute("ROLLBACK;")
            raise SocialPublishError(f"Post {post_id} not found.")
        status = post["status"]
        if status == "PUBLISHED":
            conn.execute("COMMIT;")
            return {"post_id": post_id, "status": "PUBLISHED", "external_id": post["external_id"], "message": "Already published; duplicate publish blocked."}
        if status in ("PUBLISHING", "REJECTED", "FAILED"):
            conn.execute("ROLLBACK;")
            raise SocialPublishError(f"Post is {status}; cannot approve.")
        platform = post["platform"]
        automated = str(actor).split("@")[0] in ("auto", "autopilot", "system")
        if automated and (post["preflight"] or "") not in ("PASS", "AUTO_FIXED"):
            conn.execute("ROLLBACK;")
            record_audit("social_auto_approval_refused", actor, {"post_id": post_id, "preflight": post["preflight"]}, db_path)
            raise SocialPublishError(f"auto_approval_refused: preflight={post['preflight'] or 'UNKNOWN'} needs a human decision")
        need = missing_media_requirement(post)
        if need:
            conn.execute("ROLLBACK;")
            raise SocialPublishError(f"media_required: {need}")
        req = credential_requirements(platform)
        if not req["implemented"]:
            conn.execute("UPDATE social_posts SET status='FAILED', last_error='platform_adapter_not_implemented', approved_by=?, approved_at=? WHERE id=?;", (actor, now, post_id))
            conn.execute("COMMIT;")
            record_audit("social_approve_unsupported", actor, {"post_id": post_id, "platform": platform}, db_path)
            return {"post_id": post_id, "status": "FAILED", "message": f"Approved, but the {platform} publisher is NOT_IMPLEMENTED in this build. Nothing was sent."}
        missing = missing_credentials(platform, env)
        if missing:
            conn.execute("UPDATE social_posts SET status='APPROVED_AWAITING_CREDENTIALS', approved_by=?, approved_at=? WHERE id=?;", (actor, now, post_id))
            conn.execute("COMMIT;")
            record_audit("social_approve", actor, {"post_id": post_id, "result": "awaiting_credentials"}, db_path)
            return {"post_id": post_id, "status": "APPROVED_AWAITING_CREDENTIALS",
                    "message": f"Approved by operator, but {', '.join(missing)} is not configured. Truthfully halted before any dispatch."}
        conn.execute("UPDATE social_posts SET status='APPROVED', approved_by=?, approved_at=? WHERE id=?;", (actor, now, post_id))
        conn.execute("COMMIT;")
    except SocialPublishError:
        raise
    except Exception:
        try:
            conn.execute("ROLLBACK;")
        except Exception:
            pass
        raise
    finally:
        conn.close()

    record_audit("social_approve", actor, {"post_id": post_id, "result": "approved"}, db_path)
    if not auto_publish:
        return {"post_id": post_id, "status": "APPROVED", "message": "Approved. Auto-publish is off; dispatch it explicitly."}
    return dispatch_post(post_id, db_path, queue)


def dispatch_post(post_id: str, db_path: str = DEFAULT_DB_PATH, queue: Optional[DurableQueue] = None) -> Dict[str, Any]:
    post = get_post(post_id, db_path)
    if not post or post["status"] != "APPROVED":
        raise SocialPublishError("only APPROVED posts can be dispatched")
    from kora.services import fortress  # independent watchdog can halt every external effect
    try:
        fortress.assert_running(db_path)
    except fortress.HaltedError as exc:
        raise SocialPublishError(str(exc))
    q = queue or DurableQueue(db_path)
    job = q.enqueue_once("social_publish", {"post_id": post_id}, f"social-publish:{post_id}", priority=50, max_retries=4)
    conn = get_connection(db_path)
    try:
        conn.execute("UPDATE social_posts SET job_id=? WHERE id=?;", (job["id"], post_id))
    finally:
        conn.close()
    return {"post_id": post_id, "status": "APPROVED_QUEUED", "job_id": job["id"], "duplicate_job": job.get("duplicate", False),
            "message": "Approved and queued for automatic publishing by the worker."}


def run_publish(post_id: str, db_path: str = DEFAULT_DB_PATH, env: Optional[Mapping[str, str]] = None,
                transport: Callable = https_request) -> Dict[str, Any]:
    """Worker-side publish. Raises PermanentJobError / RuntimeError so the queue applies retry or DLQ."""
    env = os.environ if env is None else env
    conn = get_connection(db_path)
    try:
        conn.execute("BEGIN IMMEDIATE;")
        post = _get(conn, post_id)
        if not post:
            conn.execute("ROLLBACK;")
            raise PermanentJobError("post_not_found")
        if post["status"] == "PUBLISHED" and post["external_id"]:
            conn.execute("COMMIT;")
            return {"ok": True, "already_published": True, "external_id": post["external_id"]}
        if post["status"] == "PUBLISHING":
            conn.execute("UPDATE social_posts SET status='FAILED', last_error='publishing_interrupted_verify_on_platform_before_retry' WHERE id=?;", (post_id,))
            conn.execute("COMMIT;")
            raise PermanentJobError("publishing_interrupted: verify on the platform before any retry (avoids double-posting)")
        if post["status"] != "APPROVED":
            conn.execute("ROLLBACK;")
            raise PermanentJobError(f"post_not_approved (status={post['status']})")
        conn.execute("UPDATE social_posts SET status='PUBLISHING', attempts=attempts+1 WHERE id=? AND status='APPROVED';", (post_id,))
        conn.execute("COMMIT;")
    finally:
        conn.close()

    post = dict(post)
    platform = post["platform"]
    missing = missing_credentials(platform, env)
    try:
        if missing:
            raise PublishError("credentials_missing", retryable=False, detail=",".join(missing))
        external_id = PUBLISHERS[platform](post, env, transport)
        if not external_id:
            raise PublishError("empty_external_id", retryable=False)
    except PublishError as exc:
        msg = _scrub_secrets(str(exc), env)  # platform error bodies often echo the token: never store/raise it
        conn = get_connection(db_path)
        try:
            if exc.retryable:
                conn.execute("UPDATE social_posts SET status='APPROVED', last_error=? WHERE id=? AND status='PUBLISHING';", (msg[:500], post_id))
            else:
                conn.execute("UPDATE social_posts SET status='FAILED', last_error=? WHERE id=? AND status='PUBLISHING';", (msg[:500], post_id))
        finally:
            conn.close()
        if exc.retryable:
            raise RuntimeError(msg)
        raise PermanentJobError(msg)

    conn = get_connection(db_path)
    try:
        conn.execute("UPDATE social_posts SET status='PUBLISHED', external_id=?, published_at=?, last_error=NULL WHERE id=? AND status='PUBLISHING';",
                     (external_id, time.time(), post_id))
    finally:
        conn.close()
    record_audit("social_published", "worker", {"post_id": post_id, "platform": platform, "external_id": external_id}, db_path)
    return {"ok": True, "post_id": post_id, "platform": platform, "external_id": external_id}


def mark_dead_lettered(post_id: str, error: str, db_path: str = DEFAULT_DB_PATH) -> None:
    conn = get_connection(db_path)
    try:
        conn.execute("UPDATE social_posts SET status='FAILED', last_error=? WHERE id=? AND status IN ('APPROVED','PUBLISHING');", (f"dead_lettered: {error}"[:500], post_id))
    finally:
        conn.close()


def recover_interrupted(db_path: str = DEFAULT_DB_PATH, older_than_seconds: float = 900.0) -> int:
    """Posts stuck in PUBLISHING with no running job are flagged FAILED for manual verification (never auto-retried)."""
    conn = get_connection(db_path)
    try:
        cutoff = time.time() - older_than_seconds
        return conn.execute(
            """UPDATE social_posts SET status='FAILED', last_error='publishing_interrupted_verify_on_platform_before_retry'
               WHERE status='PUBLISHING' AND NOT EXISTS (SELECT 1 FROM jobs j WHERE j.id = social_posts.job_id AND j.status='RUNNING')
               AND COALESCE(approved_at, created_at) < ?;""", (cutoff,)).rowcount
    finally:
        conn.close()
