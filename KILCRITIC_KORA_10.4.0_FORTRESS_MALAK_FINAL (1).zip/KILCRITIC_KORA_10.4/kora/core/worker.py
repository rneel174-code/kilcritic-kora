"""
KORA PRO - Worker pool & registered safe handlers.

* Handlers are a CLOSED registry (name -> python callable). A job payload is data, never code.
* Every job runs under a timeout; the lease is renewed while the handler is alive (heartbeat).
* Handler outcome -> queue outcome:
    returns dict (ok != False)  -> COMPLETED
    raises PermanentJobError    -> DEAD_LETTER immediately
    raises anything else        -> retry with backoff, DEAD_LETTER once attempts are exhausted
    exceeds timeout             -> failure (kind='timeout'); a late result is DISCARDED (never written)
* Python cannot kill a thread, so an abandoned (timed-out) handler may keep running; the number of such
  threads is capped and the worker stops claiming new work while the cap is reached (backpressure).
"""
import logging
import os
import threading
import time
import uuid
from typing import Any, Callable, Dict, List, Optional

from kora.core import anti_loop
from kora.core.queue import DEFAULT_LEASE_SECONDS, DurableQueue, PermanentJobError

logger = logging.getLogger("kora.worker")

HANDLERS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {}
DEAD_LETTER_HOOKS: Dict[str, Callable[[Dict[str, Any], str], None]] = {}

MAX_ABANDONED_THREADS = 8
_abandoned: List[threading.Thread] = []
_abandoned_lock = threading.Lock()


_ctx = threading.local()


def current_db() -> Optional[str]:
    """DB path of the queue that dispatched the running job (so handlers act on the right database)."""
    return getattr(_ctx, "db", None)


def register_handler(name: str):
    def decorator(fn: Callable[[Dict[str, Any]], Dict[str, Any]]):
        HANDLERS[name] = fn
        return fn
    return decorator


def register_dead_letter_hook(handler_name: str):
    """Hook(job, error) is called after a job of this handler is dead-lettered by the worker."""
    def decorator(fn):
        DEAD_LETTER_HOOKS[handler_name] = fn
        return fn
    return decorator


def abandoned_alive() -> int:
    with _abandoned_lock:
        _abandoned[:] = [t for t in _abandoned if t.is_alive()]
        return len(_abandoned)


# Default built-in safe handlers -------------------------------------------------
@register_handler("noop")
def handle_noop(payload: Dict[str, Any]) -> Dict[str, Any]:
    return {"status": "ok", "echo": payload}


@register_handler("math_compute")
def handle_math(payload: Dict[str, Any]) -> Dict[str, Any]:
    a = payload.get("a", 0)
    b = payload.get("b", 0)
    op = payload.get("op", "add")
    if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
        raise PermanentJobError("math_compute operands must be numbers")
    if op == "add":
        return {"result": a + b}
    if op == "multiply":
        return {"result": a * b}
    raise PermanentJobError(f"Unknown operation: {op}")


class SafeWorker:
    def __init__(self, queue: DurableQueue, worker_id: Optional[str] = None,
                 job_timeout: float = 300.0, lease_seconds: float = DEFAULT_LEASE_SECONDS,
                 skill_gate: Optional[Callable[[str], bool]] = None, loop_threshold: int = 0):
        self.skill_gate = skill_gate          # optional trust gate: handler name -> runnable?
        self.loop_threshold = loop_threshold  # >0: freeze a handler after N distinct jobs fail with the same error
        self.queue = queue
        self.worker_id = worker_id or f"worker-{os.getpid()}-{uuid.uuid4().hex[:6]}"
        self.job_timeout = job_timeout
        self.lease_seconds = lease_seconds
        self._stop_requested = False

    def request_stop(self) -> None:
        self._stop_requested = True

    # -- run handler in a helper thread so we can enforce timeout / heartbeat / cancel
    def _run_handler(self, job: Dict[str, Any], handler) -> Dict[str, Any]:
        box: Dict[str, Any] = {}

        def target():
            _ctx.db = self.queue.db_path
            try:
                box["result"] = handler(job["payload"])
            except BaseException as exc:  # noqa: BLE001 - reported, never swallowed
                box["exc"] = exc

        th = threading.Thread(target=target, name=f"kora-job-{job['id'][-8:]}", daemon=True)
        th.start()
        deadline = time.monotonic() + self.job_timeout
        beat = max(0.05, min(self.lease_seconds / 3.0, 5.0))
        while th.is_alive():
            th.join(timeout=min(beat, max(0.0, deadline - time.monotonic())))
            if not th.is_alive():
                break
            if time.monotonic() >= deadline:
                with _abandoned_lock:
                    _abandoned.append(th)
                return {"timeout": True}
            if self.queue.is_cancelled(job["id"]):
                with _abandoned_lock:
                    _abandoned.append(th)
                return {"cancelled": True}
            self.queue.renew_lease(job["id"], self.worker_id, self.lease_seconds)
        return box

    def process_one(self) -> Optional[Dict[str, Any]]:
        if self._stop_requested:
            return None
        if abandoned_alive() >= MAX_ABANDONED_THREADS:
            logger.warning("backpressure: too many abandoned handler threads; not claiming work")
            return None

        job = self.queue.claim_next_job(self.worker_id, self.lease_seconds)
        if not job:
            return None

        job_id, handler_name = job["id"], job["handler_name"]
        handler = HANDLERS.get(handler_name)
        if not handler:
            status = self.queue.fail_job(job_id, self.worker_id, f"Handler '{handler_name}' not registered in worker pool.", permanent=True)
            self._after_fail(job, status, "UNREGISTERED_HANDLER")
            return {"job_id": job_id, "status": "FAILED" if status == "DEAD_LETTER" else status, "error": "UNREGISTERED_HANDLER"}

        if self.skill_gate is not None and not self.skill_gate(handler_name):
            err = "skill_not_trusted"
            status = self.queue.fail_job(job_id, self.worker_id, err, permanent=True, kind="trust")
            self._after_fail(job, status, err)
            return {"job_id": job_id, "status": "FAILED" if status == "DEAD_LETTER" else status, "error": err}
        if self.loop_threshold and anti_loop.is_frozen(handler_name, self.queue.db_path):
            err = "operation_frozen_after_repeated_errors"
            status = self.queue.fail_job(job_id, self.worker_id, err, permanent=True, kind="frozen")
            self._after_fail(job, status, err)
            return {"job_id": job_id, "status": "FAILED" if status == "DEAD_LETTER" else status, "error": err}

        out = self._run_handler(job, handler)

        if out.get("cancelled"):
            return {"job_id": job_id, "status": "CANCELLED"}
        if out.get("timeout"):
            err = f"job_timeout_after_{self.job_timeout}s"
            status = self.queue.fail_job(job_id, self.worker_id, err, kind="timeout")
            self._after_fail(job, status, err)
            return {"job_id": job_id, "status": status, "error": err}
        if "exc" in out:
            exc = out["exc"]
            permanent = isinstance(exc, PermanentJobError)
            err = str(exc) or exc.__class__.__name__
            status = self.queue.fail_job(job_id, self.worker_id, err, permanent=permanent)
            self._after_fail(job, status, err)
            return {"job_id": job_id, "status": status, "error": err}

        result = out.get("result")
        if not isinstance(result, dict):  # result validation: no silent success on garbage output
            err = "invalid_result_type"
            status = self.queue.fail_job(job_id, self.worker_id, err, permanent=True)
            self._after_fail(job, status, err)
            return {"job_id": job_id, "status": status, "error": err}
        if result.get("ok") is False:
            err = str(result.get("error", "handler_reported_failure"))
            status = self.queue.fail_job(job_id, self.worker_id, err)
            self._after_fail(job, status, err)
            return {"job_id": job_id, "status": status, "error": err}

        if not self.queue.complete_job(job_id, self.worker_id, result, version=job["version"]):
            # lease was lost / job cancelled while running: result is NOT recorded
            return {"job_id": job_id, "status": "LEASE_LOST"}
        if self.loop_threshold:
            anti_loop.record_success(handler_name, self.queue.db_path)
        return {"job_id": job_id, "status": "COMPLETED", "result": result}

    def _after_fail(self, job: Dict[str, Any], status: str, err: str) -> None:
        logger.warning("job failed id=%s handler=%s -> %s: %s", job["id"], job["handler_name"], status, err)
        if self.loop_threshold and err not in ("skill_not_trusted", "operation_frozen_after_repeated_errors"):
            anti_loop.record_failure(job["handler_name"], err, self.queue.db_path, self.loop_threshold, subject=job["id"])
        if status == "DEAD_LETTER":
            hook = DEAD_LETTER_HOOKS.get(job["handler_name"])
            if hook:
                try:
                    hook({**job, "db_path": self.queue.db_path}, err)
                except Exception:  # hook errors must never break the worker loop
                    logger.exception("dead-letter hook failed for %s", job["id"])


class WorkerPool:
    """Bounded pool of worker threads polling the durable queue. Clean stop; safe to restart."""

    def __init__(self, db_path: str, size: int = 2, poll_seconds: float = 1.0, job_timeout: float = 300.0,
                 queue_factory: Optional[Callable[[], DurableQueue]] = None,
                 skill_gate: Optional[Callable[[str], bool]] = None, loop_threshold: int = 0):
        self.skill_gate, self.loop_threshold = skill_gate, loop_threshold
        self.db_path = db_path
        self.size = max(1, min(8, int(size)))
        self.poll = poll_seconds
        self.job_timeout = job_timeout
        self._factory = queue_factory or (lambda: DurableQueue(db_path))
        self._stop = threading.Event()
        self._threads: List[threading.Thread] = []
        self._workers: List[SafeWorker] = []
        self.processed = 0
        self._lock = threading.Lock()

    def _loop(self, w: SafeWorker) -> None:
        while not self._stop.is_set():
            try:
                res = w.process_one()
            except Exception:
                logger.exception("worker loop error")
                res = None
            if res is None:
                self._stop.wait(self.poll)
            else:
                with self._lock:
                    self.processed += 1

    def start(self) -> None:
        if any(t.is_alive() for t in self._threads):
            return
        self._stop.clear()
        self._threads, self._workers = [], []
        for i in range(self.size):
            w = SafeWorker(self._factory(), f"pool-{os.getpid()}-{i}-{uuid.uuid4().hex[:4]}", job_timeout=self.job_timeout)
            t = threading.Thread(target=self._loop, args=(w,), name=f"kora-worker-{i}", daemon=True)
            self._workers.append(w)
            self._threads.append(t)
            t.start()

    def stop(self, timeout: float = 10.0) -> bool:
        self._stop.set()
        for w in self._workers:
            w.request_stop()
        end = time.monotonic() + timeout
        for t in self._threads:
            t.join(timeout=max(0.0, end - time.monotonic()))
        return not any(t.is_alive() for t in self._threads)

    def status(self) -> Dict[str, Any]:
        alive = sum(1 for t in self._threads if t.is_alive())
        return {"running": alive > 0, "threads_alive": alive, "pool_size": self.size,
                "processed": self.processed, "abandoned_threads": abandoned_alive(),
                "job_timeout_seconds": self.job_timeout}
