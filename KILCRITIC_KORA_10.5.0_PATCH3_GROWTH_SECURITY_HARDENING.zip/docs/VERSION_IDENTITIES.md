# Version identities (separate, not interchangeable)

| Identity | Value | Where it lives |
| --- | --- | --- |
| KILCRITIC product version | `10.5.0` (`VERSION = "10.5.0-KILCRITIC-SUPREME-FORTRESS-MALAK-GROWTH"`) | `kora/__init__.py`, `/api/health` |
| KORA foundation baseline | `8.8.5-KORA-GODFATHER-CTO-HARDENED` | the governance foundation the product builds on |

- These are two different identities. KORA 8.8.5 and KILCRITIC 10.5.0 are not the same version, and one is not a rename or downgrade of the other.
- There is no KORA 8.8.6 and none is to be created.
- The `VERSION` constant was not changed by the growth-loop patch or the server.ts hardening (owner decision 2026-10-09).
