# 90-day plan (HYPOTHESES - labelled SCENARIO until market-tested)
Days 1-14 pilot 10 shops. Days 15-45 fix what the evidence shows; repeat campaigns. Days 46-90 only if >=3 shops show owner-attested or ledger-reconciled lift: package the service. No revenue number is promised.
