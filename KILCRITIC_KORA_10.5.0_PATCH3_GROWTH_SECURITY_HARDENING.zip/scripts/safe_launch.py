"""Isolated launcher for KORA's Python entry points (used by server.ts).

Run as:  python3 -I scripts/safe_launch.py <module> [args...]

Why: `python3 -m kora.cli` with PYTHONPATH='.' puts the project folder FIRST on sys.path, so a file planted in that folder
(json.py, os.py, ...) shadows the standard library and runs inside KORA. Here -I (isolated mode) ignores PYTHONPATH/PYTHON* and the
current directory, and the project root is APPENDED, so the standard library and site-packages always win. Only two modules are launchable.
"""
import importlib.util
import os
import runpy
import sys

ALLOWED = frozenset({"kora.cli", "kora.tests.run_all"})


def main(argv):
    if len(argv) < 2 or argv[1] not in ALLOWED:
        sys.stderr.write("safe_launch: module not allowed (allowed: %s)\n" % ", ".join(sorted(ALLOWED)))
        return 2
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.append(root)                                    # appended, never prepended
    spec = importlib.util.find_spec("kora")
    origin = os.path.realpath(spec.origin) if spec and spec.origin else ""
    if not origin.startswith(os.path.realpath(root) + os.sep):
        sys.stderr.write("safe_launch: 'kora' did not resolve inside the project root; refusing to run\n")
        return 3
    module = argv[1]
    sys.argv = [module] + argv[2:]
    runpy.run_module(module, run_name="__main__", alter_sys=True)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
