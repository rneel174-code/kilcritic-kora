"""Local-business growth loop: campaign -> attribution link -> measured events -> ROI -> Marketing DNA, plus a 10-shop pilot
EVIDENCE framework, competitor gap radar and festival content planning.

WHY_EXISTING_COMPONENT_IS_INSUFFICIENT: dhanda.py is a flat cost/revenue ledger. It cannot say which campaign/asset produced a
sale, cannot hold a before/after pilot, and has no ROI state. This module ADDS that on top of the dhanda ledger (it never keeps a
second money ledger: level-4 evidence must point at a VERIFIED/PAYOUT_RECEIVED dhanda row).

Truth rules (enforced in code, not by caller claims):
  * Evidence level is COMPUTED, never taken from the caller: 1 self-reported (no reference), 2 observed (a reference string is
    given but NOTHING reconciles it: caller text such as "pos:x" is not trusted), 3 owner-attested (pilot observations only: the
    owner reviewed the reference and attested it, audited), 4 ledger-reconciled (event amount == a VERIFIED/PAYOUT_RECEIVED dhanda
    revenue row, single-use, same currency). dhanda "VERIFIED" itself means evidence+source text were supplied: it is a record, not a bank statement.
  * ROI states: ROI_TARGET (a goal only) / ROI_ESTIMATE (level<=1) / ROI_MEASURED (level 2-3, UNRECONCILED) / ROI_VERIFIED (level 4 only) / UNKNOWN.
  * The ROI headline never mixes classes. Nothing here charges, pays or publishes anything.
  * No hardcoded efficacy claims (no "yellow = 3x"): DNA winners need real samples and verified-grade revenue.
"""
import datetime
import json
import math
import re
import sqlite3
import time
import urllib.parse
import uuid
from typing import Any, Dict, List, Optional

from kora.core.db import DEFAULT_DB_PATH, get_connection, record_audit

EVENT_KINDS = ("IMPRESSION", "CLICK", "SCAN", "CALL", "LEAD", "SALE", "PAYMENT")
MIN_DNA_SAMPLES = 3
PILOT_FEE_THRESHOLD = 5000.0
PILOT_MIN_WINDOW_DAYS = 7
# Redacts real secret shapes only (keys, bearer tokens, key=value credentials, "otp 123456"); invoice numbers and words like "hotpot" survive.
_SECRET_RX = re.compile(r"(\bsk-[A-Za-z0-9]{16,}|\bBearer\s+\S+|\b(?:otp|pin|passcode|password|passwd|token|secret|api[_-]?key)\b\s*[:=]\s*\S+|\b(?:otp|code)\s+\d{4,8}\b)", re.I)
_KEY_RX = re.compile(r"[A-Za-z0-9_.:\-]{1,80}")
MONEY_KINDS = ("SALE", "PAYMENT")


def _clean(v: Any, n: int = 200) -> str:
    return _SECRET_RX.sub("[REDACTED]", str(v or "").strip())[:n]


def _num(v: Any, name: str, lo: Optional[float] = None, hi: Optional[float] = None) -> float:
    """Finite real number only (JSON may carry NaN/Infinity); bool is not a number here."""
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
        raise ValueError(f"{name} must be a finite number")
    if (lo is not None and v < lo) or (hi is not None and v > hi):
        raise ValueError(f"{name} out of range")
    return float(v)


def _audit(event: str, actor: str, details: Dict[str, Any], db_path: str) -> None:
    record_audit(event, actor or "system", details, db_path)      # ids/levels/amounts only; never free text secrets


def _alter(c, sql: str) -> None:
    try:
        c.execute(sql)
    except sqlite3.OperationalError:
        pass                                                      # column already exists


def init(db_path: str = DEFAULT_DB_PATH) -> None:
    c = get_connection(db_path)
    try:
        c.execute("""CREATE TABLE IF NOT EXISTS growth_campaigns(id TEXT PRIMARY KEY, merchant TEXT NOT NULL, offer TEXT NOT NULL, platform TEXT NOT NULL DEFAULT '',
            language TEXT NOT NULL DEFAULT '', hook TEXT NOT NULL DEFAULT '', cta TEXT NOT NULL DEFAULT '', post_hour INTEGER, asset_id TEXT NOT NULL DEFAULT '',
            roi_target REAL, cost REAL NOT NULL DEFAULT 0, currency TEXT NOT NULL DEFAULT 'INR', created_at REAL NOT NULL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS growth_events(id INTEGER PRIMARY KEY AUTOINCREMENT, campaign_id TEXT NOT NULL, kind TEXT NOT NULL,
            count REAL NOT NULL DEFAULT 1, amount REAL NOT NULL DEFAULT 0, source TEXT NOT NULL DEFAULT '', evidence_ref TEXT NOT NULL DEFAULT '',
            ledger_id INTEGER, evidence_level INTEGER NOT NULL, created_at REAL NOT NULL)""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_growth_events_c ON growth_events(campaign_id)")
        _alter(c, "ALTER TABLE growth_events ADD COLUMN idem_key TEXT")
        c.execute("CREATE TABLE IF NOT EXISTS growth_ledger_links(ledger_id INTEGER PRIMARY KEY, event_id INTEGER NOT NULL, campaign_id TEXT NOT NULL, created_at REAL NOT NULL)")
        try:
            c.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_growth_events_idem ON growth_events(campaign_id, idem_key) WHERE idem_key IS NOT NULL")
        except sqlite3.IntegrityError:
            pass
        c.execute("""CREATE TABLE IF NOT EXISTS pilot_shops(id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL DEFAULT '', window_days INTEGER NOT NULL DEFAULT 7,
            created_at REAL NOT NULL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS pilot_observations(id INTEGER PRIMARY KEY AUTOINCREMENT, shop_id TEXT NOT NULL, phase TEXT NOT NULL CHECK(phase IN ('BEFORE','AFTER')),
            obs_date TEXT NOT NULL, sales REAL NOT NULL, photo_ref TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT '', evidence_ref TEXT NOT NULL DEFAULT '',
            evidence_level INTEGER NOT NULL, created_at REAL NOT NULL)""")
        _alter(c, "ALTER TABLE pilot_observations ADD COLUMN attested_by TEXT")
        _alter(c, "ALTER TABLE pilot_observations ADD COLUMN attested_at REAL")
        try:
            c.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_pilot_obs ON pilot_observations(shop_id, phase, obs_date)")
        except sqlite3.IntegrityError:
            pass                                                  # legacy duplicates: application-level checks still reject new ones
        c.execute("""CREATE TABLE IF NOT EXISTS growth_competitor_gaps(id INTEGER PRIMARY KEY AUTOINCREMENT, capability TEXT NOT NULL, source TEXT NOT NULL DEFAULT '',
            public_evidence TEXT NOT NULL DEFAULT '', kilcritic_status TEXT NOT NULL DEFAULT 'UNKNOWN', gap TEXT NOT NULL DEFAULT '', cost REAL NOT NULL DEFAULT 0.5, risk REAL NOT NULL DEFAULT 0.5,
            legal_constraint TEXT NOT NULL DEFAULT '', impact REAL NOT NULL DEFAULT 0.5, feasibility REAL NOT NULL DEFAULT 0.5, test_plan TEXT NOT NULL DEFAULT '',
            result TEXT NOT NULL DEFAULT 'NOT_TESTED', next_action TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL)""")
    finally:
        c.close()


def _level(source: str, ref: str, ledger_ok: bool = False) -> int:
    """4 only via a reconciled ledger link. A caller-supplied reference (whatever its prefix) is level 2 at best: it is unreconciled."""
    if ledger_ok:
        return 4
    return 2 if (ref or "").strip() else 1


def _unit(v: Any, name: str) -> float:
    return _num(v, name, 0.0, 1.0)


# ------------------------------------------------------------------ campaigns / attribution
def create_campaign(merchant: str, offer: str, *, platform: str = "", language: str = "", hook: str = "", cta: str = "", post_hour: Optional[int] = None,
                    asset_id: str = "", roi_target: Optional[float] = None, cost: float = 0.0, currency: str = "INR", db_path: str = DEFAULT_DB_PATH,
                    actor: str = "system") -> Dict[str, Any]:
    if not _clean(merchant) or not _clean(offer):
        raise ValueError("merchant and offer required")
    cost = _num(cost, "cost", 0, 1e9)
    if post_hour is not None and not (isinstance(post_hour, int) and not isinstance(post_hour, bool) and 0 <= post_hour <= 23):
        raise ValueError("post_hour 0..23")
    if roi_target is not None:
        roi_target = _num(roi_target, "roi_target", -100, 1e6)
    init(db_path); cid = "cmp-" + uuid.uuid4().hex[:10]
    c = get_connection(db_path)
    try:
        c.execute("INSERT INTO growth_campaigns(id,merchant,offer,platform,language,hook,cta,post_hour,asset_id,roi_target,cost,currency,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (cid, _clean(merchant, 100), _clean(offer, 200), _clean(platform, 30).upper(), _clean(language, 20).lower(), _clean(hook, 200), _clean(cta, 100),
                   post_hour, _clean(asset_id, 60), roi_target, float(cost), _clean(currency, 6).upper() or "INR", time.time()))
    finally:
        c.close()
    _audit("growth_campaign_created", actor, {"campaign_id": cid}, db_path)
    return {"campaign_id": cid, "roi_state": "ROI_TARGET" if roi_target is not None else "UNKNOWN", "note": "a target is a goal, not a result"}


def attribution_link(base_url: str, campaign_id: str, asset_id: str = "") -> Dict[str, Any]:
    u = urllib.parse.urlparse(base_url or "")
    if u.scheme != "https" or not u.hostname or "." not in u.hostname:
        raise ValueError("https URL with a DNS host required")
    q = dict(urllib.parse.parse_qsl(u.query)); q.update({"utm_campaign": campaign_id, "utm_source": "kilcritic", **({"utm_content": asset_id} if asset_id else {})})
    return {"url": urllib.parse.urlunparse(u._replace(query=urllib.parse.urlencode(q))), "campaign_id": campaign_id, "state": "LINK_GENERATED",
            "note": "a link/QR only attributes clicks/scans that actually arrive; it proves nothing by itself"}


def record_event(campaign_id: str, kind: str, *, count: float = 1, amount: float = 0.0, source: str = "", evidence_ref: str = "", ledger_id: Optional[int] = None,
                 idempotency_key: str = "", db_path: str = DEFAULT_DB_PATH, actor: str = "system") -> Dict[str, Any]:
    kind = (kind or "").upper()
    if kind not in EVENT_KINDS:
        raise ValueError("unsupported event kind")
    count = _num(count, "count", 0, 1e9)
    if count <= 0:
        raise ValueError("count must be > 0")
    amount = _num(amount, "amount", 0, 1e12)
    if kind in MONEY_KINDS and amount <= 0:
        raise ValueError("SALE/PAYMENT needs amount > 0")
    key = (idempotency_key or "").strip()
    if key and not _KEY_RX.fullmatch(key):
        raise ValueError("idempotency_key must be 1-80 chars [A-Za-z0-9_.:-]")
    if kind in MONEY_KINDS and not key and ledger_id is None:
        raise ValueError("idempotency_key required for SALE/PAYMENT (a retry must not double count)")
    if ledger_id is not None and (isinstance(ledger_id, bool) or not isinstance(ledger_id, int)):
        raise ValueError("ledger_id must be an integer")
    init(db_path); c = get_connection(db_path)
    duplicate, eid, lvl = False, None, 1
    try:
        c.execute("BEGIN IMMEDIATE")
        try:
            cmp_ = c.execute("SELECT currency FROM growth_campaigns WHERE id=?", (campaign_id,)).fetchone()
            if not cmp_:
                raise ValueError("unknown campaign")
            if key:
                old = c.execute("SELECT id,evidence_level,kind,amount FROM growth_events WHERE campaign_id=? AND idem_key=?", (campaign_id, key)).fetchone()
                if old:
                    if old["kind"] != kind or abs(old["amount"] - amount) > 0.005:
                        raise ValueError("idempotency_key already used with different content")
                    duplicate, eid, lvl = True, old["id"], old["evidence_level"]
            if not duplicate:
                ledger_ok = False
                if ledger_id is not None:
                    row = c.execute("SELECT kind,status,amount,currency FROM ledger WHERE id=?", (ledger_id,)).fetchone()
                    if not (row and row["kind"] == "revenue" and row["status"] in ("VERIFIED", "PAYOUT_RECEIVED") and kind in MONEY_KINDS):
                        raise ValueError("ledger_id must reference a VERIFIED/PAYOUT_RECEIVED revenue row (dhanda)")
                    if (row["currency"] or "").upper() != (cmp_["currency"] or "").upper():
                        raise ValueError("ledger currency does not match the campaign currency")
                    if abs(float(row["amount"]) - amount) > 0.005:
                        raise ValueError("event amount must equal the ledger row amount (reconciliation)")
                    if c.execute("SELECT 1 FROM growth_ledger_links WHERE ledger_id=?", (ledger_id,)).fetchone():
                        raise ValueError("ledger row already attributed (single-use)")
                    ledger_ok = True
                lvl = _level(source, evidence_ref, ledger_ok)
                cur = c.execute("INSERT INTO growth_events(campaign_id,kind,count,amount,source,evidence_ref,ledger_id,evidence_level,created_at,idem_key) VALUES(?,?,?,?,?,?,?,?,?,?)",
                                (campaign_id, kind, count, amount, _clean(source, 60), _clean(evidence_ref, 200), ledger_id if ledger_ok else None, lvl, time.time(), key or None))
                eid = cur.lastrowid
                if ledger_ok:
                    c.execute("INSERT INTO growth_ledger_links(ledger_id,event_id,campaign_id,created_at) VALUES(?,?,?,?)", (ledger_id, eid, campaign_id, time.time()))
            c.execute("COMMIT")
        except Exception:
            c.execute("ROLLBACK")
            raise
    finally:
        c.close()
    if not duplicate:
        _audit("growth_event_recorded", actor, {"campaign_id": campaign_id, "event_id": eid, "kind": kind, "amount": amount, "count": count, "evidence_level": lvl, "ledger_id": ledger_id}, db_path)
    return {"event_id": eid, "evidence_level": lvl, "duplicate": duplicate, "reconciled": lvl == 4,
            "note": "level is computed from the evidence supplied; only a ledger-reconciled event counts as verified"}


def roi(campaign_id: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    init(db_path); c = get_connection(db_path)
    try:
        cmp_ = c.execute("SELECT * FROM growth_campaigns WHERE id=?", (campaign_id,)).fetchone()
        if not cmp_:
            raise ValueError("unknown campaign")
        ev = [dict(r) for r in c.execute("SELECT kind,count,amount,evidence_level FROM growth_events WHERE campaign_id=?", (campaign_id,)).fetchall()]
    finally:
        c.close()
    funnel = {k: sum(e["count"] for e in ev if e["kind"] == k) for k in EVENT_KINDS if k not in ("SALE", "PAYMENT")}
    sales = [e for e in ev if e["kind"] in ("SALE", "PAYMENT")]
    by = lambda lo, hi: round(sum(e["amount"] for e in sales if lo <= e["evidence_level"] <= hi), 2)
    est, measured, verified = by(0, 1), by(2, 3), by(4, 4)
    cost = float(cmp_["cost"])
    pct = lambda rev: round((rev - cost) / cost * 100, 1) if cost > 0 else None
    if verified > 0:
        state, rev = "ROI_VERIFIED", verified
    elif measured > 0:
        state, rev = "ROI_MEASURED", measured
    elif est > 0:
        state, rev = "ROI_ESTIMATE", est
    elif cmp_["roi_target"] is not None:
        return {"campaign_id": campaign_id, "state": "ROI_TARGET", "roi_target_pct": cmp_["roi_target"], "roi_pct": None, "funnel": funnel, "cost": cost,
                "revenue": {"estimated": 0, "measured": 0, "verified": 0}, "note": "no sale evidence yet: this is a goal, not a result"}
    else:
        return {"campaign_id": campaign_id, "state": "UNKNOWN", "roi_pct": None, "funnel": funnel, "cost": cost, "revenue": {"estimated": 0, "measured": 0, "verified": 0}}
    return {"campaign_id": campaign_id, "state": state, "roi_pct": pct(rev), "headline_revenue": rev, "cost": cost, "funnel": funnel,
            "revenue": {"estimated": est, "measured": measured, "verified": verified},
            "trust": {"estimated": "SELF_REPORTED", "measured": "UNRECONCILED_REFERENCE", "verified": "LEDGER_RECONCILED_SINGLE_USE"},
            "note": "headline uses only the strongest evidence class; classes are never summed together; MEASURED means a reference exists, not that it was reconciled"}


# ------------------------------------------------------------------ Marketing DNA (outcome-derived, sample-size aware)
def marketing_dna(group_by: str = "hook", db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    if group_by not in ("hook", "cta", "platform", "language", "post_hour", "offer"):
        raise ValueError("unsupported group_by")
    init(db_path); c = get_connection(db_path)
    try:
        camps = [dict(r) for r in c.execute("SELECT * FROM growth_campaigns").fetchall()]
        ev = [dict(r) for r in c.execute("SELECT campaign_id,kind,count,amount,evidence_level FROM growth_events").fetchall()]
    finally:
        c.close()
    groups: Dict[str, Dict[str, Any]] = {}
    for cp in camps:
        key = str(cp.get(group_by) if cp.get(group_by) not in (None, "") else "UNSPECIFIED")
        g = groups.setdefault(key, {"value": key, "campaigns": 0, "leads": 0.0, "verified_grade_revenue": 0.0, "cost": 0.0, "campaigns_with_evidence": 0})
        g["campaigns"] += 1; g["cost"] += cp["cost"]
        mine = [e for e in ev if e["campaign_id"] == cp["id"]]
        g["leads"] += sum(e["count"] for e in mine if e["kind"] == "LEAD")
        rev = sum(e["amount"] for e in mine if e["kind"] in MONEY_KINDS and e["evidence_level"] >= 4)
        g["verified_grade_revenue"] += rev
        g["campaigns_with_evidence"] += 1 if rev > 0 else 0
    out = []
    for g in groups.values():
        n = g["campaigns_with_evidence"]
        g["confidence"] = round(n / (n + 5), 2)          # grows only with real evidenced samples
        g["roi_pct"] = round((g["verified_grade_revenue"] - g["cost"]) / g["cost"] * 100, 1) if g["cost"] > 0 and n else None
        g["status"] = "SOURCE_BASED" if n >= MIN_DNA_SAMPLES else "INSUFFICIENT_DATA"
        out.append(g)
    eligible = [g for g in out if g["status"] == "SOURCE_BASED" and g["roi_pct"] is not None]
    winner = max(eligible, key=lambda g: g["roi_pct"])["value"] if eligible else None
    return {"group_by": group_by, "groups": sorted(out, key=lambda g: -g["verified_grade_revenue"]), "winner": winner,
            "note": f"a winner needs >= {MIN_DNA_SAMPLES} campaigns with ledger-reconciled (level 4) revenue; otherwise INSUFFICIENT_DATA (no guessing)"}


# ------------------------------------------------------------------ 10-shop pilot evidence framework
def pilot_add_shop(name: str, category: str = "", window_days: int = PILOT_MIN_WINDOW_DAYS, db_path: str = DEFAULT_DB_PATH, actor: str = "system") -> Dict[str, Any]:
    if not _clean(name):
        raise ValueError("name required")
    if isinstance(window_days, bool) or not isinstance(window_days, int) or not 1 <= window_days <= 60:
        raise ValueError("window_days 1..60")
    init(db_path); sid = "shop-" + uuid.uuid4().hex[:8]; c = get_connection(db_path)
    try:
        c.execute("INSERT INTO pilot_shops(id,name,category,window_days,created_at) VALUES(?,?,?,?,?)", (sid, _clean(name, 100), _clean(category, 40), window_days, time.time()))
    finally:
        c.close()
    _audit("pilot_shop_enrolled", actor, {"shop_id": sid, "window_days": window_days}, db_path)
    return {"shop_id": sid, "state": "ENROLLED", "note": "enrolment is a test plan entry, not a result"}


def _parse_date(v: str) -> datetime.date:
    if not isinstance(v, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
        raise ValueError("date YYYY-MM-DD required")
    try:
        d = datetime.date.fromisoformat(v)
    except ValueError:
        raise ValueError("not a real calendar date")
    if d > datetime.date.today() + datetime.timedelta(days=1):
        raise ValueError("observation date is in the future")
    if d < datetime.date(2020, 1, 1):
        raise ValueError("observation date implausibly old")
    return d


def pilot_record(shop_id: str, phase: str, obs_date: str, sales: float, *, photo_ref: str = "", source: str = "", evidence_ref: str = "", db_path: str = DEFAULT_DB_PATH,
                 actor: str = "system") -> Dict[str, Any]:
    phase = (phase or "").upper()
    if phase not in ("BEFORE", "AFTER"):
        raise ValueError("phase BEFORE|AFTER required")
    day = _parse_date(obs_date)
    sales = _num(sales, "sales", 0, 1e10)
    init(db_path); c = get_connection(db_path)
    dup, oid, lvl = False, None, 1
    try:
        c.execute("BEGIN IMMEDIATE")
        try:
            shop = c.execute("SELECT window_days FROM pilot_shops WHERE id=?", (shop_id,)).fetchone()
            if not shop:
                raise ValueError("unknown shop")
            rows = [(r["phase"], datetime.date.fromisoformat(r["obs_date"])) for r in c.execute("SELECT phase,obs_date FROM pilot_observations WHERE shop_id=?", (shop_id,)).fetchall()]
            same = [d for ph, d in rows if ph == phase]
            other = [d for ph, d in rows if ph != phase]
            if same and (max(same + [day]) - min(same + [day])).days + 1 > shop["window_days"]:
                raise ValueError(f"{phase} observations must fit inside the {shop['window_days']}-day window")
            if phase == "BEFORE" and other and day >= min(other):
                raise ValueError("BEFORE dates must be earlier than every AFTER date")
            if phase == "AFTER" and other and day <= max(other):
                raise ValueError("AFTER dates must be later than every BEFORE date")
            ref = (evidence_ref or photo_ref or "").strip()
            lvl = _level(source, ref)
            old = c.execute("SELECT id,sales,evidence_ref,photo_ref FROM pilot_observations WHERE shop_id=? AND phase=? AND obs_date=?", (shop_id, phase, obs_date)).fetchone()
            if old:
                if abs(old["sales"] - sales) > 0.005:
                    raise ValueError("an observation for this shop/phase/date already exists with different sales")
                dup, oid = True, old["id"]
            else:
                cur = c.execute("INSERT INTO pilot_observations(shop_id,phase,obs_date,sales,photo_ref,source,evidence_ref,evidence_level,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                                (shop_id, phase, obs_date, sales, _clean(photo_ref, 200), _clean(source, 60), _clean(evidence_ref, 200), lvl, time.time()))
                oid = cur.lastrowid
            c.execute("COMMIT")
        except Exception:
            c.execute("ROLLBACK")
            raise
    finally:
        c.close()
    if not dup:
        _audit("pilot_observation_recorded", actor, {"shop_id": shop_id, "observation_id": oid, "phase": phase, "date": obs_date, "sales": sales, "evidence_level": lvl}, db_path)
    return {"observation_id": oid, "evidence_level": lvl, "duplicate": dup}


def pilot_attest(observation_id: int, *, actor: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Owner reviews the referenced evidence (receipt/POS export/photo) and attests it: level 2 -> 3, audited. Not an automated verification."""
    if isinstance(observation_id, bool) or not isinstance(observation_id, int):
        raise ValueError("observation_id must be an integer")
    if not actor or actor == "system":
        raise ValueError("an identified owner actor is required to attest")
    init(db_path); c = get_connection(db_path)
    try:
        row = c.execute("SELECT id,shop_id,evidence_level,evidence_ref,photo_ref FROM pilot_observations WHERE id=?", (observation_id,)).fetchone()
        if not row:
            raise ValueError("unknown observation")
        if not (row["evidence_ref"] or row["photo_ref"]).strip():
            raise ValueError("nothing to attest: the observation has no evidence reference")
        c.execute("UPDATE pilot_observations SET evidence_level=3, attested_by=?, attested_at=? WHERE id=?", (actor, time.time(), observation_id))
    finally:
        c.close()
    _audit("pilot_observation_attested", actor, {"observation_id": observation_id, "shop_id": row["shop_id"]}, db_path)
    return {"observation_id": observation_id, "evidence_level": 3, "state": "OWNER_ATTESTED", "note": "attestation is a human review, not tool verification"}


def pilot_evaluate(shop_id: str, db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """Decides whether the Rs 500 condition is MET on evidence. It NEVER charges: Malak collects, and the payment is recorded in dhanda."""
    init(db_path); c = get_connection(db_path)
    try:
        shop = c.execute("SELECT * FROM pilot_shops WHERE id=?", (shop_id,)).fetchone()
        if not shop:
            raise ValueError("unknown shop")
        obs = [dict(r) for r in c.execute("SELECT * FROM pilot_observations WHERE shop_id=?", (shop_id,)).fetchall()]
    finally:
        c.close()
    before = [o for o in obs if o["phase"] == "BEFORE"]; after = [o for o in obs if o["phase"] == "AFTER"]
    days = lambda xs: len({o["obs_date"] for o in xs})
    res = {"shop_id": shop_id, "before_days": days(before), "after_days": days(after), "threshold": PILOT_FEE_THRESHOLD, "window_days": shop["window_days"]}
    if not before or not after:
        return {**res, "state": "INSUFFICIENT_EVIDENCE", "reason": "need both BEFORE and AFTER records"}
    def contiguous(xs):
        ds = sorted(datetime.date.fromisoformat(o["obs_date"]) for o in xs)
        return len(set(ds)) == shop["window_days"] and (ds[-1] - ds[0]).days + 1 == shop["window_days"]
    if not (contiguous(before) and contiguous(after)):
        return {**res, "state": "INSUFFICIENT_EVIDENCE", "reason": f"need exactly {shop['window_days']} consecutive days before and after"}
    b, a = sum(o["sales"] for o in before), sum(o["sales"] for o in after)
    lvl = min(min(o["evidence_level"] for o in before), min(o["evidence_level"] for o in after))
    inc = round(a - b, 2)
    res.update({"before_sales": b, "after_sales": a, "incremental_sales": inc, "evidence_level": lvl})
    if inc < PILOT_FEE_THRESHOLD:
        return {**res, "state": "CONDITION_NOT_MET", "reason": "incremental sales below threshold: no fee, poster returned"}
    if lvl < 3:
        return {**res, "state": "UNVERIFIED", "reason": "increase reported but not every observation is owner-attested against a reference: no fee claim"}
    return {**res, "state": "CONDITION_MET_PENDING_MALAK", "evidence": "OWNER_ATTESTED", "reason": "owner-attested evidence; a human collects the fee and records the payment in dhanda (never automatic)"}


def pilot_summary(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    init(db_path); c = get_connection(db_path)
    try:
        ids = [r["id"] for r in c.execute("SELECT id FROM pilot_shops").fetchall()]
    finally:
        c.close()
    evals = [pilot_evaluate(i, db_path) for i in ids]
    count = lambda s: sum(1 for e in evals if e["state"] == s)
    return {"shops_enrolled": len(ids), "target_shops": 10, "condition_met": count("CONDITION_MET_PENDING_MALAK"), "not_met": count("CONDITION_NOT_MET"),
            "unverified": count("UNVERIFIED"), "insufficient_evidence": count("INSUFFICIENT_EVIDENCE"),
            "status": "TEST_PLAN" if len(ids) < 10 else "PILOT_IN_PROGRESS_OR_COMPLETE",
            "note": "this reports counts only; it is a measurement framework, not a success claim"}


# ------------------------------------------------------------------ competitor gap radar (benchmarks, never code/data copying)
def competitor_add(capability: str, *, source: str = "", public_evidence: str = "", kilcritic_status: str = "UNKNOWN", gap: str = "", cost: float = 0.5, risk: float = 0.5,
                   legal_constraint: str = "", impact: float = 0.5, feasibility: float = 0.5, test_plan: str = "", next_action: str = "", db_path: str = DEFAULT_DB_PATH, actor: str = "system") -> Dict[str, Any]:
    if not _clean(capability):
        raise ValueError("capability required")
    vals = [_unit(v, n) for v, n in ((cost, "cost"), (risk, "risk"), (impact, "impact"), (feasibility, "feasibility"))]
    init(db_path); c = get_connection(db_path)
    try:
        cur = c.execute("INSERT INTO growth_competitor_gaps(capability,source,public_evidence,kilcritic_status,gap,cost,risk,legal_constraint,impact,feasibility,test_plan,next_action,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (_clean(capability, 120), _clean(source, 200), _clean(public_evidence, 400), _clean(kilcritic_status, 30).upper(), _clean(gap, 300), vals[0], vals[1],
                         _clean(legal_constraint, 200), vals[2], vals[3], _clean(test_plan, 300), _clean(next_action, 200), time.time()))
    finally:
        c.close()
    _audit("growth_competitor_added", actor, {"id": cur.lastrowid}, db_path)
    return {"id": cur.lastrowid, "evidence": "PUBLIC_EVIDENCE" if _clean(public_evidence) else "UNVERIFIED"}


def competitor_rank(db_path: str = DEFAULT_DB_PATH) -> List[Dict[str, Any]]:
    init(db_path); c = get_connection(db_path)
    try:
        rows = [dict(r) for r in c.execute("SELECT * FROM growth_competitor_gaps").fetchall()]
    finally:
        c.close()
    for r in rows:
        has = bool(r["public_evidence"].strip() and r["source"].strip())
        r["evidence"] = "PUBLIC_EVIDENCE" if has else "UNVERIFIED"
        r["priority"] = round((r["impact"] * r["feasibility"] * (1.0 if has else 0.3)) - 0.5 * (r["risk"] * r["cost"]), 3)
    return sorted(rows, key=lambda r: -r["priority"])


# ------------------------------------------------------------------ festival content planning (original ideas; no efficacy claims)
_SLOTS = ("teaser (3 days before)", "offer announcement", "story/reel with the offer", "last-day reminder", "thank-you + customer-photo request")


def festival_plan(festival: str, date_iso: str, category: str, language: str = "pa", count: int = 5) -> Dict[str, Any]:
    if not _clean(festival) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date_iso or ""):
        raise ValueError("festival and date YYYY-MM-DD required")
    count = max(1, min(int(_num(count, "count", 0, 1000)), 10))
    items = [{"slot": _SLOTS[i % len(_SLOTS)], "festival": _clean(festival, 60), "date": date_iso, "category": _clean(category, 40), "language": _clean(language, 8),
              "brief": f"{_clean(festival, 60)} {_SLOTS[i % len(_SLOTS)]} for a {_clean(category, 40)} shop", "state": "TEMPLATE_IDEA",
              "needs": "human review for cultural accuracy and rights; original assets only"} for i in range(count)]
    return {"plan": items, "note": "templates, not generated media and not performance claims; measure each through a campaign before calling anything a winner"}
