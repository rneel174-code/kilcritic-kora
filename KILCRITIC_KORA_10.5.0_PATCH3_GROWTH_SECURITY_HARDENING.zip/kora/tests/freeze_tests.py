"""10.5 freeze-phase tests (T152+): external verification, handler trust coverage, resource governor, Malak webhooks/escalation."""
import hashlib, hmac, io, json, os, tempfile, time
from kora.core.db import init_db, get_connection
from kora.services import social, malak_assist as M


def _db():
    p = os.path.join(tempfile.mkdtemp(prefix="kora-fz-"), "f.db"); init_db(p); return p


class _Env:
    def __init__(self, **kw): self.kw, self.old = kw, {}
    def __enter__(self):
        for k, v in self.kw.items():
            self.old[k] = os.environ.get(k)
            if v is None: os.environ.pop(k, None)
            else: os.environ[k] = v
    def __exit__(self, *a):
        for k, v in self.old.items():
            if v is None: os.environ.pop(k, None)
            else: os.environ[k] = v


def _published(db, platform="X", ext="12345"):
    from kora.core.queue import DurableQueue
    env = {"X_OAUTH2_USER_TOKEN": "tok-SECRET-abc123456789"}
    r = social.create_social_post(platform, "hello " + ext, "GENERAL", db_path=db, auto_approve=False, queue=DurableQueue(db, retry_base=0), env=env, auto_publish=False, asset_meta={"rights": "OWNED", "source": "original"})
    c = get_connection(db)
    try: c.execute("UPDATE social_posts SET status='PUBLISHED', external_id=?, approved_by='owner' WHERE id=?", (ext, r["post_id"]))
    finally: c.close()
    return r["post_id"]


def social_verification_truth():
    db = _db(); env = {"X_OAUTH2_USER_TOKEN": "tok-SECRET-abc123456789"}
    pid = _published(db)
    ok = lambda m, u, h, b, t: (200, {}, json.dumps({"data": {"id": "12345"}}))
    assert social.run_verify(pid, db, env, ok)["state"] == "VERIFIED"
    p = social.get_post(pid, db); assert p["verification_state"] == "VERIFIED" and p["verified_at"]
    assert social.run_verify(pid, db, env, lambda *a: 1 / 0).get("already") is True  # idempotent, no second network call
    pid2 = _published(db, ext="999")
    assert social.run_verify(pid2, db, env, lambda *a: (404, {}, "{}"))["state"] == "NOT_FOUND"
    assert social.get_post(pid2, db)["verified_at"] is None
    pid3 = _published(db, ext="777")
    assert social.run_verify(pid3, db, {}, ok)["state"] == "UNVERIFIED"          # no credentials => never VERIFIED
    pid4 = _published(db, ext="555")
    def boom(*a): raise OSError("tok-SECRET-abc123456789 net down")
    try: social.run_verify(pid4, db, env, boom); raise AssertionError("network error must be retried, not a result")
    except RuntimeError as e: assert "tok-SECRET" not in str(e)
    assert social.get_post(pid4, db)["verification_state"] != "VERIFIED"
    c = get_connection(db)
    try:
        blob = json.dumps([tuple(r) for r in c.execute("SELECT verification_detail,last_error FROM social_posts").fetchall()])
    finally: c.close()
    assert "tok-SECRET" not in blob
    try: social.run_verify("missing", db, env, ok); raise AssertionError
    except Exception as e: assert "nothing_to_verify" in str(e) or "PermanentJob" in type(e).__name__


def every_handler_is_trust_runnable():
    from kora.core.worker import HANDLERS
    import kora.services.handlers  # noqa: F401 registers
    from kora.services import trust
    db = _db(); trust.sync_skills(HANDLERS, db)
    for name in ("scheduled_autopilot", "fortress_watchdog", "social_verify", "social_publish"):
        assert name in HANDLERS and name in trust.SKILL_META, name
    unknown = sorted(n for n in HANDLERS if n not in trust.SKILL_META and not n.startswith(("t_", "fz_")))  # t_*/fz_* = other tests' probes
    assert not unknown, "handlers invisible to trust gate (would be refused live): %s" % unknown


def worker_yields_under_pressure():
    from kora.core.queue import DurableQueue
    from kora.core.worker import WorkerPool, register_handler
    seen = []
    register_handler("fz_probe")(lambda p: (seen.append(1), {"ok": True})[1])
    db = _db(); q = DurableQueue(db, retry_base=0); q.enqueue("fz_probe", {})
    pool = WorkerPool(db, size=1, poll_seconds=0.05)
    flag = {"p": True}; pool.pressure_check = lambda: flag["p"]
    pool.start()
    try:
        time.sleep(0.6)
        assert not seen and pool.status()["yielded_under_pressure"] >= 1
        flag["p"] = False
        end = time.time() + 6
        while not seen and time.time() < end: time.sleep(0.1)
        assert seen, "work resumes when pressure clears"
    finally:
        pool.stop()


def resource_governor_and_bounded_http():
    from kora.services import runtime_limits as R
    from kora.bridge import server as S
    rss = R.current_rss_mb()
    assert rss is None or rss > 1
    lim = R.env_limits({"KORA_MAX_RSS_MB": "bad", "KORA_MIN_FREE_DISK_MB": "7"})
    assert lim.max_rss_mb == 1536 and lim.min_free_disk_mb == 7
    tight = R.ResourceLimits(max_rss_mb=1, min_free_disk_mb=1)
    if rss is not None:
        assert R.pressure(tight)["under_pressure"] and "rss_high" in R.pressure(tight)["reasons"]
        try: R.enforce(tight); raise AssertionError
        except R.ResourceLimitError: pass
    assert R.pressure(R.ResourceLimits(max_rss_mb=10**6, min_free_disk_mb=1))["under_pressure"] is False
    # bounded request threads: with no free slot the connection is refused with an honest 503
    import threading
    class Sock:
        data = b""; closed = False
        def sendall(self, b): self.data += b
    srv = S._Threaded.__new__(S._Threaded)
    old = S._Threaded._slots
    S._Threaded._slots = threading.BoundedSemaphore(1); S._Threaded._slots.acquire()
    shut = []
    srv.shutdown_request = lambda r: shut.append(r)
    try:
        s = Sock(); before = S._Threaded.rejected
        srv.process_request(s, ("127.0.0.1", 1))
        assert s.data.startswith(b"HTTP/1.1 503") and S._Threaded.rejected == before + 1 and shut
    finally:
        S._Threaded._slots = old


def _app(db):
    from dataclasses import replace
    from kora.bridge.api import KoraApp
    from kora.config.settings import load_settings
    app = KoraApp(replace(load_settings({}, dotenv_path="/nonexistent"), auth_token="tok-abcdef123456", rate_write_per_min=10**6), db_path=db)
    def call(method, path, body=None, headers=None, query="", raw=None):
        raw = raw if raw is not None else (json.dumps(body).encode() if body is not None else b"")
        env = {"REQUEST_METHOD": method, "PATH_INFO": path, "QUERY_STRING": query, "REMOTE_ADDR": "203.0.113.9", "HTTP_HOST": "127.0.0.1:8080",
               "CONTENT_LENGTH": str(len(raw)) if raw else "", "CONTENT_TYPE": "application/json" if raw else "", "wsgi.input": io.BytesIO(raw)}
        for k, v in (headers or {}).items(): env["HTTP_" + k.upper().replace("-", "_")] = v
        out = {}; b = b"".join(app(env, lambda s, h, e=None: out.update(s=int(s.split()[0]))))
        return out["s"], (json.loads(b) if b[:1] == b"{" else b)
    return app, call


def malak_webhooks_authenticated():
    db = _db(); app, call = _app(db)
    envs = {"KORA_MALAK_TELEGRAM_WEBHOOK_SECRET": None, "KORA_MALAK_TELEGRAM_CHAT_ID": None, "KORA_WHATSAPP_APP_SECRET": None,
            "KORA_WHATSAPP_VERIFY_TOKEN": None, "KORA_MALAK_WHATSAPP_TO": None, "KORA_MALAK_TELEGRAM_BOT_TOKEN": None}
    with _Env(**envs):
        tg = {"message": {"chat": {"id": 4242}, "text": "x"}}
        assert call("POST", "/api/malak-assist/webhook/telegram", tg)[0] == 503, "NOT_CONFIGURED must be truthful"
        assert call("POST", "/api/malak-assist/webhook/whatsapp", {"entry": []})[0] == 503
        assert call("GET", "/api/malak-assist/webhook/whatsapp", query="hub.mode=subscribe&hub.verify_token=a&hub.challenge=1")[0] == 503
    with _Env(**{**envs, "KORA_MALAK_TELEGRAM_WEBHOOK_SECRET": "whsec-1234567890", "KORA_MALAK_TELEGRAM_CHAT_ID": "4242"}):
        t = M.pause_for_malak("OTP", {"step": 1}, db_path=db)
        tid, code = t["task_id"], t["resume_token"]
        H = {"X-Telegram-Bot-Api-Secret-Token": "whsec-1234567890"}
        msg = lambda chat, text: {"message": {"chat": {"id": chat}, "text": text}}
        assert call("POST", "/api/malak-assist/webhook/telegram", msg(4242, f"{tid} {code}"))[0] == 401, "no secret header"
        assert call("POST", "/api/malak-assist/webhook/telegram", msg(4242, f"{tid} {code}"), headers={"X-Telegram-Bot-Api-Secret-Token": "wrong"})[0] == 401
        s, b = call("POST", "/api/malak-assist/webhook/telegram", msg(999, f"{tid} {code}"), headers=H)
        assert s == 200 and b["status"] == "REJECTED"                      # unauthorized sender
        s, b = call("POST", "/api/malak-assist/webhook/telegram", msg(4242, f"{tid} WRONG123"), headers=H)
        assert b["status"] != "RESUMABLE"                                  # wrong code
        assert "checkpoint" not in json.dumps(b) and code not in json.dumps(b)
        s, b = call("POST", "/api/malak-assist/webhook/telegram", msg(4242, f"{tid} {code}"), headers=H)
        assert b["status"] == "RESUMABLE", b
        s, b = call("POST", "/api/malak-assist/webhook/telegram", msg(4242, f"{tid} {code}"), headers=H)
        assert b["status"] != "RESUMABLE", "duplicate/replayed code rejected"
        c = get_connection(db)
        try: blob = " ".join(str(tuple(r)) for r in c.execute("SELECT details FROM audit_events").fetchall())
        finally: c.close()
        assert code not in blob and "whsec-1234567890" not in blob
    secret = "wa-app-secret-xyz"
    with _Env(**{**envs, "KORA_WHATSAPP_APP_SECRET": secret, "KORA_WHATSAPP_VERIFY_TOKEN": "vt-123456", "KORA_MALAK_WHATSAPP_TO": "+91 98765-43210"}):
        t = M.pause_for_malak("CAPTCHA", {"s": 2}, db_path=db)
        payload = {"entry": [{"changes": [{"value": {"messages": [{"type": "text", "from": "919876543210", "text": {"body": f"{t['task_id']} {t['resume_token']}"}}]}}]}]}
        raw = json.dumps(payload).encode()
        sig = "sha256=" + hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
        assert call("POST", "/api/malak-assist/webhook/whatsapp", raw=raw)[0] == 401
        assert call("POST", "/api/malak-assist/webhook/whatsapp", raw=raw, headers={"X-Hub-Signature-256": "sha256=" + "0" * 64})[0] == 401
        assert call("POST", "/api/malak-assist/webhook/whatsapp", raw=raw + b" ", headers={"X-Hub-Signature-256": sig})[0] == 401, "signature covers exact body"
        s, b = call("POST", "/api/malak-assist/webhook/whatsapp", raw=raw, headers={"X-Hub-Signature-256": sig})
        assert s == 200 and b["statuses"] == ["RESUMABLE"], b                 # +91 98765-43210 == 919876543210
        s, b = call("GET", "/api/malak-assist/webhook/whatsapp", query="hub.mode=subscribe&hub.verify_token=vt-123456&hub.challenge=777")
        assert s == 200 and b == b"777"
        assert call("GET", "/api/malak-assist/webhook/whatsapp", query="hub.mode=subscribe&hub.verify_token=bad&hub.challenge=777")[0] == 403


def malak_escalation_and_recovery():
    db = _db()
    with _Env(KORA_MALAK_TELEGRAM_BOT_TOKEN=None, KORA_MALAK_TELEGRAM_CHAT_ID=None, KORA_WHATSAPP_CLOUD_TOKEN=None):
        t = M.pause_for_malak("PAYMENT", {"k": 1}, db_path=db, ttl_seconds=3600)
        assert t["notifiers"][0]["status"] == "NOT_CONFIGURED"
        now = time.time()
        assert M.escalate_overdue(db, after=900, now=now + 10)["escalated"] == []          # too early
        r = M.escalate_overdue(db, after=900, now=now + 1000)["escalated"]
        assert len(r) == 1 and r[0]["sent"] is False, "never claim SENT without a real send"
        assert M.escalate_overdue(db, after=900, now=now + 1100)["escalated"] == []         # spaced out
        for i in range(2, 8): M.escalate_overdue(db, after=1, now=now + 1000 + i * 10)
        c = get_connection(db)
        try: n = c.execute("SELECT escalations FROM malak_assist_tasks").fetchone()[0]
        finally: c.close()
        assert n == M.MAX_ESCALATIONS, n
        # expired tasks are expired by tick, not reminded; restart recovery keeps waiting tasks
        t2 = M.pause_for_malak("OTP", {"k": 2}, db_path=db, ttl_seconds=60)
        assert M.recover(db)["waiting"]
        c = get_connection(db)
        try: c.execute("UPDATE malak_assist_tasks SET expires_at=1 WHERE id=?", (t2["task_id"],))
        finally: c.close()
        out = M.tick(db); assert t2["task_id"] in out["expired"]
        assert M.resume(t2["task_id"], t2["resume_token"], db_path=db, authenticated_sender=True)["status"] != "RESUMABLE", "expired code rejected"


def growth_roi_truth():
    from kora.services import growth_loop as G, dhanda
    db = _db()
    c = G.create_campaign("Bebe Samosa", "2 naal 1 free", platform="instagram", hook="peela", cta="QR", post_hour=19, roi_target=500, cost=100, db_path=db)["campaign_id"]
    assert G.roi(c, db)["state"] == "ROI_TARGET" and G.roi(c, db)["roi_pct"] is None
    G.record_event(c, "SALE", amount=1000, idempotency_key="s1", db_path=db)            # self-reported
    r = G.roi(c, db); assert r["state"] == "ROI_ESTIMATE" and r["revenue"]["verified"] == 0
    e = G.record_event(c, "SALE", amount=2000, source="manual", evidence_ref="photo-1", idempotency_key="s2", db_path=db); assert e["evidence_level"] == 2
    assert G.roi(c, db)["state"] == "ROI_MEASURED"
    e = G.record_event(c, "SALE", amount=3000, source="pos:paytm", evidence_ref="stmt-9", idempotency_key="s3", db_path=db); assert e["evidence_level"] == 2   # caller text is never trusted as tool evidence
    r = G.roi(c, db); assert r["state"] == "ROI_MEASURED" and r["headline_revenue"] == 5000.0 and r["roi_pct"] == 4900.0
    try: G.record_event(c, "SALE", amount=9999, ledger_id=424242, db_path=db); raise AssertionError("fake ledger link accepted")
    except ValueError: pass
    est = dhanda.add_entry("revenue", 4000, "paid", currency="INR", evidence="upi-ref-1", source="upi", db_path=db)
    est2 = dhanda.add_entry("revenue", 50, "unverified", currency="INR", db_path=db)
    try: G.record_event(c, "SALE", amount=50, ledger_id=est2["id"], db_path=db); raise AssertionError("unverified ledger accepted")
    except ValueError: pass
    assert G.record_event(c, "PAYMENT", amount=4000, ledger_id=est["id"], db_path=db)["evidence_level"] == 4
    r = G.roi(c, db); assert r["state"] == "ROI_VERIFIED" and r["headline_revenue"] == 4000.0, r
    assert G.attribution_link("https://shop.example.com/offer", c, "poster1")["url"].count("utm_campaign=") == 1
    for bad in ("http://shop.example.com", "https://localhost", "javascript:alert(1)"):
        try: G.attribution_link(bad, c); raise AssertionError(bad)
        except ValueError: pass
    try: G.record_event(c, "VIRAL", db_path=db); raise AssertionError
    except ValueError: pass


def growth_pilot_and_dna_truth():
    from kora.services import growth_loop as G
    db = _db()
    assert G.pilot_summary(db)["status"] == "TEST_PLAN" and G.pilot_summary(db)["condition_met"] == 0
    s = G.pilot_add_shop("Chaat Corner", "food", 7, db)["shop_id"]
    assert G.pilot_evaluate(s, db)["state"] == "INSUFFICIENT_EVIDENCE"
    for i in range(7):
        G.pilot_record(s, "BEFORE", f"2026-09-0{i+1}", 1000, source="manual", evidence_ref="book-photo", db_path=db)
        G.pilot_record(s, "AFTER", f"2026-09-1{i}", 1900, source="manual", evidence_ref="book-photo", db_path=db)
    r = G.pilot_evaluate(s, db); assert r["incremental_sales"] == 6300 and r["state"] == "UNVERIFIED", r      # photo-only evidence => no fee claim
    s2 = G.pilot_add_shop("Bakery", "food", 7, db)["shop_id"]
    oids = []
    for i in range(7):
        oids.append(G.pilot_record(s2, "BEFORE", f"2026-09-0{i+1}", 1000, source="pos:vyapar", evidence_ref=f"b{i}", db_path=db)["observation_id"])
        oids.append(G.pilot_record(s2, "AFTER", f"2026-09-1{i}", 1900, source="pos:vyapar", evidence_ref=f"a{i}", db_path=db)["observation_id"])
    assert G.pilot_evaluate(s2, db)["state"] == "UNVERIFIED"                            # a "pos:" label alone proves nothing
    for o in oids[:-1]: G.pilot_attest(o, actor="owner:owner@test", db_path=db)
    assert G.pilot_evaluate(s2, db)["state"] == "UNVERIFIED"                            # one unattested observation blocks the claim
    G.pilot_attest(oids[-1], actor="owner:owner@test", db_path=db)
    assert G.pilot_evaluate(s2, db)["state"] == "CONDITION_MET_PENDING_MALAK"
    s3 = G.pilot_add_shop("Flat", "food", 7, db)["shop_id"]
    for i in range(7):
        G.pilot_record(s3, "BEFORE", f"2026-09-0{i+1}", 1000, source="pos:x", evidence_ref="r", db_path=db); G.pilot_record(s3, "AFTER", f"2026-09-1{i}", 1100, source="pos:x", evidence_ref="r", db_path=db)
    assert G.pilot_evaluate(s3, db)["state"] == "CONDITION_NOT_MET"
    sm = G.pilot_summary(db); assert sm["condition_met"] == 1 and sm["unverified"] == 1 and sm["not_met"] == 1 and sm["status"] == "TEST_PLAN"
    # Marketing DNA: no winner on thin data; winner only with >=3 evidenced campaigns; secrets never stored
    for hook, n in (("peela", 1), ("laal", 3)):
        for _ in range(n):
            c = G.create_campaign("m", "o", hook=hook, cost=100, db_path=db)["campaign_id"]
            from kora.services import dhanda as _dh
            lid = _dh.add_entry("revenue", 1000, "paid", currency="INR", evidence="ref", source="upi", db_path=db)["id"]
            G.record_event(c, "SALE", amount=1000, ledger_id=lid, db_path=db)
    d = G.marketing_dna("hook", db); assert d["winner"] == "laal"
    g = {x["value"]: x for x in d["groups"]}; assert g["peela"]["status"] == "INSUFFICIENT_DATA" and g["laal"]["status"] == "SOURCE_BASED"
    c = G.create_campaign("m", "o", hook="Bearer sk-abcdefghijklmnopqrstuvwx", db_path=db)["campaign_id"]
    cn = get_connection(db)
    try: assert "sk-abcdef" not in cn.execute("SELECT hook FROM growth_campaigns WHERE id=?", (c,)).fetchone()[0]
    finally: cn.close()
    # competitor radar: unevidenced capability ranks below an evidenced one with equal scores
    G.competitor_add("A no evidence", impact=.9, feasibility=.9, db_path=db); G.competitor_add("B evidenced", source="https://x.example", public_evidence="public pricing page", impact=.9, feasibility=.9, db_path=db)
    rk = G.competitor_rank(db); assert rk[0]["capability"] == "B evidenced" and rk[1]["evidence"] == "UNVERIFIED"
    p = G.festival_plan("Lohri", "2027-01-13", "bakery", "pa", 7)
    assert len(p["plan"]) == 7 and all(i["state"] == "TEMPLATE_IDEA" for i in p["plan"]) and "yellow" not in json.dumps(p).lower()


def growth_api_wired():
    db = _db(); app, call = _app(db)
    H = {"Authorization": "Bearer tok-abcdef123456"}
    s, b = call("POST", "/api/growth/campaigns", {"merchant": "Shop", "offer": "2+1", "cost": 100, "roi_target": 300}, headers=H); assert s == 201, b
    cid = b["campaign_id"]
    assert call("GET", f"/api/growth/campaigns/{cid}/roi", headers=H)[1]["state"] == "ROI_TARGET"
    assert call("POST", f"/api/growth/campaigns/{cid}/events", {"kind": "SALE", "amount": 500, "idempotency_key": "k1"}, headers=H)[0] == 201
    assert call("GET", f"/api/growth/campaigns/{cid}/roi", headers=H)[1]["state"] == "ROI_ESTIMATE"
    assert call("POST", f"/api/growth/campaigns/{cid}/events", {"kind": "BOT_CLICKS", "amount": 5}, headers=H)[0] == 400
    assert call("GET", "/api/growth/pilot", headers=H)[1]["status"] == "TEST_PLAN"
    assert call("GET", "/api/growth/pilot")[0] in (401, 403)


def growth_security_regressions():
    import math
    from kora.services import growth_loop as G, dhanda
    db = _db(); N = float("nan"); I = float("inf")
    def bad(fn, *a, **k):
        try: fn(*a, **k)
        except ValueError: return
        raise AssertionError("accepted: %r %r" % (a, k))
    # 1+2) caller-supplied "tool" evidence is never level 3; ledger reconciliation is exact and single-use
    c = G.create_campaign("S", "o", cost=100, db_path=db)["campaign_id"]
    assert G.record_event(c, "SALE", amount=100000, source="pos:x", evidence_ref="a", idempotency_key="k", db_path=db)["evidence_level"] == 2
    r = G.roi(c, db); assert r["state"] == "ROI_MEASURED" and r["trust"]["measured"] == "UNRECONCILED_REFERENCE"
    lid = dhanda.add_entry("revenue", 10, "t", currency="INR", evidence="e", source="s", db_path=db)["id"]
    bad(G.record_event, c, "SALE", amount=999999, ledger_id=lid, db_path=db)           # amount must equal the ledger row
    other = dhanda.add_entry("revenue", 10, "t", currency="USD", evidence="e", source="s", db_path=db)["id"]
    bad(G.record_event, c, "SALE", amount=10, ledger_id=other, db_path=db)             # currency mismatch
    assert G.record_event(c, "SALE", amount=10, ledger_id=lid, db_path=db)["evidence_level"] == 4
    bad(G.record_event, c, "SALE", amount=10, ledger_id=lid, db_path=db)               # single use
    c2 = G.create_campaign("S2", "o", cost=1, db_path=db)["campaign_id"]
    bad(G.record_event, c2, "SALE", amount=10, ledger_id=lid, db_path=db)              # not reusable across campaigns either
    assert G.roi(c, db)["revenue"]["verified"] == 10.0
    # 3) idempotency
    bad(G.record_event, c, "SALE", amount=5, db_path=db)                               # money event without key
    a = G.record_event(c, "LEAD", idempotency_key="lead-1", db_path=db); b = G.record_event(c, "LEAD", idempotency_key="lead-1", db_path=db)
    assert b["duplicate"] is True and a["event_id"] == b["event_id"] and G.roi(c, db)["funnel"]["LEAD"] == 1.0
    bad(G.record_event, c, "SALE", amount=7, idempotency_key="k", db_path=db)          # same key, different content
    bad(G.record_event, c, "LEAD", idempotency_key="bad key!", db_path=db)
    # 4) pilot: duplicates, dates, windows
    s = G.pilot_add_shop("X", window_days=3, db_path=db)["shop_id"]
    o = G.pilot_record(s, "BEFORE", "2026-09-01", 100, source="manual", evidence_ref="r", db_path=db)
    assert G.pilot_record(s, "BEFORE", "2026-09-01", 100, source="manual", evidence_ref="r", db_path=db)["duplicate"] is True
    bad(G.pilot_record, s, "BEFORE", "2026-09-01", 9999, db_path=db)                   # same day, different sales: no summing/overwriting
    for d in ("2026-13-99", "2026-02-30", "2999-01-01", "01/09/2026", "2019-01-01"): bad(G.pilot_record, s, "AFTER", d, 1, db_path=db)
    bad(G.pilot_record, s, "BEFORE", "2026-09-09", 1, db_path=db)                      # outside the 3-day window
    bad(G.pilot_record, s, "AFTER", "2026-08-30", 1, db_path=db)                       # AFTER before BEFORE
    bad(G.pilot_record, s, "BEFORE", "2026-09-02", N, db_path=db)
    G.pilot_record(s, "BEFORE", "2026-09-03", 100, db_path=db)                         # gap day 09-02 => not contiguous
    for d in ("2026-09-10", "2026-09-11", "2026-09-12"): G.pilot_record(s, "AFTER", d, 9000, source="manual", evidence_ref="r", db_path=db)
    assert G.pilot_evaluate(s, db)["state"] == "INSUFFICIENT_EVIDENCE" and "consecutive" in G.pilot_evaluate(s, db)["reason"]
    bad(G.pilot_attest, o["observation_id"], actor="system", db_path=db)                # needs an identified actor
    bad(G.pilot_attest, 99999, actor="owner:o", db_path=db)
    ref0 = G.pilot_record(G.pilot_add_shop("Y", db_path=db)["shop_id"], "BEFORE", "2026-09-01", 1, db_path=db)
    bad(G.pilot_attest, ref0["observation_id"], actor="owner:o", db_path=db)            # no reference => nothing to attest
    # 5) audit of every mutation
    cn = get_connection(db)
    try:
        kinds = {r[0] for r in cn.execute("SELECT event_type FROM audit_events").fetchall()}
        assert {"growth_campaign_created", "growth_event_recorded", "pilot_shop_enrolled", "pilot_observation_recorded"} <= kinds, kinds
        assert "growth_competitor_added" not in kinds
    finally: cn.close()
    G.pilot_attest(o["observation_id"], actor="owner:owner@t", db_path=db); G.competitor_add("cap", db_path=db, actor="owner:owner@t")
    cn = get_connection(db)
    try:
        kinds = {r[0] for r in cn.execute("SELECT event_type FROM audit_events").fetchall()}
        assert {"pilot_observation_attested", "growth_competitor_added"} <= kinds
        assert "attested" not in str(cn.execute("SELECT details FROM audit_events WHERE event_type='growth_event_recorded'").fetchall()).lower()
    finally: cn.close()
    # 6) redaction: real secrets removed, ordinary evidence kept
    assert G._clean("invoice 123456 hotpot") == "invoice 123456 hotpot"
    for secret in ("otp: 123456", "OTP 482913", "password=hunter2", "Bearer abc.def", "sk-abcdefghijklmnopqrstuvwx", "api_key: zzz"):
        assert "[REDACTED]" in G._clean(secret) and "hunter2" not in G._clean(secret) and "482913" not in G._clean(secret), secret
    # 7) finite numbers everywhere
    for v in (N, I, -I): 
        bad(G.create_campaign, "S", "o", cost=v, db_path=db); bad(G.create_campaign, "S", "o", roi_target=v, db_path=db)
        bad(G.record_event, c, "LEAD", count=v, db_path=db); bad(G.record_event, c, "SALE", amount=v, idempotency_key="z", db_path=db)
        bad(G.pilot_record, s, "AFTER", "2026-09-12", v, db_path=db); bad(G.competitor_add, "x", impact=v, db_path=db); bad(G.festival_plan, "Lohri", "2027-01-13", "b", "pa", v)
    bad(G.create_campaign, "S", "o", roi_target=True, db_path=db); bad(G.create_campaign, "S", "o", post_hour=True, db_path=db)
    # 8) API: NaN/Infinity JSON, attest route owner-only, idempotency over HTTP
    app, call = _app(db); H = {"Authorization": "Bearer tok-abcdef123456"}
    assert call("POST", "/api/growth/campaigns", raw=b'{"merchant":"m","offer":"o","cost":NaN}', headers=H)[0] == 400
    cid = call("POST", "/api/growth/campaigns", {"merchant": "m", "offer": "o"}, headers=H)[1]["campaign_id"]
    assert call("POST", f"/api/growth/campaigns/{cid}/events", {"kind": "SALE", "amount": 5}, headers=H)[0] == 400
    r1 = call("POST", f"/api/growth/campaigns/{cid}/events", {"kind": "SALE", "amount": 5, "idempotency_key": "a"}, headers=H); r2 = call("POST", f"/api/growth/campaigns/{cid}/events", {"kind": "SALE", "amount": 5, "idempotency_key": "a"}, headers=H)
    assert r1[1]["event_id"] == r2[1]["event_id"] and r2[1]["duplicate"] is True
    sid = call("POST", "/api/growth/pilot/shops", {"name": "S"}, headers=H)[1]["shop_id"]
    ob = call("POST", f"/api/growth/pilot/{sid}/observations", {"phase": "BEFORE", "date": "2026-09-01", "sales": 10, "evidence_ref": "r"}, headers=H)[1]["observation_id"]
    from kora.core import identity
    tok = identity.create_principal("u", "user", db_path=db)["token"]
    assert call("POST", f"/api/growth/pilot/observations/{ob}/attest", {}, headers={"Authorization": "Bearer " + tok})[0] == 403
    assert call("POST", f"/api/growth/pilot/observations/{ob}/attest", {}, headers=H)[1]["state"] == "OWNER_ATTESTED"
    cn = get_connection(db)
    try: assert "owner:owner@" in str(cn.execute("SELECT actor FROM audit_events WHERE event_type='pilot_observation_attested'").fetchall()[0][0])
    finally: cn.close()


def backup_321_truth():
    from kora.services import backup as B
    d = tempfile.mkdtemp(prefix="kora-321-"); src = os.path.join(d, "a.db"); open(src, "wb").write(os.urandom(5000))
    c1, c2 = os.path.join(d, "c1.db"), os.path.join(d, "off", "c2.db"); os.makedirs(os.path.dirname(c2))
    import shutil; shutil.copy(src, c1); shutil.copy(src, c2)
    r = B.backup_321_report(src, [c1, c2], os.path.join(d, "off"), offsite_attested=False)
    assert r["status"] != "PASS" and r["offsite"] == "OFFSITE_UNVERIFIED", r                # never auto-PASS offsite
    r = B.backup_321_report(src, [c1, c2], os.path.join(d, "off"), offsite_attested=True)
    assert r["verified_copies"] == 3 and (r["status"] == "PASS") == (r["distinct_devices"] >= 2)   # same disk => cannot be 2 media
    open(c1, "ab").write(b"x")
    r = B.backup_321_report(src, [c1, src, "/nonexistent"], "", True)
    assert r["verified_copies"] == 1 and r["status"] == "FAIL", r                            # tampered / same-file / missing copies do not count
    assert B.backup_321_report("/nonexistent", [])["status"] == "FAIL"


def moat_store_truth():
    from kora.services import moat_store as M2
    d = tempfile.mkdtemp(prefix="kora-moat-")
    try: M2.put(d, "pw", {"a": 1}); assert False
    except M2.MoatError as e: assert str(e) == "consent_off"          # OFF by default
    M2.set_consent(d, collection=True)
    r = M2.put(d, "pw", {"hook": "peela", "phone": "98765 43210", "note": "call +91 98765 43210 or a@b.com"}, now=1760000000)
    M2.put(d, "pw", {"x": 2}, now=1760000001)
    raw = open(os.path.join(d, "moat-%s.sealed" % r["month"])).read()
    assert "peela" not in raw and "98765" not in raw and "AES-256-GCM" in raw      # ciphertext only
    assert M2.verify(d, "pw")["status"] == "PASS"
    try: M2.export_anonymized(d, "pw", r["month"], "s"); assert False
    except M2.MoatError as e: assert str(e) == "export_consent_off"
    M2.set_consent(d, collection=True, export=True)
    ex = M2.export_anonymized(d, "pw", r["month"], "s"); s = json.dumps(ex)
    assert "98765" not in s and "a@b.com" not in s and "phone_hash" in s
    assert M2.verify(d, "wrong")["status"] == "FAIL"                               # wrong key never passes
    f = os.path.join(d, "moat-%s.sealed" % r["month"]); open(f, "a").write(" "); assert M2.verify(d, "pw")["status"] == "FAIL"   # tamper detected
    assert M2.verify(tempfile.mkdtemp(), "pw")["status"] == "UNKNOWN"


def server_python_module_shadowing_fix():
    import shutil, subprocess, sys
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    launcher = os.path.join(root, "scripts", "safe_launch.py")
    tmp = tempfile.mkdtemp(prefix="kora-shadow-")
    os.makedirs(os.path.join(tmp, "kora")); os.makedirs(os.path.join(tmp, "scripts"))
    open(os.path.join(tmp, "kora", "__init__.py"), "w").write("")
    open(os.path.join(tmp, "kora", "cli.py"), "w").write("import json, sys\nprint('JSONFILE', json.__file__)\nprint('ARGV', sys.argv)\n")
    open(os.path.join(tmp, "json.py"), "w").write("import sys\nsys.stdout.write('PWNED\\n')\nraise ImportError('planted shadow')\n")   # planted stdlib shadow
    shutil.copy(launcher, os.path.join(tmp, "scripts", "safe_launch.py"))
    run = lambda argv, env=None: subprocess.run(argv, cwd=tmp, env=env, capture_output=True, text=True, timeout=60)
    hostile = dict(os.environ, PYTHONPATH=tmp)
    # control: the OLD launch (-m + PYTHONPATH='.') is shadowed, proving the test can see the vulnerability
    old = run([sys.executable, "-m", "kora.cli"], dict(os.environ, PYTHONPATH="."))
    assert "PWNED" in old.stdout or "planted shadow" in old.stderr, ("control failed to reproduce the shadowing", old.stdout, old.stderr)
    # fix: isolated + appended root => stdlib json wins, args pass through, hostile env/cwd ignored
    new = run([sys.executable, "-I", os.path.join(tmp, "scripts", "safe_launch.py"), "kora.cli", "a", "b"], hostile)
    assert new.returncode == 0 and "PWNED" not in new.stdout + new.stderr, (new.stdout, new.stderr)
    assert "JSONFILE" in new.stdout and tmp not in new.stdout.split("JSONFILE", 1)[1].splitlines()[0], new.stdout     # stdlib json, not tmp/json.py
    assert "cli.py', 'a', 'b']" in new.stdout, new.stdout                       # same argv shape as `python -m` (argv[0] = module file)
    # allowlist: nothing else is launchable
    for mod in ("json", "os", "kora.core.db", "kora.cli.evil", ""):
        r = run([sys.executable, "-I", os.path.join(tmp, "scripts", "safe_launch.py"), mod], hostile)
        assert r.returncode == 2 and "not allowed" in r.stderr, (mod, r.returncode, r.stderr)
    assert run([sys.executable, "-I", os.path.join(tmp, "scripts", "safe_launch.py")], hostile).returncode == 2
    # 'kora' must resolve inside the project root
    shutil.rmtree(os.path.join(tmp, "kora"))
    r = run([sys.executable, "-I", os.path.join(tmp, "scripts", "safe_launch.py"), "kora.cli"], hostile)
    assert r.returncode == 3 and "refusing" in r.stderr, (r.returncode, r.stderr)
    # normal startup of the REAL entry point through the launcher
    real = subprocess.run([sys.executable, "-I", launcher, "kora.cli", "--help"], cwd=tempfile.mkdtemp(prefix="kora-cwd-"), env=hostile, capture_output=True, text=True, timeout=120)
    assert real.returncode == 0 and "KORA PRO Command Center" in real.stdout, (real.returncode, real.stdout[-200:], real.stderr[-300:])
    # server.ts: no remaining PYTHONPATH / '-m' python spawns; both spawn sites use the launcher; syntax OK where node exists
    ts = open(os.path.join(root, "server.ts")).read()
    assert "PYTHONPATH" not in ts and "'-m'" not in ts and ts.count("pythonLaunchArgs(") == 3, "server.ts still has an unsafe python spawn"
    assert "spawn('python3', pythonLaunchArgs('kora.cli', args)" in ts and "pythonLaunchArgs('kora.tests.run_all')" in ts
    api = open(os.path.join(root, "kora", "bridge", "api.py")).read()
    assert 'env["PYTHONPATH"]' not in api and '"-m", "kora.tests.run_all"' not in api and 'safe_launch.py"), "kora.tests.run_all"' in api, "api.py run_tests still uses the shadowable launch"
    if shutil.which("node"):
        assert subprocess.run(["node", "--check", os.path.join(root, "server.ts")], capture_output=True, text=True, timeout=60).returncode == 0


def generated_test_cwd_independent():
    """Regression (PATCH3): the run_tests route runs the suite with cwd = an isolated temp dir, where T110 used to FAIL because a generated
    regression test reads a repo-relative path. The helper must run generated tests from the project root and restore the caller's cwd."""
    import tempfile
    from kora.tests import evolution3_tests as e3
    src = 'def t():\n    from pathlib import Path\n    assert "def " in Path("kora/services/ops.py").read_text(encoding="utf-8")\n'
    ns = {}
    exec(compile(src, "gen", "exec"), ns)
    here = os.getcwd()
    with tempfile.TemporaryDirectory() as td:
        os.chdir(td)
        try:
            try:   # control: the old behaviour (run in the foreign cwd) really fails
                ns["t"]()
                raise AssertionError("control should have failed from a foreign cwd")
            except FileNotFoundError:
                pass
            e3.run_generated_from_root(ns["t"])   # the fix: runs from the project root
            assert os.path.realpath(os.getcwd()) == os.path.realpath(td), "caller cwd must be restored"
        finally:
            os.chdir(here)


def run_tests_route_launch_cwd_tmp():
    """Regression (PATCH3): the /api/tests/run launch path (cwd = temp dir, safe_launch, env filter) must run T110 successfully.
    Uses the route's own launcher restricted to one test (KORA_TEST_ONLY) so the suite never runs inside itself."""
    from kora.bridge import api
    p = api._run_suite_subprocess(only="T110")
    out = p.stdout
    assert p.returncode == 0, f"route launch of T110 failed rc={p.returncode}: {[l for l in out.splitlines() if 'FAIL' in l][:2]}"
    assert "[PASS] T110" in out and "TEST SUITE COMPLETE: 1/1 PASS" in out, out[-300:]
    bad = api._run_suite_subprocess(only="T999")   # control: an unknown id can never produce a pass
    assert bad.returncode != 0 and "[FAIL] FILTER" in bad.stdout
    rec = api._run_suite_subprocess(only="T169")   # control: the recursion guard skips this test, so the filter mismatch fails instead of recursing
    assert rec.returncode != 0 and "[PASS]" not in rec.stdout


def register(run_test):
    run_test("T152", "Social external verification: VERIFIED/NOT_FOUND/UNVERIFIED(no creds)/network-retry, idempotent, no token leak", social_verification_truth)
    run_test("T153", "Every registered queue handler is visible to the trust gate (none silently refused live)", every_handler_is_trust_runnable)
    run_test("T154", "Worker pool yields under RAM/disk pressure and resumes when it clears", worker_yields_under_pressure)
    run_test("T155", "Resource governor: current RSS, env limits, pressure, enforce; HTTP request threads bounded (503 when full)", resource_governor_and_bounded_http)
    run_test("T156", "Malak webhooks: Telegram secret + WhatsApp HMAC/verify-challenge, NOT_CONFIGURED=503, wrong sender/code/replay rejected, no secret in audit", malak_webhooks_authenticated)
    run_test("T157", "Malak escalation/timeout: spaced reminders capped, never claim SENT unsent, expired code rejected, restart recovery", malak_escalation_and_recovery)
    run_test("T158", "Growth loop: ROI_TARGET/ESTIMATE/MEASURED/VERIFIED computed from evidence, ledger link must be VERIFIED dhanda row, attribution link validated", growth_roi_truth)
    run_test("T159", "10-shop pilot evidence framework + Rs500 rule needs tool-verified before/after; Marketing DNA needs real samples; competitor radar ranks evidence first", growth_pilot_and_dna_truth)
    run_test("T160", "Growth API wired, authenticated, rejects fake event kinds", growth_api_wired)
    run_test("T161", "Backup 3-2-1 truth: byte-identical copies, distinct devices, offsite only owner-attested; tampered/duplicate/missing copies never count", backup_321_truth)
    run_test("T165", "Growth security regressions: untrusted evidence never level 3, single-use exact ledger reconciliation, idempotency, strict pilot dates/windows/duplicates, full mutation audit, safe redaction, finite numbers, owner-only attestation", growth_security_regressions)
    run_test("T162", "Moat store: consent OFF by default, AES-256-GCM at rest, checksum index, tamper/wrong-key FAIL, anonymised export needs export consent", moat_store_truth)
    run_test("T167", "server.ts Python launch is shadow-proof: planted json.py is reproduced against the old launch, ignored by scripts/safe_launch.py (-I, appended root, module allowlist, kora-origin check); real entry point still starts", server_python_module_shadowing_fix)
    run_test("T168", "run_tests route cwd-independence: generated tests run from the project root and the caller cwd is restored (T110 failed under cwd=temp)", generated_test_cwd_independent)
    run_test("T169", "run_tests route launch (cwd=temp, safe_launch, env filter) runs T110 to PASS; unknown id/recursion guard can never pass", run_tests_route_launch_cwd_tmp)
