"""
KORA 8.8.5 — Comprehensive Behavioral & Architecture Test Suite
Executes hardened, non-mocked assertions against actual production implementations.
Reports true PASS/FAIL/WARN/UNKNOWN.
"""
import os
import sys
import io
import time
import tempfile
import sqlite3
import shutil
from typing import Dict, Any, List

from kora.core.db import init_db, get_connection
from kora.core.queue import (
    DurableQueue,
    KillSwitchActiveException,
    PayloadOversizedException,
    IdempotencyConflictException
)
from kora_core.worker import SafeWorker
from kora.services.voice_transcription import transcribe, get_provider_status
from kora.services.backup_service import BackupService
from kora.core.event_bus import ProcessLocalEventBus
from kora.core.offline_queue import DurableOfflineQueue
from kora.services.media_dedup import MediaDedupEngine, compute_block_mean_phash_64, hamming_distance
from kora.services.system_doctor import SystemDoctor, run_system_doctor_inspection
from kora.core.security import (
    sanitize_recursive,
    validate_outbound_url_for_ssrf,
    check_remote_authorization
)
from kora.services.social import create_social_post, approve_and_publish_post
from kora.services.ai_failover import query_ai_model
from kora.services.subtitles import validate_subtitle_cue, SubtitleValidationError

TEST_RESULTS: List[Dict[str, Any]] = []

_ONLY = {x.strip() for x in os.environ.get("KORA_TEST_ONLY", "").split(",") if x.strip()}   # test hook for the route regression (T169)


def run_test(test_id: str, name: str, fn):
    if _ONLY and (test_id not in _ONLY or test_id == "T169"):   # T169 never runs inside a filtered child -> no recursion
        return
    t0 = time.time()
    try:
        fn()
        elapsed = round((time.time() - t0) * 1000, 2)
        TEST_RESULTS.append({
            "id": test_id,
            "name": name,
            "status": "PASS",
            "duration_ms": elapsed,
            "details": "Assertion validated cleanly."
        })
        print(f"  [PASS] {test_id}: {name} ({elapsed}ms)")
    except Exception as e:
        elapsed = round((time.time() - t0) * 1000, 2)
        TEST_RESULTS.append({
            "id": test_id,
            "name": name,
            "status": "FAIL",
            "duration_ms": elapsed,
            "details": str(e)
        })
        print(f"  [FAIL] {test_id}: {name} - Error: {e}")

def main():
    print("=" * 60)
    print("KORA PRO — EXECUTING BEHAVIORAL TEST SUITE")
    print("=" * 60)

    test_db = os.path.abspath("data/test_harness.db")
    if os.path.exists(test_db):
        os.remove(test_db)
    init_db(test_db)

    # 1. QUEUE: Priority Ordering (100 before 10)
    def test_priority_claim():
        q = DurableQueue(test_db)
        q.enqueue("noop", {"name": "low_prio"}, priority=10)
        q.enqueue("noop", {"name": "high_prio"}, priority=100)

        claimed_first = q.claim_next_job("worker-test-1")
        assert claimed_first is not None, "Failed to claim first job"
        assert claimed_first["priority"] == 100, f"Expected priority 100, got {claimed_first['priority']}"
        assert claimed_first["payload"]["name"] == "high_prio", "Wrong job payload claimed first"

        claimed_second = q.claim_next_job("worker-test-1")
        assert claimed_second is not None, "Failed to claim second job"
        assert claimed_second["priority"] == 10, f"Expected priority 10, got {claimed_second['priority']}"
        q.complete_job(claimed_first["id"], "worker-test-1", {"ok": True})
        q.complete_job(claimed_second["id"], "worker-test-1", {"ok": True})
    run_test("T01", "Durable Queue Priority Ordering (100 before 10)", test_priority_claim)

    # 2. QUEUE: Idempotency Protection
    def test_idempotency():
        q = DurableQueue(test_db)
        key = f"idem-key-unique-{time.time()}"
        q.enqueue("noop", {"data": 1}, idempotency_key=key)
        try:
            q.enqueue("noop", {"data": 2}, idempotency_key=key)
            assert False, "Should have thrown IdempotencyConflictException"
        except IdempotencyConflictException:
            pass
    run_test("T02", "Idempotency Conflict Blocking", test_idempotency)

    # 3. QUEUE: Kill-Switch Enforcement
    def test_kill_switch():
        q = DurableQueue(test_db)
        q.set_kill_switch(True)
        try:
            q.enqueue("noop", {"data": 3})
            assert False, "Should have rejected enqueue during active kill-switch"
        except KillSwitchActiveException:
            pass
        claimed = q.claim_next_job("worker-test-2")
        assert claimed is None, "Claim should be None when kill switch is active"
        q.set_kill_switch(False)
    run_test("T03", "Queue Kill-Switch Enforcement", test_kill_switch)

    # 4. OFFLINE QUEUE: Atomic Claim, Priority Ordering & Fencing Token
    def test_offline_queue_atomic_fencing():
        oq_db = os.path.abspath("data/test_oq_fencing.db")
        if os.path.exists(oq_db):
            os.remove(oq_db)
        oq = DurableOfflineQueue(oq_db)
        oq.enqueue("action_low", {"p": 10}, priority=10)
        oq.enqueue("action_high", {"p": 100}, priority=100)

        # Must claim high priority first
        c1 = oq.claim_next("worker-alpha")
        assert c1 is not None and c1["priority"] == 100, f"Expected high priority 100, got {c1}"
        assert c1["fencing_token"] == 2, f"Expected incremented fencing token 2, got {c1['fencing_token']}"

        # Unauthorized worker attempt must be rejected
        unauth_res = oq.complete_job(c1["id"], "worker-impostor", c1["fencing_token"], {"done": True})
        assert unauth_res["success"] is False, "Should have rejected completion by impostor worker"

        # Stale fencing token attempt must be rejected
        stale_res = oq.complete_job(c1["id"], "worker-alpha", 1, {"done": True})
        assert stale_res["success"] is False, "Should have rejected stale fencing token"

        # Legitimate authorized worker with correct fencing token
        valid_res = oq.complete_job(c1["id"], "worker-alpha", c1["fencing_token"], {"done": True})
        assert valid_res["success"] is True, "Legitimate completion should succeed"
    run_test("T04", "Offline Queue Atomic Claim & Fencing Token Protection", test_offline_queue_atomic_fencing)

    # 5. OFFLINE QUEUE: Idempotency Barrier
    def test_offline_queue_idempotency():
        oq_db = os.path.abspath("data/test_oq_idem.db")
        if os.path.exists(oq_db):
            os.remove(oq_db)
        oq = DurableOfflineQueue(oq_db)
        key = "unique-mutation-barrier-123"
        r1 = oq.enqueue("submit_review", {"score": 5}, priority=50, idem_key=key)
        assert r1["rejected"] is False, "First submission should succeed"

        r2 = oq.enqueue("submit_review", {"score": 5}, priority=50, idem_key=key)
        assert r2["rejected"] is True, "Duplicate idempotency submission must be rejected"
    run_test("T05", "Offline Queue Strict Idempotency Barrier", test_offline_queue_idempotency)

    # 6. VOICE: Truthful STT Fallback (No Fake Transcripts)
    def test_voice_truthful_fallback():
        # Valid WAV payload
        wav_bytes = b"RIFF\x24\x00\x00\x00WAVEfmt \x10\x00\x00\x00\x01\x00\x01\x00\x44\xac\x00\x00data\x00\x00\x00\x00"
        res = transcribe(wav_bytes)
        assert res["ok"] is False, "Expected ok=False without provider API keys"
        assert res["status"] == "transcription_unavailable", f"Expected transcription_unavailable, got {res['status']}"
        assert res["transcript"] is None, "Must NEVER return hard-coded fake transcript"
        assert res["confidence"] is None, "Must NEVER return hard-coded 0.96 confidence"
    run_test("T06", "Voice STT Truthful Unavailable Provider Cascade", test_voice_truthful_fallback)

    # 7. VOICE: Empty Audio Rejection
    def test_voice_empty_rejection():
        try:
            transcribe(b"")
            assert False, "Should have rejected 0-byte audio payload"
        except ValueError as e:
            assert "empty" in str(e).lower()
    run_test("T07", "Voice STT Empty Audio Rejection", test_voice_empty_rejection)

    # 8. VOICE: Signature/Header Validation
    def test_voice_invalid_signature():
        try:
            transcribe(b"CORRUPT_WAV_HEADER_DATA_12345", filename="audio.wav")
            assert False, "Should have rejected bad WAV header"
        except ValueError as e:
            assert "header" in str(e).lower() or "riff" in str(e).lower()
    run_test("T08", "Voice STT Corrupt Audio Header Signature", test_voice_invalid_signature)

    # 9. BACKUP: Real SQLite Online Backup API & PRAGMA Integrity
    def test_backup_sqlite_backup_api():
        bs = BackupService(test_db, backups_dir="data/test_backups")
        snap = bs.create_snapshot("FULL")
        assert snap["status"] == "VERIFIED", f"Expected VERIFIED, got {snap['status']}"
        assert len(snap["sha256"]) == 64, "SHA-256 must be 64-char hex string"
        assert snap["size_bytes"] > 0, "Backup file size must be non-zero"
        assert os.path.exists(snap["filepath"]), "Backup file must physically exist on disk"
    run_test("T09", "Backup Service Real SQLite Backup API & File SHA-256", test_backup_sqlite_backup_api)

    # 10. BACKUP: Fresh Connection Restore & Schema Readability
    def test_backup_fresh_restore_readability():
        bs = BackupService(test_db, backups_dir="data/test_backups")
        snap = bs.create_snapshot("FULL")
        target_db = os.path.abspath("data/test_restored.db")
        if os.path.exists(target_db):
            os.remove(target_db)

        restore_res = bs.restore_snapshot(snap["filepath"], target_db)
        assert restore_res["success"] is True, "Restore failed"
        assert restore_res["integrity"] == "ok", "Restored DB failed PRAGMA integrity check"
        assert "system_snapshots" in restore_res["tables"], "Restored DB missing schema tables"
    run_test("T10", "Backup Fresh Connection Restore & Schema Readability", test_backup_fresh_restore_readability)

    # 11. EVENT BUS: Process-Local Bounded Memory & Exception Isolation
    def test_event_bus_isolation():
        bus = ProcessLocalEventBus(max_history=10, max_dlq=5)
        received = []
        bus.subscribe("telemetry.ok", lambda evt: received.append(evt["id"]))
        
        # Failing subscriber
        def buggy_subscriber(evt):
            raise RuntimeError("Deliberate subscriber failure")
        bus.subscribe("telemetry.ok", buggy_subscriber)

        # Publish should not crash or stop healthy subscribers
        evt = bus.publish("telemetry.ok", {"data": "test"})
        assert evt["dispatch_count"] == 1, "Healthy subscriber must have received event"
        assert len(received) == 1, "Healthy subscriber callback must have executed"
        assert evt["status"] == "PARTIAL_FAILURE", f"Expected PARTIAL_FAILURE, got {evt['status']}"
        assert len(bus.get_dlq()) == 1, "Failed subscriber execution must be isolated in DLQ"
    run_test("T11", "Event Bus Process-Local Bounded Memory & DLQ Isolation", test_event_bus_isolation)

    # 12. EVENT BUS: Real In-Memory Replay Semantics
    def test_event_bus_replay():
        bus = ProcessLocalEventBus(max_history=50, max_dlq=10)
        replayed_receipts = []
        bus.subscribe("order.created", lambda evt: replayed_receipts.append(evt))

        evt = bus.publish("order.created", {"order_id": "ORD-99"})
        assert len(replayed_receipts) == 1

        # Execute real replay
        replay_res = bus.replay_event(evt["id"])
        assert replay_res["success"] is True
        assert replay_res["status"] == "REPLAYED"
        assert len(replayed_receipts) == 2, "Subscriber should receive replayed event"
        assert replayed_receipts[1].get("is_replay") is True
    run_test("T12", "Event Bus Real In-Memory Replay Dispatch", test_event_bus_replay)

    # 13. MEDIA DEDUP: Strict Audience Isolation (KIDS vs ADULT)
    def test_media_dedup_audience_isolation():
        engine = MediaDedupEngine(max_entries=100)
        payload = b"VIDEO_CONTENT_SHARED_BINARY_RAW_BYTES_XYZ"

        # Register in KIDS
        r_kids = engine.register_asset("clip-kids-1", payload, audience="KIDS")
        assert r_kids["is_duplicate"] is False, "First asset in KIDS must be original"

        # Register same bytes in ADULT -> MUST NOT MERGE
        r_adult = engine.register_asset("clip-adult-1", payload, audience="ADULT")
        assert r_adult["is_duplicate"] is False, "Identical bytes under ADULT must NOT cross-merge into KIDS"

        # Register duplicate in KIDS -> MUST deduplicate
        r_kids_dup = engine.register_asset("clip-kids-2", payload, audience="KIDS")
        assert r_kids_dup["is_duplicate"] is True, "Same bytes in KIDS must deduplicate"
        assert r_kids_dup["canonical_id"] == "clip-kids-1"
    run_test("T13", "Media Dedup Strict Audience Isolation (KIDS vs ADULT)", test_media_dedup_audience_isolation)

    # 14. MEDIA DEDUP: Genuine 64-Bit Block-Mean Perceptual Hash
    def test_media_dedup_phash():
        data1 = b"\x00" * 32 + b"\xff" * 32
        data2 = b"\x00" * 30 + b"\xff" * 34  # Slight variation
        
        phash1 = compute_block_mean_phash_64(data1)
        phash2 = compute_block_mean_phash_64(data2)

        assert len(phash1) == 64, f"pHash length must be 64, got {len(phash1)}"
        assert len(phash2) == 64, f"pHash length must be 64, got {len(phash2)}"
        assert set(phash1).issubset({"0", "1"}), "pHash must be binary 0 and 1"

        # Small alteration yields small Hamming distance
        dist = hamming_distance(phash1, phash2)
        assert dist <= 4, f"Expected low Hamming distance for similar data, got {dist}"
    run_test("T14", "Media Dedup 64-Bit Block-Mean Perceptual Hash Verification", test_media_dedup_phash)

    # 15. SYSTEM DOCTOR: Real Probe Execution & Latency Measurement
    def test_system_doctor_real_probes():
        doc = SystemDoctor(test_db)
        probes = doc.run_all_probes()
        assert len(probes) == 6, f"Expected 6 microservice probes, got {len(probes)}"
        
        for p in probes:
            assert "latency_ms" in p, f"Probe {p['service']} missing measured latency_ms"
            assert p["latency_ms"] >= 0.0, f"Latency cannot be negative: {p}"
            assert p["status"] in ("OPERATIONAL", "UNAVAILABLE", "DEGRADED", "HEALTHY", "INFO"), f"Unexpected status: {p}"

        score = doc.calculate_health_score(probes)
        assert 70 <= score <= 100, f"Health score should be nominal, got {score}"
    run_test("T15", "System Doctor Real Probes & Measured Latency", test_system_doctor_real_probes)

    # 16. SECURITY: Recursive Secret & Credential Sanitization
    def test_recursive_sanitization():
        sensitive = {
            "api_key": "sk-123456789",
            "password": "pass",
            "nested": {"token": "secret_tok", "public": "ok"},
            "list": [{"cookie": "session_id=abc"}]
        }
        sanitized = sanitize_recursive(sensitive)
        assert sanitized["api_key"] == "[REDACTED]"
        assert sanitized["password"] == "[REDACTED]"
        assert sanitized["nested"]["token"] == "[REDACTED]"
        assert sanitized["nested"]["public"] == "ok"
        assert sanitized["list"][0]["cookie"] == "[REDACTED]"
    run_test("T16", "Recursive Secret & Credential Sanitization", test_recursive_sanitization)

    # 17. SECURITY: SSRF Outbound Allowlist & Private IP Defense
    def test_ssrf_protection():
        assert validate_outbound_url_for_ssrf("https://api.openai.com/v1/models") is True
        assert validate_outbound_url_for_ssrf("http://api.openai.com") is False
        assert validate_outbound_url_for_ssrf("https://127.0.0.1/admin") is False
        assert validate_outbound_url_for_ssrf("https://169.254.169.254/latest/meta-data") is False
        assert validate_outbound_url_for_ssrf("https://10.0.0.1/internal") is False
    run_test("T17", "SSRF Outbound Allowlist & Private IP Defense", test_ssrf_protection)

    # 18. SECURITY: Remote Authorization
    def test_remote_auth():
        ok_local, code_local = check_remote_authorization(None, "127.0.0.1", "secret123")
        assert ok_local is True and code_local == 200

        ok_remote, code_remote = check_remote_authorization(None, "198.51.100.1", "secret123")
        assert ok_remote is False and code_remote == 403

        ok_auth, code_auth = check_remote_authorization("Bearer secret123", "198.51.100.1", "secret123")
        assert ok_auth is True and code_auth == 200
    run_test("T18", "Remote 403 vs Local Authorization Boundaries", test_remote_auth)

    # 19. SOCIAL: Mandatory Approval Workflow
    def test_social_approval():
        # current security contract: undeclared rights are NEVER PASS -> HUMAN_REVIEW, and only a human (not automation) may approve
        post = create_social_post("YOUTUBE", "Community update video ready", "GENERAL", db_path=test_db)
        assert post["status"] == "PENDING_APPROVAL" and post["preflight"] == "HUMAN_REVIEW", post
        from kora.services.social import SocialPublishError
        for bot in ("autopilot", "auto", "system"):
            try:
                approve_and_publish_post(post["post_id"], db_path=test_db, actor=bot)
                assert False, f"automation ({bot}) approved a HUMAN_REVIEW post"
            except SocialPublishError:
                pass
        # declared, original rights -> PASS, then the mandatory human approval step still applies
        ok = create_social_post("YOUTUBE", "Community update video ready (declared)", "GENERAL", db_path=test_db, asset_meta={"rights": "OWNED", "source": "original"})
        assert ok["preflight"] == "PASS" and ok["status"] == "PENDING_APPROVAL", ok
        res = approve_and_publish_post(ok["post_id"], db_path=test_db)
        assert "APPROVED" in res["status"]
    run_test("T19", "Social Platform Mandatory Approval Workflow", test_social_approval)

    # 20. SUBTITLES: Cue Boundaries & Impossibility Rejection
    def test_subtitle_bounds():
        validate_subtitle_cue(0.0, 5.0, 10.0, "Hello World")
        try:
            validate_subtitle_cue(-1.0, 5.0, 10.0, "Negative start")
            assert False, "Negative start should fail"
        except SubtitleValidationError:
            pass
        try:
            validate_subtitle_cue(5.0, 5.0, 10.0, "End equal start")
            assert False, "End equal start should fail"
        except SubtitleValidationError:
            pass
    run_test("T20", "Subtitle Cue Duration Boundaries & Impossibility Rejection", test_subtitle_bounds)

    # 21. AI FAILOVER: Labeled Local Fallback
    def test_ai_fallback():
        res = query_ai_model("Explain microservice synchronization")
        assert res["ok"] is True
        assert res["provider"] == "local_deterministic_fallback"
        assert "kora-rule-engine" in res["model"]
    run_test("T21", "Truthful AI Failover & Labeled Local Fallback", test_ai_fallback)

    # 22. WORKER: Safe Handler Execution
    def test_worker_execution():
        q = DurableQueue(test_db)
        q.enqueue("math_compute", {"a": 20, "b": 22, "op": "add"}, priority=500)
        worker = SafeWorker(q, "worker-math")
        res = worker.process_one()
        assert res is not None and res["status"] == "COMPLETED"
        assert res["result"]["result"] == 42
    run_test("T22", "Worker Pool Registered Safe Handler Execution", test_worker_execution)

    # ---- KORA PRO additions (T23+): retry/backoff, DLQ, cron, auth, rate-limit, social auto-publish, research, RAG, bridge
    from kora.tests import pro_tests
    pro_tests.register(run_test)
    from kora.tests import gov_tests
    gov_tests.register(run_test)
    from kora.tests import supreme_tests
    supreme_tests.register(run_test)
    from kora.tests import self_evolution_tests
    self_evolution_tests.register(run_test)
    from kora.tests import intel_tests
    intel_tests.register(run_test)
    from kora.tests import evolution3_tests
    evolution3_tests.register(run_test)
    from kora.tests import creator_tests
    creator_tests.register(run_test)
    from kora.tests import v104_tests
    v104_tests.register(run_test)
    from kora.tests import security_tests
    security_tests.register(run_test)
    from kora.tests import freeze_tests
    freeze_tests.register(run_test)

    # canonical coverage for the two unittest-style modules that used to run only standalone
    def _unittest_module(modname):
        import unittest
        suite = unittest.defaultTestLoader.loadTestsFromName(modname)
        assert suite.countTestCases() > 0, "no tests discovered in " + modname
        res = unittest.TextTestRunner(stream=io.StringIO(), verbosity=0).run(suite)
        assert res.wasSuccessful(), [str(f[0]) + ": " + f[1][-300:] for f in res.failures + res.errors]
    run_test("T163", "infinite_core unittest module (canonical runner)", lambda: _unittest_module("kora.tests.infinite_core_tests"))
    run_test("T164", "supreme_runtime unittest module (canonical runner)", lambda: _unittest_module("kora.tests.supreme_runtime_tests"))

    print("=" * 60)
    passed = sum(1 for r in TEST_RESULTS if r["status"] == "PASS")
    total = len(TEST_RESULTS)
    if _ONLY and {r["id"] for r in TEST_RESULTS} != _ONLY:   # a filter that matches nothing / something unknown can never pass
        print(f"  [FAIL] FILTER: requested {sorted(_ONLY)} but ran {sorted(r['id'] for r in TEST_RESULTS)}")
        sys.exit(1)
    print(f"TEST SUITE COMPLETE: {passed}/{total} PASS")
    print("=" * 60)

    if passed != total:
        sys.exit(1)

# GODFATHER META-ARCHITECTURE ADDITION (kept isolated from legacy tests)
def _run_godfather_tests():
    from kora.tests.godfather_tests import run
    run()

if __name__ == "__main__":
    main()
    if _ONLY:
        sys.exit(0)
    try:
        _run_godfather_tests()
        print("  [PASS] GF01: Godfather meta-planning/evolution gates")
    except Exception as exc:
        print(f"  [FAIL] GF01: Godfather meta-planning/evolution gates - {exc}")
        raise
